<?php
App::uses('AppController', 'Controller');
class IncidentTypesController extends AppController {
	public $layout='table';
	public function index() {
		
    }
    public function indexAjax(){
      	
    }
	public function add() { 
		
   
}

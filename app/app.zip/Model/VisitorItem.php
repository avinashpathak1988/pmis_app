<?php
App::uses('AppModel','Model');

class VisitorItem extends AppModel{

   
}
?>
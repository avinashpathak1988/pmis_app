<?php
App::uses('AppModel','Model');

class PrisonerTypeForLockup extends AppModel{

   
}    
<?php
App::uses('AppModel', 'Model');
class PetetionResult extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	
/**
 * Validation rules
 *
 * @var array
 */
	
	
	
}

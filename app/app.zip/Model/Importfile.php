<?php
App::uses('AppModel','Model');

class Importfile extends AppModel{
    
}
 ?>
<?php
App::uses('AppModel', 'Model');
/**
 * IncidentType Model
 *
 */
class IncidentType extends AppModel {
	

}

<?php
App::uses('AppModel', 'Model');
class PrisonerRemark extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	
/**
 * Validation rules
 *
 * @var array
 */
	
	
	
}

<?php
App::uses("AppModel","Model");

class DatabaseBackup extends AppModel{
    public $primaryKey = 'id';
}
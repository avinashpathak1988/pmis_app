<?php
App::uses('AppModel', 'Model');
class Module extends AppModel {
	public $displayField = 'name';
}
<?php
App::uses('AppModel','Model');

class EmploymentType extends AppModel{
   
}
 ?>

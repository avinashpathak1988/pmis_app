<?php
App::uses('AppModel','Model');

class WardType extends AppModel{
  
}
 ?>

<?php
App::uses('AppModel', 'Model');
class Pcap extends AppModel {

}

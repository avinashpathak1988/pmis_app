 <?php
App::uses('AppModel','Model');

class MentalCase extends AppModel{
    
}
 ?>

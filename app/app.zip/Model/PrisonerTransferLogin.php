<?php
App::uses('AppModel', 'Model');
/**
 * PrisonerTransfer Model
 *
 */
class PrisonerTransferLogin extends AppModel {

}

<?php
App::uses('AppModel', 'Model');
class MalnutritionType extends AppModel {
}
<?php
App::uses('AppModel', 'Model');
class StateOfPrisoner extends AppModel {
/**
 * Display field
 *
 * @var string
 */
	//public $displayField = 'name';
/**
 * Validation rules
 *
 * @var array
 */
	
}

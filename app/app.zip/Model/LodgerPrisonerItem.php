<?php
App::uses('AppModel', 'Model');
class LodgerPrisonerItem extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'date';
/**
 * Validation rules
 *
 * @var array
 */
	
    
}

<?php
App::uses('AppModel','Model');

class UgForce extends AppModel{
  
}
 ?>

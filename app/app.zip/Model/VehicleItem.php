<?php
App::uses('AppModel','Model');

class VehicleItem extends AppModel{

    public $belongsTo = array(
        /*'Prisoner' => array(
            'className'     => 'Prisoner',
            'foreignKey'    => 'prisoner_id',
        ),*/
        
    );
}

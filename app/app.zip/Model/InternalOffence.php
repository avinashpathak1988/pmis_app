<?php
App::uses('AppModel', 'Model');
class InternalOffence extends AppModel {
	//public $hasOne = 'EarningGrade';
	

	
}

<?php
App::uses('AppModel', 'Model');
class Tribe extends AppModel {
	public $displayField = 'name';
}
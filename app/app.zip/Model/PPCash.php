<?php
App::uses('AppModel','Model');

class PPCash extends AppModel{

   
}
?>
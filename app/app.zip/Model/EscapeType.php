<?php
App::uses('AppModel','Model');

class EscapeType extends AppModel{
    
}
?>

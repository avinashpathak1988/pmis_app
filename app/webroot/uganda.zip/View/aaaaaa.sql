/*
SQLyog Community v8.6 GA
MySQL - 5.5.58-0ubuntu0.14.04.1 : Database - uganda
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `uganda`;

/*Table structure for table `prisoner_transfers` */

DROP TABLE IF EXISTS `prisoner_transfers`;

CREATE TABLE `prisoner_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` text NOT NULL,
  `prisoner_id` int(11) NOT NULL,
  `transfer_from_station_id` int(11) NOT NULL,
  `transfer_to_station_id` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `escorting_officer` int(11) NOT NULL,
  `reason` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `out_reviewed_by` int(11) NOT NULL,
  `out_approved_by` int(11) NOT NULL,
  `rcv_by` int(11) NOT NULL,
  `rcv_date` date NOT NULL,
  `rejected_by` int(11) NOT NULL,
  `rejected_date` date NOT NULL,
  `in_reviewed_by` int(11) NOT NULL,
  `in_reviewed_date` date NOT NULL,
  `in_approved_by` int(11) NOT NULL,
  `in_approved_date` date NOT NULL,
  `final_save_date` date NOT NULL,
  `final_save_by` int(11) NOT NULL,
  `review_date` date NOT NULL,
  `out_reviewed_date` date NOT NULL,
  `out_approved_date` date NOT NULL,
  `discharge_by` int(11) DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `status` enum('Process','Saved','Reviewed','Approved','Recieved','Draft','Discharge') NOT NULL DEFAULT 'Draft',
  `instatus` enum('Draft','Saved','Reviewed','Review Reject','Approved','Final Reject') NOT NULL DEFAULT 'Draft',
  `is_trash` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `final_remarks` varchar(500) NOT NULL,
  `review_remarks` varchar(500) DEFAULT NULL,
  `discharge_status` enum('Draft','Saved','Reviewed','Review Reject','Approved','Final Reject') NOT NULL DEFAULT 'Draft',
  `discharge_rejected_date` date DEFAULT NULL,
  `discharge_rejected_by` int(11) DEFAULT NULL,
  `discharge_remark` varchar(500) DEFAULT NULL,
  `discharge_reviewed_date` date DEFAULT NULL,
  `discharge_reviewed_by` int(11) DEFAULT NULL,
  `discharge_review_remarks` varchar(500) DEFAULT NULL,
  `discharge_approved_date` date DEFAULT NULL,
  `discharge_approved_remarks` varchar(200) DEFAULT NULL,
  `discharge_approved_by` int(11) DEFAULT NULL,
  `close_status` varchar(200) DEFAULT NULL,
  `discharge_close` varchar(200) DEFAULT NULL,
  `received_remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

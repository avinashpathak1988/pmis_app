<?php
App::uses('AppModel','Model');

class Continent extends AppModel{
    
}
 ?>

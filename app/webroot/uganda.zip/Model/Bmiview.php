<?php
App::uses('AppModel', 'Model');
class Bmiview extends AppModel {

}
  ?>

<?php
App::uses('AppModel', 'Model');
class Country extends AppModel {
	//public $displayField = 'name';
}
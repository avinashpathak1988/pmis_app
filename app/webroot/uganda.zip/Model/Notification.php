<?php
App::uses('AppModel', 'Model');
/**
 * Notification Model
 *
 * @property User $User
 */
class Notification extends AppModel {
	public $belongsTo = array(
		'User' => array(
			'className' 	=> 'User',
			'foreignKey' 	=> 'user_id',
		)
	);
}

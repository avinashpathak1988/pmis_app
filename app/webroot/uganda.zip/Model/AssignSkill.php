<?php
App::uses('AppModel', 'Model');
class AssignSkill extends AppModel {
	
}

<?php
App::uses('AppModel','Model');

class Lopal extends AppModel{
  
}

<?php
App::uses('AppModel','Model');

class WeightUnit extends AppModel{
    
}
 ?>

<?php  
App::uses('AppModel','Model');
/**
 * 
 */
class AreaOfDeployment extends AppModel{
	
    
}
?>
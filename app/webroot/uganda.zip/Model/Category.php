<?php
App::uses('AppModel', 'Model');
class Category extends AppModel {
}
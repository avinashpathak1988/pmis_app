<?php
App::uses('AppModel','Model');

class AfterCareActivity extends AppModel{
    
}
 ?>

<?php
App::uses('AppModel', 'Model');
/**
 * District Model
 *
 */
class Privilege extends AppModel {


}
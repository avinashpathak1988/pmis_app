<?php
App::uses('AppModel','Model');

class Recommendation extends AppModel{
}
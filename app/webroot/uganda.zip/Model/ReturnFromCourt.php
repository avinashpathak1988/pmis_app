<?php
App::uses('AppModel', 'Model');
class ReturnFromCourt extends AppModel {
public $belongsTo = array(
        'CaseType' => array(
            'className'     => 'OffenceCategory',
            'foreignKey' => 'case_type'
        ),
        'Offence' => array(
            'className'     => 'Offence',
            'foreignKey' => 'offence_id'
        ),

    );
}

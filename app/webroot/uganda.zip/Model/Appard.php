<?php
App::uses('AppModel', 'Model');
class Appard extends AppModel {

}
  ?>

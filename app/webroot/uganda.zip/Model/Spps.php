<?php
App::uses('AppModel', 'Model');
class Spps extends AppModel {

}

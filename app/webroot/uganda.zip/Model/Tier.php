<?php
App::uses('AppModel','Model');

class Tier extends AppModel{
    public $validate=array(
        
    );
}
?>
<?php
App::uses('AppController', 'Controller');
class PPCashController extends AppController {
	public $layout='table';
	public function index() {
		$this->loadModel('PPCash'); 
        $this->paginate = array(
            'order'         =>array(
                'PPCash.name'
            ),            
            'limit'         => 20,
            'conditions'    => array(
                'PPCash.is_trash'       => 0,
            ),
        );

        $datas  = $this->paginate('PPCash');

        $this->set(array(
            'datas'=>$datas

        )); 



    }
    public function indexAjax(){
      	$this->loadModel('PPCash'); 


        $this->paginate = array(
            'order'         =>array(
                'PPCash.name'
            ),            
            'limit'         => 20,
        );

        $datas  = $this->paginate('PPCash');

        $this->set(array(
        	'datas'=>$datas

        )); 

    }
    public function add() { 
		$this->loadModel('PPCash');
		if (isset($this->data['PPCash']) && is_array($this->data['PPCash']) && count($this->data['PPCash'])>0){	
            if ($this->PPCash->saveAll($this->data)) {


                $this->Session->write('message_type','success');
                $this->Session->write('message','Save Successfully.');
                $this->redirect(array('action'=>'index'));
            }
		}
        if(isset($this->data['PPCashEdit']['id']) && (int)$this->data['PPCashEdit']['id'] != 0){
            if($this->PPCash->exists($this->data['PPCashEdit']['id'])){
                $this->data = $this->PPCash->findById($this->data['PPCashEdit']['id']);
            }
        }
         if(isset($this->data['PPCashDelete']['id']) && (int)$this->data['PPCashDelete']['id'] != 0){
            
            $this->PPCash->id=$this->data['PPCashDelete']['id'];
            if($this->PPCash->saveField('is_trash',1))
            {
              $this->Session->write('message_type','success');
              $this->Session->write('message','Delete successfully');
              $this->redirect(array('action'=>'index'));

            }

        }
	}
}
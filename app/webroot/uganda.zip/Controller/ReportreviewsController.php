<?php
App::uses('AppController', 'Controller');
class ReportreviewsController extends AppController {
    public $layout='table';
	public $uses = array('Ward');
    public function index(){
	 
    }
     
    public function indexAjax(){
      $this->layout = 'ajax';
      $this->loadModel('Prisoner');
	  ini_set('memory_limit', '-1');
      $condition      = array( 'Prisoner.is_trash'    => 0,);
      $condition      += array( 'Prisoner.is_trash'         => 0,
          'Prisoner.prisoner_type_id'         => Configure::read('CONVICTED'),
          // 'Prisoner.prison_id'        => $this->Auth->user('prison_id'),
          'Prisoner.present_status'        => 1,
          'Prisoner.is_approve'        => 1,
          'Prisoner.transfer_status !='        => 'Approved');
     
     /* if(isset($this->params['named']['prison_id']) && $this->params['named']['prison_id'] != ''){
          $prison_id = $this->params['named']['prison_id'];
          $condition += array('Pcap.prison_id' => $prison_id );
      }
      if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
          $from_date = $this->params['named']['from_date'];
          $fd=explode('-',$from_date);
          $fd=$fd[2].'-'.$fd[1].'-'.$fd[0];
          $condition += array("Pcap.date_of_assign >=" => $fd);
      }
      if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
          $to_date = $this->params['named']['to_date'];
          $td=explode('-',$to_date);
          $td=$td[2].'-'.$td[1].'-'.$td[0];
          $condition += array("Pcap.date_of_assign <=" => $td);
      }*/
      if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
          if($this->params['named']['reqType']=='XLS'){
              $this->layout='export_xls';
              $this->set('file_type','xls');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.xls');
          }else if($this->params['named']['reqType']=='DOC'){
              $this->layout='export_xls';
              $this->set('file_type','doc');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.doc');
          }else if($this->params['named']['reqType']=='PDF'){
              $this->layout='pdf';
              $this->set('file_type','pdf');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.pdf');
          }
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 20);
        } 

		$this->Prisoner->unbindModel(array('belongsTo' => array('Prison','Gender','Country','State','District','Occupation','LevelOfEducation','Lip','Ear',
																'Skill','Religion','Build','Face','Eye','Mouth','Speech','Teeth','Hair','MaritalStatus'),
											'hasMany' => array('PrisonerKinDetail','PrisonerChildDetail','PrisonerSpecialNeed','PrisonerRecaptureDetail',
																'MedicalCheckupRecord','MedicalDeathRecord','MedicalSeriousIllRecord','MedicalSickRecord','StagePromotion','StageDemotion',
																'StageReinstatement','InPrisonOffenceCapture','InPrisonPunishment','Property')));
     $this->paginate = array(
    		'conditions'	=> $condition,
    		'order'			=> array(
    			'Prisoner.modified'	=> 'DESC',
    		),
    	)+$limit;
      $datas = $this->paginate('Prisoner');
	  //debug($datas); exit;
      $this->set(array(
          'datas'          => $datas,
          
      ));
    }
	public function prisonerLocation()
	{
		$ward = $this->Ward->find('list',array('conditions'=>array('Ward.is_trash'=>0),'order'=>array('Ward.name'=>'ASC')));
		$this->set(array('wards'=>$ward));
       
	}
	
	public function prisonerLocationAjax()
	{
		$this->layout = 'ajax';
      $this->loadModel('Prisoner');
	  ini_set('memory_limit', '-1');
      $condition      = array( 'Prisoner.is_trash'		=> 0,);
     
      if(isset($this->params['named']['prisoner_no']) && $this->params['named']['prisoner_no'] != ''){
          $prison_no = $this->params['named']['prisoner_no'];
          $condition += array("Prisoner.prisoner_no LIKE  '%$prison_no%'" );
      }
      if(isset($this->params['named']['ward']) && $this->params['named']['ward'] != ''){
          $ward = $this->params['named']['ward'];
          $condition += array('Prisoner.assigned_ward_id' => $ward);
      }
    
      if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
          if($this->params['named']['reqType']=='XLS'){
              $this->layout='export_xls';
              $this->set('file_type','xls');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.xls');
          }else if($this->params['named']['reqType']=='DOC'){
              $this->layout='export_xls';
              $this->set('file_type','doc');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.doc');
          }else if($this->params['named']['reqType']=='PDF'){
              $this->layout='pdf';
              $this->set('file_type','pdf');
              $this->set('file_name','sentence_review_report'.date('d_m_Y').'.pdf');
          }
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 20);
        } 
		
		/*$this->Prisoner->unbindModel(array('belongsTo' => array('Prison','Gender','Country','State','District','Occupation','LevelOfEducation','Lip','Ear',
																'Skill','Religion','Build','Face','Eye','Mouth','Speech','Teeth','Hair','MaritalStatus'),
											'hasMany' => array('PrisonerIdDetail','PrisonerKinDetail','PrisonerChildDetail','PrisonerSpecialNeed','PrisonerRecaptureDetail','PrisonerSentenceDetail',
																'MedicalCheckupRecord','MedicalDeathRecord','MedicalSeriousIllRecord','MedicalSickRecord','StagePromotion','StageDemotion',
																'StageReinstatement','InPrisonOffenceCapture','InPrisonPunishment','Property','PrisonerSentence')));*/
		

		$this->Prisoner->recursive = -1;
		$this->Prisoner->bindModel(array('belongsTo'=>array('Ward')));	
		$this->paginate = array(
    		'conditions'	=> $condition,
    		'order'			=> array(
    			'Prisoner.modified'	=> 'DESC',
    		),
    	)+$limit;
		  $datas = $this->paginate('Prisoner');
			//debug($datas); exit;
		  $this->set(array(
          'datas'          => $datas,
          
      ));
	}
	public function prisonerStageReport()
	{
		$this->loadModel('Prison');
        $this->loadModel('Gender');
        if($this->Session->read('Auth.User.prison_id')!=''){
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                    'Prison.id'=>$this->Session->read('Auth.User.prison_id'),
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }else{
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }
        
        $this->set(array(
            'prisonList'    => $prisonList,
        ));
	}
	
	public function prisonerStageAjax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Prisoner');
		ini_set('memory_limit', '-1');
		$condition      = array( 'Prisoner.is_trash'=> 0,);

    if($this->Session->read('Auth.User.prison_id')!=''){
        $condition += array('Prisoner.prison_id' => $this->Session->read('Auth.User.prison_id') );
    }else{
        if(isset($this->params['named']['prison_id']) && $this->params['named']['prison_id'] != ''){
            $prison_id = $this->params['named']['prison_id'];
            $condition += array('Prisoner.prison_id' => $prison_id );
        }
    }
    
    if(isset($this->params['named']['prisoner_name']) && $this->params['named']['prisoner_name'] != ''){
        $prisoner_name = $this->params['named']['prisoner_name'];
        $condition += array("Prisoner.first_name like '%".$prisoner_name."%'");
    }
		
		if(isset($this->params['named']['epd_from']) && $this->params['named']['epd_from'] != ''){
          $epd_from = date('Y-m-d',strtotime($this->params['named']['epd_from']));
          $condition += array('Prisoner.epd >= ' => $epd_from );
      }
	  
		if(isset($this->params['named']['epd_to']) && $this->params['named']['epd_to'] != ''){
          $epd_to = date('Y-m-d',strtotime($this->params['named']['epd_to']));
          $condition += array('Prisoner.epd <= ' => $epd_to);
      }

      if(isset($this->params['named']['lpd_from']) && $this->params['named']['lpd_from'] != ''){
          $lpd_from = date('Y-m-d',strtotime($this->params['named']['lpd_from']));
          $condition += array('Prisoner.lpd >= ' => $lpd_from);
      }
	  
	  if(isset($this->params['named']['lpd_to']) && $this->params['named']['lpd_to'] != ''){
          $lpd_to = date('Y-m-d',strtotime($this->params['named']['lpd_to']));
          $condition += array('Prisoner.lpd >= ' => $lpd_to);
      }
    
      if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
          if($this->params['named']['reqType']=='XLS'){
              $this->layout='export_xls';
              $this->set('file_type','xls');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.xls');
          }else if($this->params['named']['reqType']=='DOC'){
              $this->layout='export_xls';
              $this->set('file_type','doc');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.doc');
          }else if($this->params['named']['reqType']=='PDF'){
              $this->layout='pdf';
              $this->set('file_type','pdf');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.pdf');
          }
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 20);
        } 
		
		$this->Prisoner->recursive = -1;
		$this->paginate = array(
    		'conditions'	=> array(
          'Prisoner.is_trash'         => 0,
          'Prisoner.prisoner_type_id'         => Configure::read('CONVICTED'),
          // 'Prisoner.prison_id'        => $this->Auth->user('prison_id'),
          'Prisoner.present_status'        => 1,
          'Prisoner.is_approve'        => 1,
          'Prisoner.transfer_status !='        => 'Approved'
        )+$condition,
    		'order'			=> array(
				'Prisoner.prison_id'	=> 'ASC',
    			'Prisoner.state_id'	=> 'ASC',
				'Prisoner.country_id' => 'ASC',
				'Prisoner.prisoner_type_id' => 'ASC',
				'Prisoner.prisoner_sub_type_id' => 'ASC',
    		),
			
    	)+$limit;
		  $datas = $this->paginate('Prisoner');
		
		  $this->set(array(
          'datas'          => $datas,
          
      ));
     
	}

  public function specialStageReport(){

    $this->loadModel('Prison');
        $this->loadModel('Gender');
        if($this->Session->read('Auth.User.prison_id')!=''){
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                    'Prison.id'=>$this->Session->read('Auth.User.prison_id'),
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }else{
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }
        
        $this->set(array(
            'prisonList'    => $prisonList,
        ));

  }
  // partha report stagePromotionReport
  public function stagePromotionReport() {
    $this->loadModel('Prison');
        $this->loadModel('Gender');
        if($this->Session->read('Auth.User.prison_id')!=''){
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                    'Prison.id'=>$this->Session->read('Auth.User.prison_id'),
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }else{
            $prisonList = $this->Prison->find('list', array(
                'recursive'     => -1,
                'fields'        => array(
                    'Prison.id',
                    'Prison.name',
                ),
                'conditions'    => array(
                    'Prison.is_enable'  => 1,
                    'Prison.is_trash'   => 0,
                ),
                'order'         => array(
                    'Prison.name'       => 'ASC',
                ),
            ));
        }
        
        $this->set(array(
            'prisonList'    => $prisonList,
        ));

  }
  public function stagePromotionAjax() {
     $this->layout = 'ajax';
    $this->loadModel('Prisoner');
    ini_set('memory_limit', '-1');
    $condition      = array( 'Prisoner.is_trash'=> 0);

    if($this->Session->read('Auth.User.prison_id')!=''){
        $condition += array('Prisoner.prison_id' => $this->Session->read('Auth.User.prison_id') );
    }else{
        if(isset($this->params['named']['prison_id']) && $this->params['named']['prison_id'] != ''){
            $prison_id = $this->params['named']['prison_id'];
            $condition += array('Prisoner.prison_id' => $prison_id );
        }
    }
    
    if(isset($this->params['named']['prisoner_name']) && $this->params['named']['prisoner_name'] != ''){
        $prisoner_name = $this->params['named']['prisoner_name'];
        $condition += array("Prisoner.first_name like '%".$prisoner_name."%'");
    }
    if(isset($this->params['named']['prisoner_no']) && $this->params['named']['prisoner_no'] != ''){
        $prisoner_name = $this->params['named']['prisoner_no'];
       // $condition += array("Prisoner.first_name like '%".$prisoner_no."%'");
    }
    
    if(isset($this->params['named']['epd_from']) && $this->params['named']['epd_from'] != ''){
          $epd_from = date('Y-m-d',strtotime($this->params['named']['epd_from']));
          $condition += array('Prisoner.epd >= ' => $epd_from );
      }
    
    if(isset($this->params['named']['epd_to']) && $this->params['named']['epd_to'] != ''){
          $epd_to = date('Y-m-d',strtotime($this->params['named']['epd_to']));
          $condition += array('Prisoner.epd <= ' => $epd_to);
      }

      if(isset($this->params['named']['lpd_from']) && $this->params['named']['lpd_from'] != ''){
          $lpd_from = date('Y-m-d',strtotime($this->params['named']['lpd_from']));
          $condition += array('Prisoner.lpd >= ' => $lpd_from);
      }
    
    if(isset($this->params['named']['lpd_to']) && $this->params['named']['lpd_to'] != ''){
          $lpd_to = date('Y-m-d',strtotime($this->params['named']['lpd_to']));
          $condition += array('Prisoner.lpd >= ' => $lpd_to);
      }
    
      if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
          if($this->params['named']['reqType']=='XLS'){
              $this->layout='export_xls';
              $this->set('file_type','xls');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.xls');
          }else if($this->params['named']['reqType']=='DOC'){
              $this->layout='export_xls';
              $this->set('file_type','doc');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.doc');
          }else if($this->params['named']['reqType']=='PDF'){
              $this->layout='pdf';
              $this->set('file_type','pdf');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.pdf');
          }
      $this->set('is_excel','Y');
      $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 2000,'maxLimit'   => 2000);
        } 
    // $stageCondi = $this->requestAction('/Stages/checkStagePromotion/'.$data['Prisoner']['id'].'/'.Configure::read('STAGE-IV'));
    $this->Prisoner->recursive = -1;
    $this->paginate = array(
        'joins' => array(
            array(
                'table' => 'prisoners',
                'alias' => 'Prisoner',
                'type' => 'inner',
                'conditions'=> array('StageHistory.prisoner_id = Prisoner.id')
            ),
        ), 
        'conditions'  => array(
            'Prisoner.is_trash'         => 0,
            'Prisoner.present_status'        => 1,
            'Prisoner.is_approve'        => 1,
            // 'StageHistory.stage_id'        => Configure::read('STAGE-IV'),
            // 'StageHistory.next_date_of_stage between ? and ? '        => array(date("Y-m-d",strtotime('-15 days')),date('Y-m-d')),
        )+$condition,
        'fields'    => array(
            "Prisoner.id",
            "Prisoner.first_name",
            "Prisoner.middle_name",
            "Prisoner.prisoner_no",
            "Prisoner.doc",
            "Prisoner.epd",
            "Prisoner.lpd",
            "Prisoner.doa",
            "Prisoner.created",
            "Prisoner.sentence_length",
            "max(StageHistory.id) as stage_history_id",
        ),
        "group"     => array(
            "Prisoner.id",
            "Prisoner.first_name",
            "Prisoner.middle_name",
            "Prisoner.doc",
            "Prisoner.epd",
            "Prisoner.lpd",
            "Prisoner.doa",
            "Prisoner.created",
            "Prisoner.sentence_length",
        ),
      )+$limit;
      $datas = $this->paginate('StageHistory');
        // debug($datas);
      $this->set(array(
          'datas'          => $datas,
          
      ));

  
  }

  
public function specialStageAjax(){

    $this->layout = 'ajax';
    $this->loadModel('Prisoner');
    ini_set('memory_limit', '-1');
    $condition      = array( 'Prisoner.is_trash'=> 0);

    if($this->Session->read('Auth.User.prison_id')!=''){
        $condition += array('Prisoner.prison_id' => $this->Session->read('Auth.User.prison_id') );
    }else{
        if(isset($this->params['named']['prison_id']) && $this->params['named']['prison_id'] != ''){
            $prison_id = $this->params['named']['prison_id'];
            $condition += array('Prisoner.prison_id' => $prison_id );
        }
    }
    
    if(isset($this->params['named']['prisoner_name']) && $this->params['named']['prisoner_name'] != ''){
        $prisoner_name = $this->params['named']['prisoner_name'];
        $condition += array("Prisoner.first_name like '%".$prisoner_name."%'");
    }
    
    if(isset($this->params['named']['epd_from']) && $this->params['named']['epd_from'] != ''){
          $epd_from = date('Y-m-d',strtotime($this->params['named']['epd_from']));
          $condition += array('Prisoner.epd >= ' => $epd_from );
      }
    
    if(isset($this->params['named']['epd_to']) && $this->params['named']['epd_to'] != ''){
          $epd_to = date('Y-m-d',strtotime($this->params['named']['epd_to']));
          $condition += array('Prisoner.epd <= ' => $epd_to);
      }

      if(isset($this->params['named']['lpd_from']) && $this->params['named']['lpd_from'] != ''){
          $lpd_from = date('Y-m-d',strtotime($this->params['named']['lpd_from']));
          $condition += array('Prisoner.lpd >= ' => $lpd_from);
      }
    
    if(isset($this->params['named']['lpd_to']) && $this->params['named']['lpd_to'] != ''){
          $lpd_to = date('Y-m-d',strtotime($this->params['named']['lpd_to']));
          $condition += array('Prisoner.lpd >= ' => $lpd_to);
      }
    
      if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
          if($this->params['named']['reqType']=='XLS'){
              $this->layout='export_xls';
              $this->set('file_type','xls');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.xls');
          }else if($this->params['named']['reqType']=='DOC'){
              $this->layout='export_xls';
              $this->set('file_type','doc');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.doc');
          }else if($this->params['named']['reqType']=='PDF'){
              $this->layout='pdf';
              $this->set('file_type','pdf');
              $this->set('file_name','prisoner_stage_report'.date('d_m_Y').'.pdf');
          }
      $this->set('is_excel','Y');
      $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 2000,'maxLimit'   => 2000);
        } 
    // $stageCondi = $this->requestAction('/Stages/checkStagePromotion/'.$data['Prisoner']['id'].'/'.Configure::read('STAGE-IV'));
    $this->Prisoner->recursive = -1;
    $this->paginate = array(
        'joins' => array(
            array(
                'table' => 'prisoners',
                'alias' => 'Prisoner',
                'type' => 'inner',
                'conditions'=> array('StageHistory.prisoner_id = Prisoner.id')
            ),
        ), 
        'conditions'  => array(
            'Prisoner.is_trash'         => 0,
            'Prisoner.present_status'        => 1,
            'Prisoner.is_approve'        => 1,
            'StageHistory.stage_id'        => Configure::read('STAGE-IV'),
            'StageHistory.next_date_of_stage between ? and ? '        => array(date("Y-m-d",strtotime('-15 days')),date('Y-m-d')),
        )+$condition,
        'fields'    => array(
            "Prisoner.id",
            "Prisoner.first_name",
            "Prisoner.middle_name",
            "Prisoner.doc",
            "Prisoner.epd",
            "Prisoner.lpd",
            "Prisoner.doa",
            "Prisoner.created",
            "Prisoner.sentence_length",
            "max(StageHistory.id) as stage_history_id",
        ),
        "group"     => array(
            "Prisoner.id",
            "Prisoner.first_name",
            "Prisoner.middle_name",
            "Prisoner.doc",
            "Prisoner.epd",
            "Prisoner.lpd",
            "Prisoner.doa",
            "Prisoner.created",
            "Prisoner.sentence_length",
        ),
      )+$limit;
      $datas = $this->paginate('StageHistory');
        // debug($datas);
      $this->set(array(
          'datas'          => $datas,
          
      ));

  }

}

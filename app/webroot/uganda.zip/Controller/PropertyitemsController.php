<?php
App::uses('AppController', 'Controller');
class PropertyitemsController extends AppController {
	public $layout='table';
	public function index() {
		$this->loadModel('Propertyitem'); 
        if(isset($this->data['PropertyitemDelete']['id']) && (int)$this->data['PropertyitemDelete']['id'] != 0){
        	if($this->Propertyitem->exists($this->data['PropertyitemDelete']['id'])){
                $db = ConnectionManager::getDataSource('default');
                $db->begin();                  
        		if($this->Propertyitem->updateAll(array('Propertyitem.is_trash'	=> 1), array('Propertyitem.id'	=> $this->data['PropertyitemDelete']['id']))){
                    if($this->auditLog('Propertyitem', 'propertyitem', $this->data['PropertyitemDelete']['id'], 'Trash', json_encode(array('Propertyitem.is_trash' => 1)))){
                        $db->commit();
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Property item Delete Successfully !');
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Property item Delete Failed !');
                    } 
        		}else{
					$this->Session->write('message_type','error');
                    $this->Session->write('message','Property item Delete Failed !');
        		}
        	}else{
				$this->Session->write('message_type','error');
                $this->Session->write('message','Property item Delete Failed !');
        	}
        }
    }
    public function indexAjax(){
      	$this->loadModel('Propertyitem'); 
        $this->layout = 'ajax';
        $name  = '';
        $condition = array('Propertyitem.is_trash'	=> 0);
        if(isset($this->params['named']['name']) && $this->params['named']['name'] != ''){
            $name = $this->params['named']['name'];
            $condition += array("Propertyitem.name LIKE '%$name%'");
        } 
        $this->paginate = array(
            'conditions'    => $condition,
            'order'         =>array(
                'Propertyitem.name'
            ),            
            'limit'         => 20,
        );
        $datas  = $this->paginate('Propertyitem');
        $this->set(array(
            'name'         => $name,
            'datas'             => $datas,
        )); 
    }
	public function add() { 
		$this->loadModel('Propertyitem');
		if (isset($this->data['Propertyitem']) && is_array($this->data['Propertyitem']) && count($this->data['Propertyitem'])>0){	
            $db = ConnectionManager::getDataSource('default');
            $db->begin();          		
			if ($this->Propertyitem->save($this->data)) {
                if(isset($this->data['Propertyitem']['id']) && (int)$this->data['Propertyitem']['id'] != 0){
                    if($this->auditLog('Propertyitem', 'propertyitems', $this->data['Propertyitem']['id'], 'Update', json_encode($this->data))){
                        $db->commit(); 
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Property item Saved Successfully !');
                        $this->redirect(array('action'=>'index'));                      
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Property item Saving Failed !');
                    }
                }else{
                    if($this->auditLog('Propertyitem', 'propertyitems', $this->Propertyitem->id, 'Add', json_encode($this->data))){
                        $db->commit(); 
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Property item Saved Successfully !');
                        $this->redirect(array('action'=>'index'));                      
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Property item Saving Failed !');
                    }
                }
			}else{
				$this->Flash->error(__('The Property item could not be saved. Please, try again.'));
			}
		}
        if(isset($this->data['PropertyitemEdit']['id']) && (int)$this->data['PropertyitemEdit']['id'] != 0){
            if($this->Propertyitem->exists($this->data['PropertyitemEdit']['id'])){
                $this->data = $this->Propertyitem->findById($this->data['PropertyitemEdit']['id']);
            }
        }
	}
}
<?php
App::uses('AppController', 'Controller');
class WardCellsController extends AppController {
	public $layout='table';
	public function index() {
		$this->loadModel('Ward'); 
        $this->loadModel('WardCell');
        if(isset($this->data['WardCellDelete']['id']) && (int)$this->data['WardCellDelete']['id'] != 0){
        	if($this->WardCell->exists($this->data['WardCellDelete']['id'])){
                $db = ConnectionManager::getDataSource('default');
                $db->begin();         		
                if($this->WardCell->updateAll(array('WardCell.is_trash'	=> 1), array('WardCell.id'	=> $this->data['WardCellDelete']['id']))){
                    if($this->auditLog('WardCell', 'ward_cells', $this->data['WardCellDelete']['id'], 'Trash', json_encode(array('WardCell.is_trash' => 1)))){
                        $db->commit();
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Delete Successfully !');
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Delete Failed !');
                    } 
        		}else{
                    $db->rollback();
					$this->Session->write('message_type','error');
                    $this->Session->write('message','Delete Failed !');
        		}
        	}else{
				$this->Session->write('message_type','error');
                $this->Session->write('message','Delete Failed !');
        	}
        }
        $wardList   = $this->Ward->find('list');
        $this->set(array(
            'wardList'         => $wardList,
        ));
    }
    public function indexAjax(){
      	$this->loadModel('Ward'); 
        $this->loadModel('WardCell');
        $this->layout = 'ajax';
        $ward_id  = '';
        $cell_name  = '';
        $condition = array('WardCell.is_trash'	=> 0);
        if(isset($this->params['named']['ward_id']) && (int)$this->params['named']['ward_id'] != 0){
            $ward_id = $this->params['named']['ward_id'];
            $condition += array('WardCell.ward_id' => $ward_id );
        } 
        if(isset($this->params['named']['cell_name']) && $this->params['named']['cell_name'] != ''){
            $cell_name = $this->params['named']['cell_name'];
            $condition += array("WardCell.cell_name LIKE '%$cell_name%'");
        } 
        $this->paginate = array(
            'conditions'    => $condition,
            'order'         =>array(
                'WardCell.cell_name'
            ),            
            'limit'         => 20,
        );
        $datas  = $this->paginate('WardCell');
        $this->set(array(
            'ward_id'          => $ward_id,
            'cell_name'        => $cell_name,
            'datas'             => $datas,
        )); 
    }
	public function add() { 
		$this->loadModel("WardCell"); 
		$this->loadModel('Ward');
		if (isset($this->data['WardCell']) && is_array($this->data['WardCell']) && count($this->data['WardCell'])>0){
    		$db = ConnectionManager::getDataSource('default');
            $db->begin(); 
			if ($this->WardCell->save($this->request->data)) {
                if(isset($this->data['WardCell']['id']) && (int)$this->data['WardCell']['id'] != 0){
                    if($this->auditLog('WardCell', 'ward_cells', $this->data['WardCell']['id'], 'Update', json_encode($this->data))){
                        $db->commit(); 
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Saved Successfully !');
                        $this->redirect(array('action'=>'index'));                      
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Saving Failed !');
                    }
                }else{
                    if($this->auditLog('WardCell', 'ward_cells', $this->WardCell->id, 'Add', json_encode($this->data))){
                        $db->commit(); 
                        $this->Session->write('message_type','success');
                        $this->Session->write('message','Saved Successfully !');
                        $this->redirect(array('action'=>'index'));                      
                    }else{
                        $db->rollback();
                        $this->Session->write('message_type','error');
                        $this->Session->write('message','Saving Failed !');
                    }
                }
			}else{
                $this->Session->write('message_type','error');
                $this->Session->write('message','Saving Failed !');
			}
		}
        if(isset($this->data['WardCellEdit']['id']) && (int)$this->data['WardCellEdit']['id'] != 0){
            if($this->WardCell->exists($this->data['WardCellEdit']['id'])){
                $this->data = $this->WardCell->findById($this->data['WardCellEdit']['id']);
            }
        }		
		$wardList = $this->Ward->find('list', array(
			'recursive'		=> -1,
			'fields'		=> array(
				'Ward.id',
				'Ward.name',
			),
			'conditions'	=> array(
				'Ward.is_trash'	=> 0,
				'Ward.is_enable'	=> 1,
			),			
			'order'			=> array(
				'Ward.name'
			),
		));
		$this->set(array(
			'wardList'		=> $wardList,
		));
	}
}

<?php
App::uses('AppController', 'Controller');
class VisitorsController   extends AppController {
	public $layout='table';
   // public $uses=array('VisitorPrisonerItem');
	public function index() {
		$this->loadModel('Visitor'); 
		//debug($this->data['RecordStaffDelete']['id']);
		//return false;
        if($this->request->is(array('post','put')))
        {
            if(isset($this->request->data['ApprovalProcess']) && count($this->request->data['ApprovalProcess']) > 0)
            {
                $status = 'Verified'; 
                $remark = '';
                
                $items = $this->request->data['ApprovalProcess'];
                //======================================================================
                if(isset($items) && count($items) > 0)
                {
                    $prison_id = $this->Session->read('Auth.User.prison_id');
                    $login_user_id = $this->Session->read('Auth.User.id');
                    $i = 0;
                    $data = array(); $idList = '';
                    $remark = '';
                    $model = "Visitor";
                    foreach($items as $item)
                    {
                        if($idList != '')
                        {
                            $idList .= ',';
                        }
                        $idList .= $item['fid'];
                        $data[$i]['ApprovalProcess'] = $item;
                        $data[$i]['ApprovalProcess']['prison_id'] = $prison_id;
                        $data[$i]['ApprovalProcess']['model_name'] = $model;
                        $data[$i]['ApprovalProcess']['status'] = $status;
                        $data[$i]['ApprovalProcess']['remark'] = $remark;
                        $data[$i]['ApprovalProcess']['user_id'] = $login_user_id;
                        $i++;
                    }
                    if(count($data) > 0)
                    {
                        $fields = array(
                            $model.'.verify_status'    => "'".$status."'",
                        );
                        $conds = array(
                            $model.'.id in ('.$idList.')',
                        );
                        $db = ConnectionManager::getDataSource('default');
                        $db->begin();
                        if($this->ApprovalProcess->saveAll($data))
                        {
                            if($this->auditLog('ApprovalProcess', 'approval_processes', 0, 'Add', json_encode($data)))
                            {
                                if($this->$model->updateAll($fields, $conds))
                                {
                                    //save to cash property transaction incase credit & debit cash 
                                    $db->commit();
                                    $this->Session->write('message_type','success');
                                    $this->Session->write('message','Verified Successfully !');
                                }
                                else 
                                {
                                    $db->rollback();
                                    $this->Session->write('message_type','error');
                                    $this->Session->write('message','saving failed');
                                }
                            }
                            else 
                            {
                                $db->rollback();
                                $this->Session->write('message_type','error');
                                $this->Session->write('message','saving failed');
                            }
                        }
                        else 
                        {
                            $db->rollback();
                            $this->Session->write('message_type','error');
                            $this->Session->write('message','saving failed');
                        }
                    }
                }
                //========================================================================               
                $this->redirect('index');
            }
        }
        if(isset($this->data['VisitorDelete']['id']) && (int)$this->data['VisitorDelete']['id'] != 0){
        	
            $this->Visitor->id=$this->data['VisitorDelete']['id'];
            $db = ConnectionManager::getDataSource('default');
            $db->begin();
            if($this->Visitor->saveField('is_trash',1))
            {
                if($this->auditLog('Visitor', 'visitors', $this->data['VisitorDelete']['id'], 'Delete', json_encode(array('is_trash',1))))
                {
                    $db->commit(); 
                    $this->Session->write('message_type','success');
                    $this->Session->write('message','Deleted Successfully !');
                    $this->redirect(array('action'=>'index'));
                }
                else {
                    $db->rollback();
                    $this->Session->write('message_type','error');
                    $this->Session->write('message','Delete failed');
                }
            }
            else 
            {
                $db->rollback();
                $this->Session->write('message_type','error');
                $this->Session->write('message','Delete failed');
            }
        }
        $prisonList = $this->Prison->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'Prison.id',
                'Prison.name',
            ),
            'conditions'    => array(
                'Prison.is_trash'   => 0,
                'Prison.is_enable'  => 1,
                "Prison.id IN (".$this->Session->read('Auth.User.prison_id').")"
            ),
            'order'         => array(
                'Prison.name'
            ),
        ));
        $allowUpdate = false;
        if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
            $allowUpdate = true;
        }elseif ($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')) {
            $gatekeeperData = $this->User->find('count', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                    'User.is_enable'      => 1,
                    "prison_id REGEXP CONCAT('(^|,)(', REPLACE(".$this->Session->read('Auth.User.prison_id').", ',', '|'), ')(,|$)')",
                ),
            ));
            if($gatekeeperData == 0){
                $allowUpdate = true;
            }
        }else{
            $allowUpdate = false;
        }
        
        $this->set(array(
            'prisonList'         => $prisonList,
            'allowUpdate'        => $allowUpdate,

            //'gatekeeperData'     => $gatekeeperData
        )); 
    }
   public function returnVisitorItem(){
        $this->layout = 'ajax';
        $this->loadModel('VisitorItem');
        $visitor = $this->Visitor->find('first', array(
            //'recursive'     => -1,
            'conditions'    => array(
                'Visitor.id'      => $this->data['ReturnVIsitorItem']['visitor_id']
            ),
        ));
        $collected = 0;
         foreach ($this->data['ReturnVisitorItem'] as $returnItem) {
            if(isset($returnItem['recieved_item_check'])){
                if($returnItem['recieved_item_check'] == 'on'){
                $visitorItemId = $returnItem['id'];

                $visitorItem = $this->VisitorItem->findById($visitorItemId);
                //debug($visitorPrisonerItem);exit;
                    if($visitorItem['VisitorItem']['is_collected'] == false){

                        $collected += 1;
                        $visitorItem['VisitorItem']['is_collected']=1;
                        $this->VisitorItem->saveAll($visitorItem);
                    }
                } // recieved item check end
            }
            
        }
                    echo "success";

                    $this->Session->write('message_type','success');
                    $this->Session->write('message',$collected . 'items Returned.');

        exit;
    }
    public function recieveItemCash(){
        $this->layout = 'ajax';
        $this->loadModel('CashItem');
        $this->loadModel('Prisoner'); 
        $this->loadModel('VisitorPrisonerItem'); 
        $this->loadModel('PhysicalProperty');
        $this->loadModel('PhysicalPropertyItem');
        $this->loadModel('VisitorPrisonerCashItem');

        $visitor = $this->Visitor->find('first', array(
            //'recursive'     => -1,
            'conditions'    => array(
                'Visitor.id'      => $this->data['RecieveItemCash']['visitor_id']
            ),
        ));
       //debug($this->data['RecievePrisonerItem']);exit;

        $prisoner = $this->Prisoner->find('first', array(
            //'recursive'     => -1,
            'conditions'    => array(
                'Prisoner.prisoner_no'      => $this->data['RecieveItemCash']['prisoner_no']
            ),
        ));
        /*aakash recieve prisoner item*/

        $physicalProperty=array();
        $notifyUser = $this->User->find('first',array(
                                            'recursive'     => -1,
                                            'conditions'    => array(
                                                'User.usertype_id'    => Configure::read('RECEPTIONIST_USERTYPE'),
                                                'User.is_trash'     => 0,
                                                'User.is_enable'     => 1,
                                                'User.prison_id'  => $this->Session->read('Auth.User.prison_id')
                                            )
                                        ));
            
        foreach ($this->data['RecievePrisonerItem'] as $recievedItem) {
            if(isset($recievedItem['recieved_item_check'])){
                if($recievedItem['recieved_item_check'] == 'on'){
                $visitorPrisonerPropertyId = $recievedItem['id'];

                $visitorPrisonerItem = $this->VisitorPrisonerItem->find('first', array(
                        'conditions'    => array(
                            'VisitorPrisonerItem.id'      => $visitorPrisonerPropertyId
                        ),
                ));
                //debug($visitorPrisonerItem);exit;
                if($visitorPrisonerItem['VisitorPrisonerItem']['is_collected'] == false){

                        $physicalPropertyNew =array();
                        $physicalPropertyNew['PhysicalProperty']['property_date_time']=date('Y-m-d H:i:s');
                        $physicalPropertyNew['PhysicalProperty']['login_user_id']=$notifyUser['User']['id'];
                        $physicalPropertyNew['PhysicalProperty']['description']=$visitor['Visitor']['category'];
                        $physicalPropertyNew['PhysicalProperty']['visitor_id']=$visitor['Visitor']['id'];
                        $physicalPropertyNew['PhysicalProperty']['source']='Visitor';
                        $physicalPropertyNew['PhysicalProperty']['prisoner_id']=$prisoner['Prisoner']['id'];
                        $physicalPropertyNew['PhysicalProperty']['property_type']='Physical Property';
                        $this->PhysicalProperty->saveAll($physicalPropertyNew['PhysicalProperty']);
                    

                    $physicalPropertyItem['PhysicalPropertyItem']['physicalproperty_id']=$this->PhysicalProperty->id;
                    $physicalPropertyItem['PhysicalPropertyItem']['item_id']=$visitorPrisonerItem['VisitorPrisonerItem']['item_type'];
                    $physicalPropertyItem['PhysicalPropertyItem']['quantity']=$visitorPrisonerItem['VisitorPrisonerItem']['quantity'];
                    $physicalPropertyItem['PhysicalPropertyItem']['property_type']='In Store';
                    $physicalPropertyItem['PhysicalPropertyItem']['status']='Draft';
                    $physicalPropertyItem['PhysicalPropertyItem']['item_status']='Incoming';
                    $physicalPropertyItem['PhysicalPropertyItem']['bag_no']=0;
                    if($this->PhysicalPropertyItem->saveAll($physicalPropertyItem['PhysicalPropertyItem'])){
                        $visitorPrisonerItem['VisitorPrisonerItem']['is_collected']=1;
                        $this->VisitorPrisonerItem->saveAll($visitorPrisonerItem['VisitorPrisonerItem']);
                        
                        $this->addNotification(array("user_id"=>$notifyUser['User']['id'],"content"=>"Visitor Physical Property recieved by Gatekeeper","url_link"=>"properties/physicalPropertyList"));
                    }

                }
            } // recieved item check end
            }
            
        }
        /*aakash recieve prisoner item ends*/
        //Recieve cash
            foreach ($this->data['RecievePrisonerCashItem'] as $recievedItem) {
            if(isset($recievedItem['recieved_item_check'])){
                if($recievedItem['recieved_item_check'] == 'on'){
                $visitorPrisonerCashId = $recievedItem['id'];

                $visitorPrisonerItem = $this->VisitorPrisonerCashItem->find('first', array(
                        'conditions'    => array(
                            'VisitorPrisonerCashItem.id'      => $visitorPrisonerCashId
                        ),
                ));
                //debug($visitorPrisonerItem);exit;
                if($visitorPrisonerItem['VisitorPrisonerCashItem']['is_collected'] == false){

                        $physicalPropertyNew =array();
                        $physicalPropertyNew['PhysicalProperty']['property_date_time']=date('Y-m-d H:i:s');
                        $physicalPropertyNew['PhysicalProperty']['login_user_id']=$notifyUser['User']['id'];
                        $physicalPropertyNew['PhysicalProperty']['description']=$visitor['Visitor']['category'];
                        $physicalPropertyNew['PhysicalProperty']['visitor_id']=$visitor['Visitor']['id'];
                        $physicalPropertyNew['PhysicalProperty']['source']='Visitor';
                        $physicalPropertyNew['PhysicalProperty']['prisoner_id']=$prisoner['Prisoner']['id'];
                        $physicalPropertyNew['PhysicalProperty']['property_type']='Cash';
                        ;
                    if($this->PhysicalProperty->saveAll($physicalPropertyNew['PhysicalProperty'])){
                                    $cashItem['CashItem']['physicalproperty_id']=$this->PhysicalProperty->id;
                                    $cashItem['CashItem']['amount']=$visitorPrisonerItem['VisitorPrisonerCashItem']['pp_amount'];
                                    $cashItem['CashItem']['currency_id']=$visitorPrisonerItem['VisitorPrisonerCashItem']['pp_cash'];
                                    $cashItem['CashItem']['status']='Draft';

                                    if($this->CashItem->save($cashItem)){
                                        $visitorPrisonerItem['VisitorPrisonerCashItem']['is_collected']=1;
                                        $this->VisitorPrisonerCashItem->save($visitorPrisonerItem);
                                        
                                        $this->addNotification(array("user_id"=>$notifyUser['User']['id'],"content"=>"Visitor cash recieved by Gatekeeper","url_link"=>"properties/creditList"));
                                        echo "success";
                                    }else{
                                        echo 'failed';
                                    }

                                }

                    

                }
            } // recieved item check end
            }
            
        }
        //REcieve CAsh ends
       

        //debug($prisoner);
        exit;
    }

    public function receipt($id){
        $visitor = $this->Visitor->find('first', array(
            'recursive'     => 2,
            'conditions'    => array(
                'Visitor.id'      => $id
            ),
        ));
        if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            if($this->params['named']['reqType']=='PRINT'){
              
                $this->layout='print';
            }
            
        }
         $this->set(array(
            'visitor'         => $visitor,

            //'gatekeeperData'     => $gatekeeperData
        )); 
    }

     public function getVisitorItem(){
        $this->layout = 'ajax';
        $this->loadModel('VisitorPrisonerItem'); 
        $this->loadModel('Visitor'); 
        $this->loadModel('Propertyitem'); 
        $this->loadModel('VisitorPrisonerCashItem'); 

        


        $visitorId = $this->data['visitorId'];

        $visitor = $this->Visitor->find('first', array(
            'recursive'     => 2,
            'conditions'    => array(
                'Visitor.id'      => $visitorId
            ),
        ));


        //debug($visitor);

        $data ='';
        $data .= '<div><h5>Visitor Details</h5></div>';
        $data .= '<table class="table table-bordered table-striped table-responsive"><tbody>';
        $data .=  '<tr><td>Category</td><td> ' . $visitor['Visitor']['category'].'</td></tr>';
        $data .=  '<tr><td>Sub Category</td><td> ' . $visitor['Visitor']['subcategory'].'</td></tr>';
        $data .=  '<tr><td>Other Category (if any)</td><td> ' . $visitor['Visitor']['others_category'].'</td></tr>';
        $data .=  '<tr><td>Name</td><td> ' . $visitor['Visitor']['name'].'</td></tr>';
        $data .=  '<tr><td>Gate Keeper</td><td> ' . $visitor['Visitor']['gate_keeper'].'</td></tr>';
        $data .=  '<tr><td>Contact</td><td> ' . $visitor['Visitor']['contact_no'].'</td></tr>';
        $data .=  '<tr><td>Main Gate in time</td><td> ' . $visitor['Visitor']['main_gate_in_time'].'</td></tr>';
        


        $data .= '</tbody></table>';

        $count =0;
        $allCollected ='true';
        $data .= '<div><h5>Visitor Items</h5></div>';
        $data .= '<table class="table table-bordered table-striped table-responsive"><thead><tr><th>Item Name</th><th>Quantity</th><th>Collected</th></tr></thead><tbody>';

        foreach ($visitor['VisitorItem'] as $visitorItemDetail) {
                        
                        //debug($propertyItemList);
                       
                        $data .= '<tr>';

                        $data .= '<td>';
                        $data .= '<input type="hidden" name="data[ReturnVisitorItem]['.$count .'][id] " value="'. $visitorItemDetail['id'] .'">';
                        $data .= $visitorItemDetail['item'].'</td>';

                        $data .= '<td>'. $visitorItemDetail['quantity'] .'</td>';
                        if($visitorItemDetail['is_collected'] == true){

                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[ReturnVisitorItem]['.$count.'][recieved_item_check]" checked="checked"> <span style="color:green">Already Returned</span></td>';
                        }else{
                            $allCollected ='false';
                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[ReturnVisitorItem]['.$count.'][recieved_item_check]" ><span style="color:red">Not yet Returned </span></td>';
                        }
                        $data .='</tr>';
                        $count++;
                    }
                        $data .= '</tbody></table>';

        $data .= '<div style="display:none;" id="allCollectedResponse">'.$allCollected.'</div>';
        echo $data;
        exit; 
    }
    public function getVisitorRow(){
        $this->layout = 'ajax';
        $this->loadModel('VisitorPrisonerItem'); 
        $this->loadModel('Visitor'); 
        $this->loadModel('Propertyitem'); 
        $this->loadModel('VisitorPrisonerCashItem'); 

        


        $visitorId = $this->data['visitorId'];

        $visitor = $this->Visitor->find('first', array(
            'recursive'     => 2,
            'conditions'    => array(
                'Visitor.id'      => $visitorId
            ),
        ));
          $propertyItemList = $this->Propertyitem->find('all',array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Propertyitem.is_enable'    => 1,
                    'Propertyitem.is_trash'     => 0,
                    'Propertyitem.is_prohibited'     => 0,

                )
            ));
        
        $data ='';
        $count =0;
        $allCollected ='true';
        $data .= '<div><h5>Prisoner Property Items</h5></div>';
        $data .= '<table class="table table-bordered table-striped table-responsive"><thead><tr><th>Item Name</th><th>Quantity</th><th>Collected</th></tr></thead><tbody>';

        foreach ($visitor['VisitorPrisonerItem'] as $prisonerItemDetail) {
                        $itemTypeId = $prisonerItemDetail['item_type'];
                        $propertyItemName='';
                        //debug($propertyItemList);
                        foreach ($propertyItemList as $propertyItem) {
                          //debug($propertyItem);
                            if($propertyItem['Propertyitem']['id'] ==$itemTypeId ){
                                $propertyItemName = $propertyItem['Propertyitem']['name'];
                            }
                        }
                        $data .= '<tr>';

                        $data .= '<td>';
                        $data .= '<input type="hidden" name="data[RecievePrisonerItem]['.$count .'][id] " value="'. $prisonerItemDetail['id'] .'">';
                        $data .= $propertyItemName .'</td>';

                        $data .= '<td>'. $prisonerItemDetail['quantity'] .'</td>';
                        if($prisonerItemDetail['is_collected'] == true){

                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[RecievePrisonerItem]['.$count.'][recieved_item_check]" checked="checked"> <span style="color:green">Already Recieved</span></td>';
                        }else{
                            $allCollected ='false';
                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[RecievePrisonerItem]['.$count.'][recieved_item_check]" ><span style="color:red">Not yet Received </span></td>';
                        }
                        $data .='</tr>';
                        $count++;
                    }
                        $data .= '</tbody></table>';

        $data .= '<div><h5>Prisoner Cash Items</h5></div>';
        $data .= '<table class="table table-bordered table-striped table-responsive"><thead><tr><th>Amount</th><th>Currency</th>Collected<th></th></tr></thead><tbody>';

        foreach ($visitor['VisitorPrisonerCashItem'] as $prisonerItemDetail) {
                        
                        $data .= '<tr>';

                        $data .= '<td><input type="hidden" name="data[RecievePrisonerCashItem]['.$count .'][id] " value="'. $prisonerItemDetail['id'] .'">';
                        $data .= $prisonerItemDetail['pp_amount'] .'</td>';

                        $data .= '<td>'. $prisonerItemDetail['CashCurrency']['name'] .'</td>';
                        if($prisonerItemDetail['is_collected'] == true){

                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[RecievePrisonerCashItem]['.$count.'][recieved_item_check]" checked="checked"> <span style="color:green">Already Recieved</span></td>';
                        }else{
                            $allCollected ='false';
                            $data .='<td><input type="checkbox" style="margin-left:2px;" name="data[RecievePrisonerCashItem]['.$count.'][recieved_item_check]" ><span style="color:red">Not yet Received </span></td>';
                        }
                        $data .='</tr>';

                        $count++;
                    }         
                        $data .= '</tbody></table>';

        $data .= '<div style="display:none;" id="allCollectedResponse">'.$allCollected.'</div>';
        echo $data;
        exit; 
    }
    public function indexAjax(){
      	$this->loadModel('Visitor'); 
        $this->layout = 'ajax';
        $searchData = $this->params['named'];
        $condition = array('Visitor.is_trash'   => 0);
        if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
            $condition += array("Visitor.prison_id IN (".$this->Session->read('Auth.User.prison_id').")");
        }else{
            $condition += array("Visitor.prison_id" => $this->Session->read('Auth.User.prison_id'));
        }
        
        
        if(isset($this->params['named']['from']) && $this->params['named']['from'] != '' &&
         isset($this->params['named']['to']) && $this->params['named']['to'] != ''){
            $from = $this->params['named']['from'];
            $to = $this->params['named']['to'];

            $condition += array(
                // 'Visitor.date >= ' => date('Y-m-d', strtotime($from)),
                // 'Visitor.date <= ' => date('Y-m-d', strtotime($to))
            );        
        }

        if(isset($this->params['named']['verify_status']) && $this->params['named']['verify_status'] != ''){
            $verify_status = $this->params['named']['verify_status'];

            $condition += array('Visitor.verify_status' => $verify_status);        
        }

        if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            if($this->params['named']['reqType']=='XLS'){
                $this->layout='export_xls';
                $this->set('file_type','xls');
                $this->set('file_name','visiter_report_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->layout='export_xls';
                $this->set('file_type','doc');
                $this->set('file_name','visitor_report_'.date('d_m_Y').'.doc');
            }elseif($this->params['named']['reqType']=='PDF'){
                $this->layout='pdf';
                $this->set('file_type','pdf');
                $this->set('file_name','visitor_report_'.date('d_m_Y').'.pdf');
            }else if($this->params['named']['reqType']=='PRINT'){
                $this->layout='print';
            }
            $this->set('is_excel','Y');         
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 20);
        }
        $this->loadModel('Propertyitem'); 
        
        /*aakash*/
          $propertyItemList = $this->Propertyitem->find('all',array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Propertyitem.is_enable'    => 1,
                    'Propertyitem.is_trash'     => 0,
                    'Propertyitem.is_prohibited'     => 0,

                )
            ));
          /*end aakash code*/
        $this->paginate = array(
            'conditions'    => $condition,
            'order'         =>array(
                'Visitor.created' => 'DESC'
            ),
        )+$limit;

        $datas  = $this->paginate('Visitor');
        //debug($datas);
        $allowUpdate =$this->hasMainGate($this->Session->read('Auth.User.prison_id'));

        $this->set(array(
            'searchData'         => $searchData,
            'datas'        => $datas,
            'propertyItemList'  => $propertyItemList,
            'allowUpdate' => $allowUpdate
        )); 

    }

    public function view($prison_id = ''){
        $visitorList = $this->Visitor->find('all', array(
            'recursive'     => 2,
            'conditions'    => array(
                //'Visitor.is_enable'      => 1,
                'Visitor.is_trash'       => 0,
                'Visitor.id'      => $prison_id
            ),
            'order'         => array(
                'Visitor.prisoner_no'
            ),
        ));
        $this->loadModel('Propertyitem'); 

        $propertyItemList = $this->Propertyitem->find('all',array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Propertyitem.is_enable'    => 1,
                    'Propertyitem.is_trash'     => 0,
                    'Propertyitem.is_prohibited'     => 0,

                )
            ));
        $this->set(array(
            'visitorList'         => $visitorList,
            'propertyItemList'=>$propertyItemList
        )); 

    }

	public function add() { 
       

        $this->loadModel('Visitor');
        $this->loadModel('PPCash');
        $this->loadModel('Article');
        $this->loadModel('Relationship');
        $this->loadModel('PrisonerKinDetail');
        $this->loadModel('Iddetail');
        $this->loadModel('Propertyitem');
        $this->loadModel('VisitorPrisonerItem');
        $this->loadModel('VisitorPrisonerCashItem');
        $this->loadModel('WeightUnit');

        

        
        ///$this->data['VisitorPrisonerItem'][0]['item']=90;
         // /unset($this->data['VisitorPrisonerItem']);


         //debug($visitor);
         //debug($this->data);

         //exit;

        if (isset($this->data['Visitor']) && is_array($this->data['Visitor']) && count($this->data['Visitor'])>0){          
            $db = ConnectionManager::getDataSource('default');
            $db->begin();
            if(isset($this->data['Visitor']['date']) && $this->data['Visitor']['date'] !=''){
                $this->request->data['Visitor']['date'] = date('Y-m-d',strtotime($this->data['Visitor']['date']));
            }
            // if(isset($this->data['Visitor']['time_in']) && $this->data['Visitor']['time_in'] !=''){
            //     $this->request->data['Visitor']['time_in'] = $this->data['Visitor']['time_in'];
            // }else{
            //     $this->request->data['Visitor']['time_in'] = date("h:i A");
            // }
            if(isset($this->data['Visitor']['prison_id']) && $this->data['Visitor']['prison_id'] !=''){
                $this->request->data['Visitor']['prison_id'] = $this->data['Visitor']['prison_id'];
            }else{
                $this->request->data['Visitor']['prison_id']=$this->Session->read('Auth.User.prison_id');
            }
            if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
                $this->request->data['Visitor']['main_gate_in_time'] = date('h:i A');
            }
            if($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')){
                $this->request->data['Visitor']['time_in'] = date('h:i A');
                $this->request->data['Visitor']['status'] = 'Gate IN';
            }
            // debug($this->request->data);exit;
            $visitor= array();
            $visitor['Visitor'] = $this->data['Visitor'];
            $visitor['VisitorName'] = $this->data['VisitorName'];
            $visitor['VisitorItem'] = $this->data['VisitorItem'];

            $visitor['Visitor']['date'] = date('Y-m-d', strtotime($this->data['Visitor']['date']));
            if ($this->Visitor->saveAll($visitor)) {
                /*aakash code to add visitor prisoner item*/
                if (isset($this->data['VisitorPrisonerItem']) && is_array($this->data['VisitorPrisonerItem']) && count($this->data['VisitorPrisonerItem'])>0){ 

                        $this->loadModel('Prisoner'); 

                                $prisonerToVisit = $this->Prisoner->find('first', array(
                                    //'recursive'     => -1,
                                    'conditions'    => array(
                                        'Prisoner.prisoner_no'      => $this->data['Visitor']['prisoner_no']
                                    ),
                                ));
                        $alreadyExistingItems = $this->VisitorPrisonerItem->find('all',array(
                                'recursive'     => -1,
                                'conditions'    => array(
                                    'VisitorPrisonerItem.visitor_id'    => $this->Visitor->id,

                                )
                        ));
                        if(count($alreadyExistingItems) > 0){

                        $fields = array(
                            'VisitorPrisonerItem.is_trash'    => 1,
                        );

                        $conds = array(
                            'VisitorPrisonerItem.visitor_id'    => $this->Visitor->id,
                        );  
                        $this->VisitorPrisonerItem->updateAll($fields, $conds);
                        }

                        
                        foreach ($this->data['VisitorPrisonerItem'] as $prisonerItem) {
                            //debug($prisonerItem);
                         
                            

                            $visitorPrisonerItem=array();
                            $visitorPrisonerItem['VisitorPrisonerItem']['item_type'] =$prisonerItem['item_type'];
                            $visitorPrisonerItem['VisitorPrisonerItem']['quantity'] =$prisonerItem['quantity'];
                            $visitorPrisonerItem['VisitorPrisonerItem']['prisoner_id'] =$prisonerToVisit['Prisoner']['id'];
                            $visitorPrisonerItem['VisitorPrisonerItem']['visitor_id'] =$this->Visitor->id;
                            $this->VisitorPrisonerItem->saveAll($visitorPrisonerItem['VisitorPrisonerItem']);

                        }
                    }
                    /*aakash code to add visitor prisoner item ends*/
                    //add prisoner cash
                    if (isset($this->data['VisitorPrisonerCashItem']) && is_array($this->data['VisitorPrisonerCashItem']) && count($this->data['VisitorPrisonerCashItem'])>0){ 

                        $this->loadModel('Prisoner'); 

                                $prisonerToVisit = $this->Prisoner->find('first', array(
                                    //'recursive'     => -1,
                                    'conditions'    => array(
                                        'Prisoner.prisoner_no'      => $this->data['Visitor']['prisoner_no']
                                    ),
                                ));
                        $alreadyExistingItems = $this->VisitorPrisonerCashItem->find('all',array(
                                'recursive'     => -1,
                                'conditions'    => array(
                                    'VisitorPrisonerCashItem.visitor_id'    => $this->Visitor->id,

                                )
                        ));
                        if(count($alreadyExistingItems) > 0){

                        $fields = array(
                            'VisitorPrisonerCashItem.is_trash'    => 1,
                        );

                        $conds = array(
                            'VisitorPrisonerCashItem.visitor_id'    => $this->Visitor->id,
                        );  
                        $this->VisitorPrisonerItem->updateAll($fields, $conds);
                        }

                        
                        foreach ($this->data['VisitorPrisonerCashItem'] as $prisonerItem) {
                            //debug($prisonerItem);
                         
                            
                            $visitorPrisonerItem=array();
                            $visitorPrisonerItem['VisitorPrisonerCashItem']['cash_details'] =$prisonerItem['cash_details'];
                            $visitorPrisonerItem['VisitorPrisonerCashItem']['pp_cash'] =$prisonerItem['pp_cash'];
                            $visitorPrisonerItem['VisitorPrisonerCashItem']['pp_amount'] =$prisonerItem['pp_amount'];
                            $visitorPrisonerItem['VisitorPrisonerCashItem']['visitor_id'] =$this->Visitor->id;
                            $this->VisitorPrisonerCashItem->saveAll($visitorPrisonerItem['VisitorPrisonerCashItem']);

                        }
                    }
                     //add cash ends  

                    //check if main gatekeeper not there
                    $allowUpdate = false;
                   
                    $allowUpdate =$this->checkMainGatekeeperExits();
                    //check main gatekeeper ends
                    if(!$allowUpdate){
                        //save Now to property
                        $this->recieveMainItemCash($this->Visitor->id);
                    }
                if($this->request->data['Visitor']['id'] == ''){
                    if($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')){
                        $refId = 0;
                        $action = 'Add';
                        //$user1 = Configure::read('GATEKEEPER_USERTYPE');
                        $user2 = Configure::read('RECEPTIONIST_USERTYPE');
                        $userData = $this->User->find("list", array(
                            "recursive"    => -1,
                            "conditions" => array(
                                "User.usertype_id IN (".$user2.")",
                                "User.id NOT IN('".$this->Session->read('Auth.User.id')."')",
                                "User.prison_id" => $this->Session->read('Auth.User.prison_id'),
                                ),
                            ));
                        //debug($userData);exit;
                        if(isset($userData) && $userData!=''){
                            foreach ($userData as $key => $value) {
                                $this->addNotification(array(
                                    "user_id"=>$key,
                                    "content"=>"Visitor Added Successfully",
                                    "url_link"=>"visitors"));
                                }
                            }
                        }
                     if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
                         $refId = 0;
                        $action = 'Add';
                        $user1 = Configure::read('GATEKEEPER_USERTYPE');
                        $user2 = Configure::read('RECEPTIONIST_USERTYPE');
                        $userData = $this->User->find("list", array(
                            "recursive"    => -1,
                            "conditions" => array(
                                "User.prison_id" => $this->request->data['Visitor']['prison_id'],
                                "User.usertype_id IN (".$user1.",".$user2.")",
                                ),
                            ));
                        //debug($userData);exit;
                        if(isset($userData) && is_array($userData) && count($userData)>0){
                            $this->addManyNotification($userData,"Visitor Added Successfully","visitors");
                            }
                         }
                }
                if(isset($this->data['Visitor']['id']) && (int)$this->data['Visitor']['id'] != 0)
                {
                    $refId  = $this->data['Visitor']['id'];
                    $action = 'Edit';
                }
                if($this->auditLog('Visitor', 'visitors', $refId, $action, json_encode($this->data)))
                {
                    $db->commit(); 
                    $this->Session->write('message_type','success');
                    $this->Session->write('message','The record has been saved.');
                    $this->redirect(array('action'=>'index'));
                }
                else 
                {
                    $db->rollback();
                    $this->Session->write('message_type','error');
                    $this->Session->write('message','The record could not be saved. Please, try again.');
                }
            } else {
                $db->rollback();
                $this->Session->write('message_type','error');
                $this->Session->write('message','The record could not be saved. Please, try again.');
            }
        }
        if(isset($this->data['VisitorEdit']['id']) && (int)$this->data['VisitorEdit']['id'] != 0){
            if($this->Visitor->exists($this->data['VisitorEdit']['id'])){
                $this->data = $this->Visitor->findById($this->data['VisitorEdit']['id']);
            }
        }
       //get prisoner list
          $prison_id = $_SESSION['Auth']['User']['prison_id'];
          $prisonerList = $this->Prisoner->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'Prisoner.id',
                'Prisoner.prisoner_no',
            ),
            'conditions'    => array(
                'Prisoner.is_enable'      => 1,
                'Prisoner.is_trash'       => 0,
                'Prisoner.prison_id'      => $prison_id
            ),
            'order'         => array(
                'Prisoner.prisoner_no'
            ),
        ));
          $prisonernameList = $this->Prisoner->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'Prisoner.id',
                'Prisoner.fullname',
            ),
            'conditions'    => array(
                'Prisoner.is_enable'      => 1,
                'Prisoner.is_trash'       => 0,
                'Prisoner.prison_id'      => $prison_id
            ),
            'order'         => array(
                'Prisoner.fullname'
            ),
        ));
          $gateKeepers = $this->User->find('list',array(
                'fields'        => array(
                    'User.id',
                    'User.first_name',
                ),
                'conditions'=>array(
                  'User.is_enable'=>1,
                  'User.is_trash'=>0,
                  'User.usertype_id'=>10,//Gate keeper User
                ),
                'order'=>array(
                  'User.first_name'
                )
          ));
          $ppcash = $this->PPCash->find('list',array(
                'fields'        => array(
                    'PPCash.id',
                    'PPCash.name',
                ),
                'conditions'=>array(
                  'PPCash.is_enable'=>1,
                  'PPCash.is_trash'=>0,
                ),
                'order'=>array(
                  'PPCash.name'
                )
          ));
          $weight_units = $this->WeightUnit->find('list',array(
                'fields'        => array(
                    'WeightUnit.id',
                    'WeightUnit.name',
                ),
                'conditions'=>array(
                  'WeightUnit.is_enable'=>1,
                  'WeightUnit.is_trash'=>0,
                ),
                'order'=>array(
                  'WeightUnit.name'
                )
          ));
          $relation = $this->Relationship->find('list',array(
                'fields'        => array(
                    'Relationship.id',
                    'Relationship.name',
                ),
                'conditions'=>array(
                  'Relationship.is_enable'=>1,
                  'Relationship.is_trash'=>0,
                ),
                'order'=>array(
                  'Relationship.name'
                )
          ));
          //debug($_SESSION);
          $prison_id = $_SESSION['Auth']['User']['prison_id'];
          $prisonList = $this->Prison->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'Prison.id',
                'Prison.name',
            ),
            'conditions'    => array(
                'Prison.is_trash'   => 0,
                'Prison.is_enable'  => 1,
                "Prison.id IN (".$prison_id.")" 
            ),
            'order'         => array(
                'Prison.name'
            ),
        ));
          $prionerKinLIst = $this->PrisonerKinDetail->find('all', array(
            'recursive'     => -1,
            'fields'        => array(
                'PrisonerKinDetail.first_name',
                'PrisonerKinDetail.middle_name',
                'PrisonerKinDetail.last_name',
                'PrisonerKinDetail.relationship',
                'PrisonerKinDetail.national_id_no',
            ),
            'conditions'    => array(
                'PrisonerKinDetail.is_trash'   => 0,
                'PrisonerKinDetail.is_enable'  => 0,
            ),
            'order'         => array(
                'PrisonerKinDetail.prisoner_id'
            ),
        ));
          $natIdList      = $this->Iddetail->find('list', array(
                    'recursive'     => -1,
                    'fields'        => array(
                        'Iddetail.id',
                        'Iddetail.name',
                    ),
                    'conditions'    => array(
                        'Iddetail.is_enable'      => 1,
                        'Iddetail.is_trash'       => 0,
                    ),
                    'order'         => array(
                        'Iddetail.name'
                    ),
                ));
          $article = $this->Article->find('first');

          /*aakash*/
          $propertyItemList = $this->Propertyitem->find('list',array(
                'recursive'     => -1,
                'fields'        => array(
                    'Propertyitem.id',
                    'Propertyitem.name',
                ),
                'conditions'    => array(
                    'Propertyitem.is_enable'    => 1,
                    'Propertyitem.is_trash'     => 0,
                    'Propertyitem.is_prohibited'     => 0,

                ),
                'order'=>array(
                    'Propertyitem.name'
                )
            ));
          /*end aakash code*/
        $this->set(array(
            'prisonerList'    => $prisonerList,
            'gateKeepers'     => $gateKeepers,
            'ppcash'          => $ppcash,
            'article'         => $article,
            'relation'        => $relation,
            'prisonernameList'=> $prisonernameList,
            'prisonList'      => $prisonList,
            'prionerKinLIst'  => $prionerKinLIst,
            'natIdList'       => $natIdList,
            'propertyItemList'=>$propertyItemList,
            'weight_units' => $weight_units

        ));
    }

    public function recieveMainItemCash($visitor_id){
        $this->loadModel('CashItem');
        $this->loadModel('Prisoner'); 
        $this->loadModel('VisitorPrisonerItem'); 
        $this->loadModel('PhysicalProperty');
        $this->loadModel('PhysicalPropertyItem');
        $this->loadModel('VisitorPrisonerCashItem');

        $visitor = $this->Visitor->findById($visitor_id);
       //debug($this->data['RecievePrisonerItem']);exit;

        $prisoner = $this->Prisoner->find('first', array(
            'conditions'    => array(
                'Prisoner.prisoner_no'      => $visitor['Visitor']['prisoner_no']
            ),
        ));
        /*aakash recieve prisoner item*/
        $visitorPrisonerItems  = $this->VisitorPrisonerItem->find('all',array(
            'conditions'    => array(
                'VisitorPrisonerItem.visitor_id'      => $visitor_id
            ),
        ));

        $visitorPrisonerCashItems = $this->VisitorPrisonerCashItem->find('all',array(
            'conditions'    => array(
                'VisitorPrisonerCashItem.visitor_id'      => $visitor_id
            ),
        ));
        $physicalProperty=array();
      $notifyUser = $this->User->find('first',array(
                                            'recursive'     => -1,
                                            'conditions'    => array(
                                                'User.usertype_id'    => Configure::read('RECEPTIONIST_USERTYPE'),
                                                'User.is_trash'     => 0,
                                                'User.is_enable'     => 1,
                                                'User.prison_id'  => $this->Session->read('Auth.User.prison_id')
                                            )
                                        ));
            //debug($visitorPrisonerItems);exit;
        foreach ($visitorPrisonerItems as $recievedItem) {
                $recievedItemId = $recievedItem['VisitorPrisonerItem']['id'];

                $visitorPrisonerItem = $this->VisitorPrisonerItem->findById($recievedItemId);
                
                
                if($visitorPrisonerItem['VisitorPrisonerItem']['is_collected'] == false){

                        $physicalPropertyNew =array();
                        $physicalPropertyNew['PhysicalProperty']['property_date_time']=date('Y-m-d H:i:s');
                        $physicalPropertyNew['PhysicalProperty']['login_user_id']=$notifyUser['User']['id'];
                        $physicalPropertyNew['PhysicalProperty']['description']=$visitor['Visitor']['category'];
                        $physicalPropertyNew['PhysicalProperty']['visitor_id']=$visitor['Visitor']['id'];
                        $physicalPropertyNew['PhysicalProperty']['source']='Visitor';
                        if(isset($prisoner['Prisoner']['id'])){
                          $physicalPropertyNew['PhysicalProperty']['prisoner_id']=$prisoner['Prisoner']['id'];  
                        }
                        
                        $physicalPropertyNew['PhysicalProperty']['property_type']='Physical Property';
                        $this->PhysicalProperty->saveAll($physicalPropertyNew['PhysicalProperty']);
                    

                    $physicalPropertyItem['PhysicalPropertyItem']['physicalproperty_id']=$this->PhysicalProperty->id;
                    $physicalPropertyItem['PhysicalPropertyItem']['item_id']=$visitorPrisonerItem['VisitorPrisonerItem']['item_type'];
                    $physicalPropertyItem['PhysicalPropertyItem']['quantity']=$visitorPrisonerItem['VisitorPrisonerItem']['quantity'];
                    $physicalPropertyItem['PhysicalPropertyItem']['property_type']='In Store';
                    $physicalPropertyItem['PhysicalPropertyItem']['status']='Draft';
                    $physicalPropertyItem['PhysicalPropertyItem']['item_status']='Incoming';
                    $physicalPropertyItem['PhysicalPropertyItem']['bag_no']=0;
                    if($this->PhysicalPropertyItem->saveAll($physicalPropertyItem['PhysicalPropertyItem'])){
                        $visitorPrisonerItem['VisitorPrisonerItem']['is_collected']=1;
                        $this->VisitorPrisonerItem->saveAll($visitorPrisonerItem['VisitorPrisonerItem']);
                         $this->addNotification(array("user_id"=>$notifyUser['User']['id'],"content"=>"Visitor Physical Property recieved by Gatekeeper","url_link"=>"properties/physicalPropertyList"));
                        
                    }

                }
           
            
        }
        /*aakash recieve prisoner item ends*/
        //Recieve cash
            foreach ($visitorPrisonerCashItems as $recievedItem) {
                $visitorPrisonerCashId = $recievedItem['VisitorPrisonerCashItem']['id'];

                $visitorPrisonerItem = $this->VisitorPrisonerCashItem->findById($visitorPrisonerCashId);
                //debug($visitorPrisonerItem);exit;
                if($visitorPrisonerItem['VisitorPrisonerCashItem']['is_collected'] == false){

                        $physicalPropertyNew =array();
                        $physicalPropertyNew['PhysicalProperty']['property_date_time']=date('Y-m-d H:i:s');
                        $physicalPropertyNew['PhysicalProperty']['login_user_id']=$notifyUser['User']['id'];
                        $physicalPropertyNew['PhysicalProperty']['description']=$visitor['Visitor']['category'];
                        $physicalPropertyNew['PhysicalProperty']['visitor_id']=$visitor['Visitor']['id'];
                        $physicalPropertyNew['PhysicalProperty']['source']='Visitor';
                        $physicalPropertyNew['PhysicalProperty']['prisoner_id']=$prisoner['Prisoner']['id'];
                        $physicalPropertyNew['PhysicalProperty']['property_type']='Cash';
                        ;
                    if($this->PhysicalProperty->saveAll($physicalPropertyNew['PhysicalProperty'])){
                                    $cashItem['CashItem']['physicalproperty_id']=$this->PhysicalProperty->id;
                                    $cashItem['CashItem']['amount']=$visitorPrisonerItem['VisitorPrisonerCashItem']['pp_amount'];
                                    $cashItem['CashItem']['currency_id']=$visitorPrisonerItem['VisitorPrisonerCashItem']['pp_cash'];
                                    $cashItem['CashItem']['status']='Draft';

                                    if($this->CashItem->save($cashItem)){
                                        $visitorPrisonerItem['VisitorPrisonerCashItem']['is_collected']=1;
                                        $this->VisitorPrisonerCashItem->save($visitorPrisonerItem);
                                        
                                        $this->addNotification(array("user_id"=>$notifyUser['User']['id'],"content"=>"Visitor cash recieved by Gatekeeper","url_link"=>"properties/creditList"));
                                        //echo "success";
                                    }else{
                                        //echo 'failed';
                                    }

                                }

                    

                }
            
        }
        return 1;
    }

    public function timeout(){
        $this->autoRender = false;
        if(isset($this->params['named']) && $this->params['named'] !=''){
            $visitor_id = $this->params['named']['visitor_id'];
            $visitorTimeIn = $this->Visitor->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Visitor.id'     => $visitor_id,
                ),
            ));
            $time_in = $visitorTimeIn['Visitor']['time_in'];
            $duration = date("h:i") - $time_in;
            
            // $checkTime = strtotime('03:06');
            // $loginTime = strtotime('05:07');
            // $diff = $checkTime - $loginTime;

            //Calculate Time Duration
            $in = strtotime($time_in);
            $out = strtotime(date("h:i A"));
            $duration = $in - $out;
            $timeDuration = gmdate("H:i", abs($duration));

            $fields = array(
                'Visitor.time_out'    => "'".date("h:i A")."'",
                'Visitor.duration'    => "'".$timeDuration."'",
            );
            $conds = array(
                'Visitor.id'    => $visitor_id,
            );

            if($this->Visitor->updateAll($fields, $conds)){
                echo 'SUCC';
            }else{
                echo 'FAIL';
            }
        }else{
            echo 'FAIL';
        }
    } 

    public function newTimeout(){
        $this->autoRender = false;
        if(isset($this->params['named']) && $this->params['named'] !=''){
            $visitor_id = $this->params['named']['visitor_id'];
            $visitorTimeIn = $this->Visitor->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Visitor.id'     => $visitor_id,
                ),
            ));
            
            if($this->Session->read('Auth.User.usertype_id')==Configure::read('MAIN_GATEKEEPER_USERTYPE')){
                if($visitorTimeIn['Visitor']['status']=='Gate Out'){
                    $time_in = $visitorTimeIn['Visitor']['main_gate_in_time'];
                    $duration = date("h:i") - $time_in;
                    
                    $in = strtotime($time_in);
                    $out = strtotime(date("h:i A"));
                    $duration = $in - $out;
                    $timeDuration = gmdate("H:i", abs($duration));
                    $fields = array(
                        'Visitor.main_gate_out_time'    => "'".date("h:i A")."'",
                        'Visitor.status'    => "'Exit'",
                        'Visitor.main_gate_duration'    => "'".$timeDuration."'",
                    );
                }              
            }
            if($this->Session->read('Auth.User.usertype_id')==Configure::read('GATEKEEPER_USERTYPE')){
                if($visitorTimeIn['Visitor']['status']=='IN'){
                    $fields = array(
                        'Visitor.time_in'    => "'".date("h:i A")."'",
                        'Visitor.status'    => "'Gate IN'",
                        // 'Visitor.duration'    => "'".$timeDuration."'",
                    );
                }
                if($visitorTimeIn['Visitor']['status']=='Gate IN'){
                    $time_in = $visitorTimeIn['Visitor']['time_in'];
                    $duration = date("h:i") - $time_in;
                    
                    $in = strtotime($time_in);
                    $out = strtotime(date("h:i A"));
                    $duration = $in - $out;
                    $timeDuration = gmdate("H:i", abs($duration));
                    $fields = array(
                        'Visitor.time_out'    => "'".date("h:i A")."'",
                        'Visitor.status'    => "'Gate Out'",
                        'Visitor.duration'    => "'".$timeDuration."'",
                    );
                    $gatekeeperData = $this->User->find('first', array(
                        'recursive'     => -1,
                        'conditions'    => array(
                            'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                            "(".$this->Session->read('Auth.User.prison_id').")"." IN (User.prison_id)",
                        ),
                    ));
                    $userId = $gatekeeperData['User']['id'];
                    $message = $this->getVisitorName($visitor_id).' out from gate.';
                }                
            }
            $conds = array(
                'Visitor.id'    => $visitor_id,
            );

            if($this->Visitor->updateAll($fields, $conds)){    
                if(isset($userId) && $userId!=''){
                    $this->addNotification(array(
                        "user_id"=>$userId,
                        "content"=>$message,
                        "url_link"=>"visitors"));
                } 
                echo 'SUCC';
            }else{
                echo 'FAIL';
            }
        }else{
            echo 'FAIL';
        }
    } 

    public function missing(){
        $this->autoRender = false;
        if(isset($this->params['named']) && $this->params['named'] !=''){
            $visitor_id = $this->params['named']['visitor_id'];
            $visitorTimeIn = $this->Visitor->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Visitor.id'     => $visitor_id,
                ),
            ));
            $time_in = $visitorTimeIn['Visitor']['time_in'];
            $duration = date("h:i") - $time_in;
            
            // $checkTime = strtotime('03:06');
            // $loginTime = strtotime('05:07');
            // $diff = $checkTime - $loginTime;

            //Calculate Time Duration
            $in = strtotime($time_in);
            $out = strtotime(date("h:i A"));
            $duration = $in - $out;
            $timeDuration = gmdate("H:i", abs($duration));

            $fields = array(
                'Visitor.time_out'    => "'".date("h:i A")."'",
                'Visitor.duration'    => "'".$timeDuration."'",
            );
            $conds = array(
                'Visitor.id'    => $visitor_id,
            );

            if($this->Visitor->updateAll($fields, $conds)){
                echo 'SUCC';
            }else{
                echo 'FAIL';
            }
        }else{
            echo 'FAIL';
        }
    }

    function getKinDetail()
    {
        $this->layout = 'ajax';
        $this->loadModel('PrisonerKinDetail');
        $this->loadModel('Relationship');
        $this->loadModel('Iddetail');
        //$this->autoRender = false;
        $prisoner_id = $this->request->data['name'];
        $data = '';
        if(isset($prisoner_id) && (int)$prisoner_id != 0)
        {
            //$prisonerData = $this->Prisoner->findById($prisoner_id);

            $kinData = $this->PrisonerKinDetail->find('all', array(
                'recursive'     => -1,
                'fields'        => array(

                    'PrisonerKinDetail.first_name',
                    'PrisonerKinDetail.middle_name',
                    'PrisonerKinDetail.last_name',
                    'PrisonerKinDetail.relationship',
                    'PrisonerKinDetail.national_id_no',
                ),
                'conditions'    => array(
                    'PrisonerKinDetail.is_trash'         => 0,
                    'PrisonerKinDetail.is_enable'        => 0,
                    'PrisonerKinDetail.prisoner_id'      => $prisoner_id
                ),
            ));
             $relation = $this->Relationship->find('list',array(
                'fields'        => array(
                    'Relationship.id',
                    'Relationship.name',
                ),
                'conditions'=>array(
                  'Relationship.is_enable'=>1,
                  'Relationship.is_trash'=>0,
                ),
                'order'=>array(
                  'Relationship.name'
                )
          ));
             $natIdList      = $this->Iddetail->find('list', array(
                    'recursive'     => -1,
                    'fields'        => array(
                        'Iddetail.id',
                        'Iddetail.name',
                    ),
                    'conditions'    => array(
                        'Iddetail.is_enable'      => 1,
                        'Iddetail.is_trash'       => 0,
                    ),
                    'order'         => array(
                        'Iddetail.name'
                    ),
                ));

            $this->set(array(
                'kinData'         => $kinData,
                'relation'        => $relation,
                'natIdList'		  => $natIdList 
            )); 

        }
    }
    public function alert(){
        $this->autoRender = false;
        if(isset($this->params['named']) && $this->params['named'] !=''){
             $gatekeeperData = $this->User->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                    "(".$this->Session->read('Auth.User.prison_id').")"." IN (User.prison_id)",
                ),
            ));
            $userId = $gatekeeperData['User']['id'];
            $this->addNotification(array(
                "user_id"=>$userId,
                "content"=>"Visitor Not Reached Yet",
                "url_link"=>"visitors"));
            echo 'SUCC';
      
        }else{
            echo 'FAIL';
        }
    }
    public function newAlert(){
        $this->autoRender = false;
        // debug($this->params);
        if(isset($this->params['named']['visitor_id']) && $this->params['named']['visitor_id'] !=''){
            if($this->Session->read('Auth.User.usertype_id')==Configure::read('MAIN_GATEKEEPER_USERTYPE')){
                
                $gatekeeperData = $this->User->find('first', array(
                    'recursive'     => -1,
                    'conditions'    => array(
                        'User.usertype_id'      => Configure::read('GATEKEEPER_USERTYPE'),
                        'User.prison_id'      => $this->getName($this->params['named']['visitor_id'],"Visitor","prison_id"),
                    ),
                ));
                $userId = $gatekeeperData['User']['id'];
                $visiterName = $this->getVisitorName($this->params['named']['visitor_id']);
                $this->addNotification(array(
                    "user_id"=>$userId,
                    "content"=>$visiterName." Not Reached Yet",
                    "url_link"=>"visitors"));
                echo 'SUCC';exit;
            }
            if($this->Session->read('Auth.User.usertype_id')==Configure::read('GATEKEEPER_USERTYPE')){
                $gatekeeperData = $this->User->find('first', array(
                    'recursive'     => -1,
                    'conditions'    => array(
                        'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                        "(".$this->Session->read('Auth.User.prison_id').")"." IN (User.prison_id)",
                    ),
                ));
                $userId = $gatekeeperData['User']['id'];
                $visiterName = $this->getVisitorName($this->params['named']);
                $this->addNotification(array(
                    "user_id"=>$userId,
                    "content"=>$visiterName. " Not Reached Yet",
                    "url_link"=>"visitors"));
                echo 'SUCC';exit;        
            }
        }else{
            echo 'FAIL';exit;
        }
    }


    //code by smita for gate book//
    public function gateBookReport(){
    $this->loadModel('Visitor'); 
        //debug($this->data['RecordStaffDelete']['id']);
        //return false;
        if(isset($this->data['VisitorDelete']['id']) && (int)$this->data['VisitorDelete']['id'] != 0){
            
            $this->Visitor->id=$this->data['VisitorDelete']['id'];
            $db = ConnectionManager::getDataSource('default');
            $db->begin();
            if($this->Visitor->saveField('is_trash',1))
            {
                if($this->auditLog('Visitor', 'visitors', $this->data['VisitorDelete']['id'], 'Delete', json_encode(array('is_trash',1))))
                {
                    $db->commit(); 
                    $this->Session->write('message_type','success');
                    $this->Session->write('message','Deleted Successfully !');
                    $this->redirect(array('action'=>'index'));
                }
                else {
                    $db->rollback();
                    $this->Session->write('message_type','error');
                    $this->Session->write('message','Delete failed');
                }
            }
            else 
            {
                $db->rollback();
                $this->Session->write('message_type','error');
                $this->Session->write('message','Delete failed');
            }
        }
        $prisonList = $this->Prison->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'Prison.id',
                'Prison.name',
            ),
            'conditions'    => array(
                'Prison.is_trash'   => 0,
                'Prison.is_enable'  => 1,
                "Prison.id IN (".$this->Session->read('Auth.User.prison_id').")"
            ),
            'order'         => array(
                'Prison.name'
            ),
        ));
        $allowUpdate = true;
        if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
            $allowUpdate = true;
        }elseif ($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')) {
            $gatekeeperData = $this->User->find('count', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                    "prison_id REGEXP CONCAT('(^|,)(', REPLACE(".$this->Session->read('Auth.User.prison_id').", ',', '|'), ')(,|$)')",
                ),
            ));
            exit;
            if($gatekeeperData == 0){
                $allowUpdate = false;
            }
        }else{
            $allowUpdate = false;
        }
        
         $this->set(array(
            'prisonList'         => $prisonList,
            'allowUpdate'        => $allowUpdate,
            //'gatekeeperData'     => $gatekeeperData
        )); 
}

public function gateBookReportAjax(){
        $this->loadModel('Visitor'); 
        $this->layout = 'ajax';
        $from  = '';
        $to  = '';
        $category = $this->params['named']['category'];
        $condition = array('Visitor.is_trash'   => 0);
        if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
        $condition += array("Visitor.prison_id IN (".$this->Session->read('Auth.User.prison_id').")");
      }else{
        $condition += array("Visitor.prison_id" => $this->Session->read('Auth.User.prison_id'));
      }
        //debug($this->params);exit;
        if(isset($this->params['named']['from']) && $this->params['named']['from'] != '' &&
         isset($this->params['named']['to']) && $this->params['named']['to'] != ''){
            $from = $this->params['named']['from'];
            $to = $this->params['named']['to'];

         $condition += array('Visitor.date >= ' => date('Y-m-d', strtotime($from)),
                              'Visitor.date <= ' => date('Y-m-d', strtotime($to))
                             );        
        }
        if(isset($this->params['named']['category']) && $this->params['named']['category'] != ''){
            $prisoner_id = $this->params['named']['category'];
             
            $condition += array(
                "Visitor.category"=>$category
                
            );
        }
        if(isset($this->params['named']['gate_keeper_name']) && $this->params['named']['gate_keeper_name'] != ''){
             $name = str_replace('  ', '', $this->params['named']['gate_keeper_name']);

            $condition += array("Visitor.gate_keeper LIKE '%$name%'");
              //$condition += array('Visitor.gate_keeper' => $this->params['named']['gate_keeper_name'] );
            //debug($condition);
           // $condition += array("CONCAT('Prisoner.first_name', 'Prisoner.middle', 'Prisoner.lastname') LIKE '%$name%'");
        } 
       
        $this->paginate = array(
            'conditions'    => $condition,
            'order'         =>array(
                'Visitor.created' => 'DESC'
            ),            
            'limit'         => 20,
        );

        $datas  = $this->paginate('Visitor');
        //debug($datas);

        $this->set(array(
            'from'         => $from,
            'to'           => $to,
            'datas'        => $datas,
        )); 
    }

    function getVisitorName($visitor_id){
        $this->loadModel('VisitorName');
        $condition = array(
            'VisitorName.visitor_id'    => $visitor_id
        );
        $data = $this->VisitorName->find('list', array(
            'recursive'     => -1,
            'fields'        => array(
                'VisitorName.id',
                'VisitorName.name',
            ),
            'conditions'    => $condition
        ));
        if(isset($data) && is_array($data) && count($data)>0){
            return implode(", ", $data);
        }else{
            return '';
        }        
    }

    public function checkMainGatekeeperExits(){
        $allowUpdate = false;
        if($this->Session->read('Auth.User.usertype_id') == Configure::read('MAIN_GATEKEEPER_USERTYPE')){
            $allowUpdate = true;
        }elseif ($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')) {
            $gatekeeperData = $this->User->find('count', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                    "prison_id REGEXP CONCAT('(^|,)(', REPLACE(".$this->Session->read('Auth.User.prison_id').", ',', '|'), ')(,|$)')",
                ),
            ));
            if($gatekeeperData == 0){
                $allowUpdate = true;
            }
        }else{
            $allowUpdate = false;
        }
        return $allowUpdate;
    }

    public function getPrisoner(){
        $this->layout = 'ajax';
        $prisonernameList = $this->Prisoner->find("list", array(
            "conditions"    => array(
                "Prisoner.prison_id"    => $this->data['prison_id'],
                "Prisoner.is_trash"    => 0,
                "Prisoner.is_enable"    => 1,
                "Prisoner.present_status"    => 1,
                'Prisoner.transfer_status !='        => 'Approved',
                'Prisoner.status'        => 'Approved',
            ),
            "fields"        => array(
                "Prisoner.id",
                "Prisoner.fullname",
            ),
        ));
        $this->set(array(
            'prisonernameList'         => $prisonernameList,
        ));
    }

    public function hasMainGate($prison_id){
        if ($this->Session->read('Auth.User.usertype_id') == Configure::read('GATEKEEPER_USERTYPE')) {
            return $this->User->find('count', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'User.usertype_id'      => Configure::read('MAIN_GATEKEEPER_USERTYPE'),
                    "prison_id REGEXP CONCAT('(^|,)(', REPLACE(".$prison_id.", ',', '|'), ')(,|$)')",
                ),
            ));
            return 0;
        }else{
            return 1;
        }
    }

    public function getNextReceive($prisoner_id){
        // $prisoner_id = $this->params['named']['prisoner_id'];
        $this->loadModel('Privilege');
        $stageData = $this->StageHistory->find("first", array(
            "recursive"     => -1,
            "conditions"    => array(
                "StageHistory.prisoner_id"  => $prisoner_id,
                "StageHistory.is_trash"     => 0,
            ),
        ));

        if(isset($stageData) && count($stageData)>0){
            $conditionPri = array();
            $conditionLetter = array();
            $type = '';            
            $conditionPri = array("Privilege.privilege_right_id"=>Configure::read('VISIT-RECEIVE'));

            // check the diciplinary action for privilages =====
            $punishmentData = $this->InPrisonPunishment->find("first", array(
                "recursive"     => -1,
                "conditions"    => array(
                    "InPrisonPunishment.prisoner_id"    => $prisoner_id,
                    "InPrisonPunishment.is_trash"       => 0,
                    "InPrisonPunishment.status"         => 'Approved',
                    "InPrisonPunishment.internal_punishment_id"         => 6,
                    "'".date("Y-m-d")."' between InPrisonPunishment.punishment_start_date and InPrisonPunishment.punishment_end_date"
                ),
                "order"         => array(
                    "InPrisonPunishment.id"    => "desc",
                ),
            ));
            // echo "<pre>";print_r($punishmentData);
            $is_punishment = false;
            if(isset($punishmentData['InPrisonPunishment']['privilege_id']) && $punishmentData['InPrisonPunishment']['privilege_id']!=''){
                if(in_array(Configure::read("VISIT-RECEIVE"),explode(",", $punishmentData['InPrisonPunishment']['privilege_id']))){
                    $type = "receive";
                    $conditionPri = array("Privilege.privilege_right_id"=>Configure::read("VISIT-RECEIVE"));
                    $is_punishment = true;
                }
            }

            
            $privilegeData = $this->Privilege->find("first", array(
                "recursive"     => -1,
                "conditions"    => array(
                    "Privilege.stage_id"  => $stageData['StageHistory']['stage_id'],
                    "Privilege.is_trash"     => 0,
                )+$conditionPri,
            ));
            // debug($privilegeData);
            if(isset($privilegeData['Privilege']['interval_week']) && $privilegeData['Privilege']['interval_week']!=''){
                $visitersData = $this->Visitor->find("first", array(
                    "recursive"     => -1,
                    "conditions"    => array(
                        "Visitor.prisoner_no"  => $this->Prisoner->field("prisoner_no", array("Prisoner.id"=>$prisoner_id)),
                        "Visitor.is_trash"     => 0,
                    ),
                    "order"         => array(
                        "Visitor.id"    => "desc",
                    ),
                ));
                //=====================================================
                if($is_punishment){
                    $nextReceiveDate = date('d-m-Y', strtotime($punishmentData['InPrisonPunishment']['punishment_end_date']));

                    if(strtotime($nextReceiveDate) > strtotime(date("d-m-Y"))){
                        $privilage = array();
                        foreach (explode(",", $punishmentData["InPrisonPunishment"]["privilege_id"]) as $key => $value) {
                            $privilage[] = $this->getName($value,"PrivilegeRight","name");
                        }
                        echo "This prisoner receive visiter after ".$nextReceiveDate.". Prisoner has punished by Forfeiture of privileges, restrict for ".implode(", ", $privilage)." till ".$nextReceiveDate;exit;
                    }
                }
                //=====================================================
                if(isset($visitersData) && count($visitersData)>0){
                    $nextReceiveDate = date('d-m-Y', strtotime('+'.$privilegeData['Privilege']['interval_week'].' week', strtotime($visitersData['Visitor']['date'])));
                    if(strtotime($nextReceiveDate) > strtotime(date("d-m-Y"))){
                        echo "This prisoner receive visiter after ".date('d-m-Y', strtotime('+'.$privilegeData['Privilege']['interval_week'].' week', strtotime($visitersData['Visitor']['date']))).". Prisoner belongs to ".$this->getName($stageData['StageHistory']['stage_id'],"Stage","name").", So the prisoner will be able to receive visiter in interval of ".$privilegeData['Privilege']['interval_week']." weeks";exit;
                    }                    
                }
            }else{
                echo "Privilege is not updated for ".$this->getName($stageData['StageHistory']['stage_id'],"Stage","name");exit;
            }
        }else{
            echo "This prisoner is not in stage system";exit;
        }
        exit;
    }

}
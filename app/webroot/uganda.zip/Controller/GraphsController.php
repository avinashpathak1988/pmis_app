<?php
App::uses('Controller', 'Controller');
App::uses('CakeEmail', 'Network/Email');
class GraphsController extends AppController{
    public $layout='table';
    public $uses=array('User', 'Department', 'Designation', 'Usertype', 'State', 'District', 'Prison','Officer','MedicalDeathRecord','MedicalCheckupRecord');
    public function mortality() { 
        $prisonCondi = array();
        if($this->Session->read('Auth.User.prison_id')!=''){
            $prisonCondi = array("Prison.id"=>$this->Session->read('Auth.User.prison_id'));
        }
        $prisonData = $this->Prison->find("all", array(
            "conditions"    => array(
                "Prison.is_enable"  => 1,
                "Prison.is_trash"  => 0,
            )+$prisonCondi,
        ));
        $prisonGraph = array();
        if(isset($prisonData) && is_array($prisonData) && count($prisonData)>0){
            foreach ($prisonData as $key => $value) {
                $prisonGraph['name'][$key]         = $value['Prison']['name'];
                $prisonGraph['Available'][$key]    = $this->MedicalCheckupRecord->find("count", array(
                        "conditions"    => array(
                            'MedicalCheckupRecord.is_trash'             => 0,
                            'MedicalCheckupRecord.prison_id'            => $value['Prison']['id'],
                        ),
                ));
                $prisonGraph['Death'][$key]    = $this->MedicalDeathRecord->find("count", array(
                        "conditions"    => array(
                            'MedicalDeathRecord.status'             => 'Approved',
                            'MedicalDeathRecord.is_trash'           => 0,
                            'MedicalDeathRecord.prison_id'           => $value['Prison']['id'],
                        ),
                ));
            }
        }        

        $this->set(array(
            "prisonGraph"    => $prisonGraph,
        ));
    }

    public function congestionLevel() { 
        $prisonCondi = array();
        if($this->Session->read('Auth.User.prison_id')!=''){
            $prisonCondi = array("Prison.id"=>$this->Session->read('Auth.User.prison_id'));
        }
        $prisonData = $this->Prison->find("all", array(
            "conditions"    => array(
                "Prison.is_enable"  => 1,
                "Prison.is_trash"  => 0,
            )+$prisonCondi,
            'order'         => array(
                'Prison.name'       => 'ASC',
            ),
        ));
        $prisonGraph = array();
        if(isset($prisonData) && is_array($prisonData) && count($prisonData)>0){
            foreach ($prisonData as $key => $value) {
                $prisonGraph['name'][$key]         = $value['Prison']['name'];
                $prisonGraph['Capacity'][$key]     = $value['Prison']['capacity'];
                $prisonGraph['Available'][$key]    = $this->Prisoner->find("count", array(
                        "conditions"    => array(
                            'Prisoner.is_trash'             => 0,
                            'Prisoner.present_status'       => 1,
                            'Prisoner.is_approve'          => 1,
                            'Prisoner.prison_id'            => $value['Prison']['id'],
                            'Prisoner.transfer_status !='   => 'Approved'
                        ),
                ));
            }
        }        

        $this->set(array(
            "prisonGraph"    => $prisonGraph,
        ));
    }
}
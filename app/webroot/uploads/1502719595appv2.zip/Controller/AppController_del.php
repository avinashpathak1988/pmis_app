<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    function beforeFilter(){
        //craete a object which will used in other view pages to call the native functions
        $this->set('funcall',$this);

    }
    public function message($message_type,$message){
        $this->Session->write('message_type',$message_type);
        $this->Session->write('message',$message);
    }
    function add_postpreg_btn($rch_no)
    {
      $this->loadModel('Delivery');
      $this->loadModel('Beneficiary');

      $getdetails = $this->Beneficiary->find('first', array(
        'conditions' => array(
          'Beneficiary.id' => $rch_no
        )
      ));
    //  debug($getdetails);


    }
 public

function getsectorName($value = '')
  {
  $this->loadModel('Sector');
  if (isset($value) && $value != '')
    {
    $sector = $this->Sector->find('first', array(
      'recursive' => - 1,
      'conditions' => array(
        'id' => $value
      ) ,
      'fields' => array(
        'name'
      )
    ));
    return $sector['Sector']['name'];
    }
  }

public

function getProjectName($value = '')
  {
  $this->loadModel('Project');
  if (isset($value) && $value != '')
    {
    $data = $this->Project->find('first', array(
      'recursive' => - 1,
      'conditions' => array(
        'id' => $value
      ) ,
      'fields' => array(
        'name'
      )
    ));
	if(isset($data['Project']['name'])){
		return $data['Project']['name'];
	}
    }
  }

public

function getDistrictName($value = '')
  {
  $this->loadModel('District');
  if (isset($value) && $value != '')
    {
    $data = $this->District->find('first', array(
      'recursive' => - 1,
      'conditions' => array(
        'id' => $value
      ) ,
      'fields' => array(
        'name'
      )
    ));
	if(isset($data['District']['name'])){
		return $data['District']['name'];
	}
    }
  }

public

function getAwcName($value = '')
  {
  $this->loadModel('Awc');
  if (isset($value) && $value != '')
    {
    $data = $this->Awc->find('first', array(
      'recursive' => - 1,
      'conditions' => array(
        'id' => $value
      ) ,
      'fields' => array(
        'name'
      )
    ));
    return $data['Awc']['name'];
    }
  }  
  function date2DB($dt=null, $format='/'){
        if($dt){
            $dateArray = explode($format,$dt);
            if(count($dateArray) > 1){
                $formatedDate = $dateArray[2].'-'.$dateArray[1].'-'.$dateArray[0];
                return $formatedDate;
            }else{
                return '0000-00-00';
            }
        }else{
            return '';
        }
    }

    function DB2date($dt){
        if($dt != '' && $dt != '0000-00-00' && $dt != '1900-01-01' && $dt != '1970-01-01'){
            $formatedDate = date('d/m/Y',strtotime($dt));
            return $formatedDate;
        }
    }

    /**
      * Add Days to a Date
      **/
    function addDayswithdate($date,$days){
      $date = strtotime("+".$days." days", strtotime($date));
      return  date("Y-m-d", $date);
    }
      function addDayswithdatenew($date,$days){
          $date = strtotime("+".$days." days", strtotime($date));
          return  date("d/m/Y", $date);
      }
      function addMonthswithdatenew($date,$month){
          $date = strtotime("+".$month." months", strtotime($date));
          return  date("d/m/Y", $date);
      }
      function installmentDate($date_str, $months) {
          $date_timestamp = strtotime($date_str);
          $date_after = strtotime("+".$months." months", $date_timestamp);
          return date("Y-m-d", $date_after);
          //return date("Y-m-d",strtotime(date("Y-m-d", strtotime($date_str)) . " ".$months." month"));
      }
      function installmentDateByDOD($date_str, $months) {
          return date("Y-m-d",strtotime(date("Y-m-d", strtotime($date_str)) ." ".$months." month"));
      }

      function plusDate($date_str, $months) {
          $date_timestamp = strtotime($date_str);
          $date_after = strtotime("+".$months." months", $date_timestamp);
          return date("Y-m-d", $date_after);
      }
      function minusDate($date_str, $months) {
          $date_timestamp = strtotime($date_str);
          $date_after = strtotime("-".$months." months", $date_timestamp);
          return date("Y-m-d", $date_after);
      }
      function subtractdaysfromdate($date_str, $days) {
          $date_timestamp = strtotime($date_str);
          $date_after = strtotime("-".$days." days", $date_timestamp);
          return date("d/m/Y", $date_after);
      }
    function getUniqueno($pregid){
        $pregid = base64_decode($pregid);
        $this->loadModel('Pregnency');
        $pregDetails = $this->Pregnency->find('first', array(
            'conditions' => array(
                'Pregnency.id' => $pregid
            )
        ));
        return $pregDetails['Beneficiary']['rch_mcts_no'];
    }

    //Calculate Live Birth//////////
    public function returnlive($id){
    //  $this->layout=NULL;
        $this->loadModel('Delivery');
        $this->loadModel('Pregnency');
        $this->loadModel('Beneficiary');

      $live_birth_reg=0;
      $live_birth_del=0;
      $live_birth_total=0;

      $live_birth_reg=$this->Beneficiary->findById($id);
      $live_birth_reg=$live_birth_reg['Beneficiary']['no_of_live_birth'];

      $this->Delivery->recursive=-1;
      $d=$this->Delivery->find('all',array(
        'conditions'=>array(
          'Delivery.beneficiary_id'=>$id,
        ),
        'order'=>array(
          'Delivery.id'
        )
      ));
$this->Pregnency->recursive=-1;
$e=$this->Pregnency->find('all',array(
  'conditions'=>array(
    'Pregnency.beneficiary_id'=>$id
  ),
  'order'=>array(
    'Pregnency.id'=>'DESC'
  ),
  //'limit'=>1
));

foreach($e as $e1){
  if(strtoupper($e1['Pregnency']['exit_reason']) == 'INFANT DEATH'){
    $live_birth_del=$live_birth_del + 1;
  }
}



//echo "<pre>";
//print_r($d); exit();

      foreach($d as $d1){
        if(strtoupper($d1['Delivery']['outcome']) == 'SINGLE LIVE BIRTH'){
          $live_birth_del=$live_birth_del + 1;
        }
        //if(strtoupper($d1['Delivery']['outcome']) == 'INFANT DEATH'){
        //  $live_birth_del=$live_birth_del + 1;
      //  }
        if(strtoupper($d1['Delivery']['outcome']) == 'STILL BIRTH'){
          $live_birth_del=$live_birth_del + 0;
        }
        if(strtoupper($d1['Delivery']['outcome']) == 'TWIN LIVE BIRTH' && strtoupper($d1['Delivery']['child1_live_birth']) == 'YES' && strtoupper($d1['Delivery']['child2_live_birth']) == 'YES'){
          $live_birth_del=$live_birth_del + 2;
        }
        if(strtoupper($d1['Delivery']['outcome']) == 'TWIN LIVE BIRTH' && strtoupper($d1['Delivery']['child1_live_birth']) != 'YES' && strtoupper($d1['Delivery']['child2_live_birth']) == 'YES'){
          $live_birth_del=$live_birth_del + 1;
        }
        if(strtoupper($d1['Delivery']['outcome']) == 'TWIN LIVE BIRTH' && strtoupper($d1['Delivery']['child1_live_birth']) == 'YES' && strtoupper($d1['Delivery']['child2_live_birth']) != 'YES'){
          $live_birth_del=$live_birth_del + 1;
        }
      }
      //$live_birth_total=$live_birth_reg + $live_birth_del;
      $live_birth_total= $live_birth_del;
      return $live_birth_total;

  //  exit();
    }
    public function getPregnencyExitCount($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Pregnency');
            $condition = array(
                'Pregnency.is_exit'     => 1,
                "Beneficiary.user_id in(select id from users where project_id=$project_id)",
            );
            if($from_date != ''){
                $condition += array(
                    'Pregnency.exit_date >='    => date('Y-m-d', strtotime($from_date)),
                );
            }
            if($to_date != ''){
                $condition += array(
                    'Pregnency.exit_date <='    => date('Y-m-d', strtotime($to_date)),
                );
            }            
            $tot_exits = $this->Pregnency->find('count',array(
                'recursive'     => -1,
                'joins'=>array(
                    array(
                        'table'         => 'beneficiaries',
                        'alias'         => 'Beneficiary',
                        'type'          => 'left',
                        'foreignKey'    => false,
                        'conditions'    => array('Pregnency.beneficiary_id=Beneficiary.id')                 
                    ),                            
                ),                
                'conditions'    => $condition,
            ));    
            return $tot_exits;        
        }else{
            return 0;
        }
    }
    /*public function getEligibleAwwCount($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Worker');
            $condition = array(
                0 => 'Worker.id in(select worker_id from beneficiaries where id in(select beneficiary_id from pregnencies where is_exit=1))',
                1 => "Worker.id in(select worker_id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
            );
      
            if($from_date != '' && $to_date != ''){
                $from_date  = date('Y-m-d', strtotime($from_date));
                $to_date    = date('Y-m-d', strtotime($to_date));
                $condition += array(
                    2 => "Worker.id in(select worker_id from beneficiaries where id in(select beneficiary_id from pregnencies where exit_date between '".$from_date."' and '".$to_date."'))",
                );
            }               
            $elig_aww   = $this->Worker->find('count',array(
                'recursive'     => -1,
                'conditions'    => $condition,
            ));   
            return $elig_aww;        
        }else{
            return 0;
        }        
    }
    public function getEligibleAwhCount($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Worker');
            $condition = array(
                0 => 'Worker.id in(select helper_id from beneficiaries where id in(select beneficiary_id from pregnencies where is_exit=1))',
                1 => "Worker.id in(select helper_id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
            );
      
            if($from_date != '' && $to_date != ''){
                $from_date  = date('Y-m-d', strtotime($from_date));
                $to_date    = date('Y-m-d', strtotime($to_date));
                $condition += array(
                    2 => "Worker.id in(select worker_id from beneficiaries where id in(select beneficiary_id from pregnencies where exit_date between '".$from_date."' and '".$to_date."'))",
                );
            }               
            $elig_awh = $this->Worker->find('count',array(
                'recursive'     => -1,
                'conditions'    => $condition,
            )); 
            return $elig_awh;        
        }else{
            return 0;
        }        
    }*/
    public function getEligibleAwwCount($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Pregnency');
            $condition = array(
              'Pregnency.is_exit'     => '1',
              'Incentive.amount'      => '200',
              //'Incentive.is_paid'     => '0',
              //'Incentive.paid_status' => '',
            );
            if(isset($project_id) && $project_id!=''){
              $condition += array(
                //'User.project_id >=' => $project_id,
                "Pregnency.user_id IN (select id from users where project_id = {$project_id} )"
              );
            }
            if(isset($from_date) && $from_date!=''){
              $from_date = date('Y-m-d', strtotime($from_date));
              $condition += array(
                'Pregnency.exit_date >=' => $from_date,
              );
            }
            if(isset($to_date) && $to_date!=''){
              $to_date = date('Y-m-d', strtotime($to_date));
              $condition += array(
               'Pregnency.exit_date <=' => $to_date,
              );
            }else{
              $prev_date = date('Y-m-d',strtotime("-1 days"));
              $condition += array(
               'Pregnency.exit_date <=' => $prev_date,
              );
            }  
            // /debug($condition);
            $elig_aww   = $this->Pregnency->find('count',array(
                'recursive'     => -1,
                'joins'=>array(
                    array(
                      'table'     => 'incentives',
                      'alias'     => 'Incentive',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('Incentive.pregnency_id = Pregnency.id')         
                    ),
                    array(
                      'table'     => 'users',
                      'alias'     => 'User',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('User.id = Pregnency.user_id')         
                    ),
                ),
                'conditions'    => $condition,
                'fields' => array(
                  'User.*'
                )
            ));
            /*$log = $this->Pregnency->getDataSource()->getLog(false, false);
      debug($log); exit;*/
            /*debug($condition); 
            debug($elig_aww); exit;*/
            return $elig_aww;        
        }else{
            return 0;
        }        
    }
    public function getEligibleAwhCount($from_date, $to_date, $project_id){
         if($project_id){
            $this->loadModel('Pregnency');
            $condition = array(
              'Pregnency.is_exit'     => '1',
              'Incentive.amount'      => '100',
              //'Incentive.is_paid'     => '0',
              //'Incentive.paid_status' => '',
            );
            if(isset($project_id) && $project_id!=''){
              $condition += array(
                //'User.project_id >=' => $project_id,
                "Pregnency.user_id IN (select id from users where project_id = {$project_id} )"
              );
            }
            if(isset($from_date) && $from_date!=''){
              $from_date = date('Y-m-d', strtotime($from_date)); 
              $condition += array(
                'Pregnency.exit_date >=' => $from_date,
              );
            }
            if(isset($to_date) && $to_date!=''){
              $to_date = date('Y-m-d', strtotime($to_date));
              $condition += array(
               'Pregnency.exit_date <=' => $to_date,
              );
            }else{
              $prev_date = date('Y-m-d',strtotime("-1 days"));
              $condition += array(
               'Pregnency.exit_date <=' => $prev_date,
              );
            } 
            
            $elig_aww   = $this->Pregnency->find('count',array(
                'recursive'     => -1,
                'joins'=>array(
                    array(
                      'table'     => 'incentives',
                      'alias'     => 'Incentive',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('Incentive.pregnency_id = Pregnency.id')         
                    ),
                    array(
                      'table'     => 'users',
                      'alias'     => 'User',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('User.id = Pregnency.user_id')         
                    ),
                ),
                'conditions'    => $condition,
            ));
            //debug($elig_aww); exit;
            return $elig_aww;        
        }else{
            return 0;
        }         
    }

    /* -- DISTRICT WISE ELIGIBLE AWW AWH -- */
    public function getEligibleAwwCountDistWise($from_date, $to_date, $district_id){
        if($district_id){
            $this->loadModel('Pregnency');
            $condition = array(
              'Pregnency.is_exit'     => '1',
              'Incentive.amount'      => '200',
              //'Incentive.is_paid'     => '0',
              //'Incentive.paid_status' => '',
            );
            if(isset($district_id) && $district_id!=''){
              $condition += array(
                //'User.project_id >=' => $project_id,
                "Pregnency.user_id IN (select id from users where district_id = {$district_id} )"
              );
            }
            if(isset($from_date) && $from_date!=''){
              $from_date = date('Y-m-d', strtotime($from_date));
              $condition += array(
                'Pregnency.exit_date >=' => $from_date,
              );
            }
            if(isset($to_date) && $to_date!=''){
              $to_date = date('Y-d-m', strtotime($to_date));
              $condition += array(
               'Pregnency.exit_date <=' => $to_date,
              );
            }else{
              $prev_date = date('Y-m-d',strtotime("-1 days"));
              $condition += array(
               'Pregnency.exit_date <=' => $prev_date,
              );
            }
            // /debug($condition);
            $elig_aww   = $this->Pregnency->find('count',array(
                'recursive'     => -1,
                'joins'=>array(
                    array(
                      'table'     => 'incentives',
                      'alias'     => 'Incentive',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('Incentive.pregnency_id = Pregnency.id')         
                    ),
                    array(
                      'table'     => 'users',
                      'alias'     => 'User',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('User.id = Pregnency.user_id')         
                    ),
                ),
                'conditions'    => $condition,
                'fields' => array(
                  'User.*'
                )
            ));
           /* $log = $this->Pregnency->getDataSource()->getLog(false, false);
      debug($log); exit;*/
            /*debug($condition); 
            debug($elig_aww); exit;*/
            return $elig_aww;        
        }else{
            return 0;
        }        
    }
    public function getEligibleAwhCountDistWise($from_date, $to_date, $district_id){
         if($district_id){
            $this->loadModel('Pregnency');
            $condition = array(
              'Pregnency.is_exit'     => '1',
              'Incentive.amount'      => '100',
              //'Incentive.is_paid'     => '0',
              //'Incentive.paid_status' => '',
            );
            if(isset($district_id) && $district_id!=''){
              $condition += array(
                //'User.project_id >=' => $project_id,
                "Pregnency.user_id IN (select id from users where district_id = {$district_id} )"
              );
            }
            if(isset($from_date) && $from_date!=''){
              $from_date = date('Y-m-d', strtotime($from_date));
              $condition += array(
                'Pregnency.exit_date >=' => $from_date,
              );
            }
            if(isset($to_date) && $to_date!=''){
              $to_date = date('Y-d-m', strtotime($to_date));
              $condition += array(
               'Pregnency.exit_date <=' => $to_date,
              );
            }else{
              $prev_date = date('Y-m-d',strtotime("-1 days"));
              $condition += array(
               'Pregnency.exit_date <=' => $prev_date,
              );
            } 
            
            $elig_aww   = $this->Pregnency->find('count',array(
                'recursive'     => -1,
                'joins'=>array(
                    array(
                      'table'     => 'incentives',
                      'alias'     => 'Incentive',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('Incentive.pregnency_id = Pregnency.id')         
                    ),
                    array(
                      'table'     => 'users',
                      'alias'     => 'User',
                      'type'      => 'left',
                      'foreignKey'  => false,
                      'conditions'  => array('User.id = Pregnency.user_id')         
                    ),
                ),
                'conditions'    => $condition,
            ));
            //debug($elig_aww); exit;
            return $elig_aww;        
        }else{
            return 0;
        }         
    }

    public function getWorkerIncentivePaid($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Incentive');
            $condition = array(
                "Incentive.is_Paid" => 1,
                0 => "Incentive.beneficiary_id in(select id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
                1 => "Incentive.worker_id in(select worker_id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
            );
            if($from_date != '' && $to_date != ''){
                $from_date  = date('Y-m-d', strtotime($from_date));
                $to_date    = date('Y-m-d', strtotime($to_date));
                $condition += array(
                    2 => "Incentive.payment_date between '".$from_date."' and '".$to_date."'",
                );
            }  
            $tot_paid = $this->Incentive->find('all',array(
                'recursive'     => -1,
                'fields'        => array(
                    'sum(Incentive.amount) as tot_paid'
                ),
                'conditions'    => $condition,
            ));
	    if(isset($tot_paid[0][0]['tot_paid']) && $tot_paid[0][0]['tot_paid'] != ''){
            	return $tot_paid[0][0]['tot_paid'];     
	    }else{
		return 0;
	    }
        }else{
            return 0;
        }        
    }
    public function getHelperIncentivePaid($from_date, $to_date, $project_id){
        if($project_id){
            $this->loadModel('Incentive');
            $condition = array(
                "Incentive.is_Paid" => 1,
                0 => "Incentive.beneficiary_id in(select id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
                1 => "Incentive.worker_id in(select helper_id from beneficiaries where user_id in(select id from users where project_id=$project_id))",
            );
            if($from_date != '' && $to_date != ''){
                $from_date  = date('Y-m-d', strtotime($from_date));
                $to_date    = date('Y-m-d', strtotime($to_date));
                $condition += array(
                    2 => "Incentive.payment_date between '".$from_date."' and '".$to_date."'",
                );
            }  
            $tot_paid = $this->Incentive->find('all',array(
                'recursive'     => -1,
                'fields'        => array(
                    'sum(Incentive.amount) as tot_paid'
                ),
                'conditions'    => $condition,
            ));
    	    if(isset($tot_paid[0][0]['tot_paid']) && $tot_paid[0][0]['tot_paid'] != ''){
                	return $tot_paid[0][0]['tot_paid'];     
    	    }else{
    		  return 0;
    	    }
        }else{
            return 0;
        }        
    }
    public function getWorkerHelperPaymentDateFromIncentive($beneficiary_id, $pregnency_id, $worker_id){
        if($beneficiary_id && $pregnency_id && $worker_id){
            $this->loadModel('Incentive');
            $data = $this->Incentive->find('first',array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Incentive.beneficiary_id'  => $beneficiary_id,
                    'Incentive.pregnency_id'    => $pregnency_id,
                    'Incentive.is_paid'         => 1,
                    'Incentive.worker_id'       => $worker_id,
                )
            ));
            if(isset($data['Incentive']['payment_date']) && $data['Incentive']['payment_date'] != ''){
                return date("d/m/Y",strtotime($data['Incentive']['payment_date']));
            }else{
                return '';
            }
        }else{
            return '';
        }
    }             
}

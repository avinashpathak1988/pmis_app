<?php
App::uses('AppControler','Controller');

class MenusController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
    $datas=$this->Menu->find('all',array(
      'order'=>array(
        'Menu.name'
      )
    ));
    $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
    if($this->Menu->save($this->request->data)){
      $this->message('success','Saved Successfully !');
      $this->redirect(array('action'=>'index'));
    }else{
      $this->message('error','Saving Failed !');
    }
  }
  $is_enable=array(
    '0'=>'In Active',
    '1'=>'Active'
  );
  $this->set(compact('is_enable'));
}

public function edit($id){
	if($this->request->is(array('post','put'))){
		if($this->Menu->save($this->request->data)){
			$this->message('success','Saved Successfully !');
			$this->redirect(array('action'=>'index'));
		}else{
			$this->message('error','Saving Failed !');
		}
	}
	$this->request->data=$this->Menu->findById($id);
	$is_enable=array(
		'0'=>'In Active',
		'1'=>'Active'
	);
	$this->set(compact('is_enable'));
}

public function delete($id){
	$this->Menu->delete($id);
	$this->message('success','Deleted Successfully !');
	$this->redirect(array('action'=>'index'));
}

}

<?php
App::uses('AppControler','Controller');

class IncentivesController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

	public function beforeFilter(){
		$this->response->disableCache();
		if($this->Session->read('user_auth') == ''){
			$this->redirect(array(
				'controller'=>'dashboard',
				'action'=>'login'
			));
		}
	}

public function index(){
    $this->loadModel('District');
    $this->loadModel('Project');
    $this->loadModel('Awc');
    $this->loadModel('Pregnency');
    $this->loadModel('Worker');
    $this->loadModel('Incentive');
    $this->Pregnency->recursive=2;
    $cond = array();
    $datas = array();
    if($this->request->is(array('post','put'))){
      if($this->request->data['approve']=='approve'){
        $datas=$this->Pregnency->find('all',array(
          'conditions'=>array(
            'Pregnency.is_exit'=>1
          ),
          'order'=>array(
            'Pregnency.exit_date'=>'DESC'
          ),
        ));

            foreach($datas as $data){
              $if_exists=$this->Incentive->find('count',array(
                'conditions'=>array(
                  'Incentive.pregnency_id'=>$data['Pregnency']['id'],
                  'Incentive.beneficiary_id'=>$data['Beneficiary']['id']
                )
              ));
              if($if_exists <= 0){
                    if($data['Pregnency']['is_exit'] == 1){
                      $this->request->data['Incentive']['beneficiary_id']=$data['Beneficiary']['id'];
                      $this->request->data['Incentive']['pregnency_id']=$data['Pregnency']['id'];
                      $this->request->data['Incentive']['is_paid']=0;
                      $this->request->data['Incentive']['paid_status']='';
                      $this->request->data['Incentive']['bank_tran_no']='';
                      $this->request->data['Incentive']['bank_remark']='';
                      $workers=$this->Worker->find('first',array(
                        'conditions'=>array(
                          "Worker.id in(select worker_id from beneficiaries where id='".$data['Beneficiary']['id']."')"
                        ),
                      ));
                      $worker_id="";
                      $worker_id=$workers['Worker']['id'];
                      if($worker_id != ''){
                        $this->request->data['Incentive']['worker_id']=$worker_id;
                        $this->request->data['Incentive']['amount']=200;
                        $this->Incentive->create();
                        $this->Incentive->save($this->request->data);
                      }

                      $workers=$this->Worker->find('first',array(
                        'conditions'=>array(
                          "Worker.id in(select helper_id from beneficiaries where id='".$data['Beneficiary']['id']."')"
                        ),
                      ));
                      $worker_id="";
                      $worker_id=$workers['Worker']['id'];
                      if($worker_id != ''){
                        $this->request->data['Incentive']['worker_id']=$worker_id;
                        $this->request->data['Incentive']['amount']=100;
                        $this->Incentive->create();
                        $this->Incentive->save($this->request->data);
                      }


                    }
              }

            }
  $this->message('success','Incentives Approved Successfully !');
      }
      //////////////////////////////////////////////////
      $user = $this->Session->read('user_auth');
      $project_id = $user['Project']['id'];

      $datas=$this->Pregnency->find('all',array(
        'conditions'=>array(
          'Pregnency.is_exit'=>1,
          "Pregnency.user_id IN (SELECT id FROM users WHERE project_id=$project_id)",
        ),
        'order'=>array(
          'Pregnency.exit_date'=>'DESC'
        ),
      ));
    }
    /** 
      * By : Tanmaya 
      * Purpose : Pre select District Name.
      */
	$currsess = $this->Session->read('user_auth');  
    if(isset($currsess['District']['id']) && $currsess['District']['id']!=''){
      $cond += array('District.id' => $currsess['District']['id']);
    }
    $district_id=$this->District->find('list',array(
      'conditions' => $cond,
      'order'=>array(
        'District.name'
      )
    ));

    $project_id="";
    $awc_id="";
    $bank_type=array(
      'NSBI'=>'NSBI',
      'SBI'=>'SBI'
    );
    $exit_reason=array(
      'MATERNAL DEATH'=>'MATERNAL DEATH',
      'INFANT DEATH'=>'INFANT DEATH',
      'MISCARRIAGE'=>'MISCARRIAGE',
      'STILL BIRTH'=>'STILL BIRTH',
      'MIGRATION'=>'MIGRATION'
    );
    $this->set(compact('district_id','project_id','awc_id','bank_type','exit_reason', 'datas'));
}

public function loadprojects($id){
  $this->layout=NULL;
  $this->loadModel('Project');
  $project_id=$this->Project->find('list',array(
    'conditions'=>array(
      'Project.district_id'=>$id
    ),
    'order'=>array(
      'Project.name'
    )
  ));
  $this->set(compact('project_id'));
}

public function loadawcs($id){
  $this->layout=NULL;
  $this->loadModel('Awc');
  $awc_id=$this->Awc->find('list',array(
    'conditions'=>array(
      'Awc.project_id'=>$id
    ),
    'order'=>array(
      'Awc.name'
    )
  ));
  $this->set(compact('awc_id'));
}

}

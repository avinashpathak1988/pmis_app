<?php
App::uses('AppController', 'Controller');
class ReportsController extends AppController

{
	public $components = array(
		'Paginator',
		'Flash',
		'Session'
	);
	public $uses = array('User');
	public function beforeFilter(){
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}
		$this->set('funcall',$this);
	}
	public function add_failure_to_payment()
	{		
		$this->autoRender = false;
		$this->loadModel('Payment');
		$this->loadModel('Pinstallment');
		$this->loadModel('Beneficiary');
		$this->loadModel('User');
		$this->loadModel('Branch');

		$pinst = $this->Pinstallment->find('all', array(
			'conditions' => array(
				'is_paid' => 2
			)
		));
		foreach ($pinst as $data) {
			$benDetails = $this->Beneficiary->findById($data['Pinstallment']['beneficiary_id']);
		
      //@@ GET BRANCH DETAILS
      $getBraDetails = $this->Branch->findById($benDetails['Beneficiary']['branch_id']);

		  $this->request->data['Payment']['beneficiary_id'] = $data['Pinstallment']['beneficiary_id'];
	      $this->request->data['Payment']['name'] = $benDetails['Beneficiary']['name'];
	      $this->request->data['Payment']['mail_id'] = $benDetails['Beneficiary']['mail_id'];
	      $this->request->data['Payment']['mobile_no'] = $benDetails['Beneficiary']['mobile_no'];
	      $this->request->data['Payment']['pregnency_id'] = $data['Pinstallment']['pregnency_id'];
	      $this->request->data['Payment']['installment_no'] = $data['Pinstallment']['installment_no'];
	      $this->request->data['Payment']['pinstallment_id'] = $data['Pinstallment']['id'];
	      $this->request->data['Payment']['amount'] = '3000';
	      $this->request->data['Payment']['instrument_date'] = $data['Pinstallment']['installment_date'];
	      $this->request->data['Payment']['request_date'] = $data['Pinstallment']['installment_date'];
	      $this->request->data['Payment']['is_approved'] =$data['Pinstallment']['is_payment_approve'];
	      $this->request->data['Payment']['is_paid'] = $data['Pinstallment']['is_paid'];
	      $this->request->data['Payment']['user_id'] = $data['Pinstallment']['approved_by'];
	      $this->request->data['Payment']['file_name'] = 'XYZ';
	      $this->request->data['Payment']['branch_name'] = $getBraDetails['Branch']['name'];
	      $this->request->data['Payment']['ifsc'] = $getBraDetails['Branch']['ifsc'];
	      $this->request->data['Payment']['account_no'] = $benDetails['Beneficiary']['account_no'];
	      $this->request->data['Payment']['uuid'] = '';
	      $this->request->data['Payment']['payment_date'] = $data['Pinstallment']['payment_date'];
	      $this->request->data['Payment']['payment_status'] = $data['Pinstallment']['payment_status'];
	      $this->request->data['Payment']['bankremark'] = $data['Pinstallment']['bankremark'];
	      $this->request->data['Payment']['created'] = $data['Pinstallment']['created'];
	      $this->request->data['Payment']['modified'] = $data['Pinstallment']['modified'];

	      debug($this->request->data['Payment']);
	      $this->Payment->create();
	      $this->Payment->save($this->request->data['Payment']);
		}
	}

	public function ben_payment_recv_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$datas = array();
		$user = $this->Session->read('user_auth');
		
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$this->request->data['Report']['is_paid'] = '1';
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$is_paid = array(
			'1' => 'Success',
			'2' => 'Failed'
		);
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'is_paid', 'installment_no'));
	}
	public function ben_payment_recv_report_ajax()
	{	
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$datas = array();
		$user = $this->Session->read('user_auth');
		
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		$is_paid = '';
		$installment_no = '';
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$to_date = '';
		$from_date = '';

		$sql = "";
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->params['named']['rch_mcts_no'] . "'";
		}

		$sql_account_no = "";
		if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
			$account_no = $this->params['named']['account_no'];
			$sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
		}
		//Added 
		$sql_district_id = "";
		if ($this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}
		//Added
		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}
		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id='" . $this->params['named']['awc_id'] . "'";
		}

		$sql_is_paid = "";
		if (isset($this->params['named']['is_paid']) && $this->params['named']['is_paid'] != '') {
			$is_paid = $this->params['named']['is_paid'];
			$sql_is_paid = "Pinstallment.is_paid='" . $this->params['named']['is_paid'] . "'";
		}

		$sql_installment_no = "";
		if (isset($this->params['named']['installment_no']) &&  $this->params['named']['installment_no'] != '') {
			$installment_no = $this->params['named']['installment_no'];
			$sql_installment_no = "Pinstallment.installment_no='" . $this->params['named']['installment_no'] . "'";
		}

		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pinstallment.payment_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pinstallment.payment_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
		}
		/*$sql_date = "";
		if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$from_date = explode('/', $from_date);
			$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
			$to_date = $this->params['named']['to_date'];
			$to_date = explode('/', $to_date);
			$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
			$sql_date = "Pinstallment.payment_date between '" . $from_date . "' and '" . $to_date . "'";
		}
*/
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
        }

        //echo "##".$sql_name;
	    $this->paginate = array(
	            'conditions' => array(
					$sql,
					"(Pinstallment.is_paid = 1 OR Pinstallment.is_paid = 2)",
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_is_paid,
					$sql_installment_no,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pinstallment.id'
				)
        )+$limit;
        $datas = $this->paginate('Pinstallment');
  		
  		/*$log = $this->Pinstallment->getDataSource()->getLog(false, false);
		debug($log);*/


		$this->set(compact('datas', 'sql', 'sql_name', 'sql_rch_mcts_no', 'sql_account_no', 'sql_district_id', 
					'sql_project_id', 'sql_sector_id', 'sql_is_paid', 'sql_awc_id', 'sql_approve_status', 'sql_date', 'to_date', 'from_date',
					'district_id', 'project_id', 'sector_id', 'awc_id', 'is_paid', 'installment_no', 'name',
					'rch_mcts_no', 'account_no'));
			
	}

	// ///////////////////////////////////

	public function ben_preg_report()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');

		$project_id = '';
		$sector_id = '';
		$awc_id = '';


 		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$sql = "";
			if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			$sql_name = "";
			if ($this->request->data['Report']['name'] != '') {
				$sql_name = "Beneficiary.name='" . $this->request->data['Report']['name'] . "'";
			}

			$sql_rch_mcts_no = "";
			if ($this->request->data['Report']['rch_mcts_no'] != '') {
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->request->data['Report']['rch_mcts_no'] . "'";
			}

			$sql_district_id = "";
			if ($this->request->data['Report']['district_id'] != '') {
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->request->data['Report']['district_id'] . "')";
			}

			$sql_project_id = "";
			if ($this->request->data['Report']['project_id'] != '') {
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->request->data['Report']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if ($this->request->data['Report']['sector_id'] != '') {
				$sql_sector_id = "Beneficiary.sector_id='" . $this->request->data['Report']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if ($this->request->data['Report']['awc_id'] != '') {
				$sql_awc_id = "Beneficiary.awc_id='" . $this->request->data['Report']['awc_id'] . "'";
			}

			$sql_outcome = "";
			if ($this->request->data['Report']['outcome'] != '') {
				$sql_outcome = "Delivery.outcome='" . $this->request->data['Report']['outcome'] . "'";
			}

			$sql_gender = "";
			if ($this->request->data['Report']['gender'] != '') {
				$sql_gender = "Delivery.child1_gender='" . $this->request->data['Report']['outcome'] . "' or Delivery.child2_gender='" . $this->request->data['Report']['outcome'] . "'";
			}

			$sql_is_approved = "";
			if ($this->request->data['Report']['is_approved'] != '') {
				$sql_is_approved = "Pregnency.is_approved=" . $this->request->data['Report']['is_approved'];
			}

			$sql_date = "";
			if ($this->request->data['Report']['from_date'] != '' && $this->request->data['Report']['to_date'] != '') {
				$from_date = $this->request->data['Report']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->request->data['Report']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
				$sql_date = "Pregnency.preg_reg_date between '" . $from_date . "' and '" . $to_date . "'";
			}

			$datas = $this->Pregnency->find('all', array(
				'conditions' => array(
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_sector_id,
					$sql_awc_id,
					$sql_outcome,
					$sql_gender,
					$sql_is_approved,
					$sql_date
				) ,
			));
			$this->set(compact('datas'));
		}
				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$cond1 = "";
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$cond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
		}

		$sector_id = $this->Sector->find('list', array(
			'conditions' => array(
				$cond1
			) ,
			'order' => array(
				'Sector.name'
			)
		));
		$awc_id = "";*/
		$outcome = array(
			'Still Birth' => 'Still Birth',
			'Single Live Birth' => 'Single Live Birth',
			'Twin Live Birth' => 'Twin Live Birth'
		);
		$gender = array(
			'Male' => 'Male',
			'Female' => 'Female'
		);
		$is_approved = array(
			'0' => 'No',
			'1' => 'Yes'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'outcome', 'gender', 'is_approved'));
	}

	// ///////////////////////////////////

	public function ben_preg_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$name 			= '';
		$rch_mcts_no 	= '';
		$sector_id 		= '';
		$awc_id  		= '';
		$outcome 		= '';
		$gender 		= '';
		$is_approved 	= '';
		$from_date  	= '';
		$to_date		= '';
		$sql 			= "";
		$project_id = $user['Project']['id'];
		//debug($this->params['named']);
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}
		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $name . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $rch_mcts_no . "'";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $sector_id . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id='" . $awc_id . "'";
		}

		$sql_outcome = "";
		if (isset($this->params['named']['outcome']) && $this->params['named']['outcome'] != '') {
			$outcome = $this->params['named']['outcome'];
			$sql_outcome = "Delivery.outcome='" . $outcome . "'";
		}

		$sql_gender = "";
		if ($this->params['named']['gender'] != '') {
			$gender = $this->params['named']['gender'];
			$sql_gender = "Delivery.child1_gender='" . $gender . "' or Delivery.child2_gender='" . $gender . "'";
		}

		$sql_is_approved = "";
		if ($this->params['named']['is_approved'] != '') {
			$is_approved = $this->params['named']['is_approved'];
			$sql_is_approved = "Pregnency.is_approved=" . $is_approved;
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pregnency.preg_reg_date >=" . date("Y-m-d",strtotime(str_replace("/", "-", $from_date)));
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pregnency.preg_reg_date <=" . date("Y-m-d",strtotime(str_replace("/", "-", $to_date)));
		}

		$sql_date = ""; 
		if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$to_date = $this->params['named']['to_date'];
			$sql_date = "Pregnency.preg_reg_date between '" . date('Y-m-d', strtotime($from_date)) . "' and '" . date('Y-m-d', strtotime($to_date)) . "'";
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls';
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','beneficiary_pregnancy_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','beneficiary_pregnancy_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		}

		$this->paginate = array(
			'conditions' => array(
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
				$sql,
				$sql_name,
				$sql_rch_mcts_no,
				$sql_district_id,
				$sql_project_id,
				$sql_sector_id,
				$sql_awc_id,
				$sql_outcome,
				$sql_gender,
				$sql_is_approved,
				$sql_date
			) ,
			'maxLimit' => 1000,
		)+$limit;
		$datas = $this->paginate('Pregnency');
		$this->set(compact('datas', 'sql', 'sql_name', 'sql_rch_mcts_no', 'sql_sector_id', 'sql_awc_id'));
		$this->set(compact('sql_outcome', 'sql_district_id', 'sql_district_id', 'sql_gender', 'sql_is_approved', 'sql_date', 'name', 'rch_mcts_no', 'sector_id', 'awc_id', 'outcome', 'gender', 'is_approved', 'from_date', 'to_date'));
	}

	// ///////////////////////////////////

	public function loadawcs($id='')
	{
		$this->layout = NULL;
		$this->loadModel('Awc');
		$awc_id = $this->Awc->find('list', array(
			'conditions' => array(
				'Awc.sector_id' => $id
			) ,
			'order' => array(
				'Awc.name'
			)
		));
		$this->set(compact('awc_id'));
	}

	public function loadprojects($id='')
	{
		$this->layout = NULL;
		$this->loadModel('Project');
		$user = $this->Session->read('user_auth');
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "Project.id='" . $user['Project']['id'] . "'";
		}
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "Project.district_id='" . $user['District']['id'] . "'";
		}

		$project_id = $this->Project->find('list', array(
			'conditions' => array(
				$sql_cond1,
				'Project.district_id' => $id
			) ,
			'order' => array(
				'Project.name'
			)
		));
		$this->set(compact('project_id'));
	}
	public function getProjects(){
		$this->autoRender = false;
		if(isset($this->data['district_id']) && (int)$this->data['district_id'] != 0){
			$this->loadModel('Project');
			$data = $this->Project->find('list', array(
				'conditions' => array(
					'Project.district_id' => $this->data['district_id'],
				) ,
				'order' => array(
					'Project.id',
					'Project.name',
				)
			));	
			if(is_array($data) && count($data)>0){
				echo '<option value="">-- Select Project Location --</option>';
				foreach($data as $key=>$val){
					echo '<option value="'.$key.'">'.$val.'</option>';
				}
			}else{
				echo '<option value="">-- Select Project Location --</option>';
			}	
		}else{
			echo '<option value="">-- Select Project Location --</option>';
		}
	}
	public function getsectors(){
		$this->autoRender = false;
		if(isset($this->data['project_id']) && (int)$this->data['project_id'] != 0){
			$this->loadModel('Sector');
			$data = $this->Sector->find('list', array(
				'recursive'		=> -1,
				'conditions' 	=> array(
					'Sector.project_id' => $this->data['project_id']
				),
				'fields'		=> array(
					'Sector.id',
					'Sector.name',
				),
				'order' 		=> array(
					'Sector.name'
				)
			));	
			if(is_array($data) && count($data)>0){
				echo '<option value="">-- Select Sector --</option>';
				foreach($data as $key=>$val){
					echo '<option value="'.$key.'">'.$val.'</option>';
				}
			}else{
				echo '<option value="">-- Select Sector --</option>';
			}
		}else{
			echo '<option value="">-- Select Sector --</option>';
		}	
	}
	public function getawcs(){
		$this->autoRender = false;
		if(isset($this->data['sector_id']) && (int)$this->data['sector_id'] != 0){
			$this->loadModel('Awc');
			$data = $this->Awc->find('list', array(
				'conditions' => array(
					'Awc.sector_id' => $this->data['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
			if(is_array($data) && count($data)>0){
				echo '<option value="">-- Select AWC --</option>';
				foreach($data as $key=>$val){
					echo '<option value="'.$key.'">'.$val.'</option>';
				}				
			}else{	
				echo '<option value="">-- Select AWC --</option>';
			}
		}else{
			echo '<option value="">-- Select AWC --</option>';
		}
	}
	public function loadsectors($id=''){
		$this->layout = NULL;
		$this->loadModel('Sector');
		$sector_id = $this->Sector->find('list', array(
			'conditions' => array(
				'Sector.project_id' => $id
			) ,
			'order' => array(
				'Sector.name'
			)
		));
		$this->set(compact('sector_id'));
	}
	public function loadawcs1($id=''){
		$this->layout = NULL;
		$this->loadModel('Awc');
		$awc_id = $this->Awc->find('list', array(
			'conditions' => array(
				'Awc.sector_id' => $id
			) ,
			'order' => array(
				'Awc.name'
			)
		));
		$this->set(compact('awc_id'));
	}
	// //////////////////////////////////////////
	public function ben_exit_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$datas = array();
		$project_id = '';
		$sector_id = '';
		$awc_id = '';

		
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$exit_reason = array(
			'MATERNAL DEATH' => 'MATERNAL DEATH',
			'INFANT DEATH' => 'INFANT DEATH',
			'MISCARRIAGE' => 'MISCARRIAGE',
			'STILL BIRTH' => 'STILL BIRTH',
			'MIGRATION' => 'MIGRATION',
			'AUTO' => 'ALL DUE PAID'
		);
		$this->set(compact('district_id', 'project_id', 'awc_id', 'sector_id', 'exit_reason', 'datas'));
	}

	public function ben_exit_report_ajax()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$datas = array();
		$this->layout = 'ajax';
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$exit_reason='';
		$from_date='';
		$to_date = '';
		$account_no = '';

			$sql = "";
			if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->params['named']['rch_mcts_no'] . "'";
			}


			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}


			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Pregnency.exit_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Pregnency.exit_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}
			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
			}
			$sql_exit_reason = "";
			if (isset($this->params['named']['exit_reason']) && $this->params['named']['exit_reason'] != '') {
				$exit_reason = $this->params['named']['exit_reason'];
				$sql_exit_reason = "Pregnency.exit_reason='" . $this->params['named']['exit_reason'] . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

			$this->paginate = array(
				'conditions' => array(
					'Pregnency.is_exit' => 1,
					'Beneficiary.husband_govt' => 'No',
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_account_no,
					$sql_exit_reason,
					$sql_to_date,
					$sql_from_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				)
	        )+$limit;

	        $datas = $this->paginate('Pregnency');

			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no'			=> $rch_mcts_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'account_no'			=> $account_no,
				'exit_reason'			=> $exit_reason,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
		

	}
	// ///////////////////////////////////////////
	public function ben_due_details(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		
				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		
		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/

		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$exit_status = array(
			'0' => 'Not Exited',
			'1' => 'Exited'
		);
		$this->set(compact('district_id' , 'project_id', 'sector_id', 'awc_id', 'installment_no', 'exit_status'));
	}
	// ////////////////////////////////////////////////
	public function ben_due_details_ajax(){
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user 			= $this->Session->read('user_auth');
		$sql 			= "";
		$name 			= '';
		$rch_mcts_no 	= '';
		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$account_no 	= '';
		$installment_no = '';
		$is_exit 		= '';
		$from_date 		= '';
		$to_date		= '';
		//debug($this->params['named']);
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $name . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $rch_mcts_no . "'";
		}
		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}
		$sql_sector_id = "";
		if ($this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $sector_id . "'";
		}

		$sql_awc_id = "";
		if ($this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id='" . $awc_id . "'";
		}

		$sql_account_no = "";
		if ($this->params['named']['account_no'] != '') {
			$account_no = $this->params['named']['account_no'];
			$sql_account_no = "Beneficiary.account_no='" . $account_no . "'";
		}

		$sql_installment_no = "";
		if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
			$installment_no = $this->params['named']['installment_no'];
			$sql_installment_no = "Pregnency.id in(select pregnency_id from pinstallments where installment_no='".$installment_no."')";
		}

		$sql_exit_status = "";
		if (isset($this->params['named']['is_exit']) && $this->params['named']['is_exit'] != '') {
			$is_exit = $this->params['named']['is_exit'];
			$sql_exit_status = "Pregnency.is_exit='" . $is_exit . "'";
		}

		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
		}

		/*$sql_date = "";  
		if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {
			$from_date = $this->request->data['Report']['from_date'];
			$to_date = $this->request->data['Report']['to_date'];
			$sql_date = "Pregnency.id in(select pregnency_id from pinstallments where installment_date between '" . date("Y-m-d",strtotime(str_replace("/", "-", $from_date))) . "' and '" . date("Y-m-d",strtotime(str_replace("/", "-", $to_date))) . "')";
		}*/
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls'; ///exit;
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','beneficiary_due_details_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','beneficiary_due_details_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		} 


		$this->paginate = array(
			'conditions' => array(
				"Pregnency.is_approved" => 1,
				$sql,
				$sql_name,
				$sql_rch_mcts_no,
				$sql_district_id,
				$sql_project_id,
				$sql_sector_id,
				$sql_awc_id,
				$sql_account_no,
				$sql_installment_no,
				$sql_exit_status,
				$sql_from_date,
				$sql_to_date
			) ,
			'order' => array(
				'Pregnency.preg_reg_date'
			) ,
		)+$limit;
		$datas = $this->paginate('Pregnency');
		$this->set(compact('datas'));
		$this->set(compact('sql', 'sql_name', 'sql_rch_mcts_no', 'sql_sector_id', 'sql_awc_id', 'sql_account_no'));
		$this->set(compact('sql_installment_no', 'sql_exit_status', 'name', 'rch_mcts_no', 'district_id', 'project_id', 'sector_id', 'awc_id', 'account_no', 'installment_no', 'is_exit', 'from_date', 'to_date'));

	}

	// ////////////////////////////////////////////////

	public function ben_in_scheme_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$datas = array();
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';

				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'awc_id', 'installment_no', 'sector_id', 'datas'));
	}

	public function ben_in_scheme_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');

		$name 			= '';
		$rch_mcts_no 	= '';
		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$account_no 	= '';
		$installment_no = '';
		//$is_exit 		= '';
		$from_date 		= '';
		$to_date		= '';

			$sql = "";
			if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}	

		
			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}
			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date'])))  . "'";
			}

			$sql_account_no = "";
			if ($this->params['named']['account_no'] != '') {
				$sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
			}

			$sql_installment_no = "";
			if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
				$installment_no = $this->params['named']['installment_no'];
				$sql_installment_no = "Beneficiary.id in(select beneficiary_id from pinstallments where installment_no='" . $this->params['named']['installment_no'] . "')";
			}

			/*$sql_date = "";
			if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->params['named']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
				$sql_date = "Pregnency.id in(select pregnency_id from pinstallments where installment_date between '" . $from_date . "' and '" . $to_date . "')";
			}*/

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 10,'maxLimit'   => 10);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

	        $this->paginate = array(
				'recursive' => 2,
	            'conditions'    => array(
					$sql,
					"Beneficiary.husband_govt" => 'No',
					"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
					$sql_name,
					$sql_district_id,
					$sql_project_id,
					$sql_rch_mcts_no,
					$sql_sector_id,
					$sql_awc_id,
					$sql_account_no,
					$sql_installment_no,
					$sql_from_date,
					$sql_to_date
					
				),
	            //'limit'         => 10,
	            'order' => array(
					'Beneficiary.created'
				)
        )+$limit;
        $datas = $this->paginate('Beneficiary');

		$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'installment_no'		=> $installment_no,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}

	//PVTG REPORT START
	public function ben_pvtg_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$datas = array();
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';

				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'awc_id', 'installment_no', 'sector_id', 'datas'));
	}

	public function ben_pvtg_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');

		$name 			= '';
		$rch_mcts_no 	= '';
		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$account_no 	= '';
		$installment_no = '';
		//$is_exit 		= '';
		$from_date 		= '';
		$to_date		= '';

			$sql = "";
			if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}	

		
			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}
			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date'])))  . "'";
			}

			$sql_account_no = "";
			if ($this->params['named']['account_no'] != '') {
				$sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
			}

			$sql_installment_no = "";
			if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
				$installment_no = $this->params['named']['installment_no'];
				$sql_installment_no = "Beneficiary.id in(select beneficiary_id from pinstallments where installment_no='" . $this->params['named']['installment_no'] . "')";
			}

			/*$sql_date = "";
			if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->params['named']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
				$sql_date = "Pregnency.id in(select pregnency_id from pinstallments where installment_date between '" . $from_date . "' and '" . $to_date . "')";
			}*/

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 10,'maxLimit'   => 10);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

	        $this->paginate = array(
				'recursive' => 2,
	            'conditions'    => array(
					$sql,
					"Beneficiary.husband_govt" => 'No',
					"Beneficiary.is_pvtg" => 'Y',
					$sql_name,
					$sql_district_id,
					$sql_project_id,
					$sql_rch_mcts_no,
					$sql_sector_id,
					$sql_awc_id,
					$sql_account_no,
					$sql_installment_no,
					$sql_from_date,
					$sql_to_date
					
				),
	            //'limit'         => 10,
	            'order' => array(
					'Beneficiary.created'
				)
        )+$limit;
        $datas = $this->paginate('Beneficiary');

		$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'installment_no'		=> $installment_no,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}
	//PVTG REPORT END

	// //////////////////////////////////////////////////////////////////////

	public function ben_tran_fail_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		$datas = array();


				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'awc_id', 'installment_no', 'sector_id', 'datas'));
	}

	public function ben_tran_fail_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$installment_no = '';
		$from_date = '';
		$to_date = '';

		$sql = "";
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$sql_file_name = "";
		if (isset($this->params['named']['file_name']) && $this->params['named']['file_name'] != '') {
			$file_name = $this->params['named']['file_name'];
			$sql_file_name = "Payment.file_name='" . $this->request->data['Report']['file_name'] . "'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
		}
		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
		}

		$sql_installment_no = "";
		if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
			$installment_no = $this->params['named']['installment_no'];
			$sql_installment_no = "Payment.installment_no='" . $this->params['named']['installment_no'] . "'";
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
        }

		$this->paginate = array(
			'recursive' => 2,
			'conditions' => array(
				$sql,
				'Payment.is_paid' => 2,
				$sql_district_id,
				$sql_project_id,
				$sql_file_name,
				$sql_rch_mcts_no,
				$sql_sector_id,
				$sql_awc_id,
				$sql_installment_no,
				$sql_from_date,
				$sql_to_date
			) ,
			'order' => array(
				'Payment.id'
			)
        )+$limit;

        $datas = $this->paginate('Payment');

		$this->set(compact('datas'));
		$this->set(array(
			'name' 					=> $name,
			'rch_mcts_no' 			=> $rch_mcts_no,
			'account_no'			=> $account_no,
			'district_id'			=> $district_id,
			'project_id'			=> $project_id,
			'sector_id'				=> $sector_id,
			'awc_id'				=> $awc_id,
			'installment_no'		=> $installment_no,
			'from_date'				=> $from_date,
			'to_date'				=> $to_date
		));
	}
	// ///////////////////////////////////////////////////////////////

	public function ben_payment_pending_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$datas = array();
		
		$project_id = '';
		$sector_id = '';
		$awc_id = '';

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'awc_id', 'installment_no', 'sector_id', 'datas'));
	}

	public function ben_payment_pending_report_ajax()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');

		$name 			= '';
		$rch_mcts_no 	= '';
		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$account_no 	= '';
		$installment_no = '';
		$is_exit 		= '';
		$from_date 		= '';
		$to_date		= '';

		$this->layout = 'ajax';
		$sql = "";
		if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->params['named']['rch_mcts_no'] . "'";
		}
		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}
		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id='" . $this->params['named']['awc_id'] . "'";
		}

		$sql_installment_no = "";
		if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
			$installment_no = $this->params['named']['installment_no'];
			$sql_installment_no = "Pinstallment.installment_no='" . $this->params['named']['installment_no'] . "'";
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pinstallment.approved_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pinstallment.approved_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
		}


		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls'; //exit;
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','beneficiary_due_details_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','beneficiary_due_details_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		} 

		$this->paginate = array(
			'recursive' => 2,
			'conditions' => array(
				$sql,
				//'Pinstallment.is_payment_approve' => 1,
				'Pregnency.is_approved' => 1,
				'Pinstallment.is_paid' => 0,
				$sql_name,
				$sql_rch_mcts_no,
				$sql_district_id,
				$sql_project_id,
				$sql_sector_id,
				$sql_awc_id,
				$sql_installment_no,
				$sql_from_date,
				$sql_to_date
			) ,
			'order' => array(
				'Pinstallment.payment_date'
			),
			//'limit' => 50
		)+$limit;
		$datas = $this->paginate('Pinstallment');
		//debug($datas);
		$this->set(compact('datas'));
		//$this->set(compact('sql', 'sql_name', 'sql_rch_mcts_no', 'sql_sector_id', 'sql_awc_id', 'sql_account_no'));
		$this->set(compact('sql_installment_no', 'sql_date', 'name', 'rch_mcts_no', 'district_id', 'project_id', 'sector_id', 'awc_id', 'account_no', 'installment_no', 'is_exit', 'from_date', 'to_date'));

	}
	// /////////////////////////////////////

	public function dist_wise_exit_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		

		$district_id = $this->District->find('list', array(
			'order' => array(
				'District.name'
			)
		));
		$this->set(compact('district_id'));
	}
	public function dist_wise_exit_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$user = $this->Session->read('user_auth');
		$district_id = '';
		$from_date = '';
		$to_date = '';
		$sql_from_date= '';
		$sql_to_date = '';

		$sql = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql = "District.id='" . $this->params['named']['district_id'] . "'";
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
		}

		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 2);
        }
		$datas = $this->District->find('all', array(
			'conditions' => array(
				$sql,
			) ,
			'order' => array(
				'District.name'
			)
		));
		$this->set(compact('datas'));
		$this->set(array(
			'district_id'			=> $district_id,
			'from_date'				=> $from_date,
			'to_date'				=> $to_date,
			'sql_from_date' 		=> $sql_from_date,
			'sql_to_date' 		=> $sql_to_date,
		));
	
	}
	// ////////////////////////////

	public function dist_wise_inc_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$sql = "";
			if ($this->request->data['Report']['district_id'] != '') {
				$sql = "District.id='" . $this->request->data['Report']['district_id'] . "'";
			}

			$datas = $this->District->find('all', array(
				'conditions' => array(
					$sql,
				) ,
				'order' => array(
					'District.name'
				)
			));
			$this->set(compact('datas'));
		}

		$district_id = $this->District->find('list', array(
			'order' => array(
				'District.name'
			)
		));
		$from_date = "";
		$to_date = "";
		if ($this->request->data['Report']['from_date'] != '' && $this->request->data['Report']['to_date'] != '') {
			$from_date = $this->request->data['Report']['from_date'];
			$from_date = explode('/', $from_date);
			$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
			$to_date = $this->request->data['Report']['to_date'];
			$to_date = explode('/', $to_date);
			$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
		}

		$this->set(compact('district_id', 'from_date', 'to_date'));
	}

	// ////////////////////////////////////////////////////

	public function proj_wise_pstat_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$datas = array();
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$sql_district_id = "";
			if ($this->request->data['Report']['district_id'] != '') {
				$sql_district_id = "District.id='" . $this->request->data['Report']['district_id'] . "'";
			}

			$sql_project_id = "";
			if ($this->request->data['Report']['project_id'] != '') {
				$sql_project_id = "Project.id='" . $this->request->data['Report']['project_id'] . "'";
			}

			$datas = $this->Project->find('all', array(
				'conditions' => array(
					$sql_district_id,
					$sql_project_id,
				) ,
				'order' => array(
					'Project.name'
				) ,
			));


		}

				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/

		if (isset($this->request->data['Report']['from_date']) && $this->request->data['Report']['from_date'] != '' && isset($this->request->data['Report']['to_date']) && $this->request->data['Report']['to_date'] != '') {
			$from_date = $this->request->data['Report']['from_date'];
			$from_date = explode('/', $from_date);
			$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
			$to_date = $this->request->data['Report']['to_date'];
			$to_date = explode('/', $to_date);
			$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
		}

		$this->set(compact('district_id', 'from_date', 'to_date', 'project_id', 'datas'));
	}

	public function sector_wise_pstat_report(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$datas = array();
		if ($this->request->is(array('post', 'put'))) {
			$sql_district_id = "";
			if ($this->request->data['Report']['district_id'] != '') {
				$sql_district_id = "District.id='" . $this->request->data['Report']['district_id'] . "'";
			}

			$sql_project_id = "";
			if ($this->request->data['Report']['project_id'] != '') {
				$sql_project_id = "Project.id='" . $this->request->data['Report']['project_id'] . "'";
			}
			$sql_sector_id = "";
			if ($this->request->data['Report']['sector_id'] != '') {
				$sql_sector_id = "Sector.id='" . $this->request->data['Report']['sector_id'] . "'";
			}

			$datas = $this->Sector->find('all', array(
				'conditions' => array(
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id
				) ,
				'order' => array(
					'Sector.name'
				) ,
			));
			//debug($datas); exit;
			
		}

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/

		if (isset($this->request->data['Report']['from_date']) && $this->request->data['Report']['from_date'] != '' && isset($this->request->data['Report']['to_date']) && $this->request->data['Report']['to_date'] != '') {
			$from_date = $this->request->data['Report']['from_date'];
			$from_date = explode('/', $from_date);
			$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
			$to_date = $this->request->data['Report']['to_date'];
			$to_date = explode('/', $to_date);
			$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
		}

		$this->set(compact('district_id', 'from_date', 'to_date', 'project_id', 'datas'));
	}

	// /////////////////////////////////////////////////

	public function proj_wise_exit_report()
		{
			$this->loadModel('Beneficiary');
			$this->loadModel('Payment');
			$this->loadModel('Pregnency');
			$this->loadModel('Pinstallment');
			$this->LoadModel('District');
			$this->LoadModel('Sector');
			$this->LoadModel('Awc');
			$this->LoadModel('Project');
			$this->LoadModel('Delivery');
			$this->LoadModel('Worker');
			$this->LoadModel('Incentive');
			$user = $this->Session->read('user_auth');
			$datas = array();
			if ($this->request->is(array('post', 'put'))) {
				$sql_district_id = "";
				if ($this->request->data['Report']['district_id'] != '') {
					$sql_district_id = "District.id='" . $this->request->data['Report']['district_id'] . "'";
				}

				$sql_project_id = "";
				if ($this->request->data['Report']['project_id'] != '') {
					$sql_project_id = "Project.id='" . $this->request->data['Report']['project_id'] . "'";
				}

				$sqlcond = "";
				if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'DPC') {
					$sqlcond = "District.id in(select district_id from users where user_id='" . $user['User']['user_id'] . "')";
				}

				if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
					$sqlcond = "Project.id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
				}

				$datas = $this->Project->find('all', array(
					'conditions' => array(
						$sqlcond,
						$sql_district_id,
						$sql_project_id,
					) ,
					'order' => array(
						'Project.name'
					) ,
				));
			}

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/


			if (isset($this->request->data['Report']['from_date']) && $this->request->data['Report']['from_date'] != '' && isset($this->request->data['Report']['to_date']) && $this->request->data['Report']['to_date'] != '') {
				$from_date = $this->request->data['Report']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->request->data['Report']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
			}

			$this->set(compact('district_id', 'from_date', 'to_date', 'project_id', 'datas'));
		}
	
	public function sector_wise_exit_report()
		{
			$this->loadModel('Beneficiary');
			$this->loadModel('Payment');
			$this->loadModel('Pregnency');
			$this->loadModel('Pinstallment');
			$this->LoadModel('District');
			$this->LoadModel('Sector');
			$this->LoadModel('Awc');
			$this->LoadModel('Project');
			$this->LoadModel('Delivery');
			$this->LoadModel('Worker');
			$this->LoadModel('Incentive');
			$user = $this->Session->read('user_auth');
			$datas = array();
			if ($this->request->is(array('post', 'put'))) {
				$sql_district_id = "";


				if ($this->request->data['Report']['district_id'] != '') {
					$sql_district_id = "dis.id='" . $this->request->data['Report']['district_id'] . "' AND ";
				}

				$sql_project_id = "";
				if ($this->request->data['Report']['project_id'] != '') {
					$sql_project_id = "pro.id='" . $this->request->data['Report']['project_id'] . "' AND ";
				}

				$sql_sector_id = "";
				if ($this->request->data['Report']['sector_id'] != '') {
					$sql_sector_id = "sec.id = ".$this->request->data['Report']['sector_id']." AND";
				}

				$sqlcond = "";
				if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'DPC') {
					$sqlcond = "District.id in(select district_id from users where user_id='" . $user['User']['user_id'] . "')";
				}

				if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
					$sqlcond = "Sector.id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
				}
				
				$datas = $this->Sector->query("SELECT bene.id, bene.name, dis.name, sec.id, sec.name AS sec_name, pro.name AS pro_name , COUNT(sec.name)  FROM pregnencies a
												LEFT JOIN beneficiaries bene ON a.beneficiary_id = bene.id
												LEFT JOIN sectors sec ON bene.sector_id = sec.id
												LEFT JOIN projects pro ON sec.project_id = pro.id
												LEFT JOIN districts dis ON pro.district_id = dis.id
												WHERE ".$sql_district_id.$sql_project_id.$sql_sector_id." a.is_exit =1
												GROUP BY sec.name");

				
				
				
			}

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/


			if (isset($this->request->data['Report']['from_date']) && $this->request->data['Report']['from_date'] != '' && isset($this->request->data['Report']['to_date']) && $this->request->data['Report']['to_date'] != '') {
				$from_date = $this->request->data['Report']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->request->data['Report']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
			}

			$this->set(compact('district_id', 'sector_id', 'project_id', 'from_date', 'to_date', 'project_id', 'datas'));
		}		

	public function proj_wise_inc_report(){
		$this->loadModel('District');
		$this->loadModel('Project');
		$auth = $this->Session->read('user_auth');
		$projectList 	= array();
		$projectCond 	= array();
		$distCondition 	= array();
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO' || $auth['Designation']['name'] == 'DPC'){
			$distCondition += array(
				'District.id'	=> $auth['District']['id'], 
			);
		}		
		$districtList = $this->District->find('list', array(
			'recursive'		=> -1,
			'conditions'	=> $distCondition,
			'fields' 		=> array(
				'District.id',
				'District.name'
			),
			'order'			=> array(
				'District.name',	
			),
		));
		if(is_array($districtList) && count($districtList) != 1){
			$districtList = array(''=>'-- Select District --')+$districtList;
		}
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO') {
			$projectCond += array(
				'Project.id'	=> $auth['Project']['id'], 
			);
		}
		if($auth['Designation']['name'] == 'DPC') {
			$projectCond += array(
				'Project.district_id'	=> $auth['District']['id'], 
			);			
		}
		if(is_array($projectCond) && count($projectCond)>0){
			$projectList = $this->Project->find('list', array(
				'recursive'		=> -1,
				'conditions'	=> $projectCond, 
				'fields' 		=> array(
					'Project.id',
					'Project.name'
				),
				'order'		=> array(
					'Project.name',
				),
			));
		}
		if(is_array($projectList) && count($projectList) != 1){
			$projectList = array(''=>'-- Select Project Location --')+$projectList;
		}		
		$this->set(compact('districtList', 'projectList'));
	}

	public function sector_wise_inc_report(){
		$this->loadModel('District');
		$this->loadModel('Project');
		$auth = $this->Session->read('user_auth');
		$projectList 	= array();
		$projectCond 	= array();
		$distCondition 	= array();
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO' || $auth['Designation']['name'] == 'DPC'){
			$distCondition += array(
				'District.id'	=> $auth['District']['id'], 
			);
		}		
		$districtList = $this->District->find('list', array(
			'recursive'		=> -1,
			'conditions'	=> $distCondition,
			'fields' 		=> array(
				'District.id',
				'District.name'
			),
			'order'			=> array(
				'District.name',	
			),
		));
		if(is_array($districtList) && count($districtList) != 1){
			$districtList = array(''=>'-- Select District --')+$districtList;
		}
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO') {
			$projectCond += array(
				'Project.id'	=> $auth['Project']['id'], 
			);
		}
		if($auth['Designation']['name'] == 'DPC') {
			$projectCond += array(
				'Project.district_id'	=> $auth['District']['id'], 
			);			
		}
		if(is_array($projectCond) && count($projectCond)>0){
			$projectList = $this->Project->find('list', array(
				'recursive'		=> -1,
				'conditions'	=> $projectCond, 
				'fields' 		=> array(
					'Project.id',
					'Project.name'
				),
				'order'		=> array(
					'Project.name',
				),
			));
		}
		if(is_array($projectList) && count($projectList) != 1){
			$projectList = array(''=>'-- Select Project Location --')+$projectList;
		}		
		$this->set(compact('districtList', 'projectList'));
	}
	public function sector_wise_inc_report_ajax(){
		$this->layout = 'ajax';
		$this->loadModel('Project');
		$this->loadModel('Sector');
		$condition   = array();
		$district_id = '';
		$sector_id  = '';
		$project_id  = '';
		$from_date   = '';
		$to_date     = '';
        if(isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != ''){
            $district_id = $this->params['named']['district_id'];
            $condition += array('Sector.district_id' => $district_id);
        }		
        if(isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != ''){
            $project_id = $this->params['named']['project_id'];
            $condition += array('Sector.project_id' => $project_id);
        }
        if(isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != ''){
            $sector_id = $this->params['named']['sector_id'];
            $condition += array('Sector.id' => $sector_id);
        }
        if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
            $from_date = $this->params['named']['from_date'];
        }
        if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
            $to_date = $this->params['named']['to_date'];
        }  
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls';
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','project_wise_awwawh_incentive_received_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','project_wise_awwawh_incentive_received_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		}                             
		$this->paginate = array(
			'conditions' 	=> $condition,
			'order' 		=> array(
				'Sector.name'
			),
		)+$limit;	
		$datas = $this->paginate('Sector');	
		debug($datas); exit;
		$this->set(array(
			'datas'			=> $datas,
			'project_id'	=> $project_id,
			'district_id'	=> $district_id,
			'sector_id'		=> $sector_id,
			'from_date'		=> $from_date,
			'to_date'		=> $to_date,
		));
	}
	public function proj_wise_inc_report_ajax(){
		$this->layout = 'ajax';
		$this->loadModel('Project');
		$condition   = array();
		$district_id = '';
		$project_id  = '';
		$from_date   = '';
		$to_date     = '';
        if(isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != ''){
            $district_id = $this->params['named']['district_id'];
            $condition += array('Project.district_id' => $district_id);
        }		
        if(isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != ''){
            $project_id = $this->params['named']['project_id'];
            $condition += array('Project.id' => $project_id);
        }
        if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
            $from_date = $this->params['named']['from_date'];
        }
        if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
            $to_date = $this->params['named']['to_date'];
        }  
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls';
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','project_wise_awwawh_incentive_received_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','project_wise_awwawh_incentive_received_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		}                             
		$this->paginate = array(
			'conditions' 	=> $condition,
			'order' 		=> array(
				'Project.name'
			),
		)+$limit;	
		$datas = $this->paginate('Project');	
		/*$log = $this->Project->getDataSource()->getLog(false, false);
		debug($log);*/
		$this->set(array(
			'datas'			=> $datas,
			'project_id'	=> $project_id,
			'district_id'	=> $district_id,
			'from_date'		=> $from_date,
			'to_date'		=> $to_date,
		));
	}
	// ///////////////////////////////

	public function dist_wise_payment_stat_report()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		$from_date = '';
		$to_date = '';

		$district_id = $this->District->find('list', array(
			'order' => array(
				'District.name'
			)
		));

		$this->set(compact('district_id', 'from_date', 'to_date', 'project_id' , 'sector_id' , 'awc_id'));
	}
	public function dist_wise_payment_stat_report_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$district_id = '';
		/*$project_id = '';
		$sector_id = '';
		$awc_id = '';*/
		$from_date = '';
		$to_date = '';

		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "District.id='" . $this->params['named']['district_id'] . "'";
		}
		/*$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
		}*/
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pregnency.preg_reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pregnency.preg_reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
		}

		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
        }

		$datas = $this->District->find('all', array(
			'conditions' => array(
				$sql_district_id,
			) ,
			'order' => array(
				'District.name'
			) ,
		));
		
		$this->set(compact('datas'));
		$this->set(array(
			'district_id'			=> $district_id,
			'from_date'				=> $from_date,
			'to_date'				=> $to_date,
			'sql_from_date'			=> $sql_from_date,
			'sql_to_date'			=> $sql_to_date,
			/*
			'sector_id'				=> $sector_id,
			'project_id'			=> $project_id,
			'awc_id'				=> $awc_id,
			'sql_project_id'		=> $sql_project_id,
			'sql_sector_id'			=> $sql_sector_id,
			'sql_awc_id'			=> $sql_awc_id*/
		));
		

	}

	// ///////////////////////////////////////////////////////////////

	public function ben_wise_inc_report(){
		$this->LoadModel('District');
		$this->LoadModel('Project');
		$auth = $this->Session->read('user_auth');
		$projectList 	= array();
		$sectorList 	= array();
		$awcList 		= array();	
		$distCondition  = array();
		$projectCond    = array();
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO' || $auth['Designation']['name'] == 'DPC'){
			$distCondition += array(
				'District.id'	=> $auth['District']['id'], 
			);
		}			
		$districtList = $this->District->find('list', array(
			'recursive'		=> -1,
			'fields'		=> array(
				'District.id',
				'District.name',
			),
			'conditions'	=> $distCondition,
			'order' 		=> array(
				'District.name'
			)
		));
		if(is_array($districtList) && count($districtList) != 1){
			$districtList = array(''=>'-- Select District --')+$districtList;
		}
		if($auth['Designation']['name'] == 'PA' || $auth['Designation']['name'] == 'CDPO') {
			$projectCond += array(
				'Project.id'	=> $auth['Project']['id'], 
			);
		}
		if($auth['Designation']['name'] == 'DPC') {
			$projectCond += array(
				'Project.district_id'	=> $auth['District']['id'], 
			);			
		}
		if(is_array($projectCond) && count($projectCond)>0){
			$projectList = $this->Project->find('list', array(
				'recursive'		=> -1,
				'conditions'	=> $projectCond, 
				'fields' 		=> array(
					'Project.id',
					'Project.name'
				),
				'order'		=> array(
					'Project.name',
				),
			));
		}
		if(is_array($projectList) && count($projectList) != 1){
			$projectList = array(''=>'-- Select Project Location --')+$projectList;
		}		
		$exitReason = array(
			'STILL BIRTH' 		=> 'STILL BIRTH',
			'MATERNAL DEATH' 	=> 'MATERNAL DEATH',
			'INFANT DEATH' 		=> 'INFANT DEATH',
			'MISCARRIAGE' 		=> 'MISCARRIAGE',
			'MIGRATION' 		=> 'MIGRATION'
		);
		$this->set(compact('districtList', 'projectList', 'sectorList', 'awcList', 'exitReason'));
	}
	public function ben_wise_inc_report_ajax(){
		$this->layout = 'ajax';
		$this->loadModel('Pregnency');
		$condition   = array('Pregnency.is_exit' => 1);
		$district_id = '';
		$project_id  = '';
		$from_date   = '';
		$to_date     = '';
		$name 		 = '';
		$rch_mcts_no = '';
		$sector_id 	 = '';
		$awc_id 	 = '';
		$exit_reason = '';
        if(isset($this->params['named']['name']) && $this->params['named']['name'] != ''){
            $name = $this->params['named']['name'];
            $condition += array('Beneficiary.name' => $name);
        }		
        if(isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != ''){
            $rch_mcts_no = $this->params['named']['rch_mcts_no'];
            $condition += array('Beneficiary.rch_mcts_no' => $rch_mcts_no);
        }		
        if(isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != ''){
            $district_id = $this->params['named']['district_id'];
            $condition += array(0	=> "Beneficiary.user_id in(select id from users where district_id=$district_id)");
        }		
        if(isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != ''){
            $project_id = $this->params['named']['project_id'];
            $condition += array(1	=> "Beneficiary.user_id in(select id from users where project_id=$project_id)");
        }
        if(isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != ''){
            $sector_id = $this->params['named']['sector_id'];
            $condition += array('Beneficiary.sector_id' => $sector_id);
        }
        if(isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != ''){
            $awc_id = $this->params['named']['awc_id'];
            $condition += array('Beneficiary.awc_id' => $awc_id);
        }
        if(isset($this->params['named']['exit_reason']) && $this->params['named']['exit_reason'] != ''){
            $exit_reason = $this->params['named']['exit_reason'];
            $condition += array('Pregnency.exit_reason' => $exit_reason);
        }                 
        if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
            $from_date = $this->params['named']['from_date'];
            $condition += array('Pregnency.preg_reg_date >=' => date('Y-m-d', strtotime($from_date)));
        }
        if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
            $to_date = $this->params['named']['to_date'];
            $condition += array('Pregnency.preg_reg_date <=' => $to_date);
        }   		
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
			$this->layout='export_xls';
			if($this->params['named']['reqType']=='XLS'){
				$this->set('file_type','xls');
				$this->set('file_name','beneficiary_wise_awwawh_incentive_received_report'.date('d_m_Y').'.xls');
			}else if($this->params['named']['reqType']=='DOC'){
				$this->set('file_type','doc');
				$this->set('file_name','beneficiary_wise_awwawh_incentive_received_report'.date('d_m_Y').'.doc');
			}
			$this->set('is_excel','Y');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
		}	        
		$this->paginate = array(
			'recursive'		=> -1,
			'joins'=>array(
				array(
					'table' 		=> 'beneficiaries',
					'alias' 		=> 'Beneficiary',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Pregnency.beneficiary_id = Beneficiary.id')					
				),
				array(
					'table' 		=> 'sectors',
					'alias' 		=> 'Sector',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Beneficiary.sector_id = Sector.id')					
				),
				array(
					'table' 		=> 'awcs',
					'alias' 		=> 'Awc',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Beneficiary.awc_id = Awc.id')					
				),			
				array(
					'table' 		=> 'workers',
					'alias' 		=> 'Worker',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Beneficiary.worker_id = Worker.id')					
				),
				array(
					'table' 		=> 'workers',
					'alias' 		=> 'Helper',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Beneficiary.helper_id = Helper.id')					
				),															
				array(
					'table' 		=> 'users',
					'alias' 		=> 'User',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('Beneficiary.user_id = User.id')					
				),
				array(
					'table' 		=> 'districts',
					'alias' 		=> 'District',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('User.district_id = District.id')					
				),
				array(
					'table' 		=> 'projects',
					'alias' 		=> 'Project',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array('User.project_id = Project.id')					
				),	
				array(
					'table' 		=> 'incentives',
					'alias' 		=> 'Incentive',
					'type' 			=> 'left',
					'foreignKey' 	=> false,
					'conditions'	=> array(
						'User.project_id = Project.id'
					),					
				),																						
			),			
			'conditions' 	=> $condition,
			'fields'		=> array(
				'Beneficiary.id',
				'Beneficiary.name',
				'Beneficiary.rch_mcts_no',
				'Beneficiary.worker_id',
				'Beneficiary.helper_id',
				'District.name',
				'Project.name',
				'Sector.name',
				'Awc.name',
				'Pregnency.id',
				'Pregnency.exit_date',
				'Pregnency.exit_reason',
				'Worker.name',
				'Helper.name'
			),
			'order' 		=> array(
				'Pregnency.preg_reg_date'
			),
			'group' => 'Beneficiary.id'
		)+$limit;
		$datas = $this->paginate('Pregnency');
		$this->set(array(
			'datas'			=> $datas,
			'district_id'	=> $district_id,
			'project_id'	=> $project_id,
			'from_date'		=> $from_date,
			'to_date'		=> $to_date,
			'name'			=> $name,
			'rch_mcts_no'	=> $rch_mcts_no,
			'sector_id'		=> $sector_id,
			'awc_id'		=> $awc_id,
			'exit_reason'	=> $exit_reason,
		));
	}
	// //////////////////////////////
	public function dashboard_eligible_reg($tm = ''){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');

		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$user = $this->Session->read('user_auth');
		if(isset($tm) && $tm!=''){
			$this->request->data['Report']['from_date'] = date('01-m-Y');
			$this->request->data['Report']['to_date'] = date('t-m-Y');

		}

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the District List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$approve_status = array(
			'0' => 'No',
			'1' => 'Yes'
		);
		/**
		  * Load Sector Data if District is hidden as per user Role.
		  * Added by Tanmaya on 14-04-2017
		  **/
			$cond1 = "";
			if (isset($user['Designation']['name']) && $user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$cond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
				$sector_id = $this->Sector->find('list', array(
					'conditions' => array(
						$cond1
					) ,
					'order' => array(
						'Sector.name'
					)
				));
			}
			// Pre-Select the Project List
			if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
				$project_id = $this->Project->find('list', array(
					'conditions' => array(
						'district_id' => $user['District']['id']
					) ,
					'order' => array(
						'Project.name'
					)
				));
			}
			// Pre-Select the AWC List
			if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
				$awc_id = $this->Awc->find('list', array(
					'conditions' => array(
						'sector_id' => $this->data['Report']['sector_id']
					) ,
					'order' => array(
						'Awc.name'
					)
				));
			}
			// Pre-Select the Project List
			if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
				$sector_id = $this->Sector->find('list', array(
					'conditions' => array(
						'project_id' => $this->data['Report']['project_id']
					) ,
					'order' => array(
						'Sector.name'
					)
				));
			}
			if (isset($this->data['Report']['awc_id']) && $this->data['Report']['awc_id'] != '') {
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->request->data['Report']['awc_id'] . "'";
			}

		//Addning end
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'approve_status'));
	}
	public function dashboard_eligible_reg_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');

		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';
		//debug($this->params['named']);
			$user = $this->Session->read('user_auth');
			//debug($this->request->data['Report']);
			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}
			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			/*$sql_approve_status = "";
			if (isset($this->params['named']['approve_status']) && $this->params['named']['approve_status'] != '') {
				$approve_status = $this->params['named']['approve_status'];
				$sql_approve_status = "Pregnency.is_approved = '" . $this->params['named']['approve_status'] . "'";
			}*/

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >= '" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

			$this->paginate = array(
				//'recursive' => 2,
	            'conditions'    => array(
					$sql,
					$sql_name,
					'Beneficiary.husband_govt' => 'no', //Added for condition required after migration
					'Beneficiary.age >= 19 AND Beneficiary.age <= 45',
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				),
	            //'limit'         => 10,
	            'order' => array(
						'Beneficiary.reg_date'
				)
        )+$limit;
        $datas = $this->paginate('Beneficiary');
       /* $log = $this->Pregnency->getDataSource()->getLog(false, false);
		debug($log);*/
		$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}

	public function dashboard_preg_reg($tm = ''){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');

		$district_id 	= '';
		$project_id 	= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$user = $this->Session->read('user_auth');
		if(isset($tm) && $tm!=''){
			$this->request->data['Report']['from_date'] = date('01-m-Y');
			$this->request->data['Report']['to_date'] = date('t-m-Y');

		}

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the District List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$approve_status = array(
			'0' => 'No',
			'1' => 'Yes'
		);
		/**
		  * Load Sector Data if District is hidden as per user Role.
		  * Added by Tanmaya on 14-04-2017
		  **/
			$cond1 = "";
			if (isset($user['Designation']['name']) && $user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
				$cond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
				$sector_id = $this->Sector->find('list', array(
					'conditions' => array(
						$cond1
					) ,
					'order' => array(
						'Sector.name'
					)
				));
			}
			// Pre-Select the Project List
			if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
				$project_id = $this->Project->find('list', array(
					'conditions' => array(
						'district_id' => $user['District']['id']
					) ,
					'order' => array(
						'Project.name'
					)
				));
			}
			// Pre-Select the AWC List
			if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
				$awc_id = $this->Awc->find('list', array(
					'conditions' => array(
						'sector_id' => $this->data['Report']['sector_id']
					) ,
					'order' => array(
						'Awc.name'
					)
				));
			}
			// Pre-Select the Project List
			if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
				$sector_id = $this->Sector->find('list', array(
					'conditions' => array(
						'project_id' => $this->data['Report']['project_id']
					) ,
					'order' => array(
						'Sector.name'
					)
				));
			}
			if (isset($this->data['Report']['awc_id']) && $this->data['Report']['awc_id'] != '') {
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->request->data['Report']['awc_id'] . "'";
			}

		//Addning end
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'approve_status'));
	}
	public function dashboard_preg_reg_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');

		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';
		//debug($this->params['named']);
			$user = $this->Session->read('user_auth');
			//debug($this->request->data['Report']);
			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}
			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			$sql_approve_status = "";
			if (isset($this->params['named']['approve_status']) && $this->params['named']['approve_status'] != '') {
				$approve_status = $this->params['named']['approve_status'];
				$sql_approve_status = "Pregnency.is_approved = '" . $this->params['named']['approve_status'] . "'";
			}

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Pregnency.preg_reg_date >= '" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Pregnency.preg_reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

			$this->paginate = array(
				'recursive' => 2,
	            'conditions'    => array(
					$sql,
					$sql_name,
					'Beneficiary.husband_govt' => 'No', //Added for condition required after migration
					'Beneficiary.age >= 19 AND Beneficiary.age <= 45', //Added for condition required after migration
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_approve_status,
					$sql_from_date,
					$sql_to_date
				),
	            //'limit'         => 10,
	            'order' => array(
						'Pregnency.preg_reg_date'
				)
        )+$limit;
        $datas = $this->paginate('Pregnency');
       /* $log = $this->Pregnency->getDataSource()->getLog(false, false);
		debug($log);*/
		$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}

	// /////////////////////////////////////////////////////

	public function dashboard_first_installment()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$is_paid = array(
			'1' => 'PAID',
			'2' => 'FAILED'
		);
		$this->request->data['Report']['is_paid'] = '1';
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'is_paid'));
	}

	public function dashboard_first_installment_ajax($value='')
	{
		$this->layout = 'ajax';
			$this->loadModel('Beneficiary');
			$this->loadModel('Payment');
			$this->loadModel('Pregnency');
			$this->loadModel('Pinstallment');
			$this->LoadModel('District');
			$this->LoadModel('Sector');
			$this->LoadModel('Awc');
			$this->LoadModel('Project');
			$this->LoadModel('Delivery');
			$this->LoadModel('Worker');
			$this->LoadModel('Incentive');
			$user = $this->Session->read('user_auth');
			$sql = "";
			$name = '';
			$rch_mcts_no = '';
			$account_no = '';
			$district_id = '';
			$project_id = '';
			$sector_id ='';
			$awc_id = '';
			$is_paid = '';
			$from_date = '';
			$to_date = '';

			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_paid = "";
			if (isset($this->params['named']['is_paid']) && $this->params['named']['is_paid'] != '') {
				$is_paid = $this->params['named']['is_paid'];
				$sql_is_paid = "Pinstallment.is_paid = '" . $this->params['named']['is_paid'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Pregnency.preg_reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Pregnency.preg_reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }


			$this->paginate = array(
				'recursive' => 2,
	            'conditions'    => array(
					'Pinstallment.installment_no' => 1,
					//'Pinstallment.is_payment_approve' => 1,
					'Pinstallment.is_paid' => 1,
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_is_paid,
					$sql_from_date,
					$sql_to_date
				),
	            //'limit'         => 10,
	            'order' => array(
					'Pinstallment.installment_date'
				)
        )+$limit;
        $datas = $this->paginate('Pinstallment');
        
        $this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_paid'				=> $is_paid,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}

	// //////////////////////////////////////////////////////////////////

	public function dashboard_second_installment(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');

		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['disrtict_id']) && $this->data['Report']['disrtict_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$is_paid = array(
			'1' => 'PAID',
			'2' => 'FAILED'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'is_paid'));
	}

	public function dashboard_second_installment_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_paid = '';
		$from_date = '';
		$to_date = '';

			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
			}

			/*$sql_date = "";
			$from_date = "";
			$to_date = "";
			if ($this->request->data['Report']['from_date'] != '' && $this->request->data['Report']['to_date'] != '') {
				$from_date = $this->request->data['Report']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->request->data['Report']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
				$sql_date = "Pregnency.preg_reg_date between '" . $from_date . "' and '" . $to_date . "'";
			}
*/
			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_paid = "";
			if (isset($this->params['named']['is_paid']) && $this->params['named']['is_paid'] != '') {
				$is_paid = $this->params['named']['is_paid'];
				$sql_is_paid = "Pinstallment.is_paid = '" . $this->request->data['Report']['is_paid'] . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }
			/*$this->Pinstallment->recursive = 2;
			$datas = $this->Pinstallment->find('all', array(
				'conditions' => array(
					'Pinstallment.installment_no' => 2,
					'Pinstallment.is_payment_approve' => 1,
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_is_paid,
					$sql_date
				) ,
				'order' => array(
					'Pinstallment.installment_date'
				)
			));
			$this->set(compact('datas'));*/




			$this->paginate = array(
				'recursive' => 2,
				'conditions' => array(
					'Pinstallment.installment_no' => 2,
					'Pinstallment.is_payment_approve' => 1,
					'Pinstallment.is_paid' => 1,
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_is_paid,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pinstallment.installment_date'
				)
	        )+$limit;

	        $datas = $this->paginate('Pinstallment');

			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_paid'				=> $is_paid,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}
	// //////////////////////////////////////////////////////////

	public function dashboard_suspected_ben(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$user = $this->Session->read('user_auth');
		


		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		// Pre-Select the Project List
		if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id'));
	}
	public function dashboard_suspected_ben_ajax()
	{
		$this->layout= 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$approve_status = '';
		$from_date = '';
		$to_date = '';

		$user = $this->Session->read('user_auth');


			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			$this->paginate = array(
				'conditions' => array(
					//"Beneficiary.suspect_reason != ''",
					"Beneficiary.is_suspect = 1",
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Beneficiary.reg_date'
				)
	        )+$limit;

	        $datas = $this->paginate('Beneficiary');

			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'approve_status'		=> $approve_status,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	
		}

	// ////////////////////////////////////////////////////////////////////////

	public function dashboard_trans_failed(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$district_id = '';
		$project_id = '';
		$sector_id = '';
		$awc_id = '';

		$user = $this->Session->read('user_auth');

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			if(isset($this->data['Report']['project_id']) && $this->data['Report']['project_id']!=''){
				$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];
			}

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$installment_no = array(
			'1' => 'First Installment',
			'2' => 'Second Installment'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'installment_no'));
	}
	public function dashboard_trans_failed_ajax()
	{
		
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Bank');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$installment_no = '';
		$from_date = '';
		$to_date = '';

		
		$sql = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		if ($user['Designation']['name'] == 'DPC') {
			$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
		}

		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Beneficiary.from_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Beneficiary.to_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
		}
		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
		}

		$sql_account_no = "";
		if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
			$account_no = $this->params['named']['account_no'];
			$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
		}

		$sql_installment_no = "";
		if (isset($this->params['named']['installment_no']) && $this->params['named']['installment_no'] != '') {
			$installment_no = $this->params['named']['installment_no'];
			$sql_installment_no = "Beneficiary.account_no = '" . $this->params['named']['installment_no'] . "'";
		}
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pinstallment.payment_date >= '" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pinstallment.payment_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
		}

		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	        $this->layout='export_xls';
	        if($this->params['named']['reqType']=='XLS'){
	            $this->set('file_type','xls');
	            $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	        }else if($this->params['named']['reqType']=='DOC'){
	            $this->set('file_type','doc');
	            $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	        }
	        $this->set('is_excel','Y');
	        $limit = array('limit' => 2000,'maxLimit'   => 2000);
	    }else{
	        $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	    }

		/**
		  * Added by Tanmaya
		  * Purpose : To get Account details
		  **/
		/*$this->Pinstallment->bindModel(array(
            'belongsTo' => array(
                'Beneficiary' => array(
                    'foreignKey' => 'id',
                ),
            ),
        ));*/

		$this->paginate = array(
				'recursive' => 2,
				'conditions' => array(
					'Pinstallment.is_paid' => 2,
					//"Pinstallment.id in(select pinstallment_id from payments where is_paid=2)",
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_installment_no,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Beneficiary.reg_date'
				)
	        )+$limit;

	        $datas = $this->paginate('Pinstallment');

	        $bankList = $this->Bank->find('list');

	        debug($bankList); exit;
	        /*$log = $this->Pinstallment->getDataSource()->getLog(false, false);
			debug($log);*/
	        $this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'installment_no'		=> $installment_no,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
		
	}

	// //////////////////////////////////////////////////////

	public function reprocess($id){
		$this->layout = NULL;
		$this->loadModel('Payment');
		$this->loadModel('Pinstallment');
		$this->Pinstallment->query("update pinstallments set payment_date=NULL,is_paid=0,bank_payment_status='' where id=$id");
		$this->Payment->query("delete from payments where pinstallment_id=$id");
		exit();
	}

	// /////////////////////////////////////////////////////

	public function ireprocess($id){
		$this->layout = NULL;
		$this->loadModel('Incentive');
		$this->Incentive->query("update incentives set is_paid=0,paid_status='',payment_date=NULL where id=$id");
		exit();
	}

	// ///////////////////////////////////////////////////////



	// /////////////////////////////////////////////

	public function dashboard_awh_inc_rec(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$user = $this->Session->read('user_auth');
		

				/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$exit_reason = array(
			'MATERNAL DEATH' => 'MATERNAL DEATH',
			'INFANT DEATH' => 'INFANT DEATH',
			'MISCARRIAGE' => 'MISCARRIAGE',
			'STILL BIRTH' => 'STILL BIRTH',
			'MIGRATION' => 'MIGRATION'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'exit_reason'));
	}
	public function dashboard_awh_inc_rec_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$exit_reason='';
		$from_date='';
		$to_date = '';
		$user = $this->Session->read('user_auth');

		$sql = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		if ($user['Designation']['name'] == 'DPC') {
			$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
		}

		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
		}


		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pregnency.preg_reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pregnency.preg_reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
		}
		$sql_exit_reason = "";
		if (isset($this->params['named']['exit_reason']) && $this->params['named']['exit_reason'] != '') {
			$exit_reason = $this->params['named']['exit_reason'];
			$sql_exit_reason = "Pregnency.exit_reason = '" . $this->request->data['Report']['exit_reason'] . "'";
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
        }

		$this->paginate = array(
			'recursive' => 2,
			'conditions' => array(
				'Pregnency.is_exit' => 1,
				$sql,
				$sql_district_id,
				$sql_project_id,
				$sql_sector_id,
				$sql_awc_id,
				$sql_exit_reason,
				$sql_from_date,
				$sql_to_date
			) ,
			'order' => array(
				'Pregnency.preg_reg_date'
			)
        )+$limit;

        $datas = $this->paginate('Pregnency');

		$this->set(compact('datas'));
		$this->set(array(
			'district_id'			=> $district_id,
			'project_id'			=> $project_id,
			'sector_id'				=> $sector_id,
			'awc_id'				=> $awc_id,
			'from_date'				=> $from_date,
			'to_date'				=> $to_date
		));


		
	}

	public function dashboard_aww_inc_rec(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		/*if ($this->request->is(array(
			'post',
			'put'
		))) {
			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_district_id = "";
			if ($this->request->data['Report']['district_id'] != '') {
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->request->data['Report']['district_id'] . "')";
			}

			$sql_project_id = "";
			if ($this->request->data['Report']['project_id'] != '') {
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->request->data['Report']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if ($this->request->data['Report']['sector_id'] != '') {
				$sql_sector_id = "Beneficiary.sector_id='" . $this->request->data['Report']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if ($this->request->data['Report']['awc_id'] != '') {
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->request->data['Report']['awc_id'] . "'";
			}

			$sql_date = "";
			$from_date = "";
			$to_date = "";
			if ($this->request->data['Report']['from_date'] != '' && $this->request->data['Report']['to_date'] != '') {
				$from_date = $this->request->data['Report']['from_date'];
				$from_date = explode('/', $from_date);
				$from_date = $from_date[2] . '-' . $from_date[1] . '-' . $from_date[0];
				$to_date = $this->request->data['Report']['to_date'];
				$to_date = explode('/', $to_date);
				$to_date = $to_date[2] . '-' . $to_date[1] . '-' . $to_date[0];
				$sql_date = "Pregnency.preg_reg_date between '" . $from_date . "' and '" . $to_date . "'";
			}

			$sql_exit_reason = "";
			if ($this->request->data['Report']['exit_reason'] != '') {
				$sql_exit_reason = "Pregnency.exit_reason = '" . $this->request->data['Report']['exit_reason'] . "'";
			}

			$this->Pregnency->recursive = 2;
			$datas = $this->Pregnency->find('all', array(
				'conditions' => array(
					'Pregnency.is_exit' => 1,
					$sql,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_exit_reason,
					$sql_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				)
			));
			$this->set(compact('datas'));
		}*/

		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the AWC List
		if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$exit_reason = array(
			'MATERNAL DEATH' => 'MATERNAL DEATH',
			'INFANT DEATH' => 'INFANT DEATH',
			'MISCARRIAGE' => 'MISCARRIAGE',
			'STILL BIRTH' => 'STILL BIRTH',
			'MIGRATION' => 'MIGRATION'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'exit_reason'));
	}
	public function dashboard_aww_inc_rec_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$from_date = '';
		$to_date = '';

		$sql = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		if ($user['Designation']['name'] == 'DPC') {
			$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
		}

		$sql_district_id = "";
		if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
			$district_id = $this->params['named']['district_id'];
			$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
		}

		$sql_project_id = "";
		if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
			$project_id = $this->params['named']['project_id'];
			$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
		}

		$sql_sector_id = "";
		if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
			$sector_id = $this->params['named']['sector_id'];
			$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
		}

		$sql_awc_id = "";
		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
		}

		$sql_name = "";
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
		}

		$sql_rch_mcts_no = "";
		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
		}

		$sql_account_no = "";
		if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
			$account_no = $this->params['named']['account_no'];
			$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
		}

		
		$sql_from_date = "";
		if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
			$from_date = $this->params['named']['from_date'];
			$sql_from_date = "Pregnency.preg_reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
		}
		$sql_to_date = "";
		if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
			$to_date = $this->params['named']['to_date'];
			$sql_to_date = "Pregnency.preg_reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
		}

		$sql_exit_reason = "";
		if (isset($this->params['named']['exit_reason']) && $this->params['named']['exit_reason'] != '') {
			$exit_reason = $this->params['named']['exit_reason'];
			$sql_exit_reason = "Pregnency.exit_reason = '" . $this->request->data['Report']['exit_reason'] . "'";
		}

		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
            }
            $this->set('is_excel','Y');
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
        }


        $this->paginate = array(
        	'recursive' => 2,
			'conditions' => array(
				'Pregnency.is_exit' => 1,
				$sql,
				$sql_district_id,
				$sql_project_id,
				$sql_sector_id,
				$sql_awc_id,
				$sql_exit_reason,
				$sql_from_date,
				$sql_to_date
			) ,
			'order' => array(
				'Pregnency.preg_reg_date'
			)
	    )+$limit;

	    $datas = $this->paginate('Pregnency');

	    $this->set(compact('datas'));
		$this->set(array(
			'name' 					=> $name,
			'rch_mcts_no' 			=> $rch_mcts_no,
			'account_no'			=> $account_no,
			'district_id'			=> $district_id,
			'project_id'			=> $project_id,
			'sector_id'				=> $sector_id,
			'awc_id'				=> $awc_id,
			'from_date'				=> $from_date,
			'to_date'				=> $to_date
		));
		
	}

	// //////////////////////////////////////////////////////////

	public function dashboard_first_approved()
	{
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');
		$user = $this->Session->read('user_auth');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			if(isset($this->data['Report']['project_id']) &&  $this->data['Report']['project_id'] !=''){
				$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];
			}

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		
		// Pre-Select the Project List
		if (isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		//echo "##".$this->data['Report']['sector_id'];
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
			//debug($sector_id);
		}
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		$is_payment_approve = array(
			'0' => 'No',
			'1' => 'Yes'
		);
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'is_payment_approve'));
	}

	public function dashboard_first_approved_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';

			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.name='" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.name='" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_payment_approve = "";
			if (isset($this->params['named']['is_payment_approve']) && $this->params['named']['is_payment_approve'] != '') {
				$is_payment_approve = $this->params['named']['is_payment_approve'];
				if(isset($is_payment_approve) && $is_payment_approve == 1){
					$sql_is_payment_approve = "VerifyFirst.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=1 AND totalverify = 6)";
				}else if(isset($is_payment_approve) && $is_payment_approve == 0){
					$sql_is_payment_approve = "Pregnency.id NOT IN  (SELECT pregnency_id FROM view_first_verify)";/*
					$sql_is_payment_approve = "VerifyFirst.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=1 AND totalverify < 6 )";*/
				}
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id']. "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}
			/*$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.from_date <='" . $this->params['named']['from_date'] . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.to_date >='" . $this->params['named']['to_date'] . "'";
			}*/

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

	        
			$this->paginate = array(
				'recursive' => -1,
				'joins' => array(
					array(
						    'table' => 'pregnencies',
						    'alias' => 'Pregnency',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					array(
						    'table' => 'beneficiaries',
						    'alias' => 'Beneficiary',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pinstallment.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
					array(
						    'table' => 'view_first_verify',
						    'alias' => 'VerifyFirst',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'VerifyFirst.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'districts',
						    'alias' => 'District',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'District.id = User.district_id'
						    )
						),
					array(
						    'table' => 'projects',
						    'alias' => 'Project',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Project.id = User.project_id'
						    )
						),
					array(
						    'table' => 'sectors',
						    'alias' => 'Sector',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Sector.id = Beneficiary.sector_id'
						    )
						),
					array(
						    'table' => 'awcs',
						    'alias' => 'Awc',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Awc.id = Beneficiary.awc_id'
						    )
						),
				),
				'conditions' => array(
					$sql,
					"Pinstallment.installment_no" => 1,
					'Beneficiary.husband_govt' => 'No',
					"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_is_payment_approve,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				),
				'fields' => array(
					'Beneficiary.*',
					'Pregnency.id',
					'District.id',
					'District.name',
					'Project.id',
					'Project.name',
					'Sector.id',
					'Sector.name',
					'Awc.id',
					'Awc.name',
					'Pinstallment.id',
					'Pinstallment.installment_no',
					'Pinstallment.installment_date',
					'Pinstallment.is_payment_approve',

				)
	        )+$limit;

	        $datas = $this->paginate('Pinstallment');


			//debug($datas); exit;
			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
		
	}
	public function dashboard_first_not_approved_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';

			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.name='" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.name='" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_payment_approve = "";
			if (isset($this->params['named']['is_payment_approve']) && $this->params['named']['is_payment_approve'] != '') {
				$is_payment_approve = $this->params['named']['is_payment_approve'];
				if(isset($is_payment_approve) && $is_payment_approve == 1){
					$sql_is_payment_approve = "VerifyFirst.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=1 AND totalverify = 6)";
				}else if(isset($is_payment_approve) && $is_payment_approve == 0){
					//$sql_is_payment_approve = "Pregnency.id NOT IN  (SELECT pregnency_id FROM view_first_verify)";
					/*$sql_is_payment_approve = "VerifyFirst.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=1 AND totalverify < 6 )";*/
				}
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id']. "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}


			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }


			$this->paginate = array(
				'recursive' => -1,
				'joins' => array(
					array(
						    'table' => 'pinstallments',
						    'alias' => 'Pinstallment',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					array(
						    'table' => 'beneficiaries',
						    'alias' => 'Beneficiary',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
					array(
						    'table' => 'view_first_verify',
						    'alias' => 'VerifyFirst',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'VerifyFirst.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'districts',
						    'alias' => 'District',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'District.id = User.district_id'
						    )
						),
					array(
						    'table' => 'projects',
						    'alias' => 'Project',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Project.id = User.project_id'
						    )
						),
					array(
						    'table' => 'sectors',
						    'alias' => 'Sector',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Sector.id = Beneficiary.sector_id'
						    )
						),
					array(
						    'table' => 'awcs',
						    'alias' => 'Awc',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Awc.id = Beneficiary.awc_id'
						    )
						),
				),
				'conditions' => array(
					$sql,
					//"Pinstallment.is_paid !=" => 2,
					'Beneficiary.husband_govt' => 'No',
					"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
					"Pinstallment.installment_no" => 1,
					"Pregnency.is_approved" => 1,
					"Pregnency.id NOT IN  (SELECT pregnency_id FROM view_first_verify)",
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_is_payment_approve,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				),
				'fields' => array(
					'Beneficiary.*',
					'Pregnency.id',
					'District.id',
					'District.name',
					'Project.id',
					'Project.name',
					'Sector.id',
					'Sector.name',
					'Awc.id',
					'Awc.name',
					'Pinstallment.id',
					'Pinstallment.installment_no',
					'Pinstallment.installment_date',
					'Pinstallment.is_payment_approve',
					'Pinstallment.is_paid',

				)
	        )+$limit;

	        $datas = $this->paginate('Pregnency');

	        /*$log = $this->Pregnency->getDataSource()->getLog(false, false);
debug($log);*/
			//debug($datas); exit;
			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
		
	}
	// //////////////////////////////

	public function dashboard_second_approved(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');

		$district_id = '';
		$project_id  = '';
		$sector_id   = '';
		$awc_id      = '';

		$user = $this->Session->read('user_auth');
		
		/**
		  *	Tanmaya Code Start
		  * Purpose : To set Filters and Serch criteria proper
		  **/
		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			if(isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] !=''){
				$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];
			}

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		// Pre-Select the Project List
		if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$is_payment_approve = array(
			'0' => 'No',
			'1' => 'Yes'
		);

		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id', 'is_payment_approve'));
	}

	public function dashboard_second_approved_ajax()
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';

			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.name='" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.name='" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_payment_approve = "";
			if (isset($this->params['named']['is_payment_approve']) && $this->params['named']['is_payment_approve'] != '') {
				$is_payment_approve = $this->params['named']['is_payment_approve'];
				if(isset($is_payment_approve) && $is_payment_approve == 1){
					$sql_is_payment_approve = "VerifySecond.pregnency_id IN (SELECT pregnency_id FROM view_second_verify WHERE pregnency_no=2 AND firstcnt >= 13 AND secondcnt >= 6)";
				}
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id']. "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}
			

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

	        
			$this->paginate = array(
				'recursive' => -1,
				'joins' => array(
					array(
						    'table' => 'pregnencies',
						    'alias' => 'Pregnency',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					array(
						    'table' => 'beneficiaries',
						    'alias' => 'Beneficiary',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pinstallment.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
					array(
						    'table' => 'view_second_verify',
						    'alias' => 'VerifySecond',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'VerifySecond.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'districts',
						    'alias' => 'District',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'District.id = User.district_id'
						    )
						),
					array(
						    'table' => 'projects',
						    'alias' => 'Project',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Project.id = User.project_id'
						    )
						),
					array(
						    'table' => 'sectors',
						    'alias' => 'Sector',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Sector.id = Beneficiary.sector_id'
						    )
						),
					array(
						    'table' => 'awcs',
						    'alias' => 'Awc',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Awc.id = Beneficiary.awc_id'
						    )
						),
				),
				'conditions' => array(
					$sql,
					"Pinstallment.installment_no" => 2,
					'Beneficiary.husband_govt' => 'No',
					"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_is_payment_approve,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				),
				'fields' => array(
					'Beneficiary.*',
					'Pregnency.id',
					'District.id',
					'District.name',
					'Project.id',
					'Project.name',
					'Sector.id',
					'Sector.name',
					'Awc.id',
					'Awc.name',
					'Pinstallment.id',
					'Pinstallment.installment_no',
					'Pinstallment.installment_date',
					'Pinstallment.is_payment_approve',

				)
	        )+$limit;

	        $datas = $this->paginate('Pinstallment');


			//debug($datas); exit;
			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	}
	public function dashboard_second_not_approved_ajax($value='')
	{
		$this->layout = 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$this->LoadModel('Verify');
		$user = $this->Session->read('user_auth');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$is_payment_approve = '';
		$from_date = '';
		$to_date = '';

			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.name='" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.name='" . $this->params['named']['account_no'] . "'";
			}

			$sql_is_payment_approve = "";
			/*if (isset($this->params['named']['is_payment_approve']) && $this->params['named']['is_payment_approve'] != '') {
				$is_payment_approve = $this->params['named']['is_payment_approve'];
				if(isset($is_payment_approve) && $is_payment_approve == 0){
					$sql_is_payment_approve = "VerifySecond.pregnency_id NOT IN (SELECT pregnency_id FROM view_second_verify)";
				}
			}*/

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id']. "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}

			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
			}


			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }


			$this->paginate = array(
				'recursive' => -1,
				'joins' => array(
					array(
						    'table' => 'pinstallments',
						    'alias' => 'Pinstallment',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					array(
						    'table' => 'beneficiaries',
						    'alias' => 'Beneficiary',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
					array(
						    'table' => 'view_second_verify',
						    'alias' => 'VerifySecond',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'VerifySecond.beneficiary_id = Beneficiary.id'
						    )
						),
					array(
						    'table' => 'districts',
						    'alias' => 'District',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'District.id = User.district_id'
						    )
						),
					array(
						    'table' => 'projects',
						    'alias' => 'Project',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Project.id = User.project_id'
						    )
						),
					array(
						    'table' => 'sectors',
						    'alias' => 'Sector',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Sector.id = Beneficiary.sector_id'
						    )
						),
					array(
						    'table' => 'awcs',
						    'alias' => 'Awc',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Awc.id = Beneficiary.awc_id'
						    )
						),
				),
				'conditions' => array(
					$sql,
					//"Pinstallment.is_paid !=" => 2,
					/*'Beneficiary.husband_govt' => 'No',
					"Beneficiary.age >= 19 AND Beneficiary.age <= 45",*/
					"Pinstallment.installment_no" => 2,
					"Pregnency.is_approved" => 1,
					"Pregnency.id NOT IN  (SELECT pregnency_id FROM view_second_verify)",
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_is_payment_approve,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Pregnency.preg_reg_date'
				),
				'fields' => array(
					'Beneficiary.*',
					'Pregnency.id',
					'District.id',
					'District.name',
					'Project.id',
					'Project.name',
					'Sector.id',
					'Sector.name',
					'Awc.id',
					'Awc.name',
					'Sector.name',
					'Pinstallment.id',
					'Pinstallment.installment_no',
					'Pinstallment.installment_date',
					'Pinstallment.is_payment_approve',
					'Pinstallment.is_paid',

				)
	        )+$limit;

	        $datas = $this->paginate('Pregnency');
			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'is_payment_approve'	=> $is_payment_approve,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
		
	}
	
	public function report_suspected_ben(){
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$user = $this->Session->read('user_auth');
		


		$sql_cond1 = "";
		if ($user['Designation']['name'] == 'DPC') {
			$sql_cond1 = "District.id='" . $user['District']['id'] . "'";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));				
		}

		if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
			$this->request->data['Report']['district_id'] = $user['District']['id'];
			$this->request->data['Report']['project_id'] = $user['Project']['id'];

			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $user['District']['id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $user['Project']['id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}

		$district_id = $this->District->find('list', array(
			'conditions' => array(
				$sql_cond1
			) ,
			'order' => array(
				'District.name'
			)
		));
		/*$project_id = "";
		$sector_id = "";
		$awc_id = "";*/
		// Pre-Select the Project List
		if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 !='' )) {
			$project_id = $this->Project->find('list', array(
				'conditions' => array(
					'district_id' => $this->data['Report']['district_id']
				) ,
				'order' => array(
					'Project.name'
				)
			));
		}
		// Pre-Select the AWC List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$awc_id = $this->Awc->find('list', array(
				'conditions' => array(
					'sector_id' => $this->data['Report']['sector_id']
				) ,
				'order' => array(
					'Awc.name'
				)
			));
		}
		// Pre-Select the Project List
		if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
			$sector_id = $this->Sector->find('list', array(
				'conditions' => array(
					'project_id' => $this->data['Report']['project_id']
				) ,
				'order' => array(
					'Sector.name'
				)
			));
		}
		/** /End of tanmaya code**/
		$this->set(compact('district_id', 'project_id', 'sector_id', 'awc_id'));
	}
	public function report_suspected_ben_ajax()
	{
		$this->layout= 'ajax';
		$this->loadModel('Beneficiary');
		$this->loadModel('Payment');
		$this->loadModel('Pregnency');
		$this->loadModel('Pinstallment');
		$this->LoadModel('District');
		$this->LoadModel('Sector');
		$this->LoadModel('Awc');
		$this->LoadModel('Project');
		$this->LoadModel('Delivery');
		$this->LoadModel('Worker');
		$this->LoadModel('Incentive');
		$name = '';
		$rch_mcts_no = '';
		$account_no = '';
		$district_id = '';
		$project_id = '';
		$sector_id ='';
		$awc_id = '';
		$approve_status = '';
		$from_date = '';
		$to_date = '';

		$user = $this->Session->read('user_auth');


			$sql = "";
			if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
				$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
			}

			if ($user['Designation']['name'] == 'DPC') {
				$sql = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
			}

			$sql_district_id = "";
			if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
				$district_id = $this->params['named']['district_id'];
				$sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
			}

			$sql_project_id = "";
			if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
				$project_id = $this->params['named']['project_id'];
				$sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
			}

			$sql_sector_id = "";
			if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
				$sector_id = $this->params['named']['sector_id'];
				$sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
			}

			$sql_awc_id = "";
			if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
				$awc_id = $this->params['named']['awc_id'];
				$sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
			}
			$sql_from_date = "";
			if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
				$from_date = $this->params['named']['from_date'];
				$sql_from_date = "Beneficiary.reg_date >='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['from_date']))) . "'";
			}
			$sql_to_date = "";
			if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
				$to_date = $this->params['named']['to_date'];
				$sql_to_date = "Beneficiary.reg_date <='" . date("Y-m-d",strtotime(str_replace("/", "-", $this->params['named']['to_date']))) . "'";
			}

			if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
	            $this->layout='export_xls';
	            if($this->params['named']['reqType']=='XLS'){
	                $this->set('file_type','xls');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.xls');
	            }else if($this->params['named']['reqType']=='DOC'){
	                $this->set('file_type','doc');
	                $this->set('file_name','Beneficiaries_details_'.date('d_m_Y').'.doc');
	            }
	            $this->set('is_excel','Y');
	            $limit = array('limit' => 2000,'maxLimit'   => 2000);
	        }else{
	            $limit = array('limit'	=> Configure::read('REPORT_LIMIT'));
	        }

			$sql_name = "";
			if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
				$name = $this->params['named']['name'];
				$sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
			}

			$sql_rch_mcts_no = "";
			if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
				$rch_mcts_no = $this->params['named']['rch_mcts_no'];
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no = '" . $this->params['named']['rch_mcts_no'] . "'";
			}

			$sql_account_no = "";
			if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
				$account_no = $this->params['named']['account_no'];
				$sql_account_no = "Beneficiary.account_no = '" . $this->params['named']['account_no'] . "'";
			}

			$this->paginate = array(
				'conditions' => array(
					//"Beneficiary.suspect_reason != ''",
					"Beneficiary.is_suspect = 1",
					$sql,
					$sql_name,
					$sql_rch_mcts_no,
					$sql_account_no,
					$sql_district_id,
					$sql_project_id,
					$sql_sector_id,
					$sql_awc_id,
					$sql_from_date,
					$sql_to_date
				) ,
				'order' => array(
					'Beneficiary.reg_date'
				)
	        )+$limit;

	        $datas = $this->paginate('Beneficiary');

			$this->set(compact('datas'));
			$this->set(array(
				'name' 					=> $name,
				'rch_mcts_no' 			=> $rch_mcts_no,
				'account_no'			=> $account_no,
				'district_id'			=> $district_id,
				'project_id'			=> $project_id,
				'sector_id'				=> $sector_id,
				'awc_id'				=> $awc_id,
				'approve_status'		=> $approve_status,
				'from_date'				=> $from_date,
				'to_date'				=> $to_date
			));
	
	}
}

<?php
App::uses('AppControler','Controller');

class BlocksController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
  $datas=$this->Block->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
      if($this->Block->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }

  $district_id=$this->Block->District->find('list',array(
    'order'=>array(
      'District.name'
    ),
  ));

  $this->set(compact('district_id'));

}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Block->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }

  $district_id=$this->Block->District->find('list',array(
    'order'=>array(
      'District.name'
    ),
  ));

  $this->set(compact('district_id'));
  $this->request->data=$this->Block->findById($id);
}

public function delete($id){
  $this->Block->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

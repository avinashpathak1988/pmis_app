<?php
App::uses('AppControler','Controller');

class AwcsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
	if($this->request->is(array('post','put'))){

$sql="";
$sql1="";
$sql2="";
$sql3="";

if(@$this->request->data['Awc']['awc_type'] != ''){
	$sql="Awc.awc_type = '".$this->request->data['Awc']['awc_type']."'";
}

if(@$this->request->data['Awc']['project_id'] != ''){
	$sql1="Awc.project_id = '".$this->request->data['Awc']['project_id']."'";
}

if(@$this->request->data['Awc']['gp_id'] != ''){
	$sql2="Awc.gp_id = '".$this->request->data['Awc']['gp_id']."'";
}

if(@$this->request->data['Awc']['sector_id'] != ''){
	$sql3="Awc.sector_id = '".$this->request->data['Awc']['sector_id']."'";
}
if($sql == '' && $sql1 == '' && $sql2 == '' && $sql3 == ''){
	$this->message('error','Please provide some filter criteria !');
}else{
$datas=$this->Awc->find('all',array(
	'conditions'=>array(
		$sql,
		$sql1,
		$sql2,
		$sql3
	),
	'order'=>array(
		'Awc.name'
	)
));
$this->set(compact('datas'));
}
	}
	$awc_type=array(
	  '0'=>'Mini AWC',
	  '1'=>'AWC'
	);

$total=$this->Awc->find('count');

	$project_id=$this->Awc->Project->find('list',array(
	  'Order'=>array(
	    'Project.name'
	  )
	));

	$gp_id=$this->Awc->Gp->find('list',array(
	  'Order'=>array(
	    'Gp.name'
	  )
	));

	$sector_id=$this->Awc->Sector->find('list',array(
	  'Order'=>array(
	    'Sector.name'
	  )
	));
	$this->set(compact('awc_type','project_id','gp_id','sector_id','total'));
}

/*public function index(){
$total=$this->Awc->find('count');
	$datas=$this->Awc->find('all',array(
	//	'limit'=>'100'
	));
	//echo "data set"; exit();
  $this->set(compact('datas','total'));
}*/

public function add(){
  if($this->request->is(array('post','put'))){
      if($this->Awc->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
$awc_type=array(
  '0'=>'Mini AWC',
  '1'=>'AWC'
);

$project_id=$this->Awc->Project->find('list',array(
  'Order'=>array(
    'Project.name'
  )
));

$gp_id=$this->Awc->Gp->find('list',array(
  'Order'=>array(
    'Gp.name'
  )
));

$sector_id=$this->Awc->Sector->find('list',array(
  'Order'=>array(
    'Sector.name'
  )
));

$is_pvtg=array(
	'Y'=>'Yes',
	'N'=>'No'
);

$this->set(compact('awc_type','project_id','gp_id','sector_id','is_pvtg'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Awc->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
$awc_type=array(
  '0'=>'Mini AWC',
  '1'=>'AWC'
);

$project_id=$this->Awc->Project->find('list',array(
  'Order'=>array(
    'Project.name'
  )
));

$gp_id=$this->Awc->Gp->find('list',array(
  'Order'=>array(
    'Gp.name'
  )
));

$sector_id=$this->Awc->Sector->find('list',array(
  'Order'=>array(
    'Sector.name'
  )
));

$is_pvtg=array(
	'Y'=>'Yes',
	'N'=>'No'
);


$this->set(compact('awc_type','project_id','gp_id','sector_id','is_pvtg'));

$this->request->data=$this->Awc->findById($id);
}

public function delete($id){
  $this->Awc->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

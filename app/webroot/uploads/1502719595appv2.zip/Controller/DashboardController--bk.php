<?php
App::uses('AppController', 'Controller');
class DashboardController extends AppController
{
	public $components = array(
		'Paginator',
		'Flash',
		'Session'
	);
	public $uses = array(
		'User'
	);

	/**
    * Migrate Pregnancy Data
    **/

  public function migrate_pregnancy($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Pregnency');
    $this->loadModel('PregnancyBeneficiary');
    $this->loadModel('BeniInstMaster');
    $this->loadModel('User');
    /*
    */
    $benDetails = $this->PregnancyBeneficiary->find('all', array('order' => array('id' => 'asc')/*, 'limit' => 100*/)) ;

    foreach ($benDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['PregnancyBeneficiary']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));

      $get_inst_details = $this->BeniInstMaster->find('first', array(
        'conditions' => array(
          'inst_number' => 1,
          'beni_id' => $data['PregnancyBeneficiary']['ben_id']
        ),
        'fields' => array(
          'inst_due_date'
        )
      ));
      if(isset($get_inst_details['BeniInstMaster']['inst_due_date']) && $get_inst_details['BeniInstMaster']['inst_due_date'] !=''){
        $inst_due_date = $get_inst_details['BeniInstMaster']['inst_due_date'];
      }else{
        $inst_due_date= NULL;
      }
      //debug($get_branch_details);


      $user_id = $get_user_id_qry['User']['id'];
        $this->request->data['Pregnency']['id'] = $data['PregnancyBeneficiary']['id'];
        $this->request->data['Pregnency']['beneficiary_id'] = $data['PregnancyBeneficiary']['ben_id'];
        $this->request->data['Pregnency']['lmp_date'] = $data['PregnancyBeneficiary']['lmp_date'];
        $this->request->data['Pregnency']['preg_reg_date'] = $data['PregnancyBeneficiary']['registration_date'];
        $this->request->data['Pregnency']['scheme_reg_date'] = $data['PregnancyBeneficiary']['scheme_registration_date'];
        $this->request->data['Pregnency']['exp_dod'] = $data['PregnancyBeneficiary']['delivery_date'];
        $this->request->data['Pregnency']['age'] = $data['PregnancyBeneficiary']['age'];
        $this->request->data['Pregnency']['preg_no'] = $data['PregnancyBeneficiary']['pregnancy_no'];
        $this->request->data['Pregnency']['is_approved'] = (isset($data['PregnancyBeneficiary']['is_approved']) && $data['PregnancyBeneficiary']['is_approved'] =='Y') ? '1' : '0';
        $this->request->data['Pregnency']['user_id'] = $user_id;
        $this->request->data['Pregnency']['approved_date'] = $data['PregnancyBeneficiary']['modified'];
        $this->request->data['Pregnency']['first_install_date'] = $inst_due_date;
        $this->request->data['Pregnency']['second_install_date'] = NULL;
        $this->request->data['Pregnency']['is_exit'] = $data['PregnancyBeneficiary']['is_exit'];
        $this->request->data['Pregnency']['exit_reason'] = $data['PregnancyBeneficiary']['exit_reason_id'];
        $this->request->data['Pregnency']['exit_date'] = $data['PregnancyBeneficiary']['exit_date'];
        $this->request->data['Pregnency']['created'] = $data['PregnancyBeneficiary']['created'];
        $this->request->data['Pregnency']['modified'] = $data['PregnancyBeneficiary']['modified'];

        //debug($this->data['Pregnency']);
        if($this->Pregnency->save($this->data['Pregnency'])){
          echo "The beneficiary having Preg ID=".$data['PregnancyBeneficiary']['id'].", And Ben ID =".$data['PregnancyBeneficiary']['ben_id']." is Successfully Inserted!"."<br>";
        }else{
          echo "There was something went Wrong";
        }
    }

  }

	public function migrate_failures()
	  {
	    $this->autoRender = false;
	    $this->loadModel('Pinstallment');
	    $this->loadModel('BeniInstMaster');

	    $bimDetails = $this->BeniInstMaster->find('all', array(
	      'conditions' => array(
	        'inst_number' => 1,
	        'is_paid' => 'N',
	        'payment_status' => 'FAILED'
	      ),
	      'fields' => array(
	      	'beni_id',
	      	'pregnancy_id'

	      )
	      //'order' => array('id' => 'asc'), 
	      //'limit' => 10
	      )) ;
	    //debug($bimDetails);

	    foreach ($bimDetails as $data) {
	    	$getPI = $this->Pinstallment->find('first', array(
	    		'conditions' => array(
	    			'Pinstallment.pregnency_id' => $data['BeniInstMaster']['pregnancy_id'],
	    			'Pinstallment.beneficiary_id' => $data['BeniInstMaster']['beni_id'],
	    			'Pinstallment.installment_no' => 1
	    		),
	    		'fields' => array(
	    			'Pinstallment.id',
	    			'Pinstallment.beneficiary_id',
	    			'Pinstallment.pregnency_id'
	    		)
	    	));
	    	echo "##".$getPI['Pinstallment']['id']."<br>";
	    	$this->Pinstallment->id = $getPI['Pinstallment']['id'];
			$this->Pinstallment->saveField('is_paid', '2');
	    }    
  } 

  public function migrate_suspects()
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Beneficiarylive');

    $susDetails = $this->Beneficiarylive->find('all', array(
      'conditions' => array(
        'is_suspect' => 'Y'
      ),
      'fields' => array(
      	'ben_id',
      )
      ));
    
    $i =1;
    foreach ($susDetails as $data) {
    	echo $i." ## ".$data['Beneficiarylive']['ben_id']."<br>";
    	$this->Beneficiary->id = $data['Beneficiarylive']['ben_id'];
		$this->Beneficiary->saveField('is_suspect', '1');
		$i ++;
    }
    
  }
  public function migrate_deliveries()
  {
    $this->autoRender = false;
    $this->loadModel('Delivery');
    $this->loadModel('BenePostPregDetail');
    $this->loadModel('User');

    $dlvDetails = $this->BenePostPregDetail->find('all');

    

    foreach ($dlvDetails as $data) {
    	$get_user_id_qry = $this->User->find('first', array(
	        'conditions' => array(
	          'project_id' => $data['BenePostPregDetail']['project_manager_id']
	        ),
	        'fields' => array(
	          'id'
	        )
	      ));
	    $user_id = $get_user_id_qry['User']['id'];
    	
    	$this->request->data['Delivery']['id'] = $data['BenePostPregDetail']['id'];
    	$this->request->data['Delivery']['beneficiary_id'] = $data['BenePostPregDetail']['ben_id'];
    	$this->request->data['Delivery']['pregnency_id'] = $data['BenePostPregDetail']['pregnancy_id'];
    	$this->request->data['Delivery']['dod'] = $data['BenePostPregDetail']['birth_date'];
    	$this->request->data['Delivery']['brd'] = $data['BenePostPregDetail']['registration_date'];
    	$this->request->data['Delivery']['outcome'] = $data['BenePostPregDetail']['outc_of_delivery_id'];
    	$this->request->data['Delivery']['child1_gender'] = $data['BenePostPregDetail']['child1_gender'];
    	$this->request->data['Delivery']['child1_weight'] = $data['BenePostPregDetail']['child1_weight'];
    	$this->request->data['Delivery']['child1_live_birth'] = $data['BenePostPregDetail']['child1_live'];
    	$this->request->data['Delivery']['child2_gender'] = $data['BenePostPregDetail']['child2_gender'];
    	$this->request->data['Delivery']['child2_weight'] = $data['BenePostPregDetail']['child2_weight'];
    	$this->request->data['Delivery']['child2_live_birth'] = $data['BenePostPregDetail']['child2_live'];
    	$this->request->data['Delivery']['user_id'] = $user_id;
    	$this->request->data['Delivery']['created'] = $data['BenePostPregDetail']['created'];
    	$this->request->data['Delivery']['modified'] = $data['BenePostPregDetail']['modified'];

    	debug($this->request->data['Delivery']);

    	$this->Delivery->create();
    	$this->Delivery->save($this->request->data['Delivery']);
    }

  }

	public function index()
	{
		$this->response->disableCache();

		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}


		// //////////////////////////

		$user = $this->Session->read('user_auth');
		//debug($user);
		//echo "<br><br><br><br><br><br><br><br><br><br>".$user['District']['id']. "  ///  ".$user['Project']['id'];
		$this->loadModel('Beneficiary');
		$this->loadModel('Pregnency');
		$this->loadModel('Payment');
		$this->loadModel('Pinstallment');
		$this->loadModel('VerifyFirst');
		$this->loadModel('VerifySecond');
		$this->loadModel('Incentive');
		$cond1 = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$cond1 = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}
		if ($user['Designation']['name'] == 'DPC') {
			$cond1 = "Beneficiary.user_id in(select id from users where district_id='" . $user['District']['id'] . "')";
		}

		$totb_registered = 0;
		$totb_registered = $this->Beneficiary->find('count', array(
			'recursive' => -1,
			'conditions' => array(
				$cond1,
				"Beneficiary.husband_govt" => 'No',
				'Beneficiary.age >= 19 AND Beneficiary.age <= 45'
			)
		));
		$this->set(compact('totb_registered'));
		$pregnency_registered = 0;
		$pregnency_registered_this_month = 0;
		$pregnency_registered = $this->Pregnency->find('count', array(
			'recursive' => 2,
			'conditions' => array(
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
				$cond1,
			)
		));

		
//echo $pregnency_registered;

//echo $cond1; exit();
		$from_date_global = date('Y') . '-' . date('m') . '-01';
		$to_date_global = date('Y') . '-' . date('m') . '-31';
		$pregnency_registered_this_month = $this->Pregnency->find('count', array(
			'conditions' => array(
				$cond1,
				"Pregnency.preg_reg_date between '" . $from_date_global . "' and '" . $to_date_global . "'",
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45"
			)
		));
		$this->set(compact('pregnency_registered', 'pregnency_registered_this_month'));
		$first_installment_paid = 0;
		$first_installment_paid = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 1,
				'Pinstallment.installment_no' => 1,
				//'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('first_installment_paid'));
		$second_installment_paid = 0;
		$second_installment_paid = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 1,
				'Pinstallment.installment_no' => 2,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('second_installment_paid'));
		$tot_trans_failed = 0;
		$tot_trans_failed = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 2,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('tot_trans_failed'));
		$total_exits = 0;
		$total_exits = $this->Pregnency->find('count', array(
			'conditions' => array(
				'Beneficiary.husband_govt' => 'No',
				'Pregnency.is_exit' => 1,
				$cond1,
			)
		));
		$total_exits_this_month = 0;
		$total_exits_this_month = $this->Pregnency->find('count', array(
			'conditions' => array(
				'Pregnency.is_exit' => 1,
				"Pregnency.exit_date between '" . $from_date_global . "' and '" . $to_date_global . "'",
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));

		$this->set(compact('total_exits', 'total_exits_this_month'));

		$total_suspects = 0;
		$total_suspects = $this->Beneficiary->find('count', array(
			'conditions' => array(
				'Beneficiary.is_suspect' => 1,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('total_suspects'));

		$total_pvtg = 0;
		$total_pvtg = $this->Beneficiary->find('count', array(
			'conditions' => array(
				'Beneficiary.is_pvtg' => 'Y',
				$cond1,
			)
		));
		$this->set(compact('total_pvtg'));
		$installment1_approved = 0;
		$installment1_not_approved = 0;
		$installment1_approved = $this->VerifyFirst->find('count', array(
			'conditions' => array(
				$cond1,
				/*'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 1,
				'Pinstallment.is_payment_approve' => 1,*/
				"VerifyFirst.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=1 AND totalverify = 6 )"
			)
		));
		// @ Installment 1 Not Approved Count
		$installment1_not_approved = $this->Pregnency->find('count', array(
			'recursive' => 2,
			'joins' => array(
					array(
						    'table' => 'pinstallments',
						    'alias' => 'Pinstallment',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
				),
			'conditions' => array(
				"Pinstallment.installment_no" => 1,
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
				"Pregnency.is_approved" => 1,
				"Pregnency.id NOT IN  (SELECT pregnency_id FROM view_first_verify)",
				$cond1,
			)
		));
		$this->set(compact('installment1_not_approved', 'installment1_not_approved'));
		//debug($cond1);
		$installment_approved_count = $this->Pregnency->find('count', array(
			'recursive' => 2,
			'conditions' => array(
				$cond1,
				'Pregnency.is_approved' => 1,
				"Beneficiary.husband_govt" => 'No',
				'Beneficiary.age >= 19 AND Beneficiary.age <= 45'
			)
		));
		/*$installment1_not_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 1,
				'Pinstallment.is_payment_approve' => 0,
			)
		));*/
		$this->set('installment_approved_count' , $installment_approved_count);
		// $installment1_not_approved=$pregnency_registered-$installment1_approved;

		$this->set(compact('installment1_approved', 'installment1_not_approved'));
		$installment2_approved = 0;
		$installment2_not_approved = 0;
		/*$installment2_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 2,
				'Pinstallment.is_payment_approve' => 1,
			)
		));*/
		
		$installment2_approved = $this->VerifySecond->find('count', array(
			'conditions' => array(
				$cond1,
				/*'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 1,
				'Pinstallment.is_payment_approve' => 1,*/
				"VerifySecond.pregnency_id IN (SELECT pregnency_id FROM view_second_verify WHERE pregnency_no=2 AND firstcnt >= 13 AND secondcnt >= 6)"
			)
		));

		$installment2_not_approved = $this->Pregnency->find('count', array(
			'recursive' => 2,
			'joins' => array(
					array(
						    'table' => 'pinstallments',
						    'alias' => 'Pinstallment',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'Pregnency.id = Pinstallment.pregnency_id'
						    )
						),
					
					array(
						    'table' => 'users',
						    'alias' => 'User',
						    'type' => 'LEFT',
						    'conditions' => array(
						        'User.id = Beneficiary.user_id'
						    )
						),
				),
			'conditions' => array(
				"Pinstallment.installment_no" => 2,
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
				"Pregnency.is_approved" => 1,
				"Pregnency.id NOT IN (SELECT pregnency_id FROM view_second_verify)",
				$cond1,
			)
		));

		// $installment2_not_approved = $this->VerifySecond->find('count', array(
		// 	'conditions' => array(
		// 		$cond1,
		// 		'Beneficiary.husband_govt' => 'No',
		// 		'Pinstallment.installment_no' => 1,
		// 		'Pinstallment.is_payment_approve' => 1,
		// 		"VerifySecond.pregnency_id IN (SELECT pregnency_id FROM view_second_verify WHERE pregnency_no=2 AND firstcnt < 13 AND secondcnt < 6)"
		// 	)
		// ));
		/*$installment2_not_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 2,
				'Pinstallment.is_payment_approve' => 0,
			)
		));*/

		// $installment2_not_approved=$pregnency_registered-$installment2_approved;

		$this->set(compact('installment2_approved', 'installment2_not_approved'));
		$aww_inc_received = 0;
		$cond1 = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$cond1 = " and project_id='" . $user['Project']['id'] . "'";
		}

		$aww_inc_received = $this->Incentive->find('count', array(
			'conditions' => array(
				'Incentive.is_paid' => 1,
				"Incentive.worker_id in(select id from workers where workertype_id=1" . $cond1 . ")"
			)
		));
		$this->set(compact('aww_inc_received'));
		$awh_inc_received = $this->Incentive->find('count', array(
			'conditions' => array(
				'Incentive.is_paid' => 1,
				"Incentive.worker_id in(select id from workers where workertype_id=2" . $cond1 . ")"
			)
		));
		$this->set(compact('awh_inc_received'));

		// //////////////////////////

	}

	public

	function login($token='')
	{
		$this->layout = 'login';
		if(isset($token) && $token!=''){
			$this->set('msg', '<div class="alert alert-danger">It seems that Date Time of your machine not matched with Server Date time. Plese Correct your System Date time.</div>');
		}
		if ($this->request->is(array('post','put'))) {
			$user_id = $this->request->data['User']['user_id'];
			$password = $this->request->data['User']['password'];
			$captcha = $this->request->data['User']['captcha'];
			$captcha1 = $this->Session->read('captcha');
			if ($captcha != $captcha1) {
				$this->message('error', 'Invalid Captcha !');
			}
			else {
				$exist = 0;
				$exist = $this->User->find('count', array(
					'conditions' => array(
						'User.user_id' => $user_id,
						'User.password' => $password,
					)
				));
				if ($exist != 1) {
					$this->message('error', 'Invalid User Credential !');
				}
				else {
					$data = $this->User->find('first', array(
						'conditions' => array(
							'User.user_id' => $user_id,
							'User.password' => $password,
						)
					));
					//debug($data); exit;
					$this->Session->write('user_auth', $data);
					$this->redirect(array(
						'controller' => 'dashboard',
						'action' => 'index'
					));
				}
			}
		}
	}

	public

	function captcha()
	{
		$this->layout = NULL;
		$string = rand(1111, 9999);
		$this->Session->write('captcha', $string);
		header("Content-type: image/png");

		// //////////////////

		$font = 80;
		$width = ImageFontWidth($font) * strlen($string);
		$height = ImageFontHeight($font);
		$im = @imagecreate($width, $height);
		$background_color = imagecolorallocate($im, 255, 255, 255); //white background
		$text_color = imagecolorallocate($im, 0, 0, 0); //black text
		imagestring($im, $font, 0, 0, $string, $text_color);
		imagepng($im);
		exit();
	}

	public function logout()
	{
		$this->Session->write('user_auth', '');
		session_destroy();
		$this->redirect(array(
			'controller' => 'dashboard',
			'action' => 'login'
		));
	}

	public function changeprofile()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}

		if ($this->request->is(array(
			'post',
			'put'
		))) {
			if ($this->User->save($this->request->data)) {
				$this->message('success', 'Saved Successfully !');
			}
			else {
				$this->message('error', 'Saving Failed !');
			}
		}

		$user = $this->Session->read('user_auth');
		$this->request->data = $this->User->findById($user['User']['id']);
	}

	public function changepassword()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}

		if ($this->request->is(array(
			'post',
			'put'
		))) {
			if ($this->User->save($this->request->data)) {
				$this->message('success', 'Saved Successfully !');
			}
			else {
				$this->message('error', 'Saving Failed !');
			}
		}

		$user = $this->Session->read('user_auth');
		$this->request->data = $this->User->findById($user['User']['id']);
	}
}

<?php
App::uses('AppControler', 'Controller');
class BeneficiariesController extends AppController

{
  public $components = array(

    'Paginator',
    'Flash',
    'Session'
  );

  /**
    * By : Tanmaya/15-03-2017
    * Info : RCH OR MCTS Number Validation
    **/
  public function search_mctno(){
        $this->autoRender = false;
        $this->loadModel('Beneficiary');
        $number = $this->params->query['mother_id'];
        $num_type = $this->params->query['num_type'];

        $getData = $this->Beneficiary->find('first', array(
          'recursive' => -1,
          'conditions' => array(
            'rch_mcts_no' => $number
          )
        ));
        if(isset($getData) && is_array($getData) && count($getData) > 0 ){
          echo "1";
        }else{
          echo "0";
        }
    }

    public function ben_history()
    {
      $this->layout = 'ajax';
      $this->loadModel('Beneficiary');
      $this->loadModel('Pregnency');
      $uid = $this->params->query['uid'];

      $data = $this->Beneficiary->find('all', array(
        'conditions' => array(
          "Beneficiary.id in(select beneficiary_id from pregnencies where id=$uid)"
        )
      ));

      //debug($data);
      $this->set(array(
        'datas' => $data[0]
      ));

    }

  public

  function beforeFilter()
  {
    $this->response->disableCache();
    if ($this->Session->read('user_auth') == '') {
      $this->redirect(array(
        'controller' => 'dashboard',
        'action' => 'login'
      ));
    }
  }

  public function index()
  {
    $this->loadModel('Pregnency');
    $this->loadModel('Pinstallment');
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      if ($this->request->data['Beneficiary']['exit_reason'] != '') {
        $ben_id = $this->request->data['Beneficiary']['id'];
        $exit_reason = $this->request->data['Beneficiary']['exit_reason'];
        if ($ben_id != '' && $exit_reason != '') {
          $this->loadModel('Pregnency');
          $pregnency_id = '';
          $pregnency_id = $this->Pregnency->find('first', array(
            'conditions' => array(
              'Pregnency.beneficiary_id' => $ben_id
            ) ,
            'order' => array(
              'Pregnency.id' => 'DESC'
            )
          ));
          $pregnency_id = $pregnency_id['Pregnency']['id'];
          $this->Pregnency->id = $pregnency_id;
          $this->Pregnency->saveField('is_exit', 1);
          $this->Pregnency->saveField('exit_reason', $exit_reason);
          $this->Pregnency->saveField('exit_date', date('Y-m-d'));
          $this->message('success', 'Exit Details Saved Successfully !');
        }
      }
    }

    $datas = "";
    $user = $this->Session->read('user_auth');
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Gp.project_id='" . $user['Project']['id'] . "'";
    }

    if ($user['Designation']['name'] != 'CDPO' && $user['Designation']['name'] != 'PA') {
      $gp_id = '';
    }
    else {
      $gp_id = $this->Beneficiary->Gp->find('list', array(
        'conditions' => array(

          // 'Gp.id in(select gp_id from beneficiaries)',

          $sqlcond1,
        ) ,
        'order' => array(
          'Gp.name'
        )
      ));
    }

    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
    }

    $sector_id = $this->Beneficiary->Sector->find('list', array(
      'conditions' => array(
        $sqlcond1

        // 'Sector.id in(select sector_id from beneficiaries)'

      ) ,
      'order' => array(
        'Sector.name'
      )
    ));
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Awc.project_id='" . $user['Project']['id'] . "'";
    }

    /*  $awc_id = $this->Beneficiary->Awc->find('list', array(
    'conditions' => array(

    // 'Awc.id in(select awc_id from beneficiaries)'

    $sqlcond1
    ) ,
    'order' => array(
    'Awc.name'
    )
    )); */
    $awc_id = '';
    if ($this->request->data['Beneficiary']['sector_id'] != '') {
      $awc_id = $this->Beneficiary->Awc->find('list', array(
        'conditions' => array(
          'Awc.sector_id' => $this->request->data['Beneficiary']['sector_id']
        ) ,
        'order' => array(
          'Awc.name'
        )
      ));
    }

    $husband_govt = array(
      'No' => 'No',
      'Yes' => 'Yes'
    );
    $is_suspect = array(
      '2' => 'All',
      '0' => 'No',
      '1' => 'Yes',
    );
    $exit_reasons = array(
      'INFANT DEATH' => 'INFANT DEATH',
      'MISCARRIAGE' => 'MISCARRIAGE',
      'MIGRATION' => 'MIGRATION'
    );
    $is_pvtg = array(
      'N' => 'No',
      'Y' => 'Yes'
    );
    $in_scheme = array(
      '0' => 'No',
      '1' => 'Yes',
    );

    $this->set(compact('in_scheme', 'is_pvtg', 'datas', 'gp_id', 'sector_id', 'awc_id', 'husband_govt', 'is_suspect', 'exit_reasons'));
  }

  // ///////////////////////////////////////

  public

  function index_ajax()
  {
    $this->layout = 'ajax';
    $sql_name = "";
    if ($this->params['named']['name'] != '') {
      $sql_name = "Beneficiary.name like '%" . $this->params['named']['name'] . "%'";
      $this->set('name', $this->params['named']['name']);
    }

    $sql_rch_mcts_no = "";
    if ($this->params['named']['rch_mcts_no'] != '') {
      $sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->params['named']['rch_mcts_no'] . "'";
      $this->set('rch_mcts_no', $this->params['named']['rch_mcts_no']);
    }

    $sql_account_no = "";
    if ($this->params['named']['account_no'] != '') {
      $sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
      $this->set('account_no', $this->params['named']['account_no']);
    }

    $sql_gp_id = "";
    if ($this->params['named']['gp_id'] != '') {
      $sql_gp_id = "Beneficiary.gp_id='" . $this->params['named']['gp_id'] . "'";
      $this->set('gp_id', $this->params['named']['gp_id']);
    }

    $sql_awc_id = "";
    if ($this->params['named']['awc_id'] != '') {
      $sql_awc_id = "Beneficiary.awc_id='" . $this->params['named']['awc_id'] . "'";
      $this->set('awc_id', $this->params['named']['awc_id']);
    }

    $sql_sector_id = "";
    if ($this->params['named']['sector_id'] != '') {
      $sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
      $this->set('sector_id', $this->params['named']['sector_id']);
    }

    $sql_date = "";
    if ($this->params['named']['from_date'] != '' && $this->params['named']['to_date'] != '') {

      // Code changed by Tanmaya.

      $this->set('from_date', $this->params['named']['from_date']);
      $this->set('to_date', $this->params['named']['to_date']);
      $from_date = $this->date2DB($this->params['named']['from_date']);
      $to_date = $this->date2DB($this->params['named']['to_date']);
      $sql_date = "Beneficiary.reg_date between '" . $from_date . "' and '" . $to_date . "'";
    }

    $sql_husband = "";
    if ($this->params['named']['husband_govt'] != '') {
      $sql_husband = "Beneficiary.husband_govt = '" . $this->params['named']['husband_govt'] . "'";
      $this->set('husband_govt', $this->params['named']['husband_govt']);
    }

    $sql_is_suspect = "";
    if ($this->params['named']['is_suspect'] != '' && $this->params['named']['is_suspect'] != 2) {
      $sql_is_suspect = "Beneficiary.is_suspect = '" . $this->params['named']['is_suspect'] . "'";
      $this->set('is_suspect', $this->params['named']['is_suspect']);
    }

    $sql_is_pvtg = "";
    if ($this->params['named']['is_pvtg'] != '') {
      $sql_is_pvtg = "Beneficiary.is_pvtg='" . $this->params['named']['is_pvtg'] . "'";
      $this->set('is_pvtg', $this->params['named']['is_pvtg']);
    }

    $user = $this->Session->read('user_auth');
    $sql = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
    }

    $sql_in_scheme = "";
    if ($this->params['named']['in_scheme'] == "1" || $this->params['named']['in_scheme'] == "") {
      $this->set('in_scheme', $this->params['named']['in_scheme']);
      $sql_in_scheme = "Beneficiary.husband_govt = 'No' and Beneficiary.age >= 19 and Beneficiary.age <= 45";
    }

    if ($this->params['named']['in_scheme'] == "0") {
      $this->set('in_scheme', $this->params['named']['in_scheme']);
      $sql_in_scheme = "Beneficiary.husband_govt = 'Yes' or Beneficiary.age < 19 or Beneficiary.age > 45";
    }


    //////////////////////////////

    // /////Download//////////////////////

    if (isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != '') {
      $this->layout = 'export_xls';
      if ($this->params['named']['reqType'] == 'XLS') {
        $this->set('file_type', 'xls');
        $this->set('file_name', 'beneficiaries' . date('d_m_Y') . '.xls');
      }
      else
      if ($this->params['named']['reqType'] == 'DOC') {
        $this->set('file_type', 'doc');
        $this->set('file_name', 'beneficiaries' . date('d_m_Y') . '.doc');
      }

      $this->set('is_excel', 'Y');
      $limit = array(
        'limit' => 2000,
        'maxLimit' => 2000
      );
    }
    else {
      $limit = array(
        'limit' => 10
      );
    }

    // //End Download//////////////////////

    $this->paginate = array(
      'conditions' => array(
        $sql,
        $sql_name,
        $sql_rch_mcts_no,
        $sql_account_no,
        $sql_gp_id,
        $sql_awc_id,
        $sql_sector_id,
        $sql_husband,
        $sql_is_suspect,
        $sql_is_pvtg,
        $sql_in_scheme,
        $sql_date
      ) ,
      'order' => array(
        'Beneficiary.id' => 'DESC'
      ) ,
      'maxLimit' => 2000,
    ) + $limit;
    $datas = $this->paginate('Beneficiary');
   /* debug($datas);*/
    $this->set(compact('datas', 'sql', 'sql_name', 'sql_rch_mcts_no', 'sql_account_no', 'sql_gp_id', 'sql_awc_id', 'sql_sector_id', 'sql_husband'));
    $this->set(compact('sql_is_suspect', 'sql_is_pvtg', 'sql_in_scheme', 'sql_date'));
  }

  // ///////////////////////////////////////

  public

  function add()
  {
    $this->layout = 'admin';
    $this->loadModel('Awc');
    $session = $this->Session->read('user_auth');
    $project_id = $session['User']['project_id'];
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      if ($this->request->data['Beneficiary']['husband_govt'] == 'Yes') {
        $this->request->data['Beneficiary']['bank_id'] = 0;
        $this->request->data['Beneficiary']['branch_id'] = 0;
        $this->request->data['Beneficiary']['account_no'] = '';
      }

      $reg_date = $this->request->data['Beneficiary']['reg_date'];
      $reg_date = explode('/', $reg_date);
      $reg_date = $reg_date[2] . '-' . $reg_date[1] . '-' . $reg_date[0];
      $this->request->data['Beneficiary']['reg_date'] = $reg_date;
      $dob = NULL;
      if ($this->request->data['Beneficiary']['dob'] != "") {
        $dob = $this->request->data['Beneficiary']['dob'];

        // $dob = explode('/', $dob);
        // $dob = $dob[2] . '-' . $dob[1] . '-' . $dob[0];
        // Code Mofidied by Tanmaya

        $dob = $this->date2DB($dob);
        $this->request->data['Beneficiary']['dob'] = $dob;
      }

      $user = $this->Session->read('user_auth');
      $user_id = $user['User']['id'];
      $this->request->data['Beneficiary']['user_id'] = $user_id;
      if ($user_id == "") {
        $this->message("error", "Invalid User ! Please login again and try.");
      }
      else {
        $this->request->data['Beneficiary']['is_exit'] = 0;
        $birthdate = new DateTime($dob);
        $today = new DateTime('today');
        $agev = $birthdate->diff($today)->y;
        if ($this->request->data['Beneficiary']['age'] != '') {
          $agev = $this->request->data['Beneficiary']['age'];
        }

        if ($agev < 0 || $agev > 150) {
          $reg_date = $this->request->data['Beneficiary']['reg_date'];
          $reg_date = explode('-', $reg_date);
          $reg_date = $reg_date[2] . '/' . $reg_date[1] . '/' . $reg_date[0];
          $this->request->data['Beneficiary']['reg_date'] = $reg_date;
          if ($this->request->data['Beneficiary']['dob'] != "") {
            $dob = $this->request->data['Beneficiary']['dob'];
            $dob = explode('-', $dob);
            $dob = $dob[2] . '/' . $dob[1] . '/' . $dob[0];
            $this->request->data['Beneficiary']['dob'] = $dob;
          }

          $this->message('error', 'Age must be in between 19 and 45 !');
        }
        else {
          $this->request->data['Beneficiary']['is_check_suspect'] = 1;

          // Find if PVTG//

          $is_pvtg = 'N';
          $is_awc_pvtg = 0;
          $is_awc_pvtg = $this->Awc->find('count', array(
            'conditions' => array(
              'Awc.id' => $this->request->data['Beneficiary']['awc_id'],
              'Awc.is_pvtg' => 'Y'
            )
          ));
          if ($is_awc_pvtg > 0 && $this->request->data['Beneficiary']['caste'] == 'ST' && $this->request->data['Beneficiary']['is_pvtg'] == 'Y') {
            $this->request->data['Beneficiary']['is_pvtg'] = 'Y';
          }
          else {
            $this->request->data['Beneficiary']['is_pvtg'] = 'N';
          }

          // End of finding if PVTG//

          if ($this->Beneficiary->save($this->request->data)) {
            $this->Beneficiary->query("update beneficiaries set is_pvtg='" . $this->request->data['Beneficiary']['is_pvtg'] . "' where id='" . $this->Beneficiary->getLastInsertId() . "'");
            $this->message('success', 'Saved Successfully !');
            $this->redirect(array(
              'action' => 'index'
            ));
          }
          else {
            $reg_date = $this->request->data['Beneficiary']['reg_date'];
            $reg_date = explode('-', $reg_date);
            $reg_date = $reg_date[2] . '/' . $reg_date[1] . '/' . $reg_date[0];
            $this->request->data['Beneficiary']['reg_date'] = $reg_date;
            if ($this->request->data['Beneficiary']['dob'] != "") {
              $dob = $this->request->data['Beneficiary']['dob'];
              $dob = explode('-', $dob);
              $dob = $dob[2] . '/' . $dob[1] . '/' . $dob[0];
              $this->request->data['Beneficiary']['dob'] = $dob;
            }

            $this->message('error', 'Saving Failed !');
          }
        }
      }
    }

    $is_rch_mcts = array(
      '0' => 'RCH',
      '1' => 'MCTS'
    );
    $user = $this->Session->read('user_auth');
    $sector_id = $this->Beneficiary->Sector->find('list', array(
      'conditions' => array(
        'Sector.project_id' => $user['Project']['id'],
      ) ,
      'order' => array(
        'Sector.name'
      ) ,
      'conditions' => array(
        'project_id' => $project_id
      )
    ));
    $gp_id = $this->Beneficiary->Gp->find('list', array(
      'order' => array(
        'Gp.name'
      ) ,
      'conditions' => array(
        'project_id' => $project_id
      )
    ));
    $caste = array(
      'General' => 'General',
      'OBC' => 'OBC',
      'ST' => 'ST',
      'SC' => 'SC',
      'Others' => 'Others'
    );
    $husband_govt = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $mobile_belong = array(
      'Self' => 'Self',
      'Husband' => 'Husband',
      'Parents' => 'Parents'
    );
    $bank_id = $this->Beneficiary->Bank->find('list', array(
      'order' => array(
        'Bank.name'
      ) ,
    ));
    $branch_id = '';
    if (isset($this->request->data['Beneficiary']['bank_id']) && $this->request->data['Beneficiary']['bank_id'] != '') {
      $branch_id = $this->Beneficiary->Branch->find('list', array(
        'conditions' => array(
          'Branch.bank_id' => $this->request->data['Beneficiary']['bank_id']
        ) ,
        'order' => array(
          'Branch.name'
        ) ,
      ));
    }

    $is_bpl = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $is_disability = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $awc_id = '';
    if (@$this->request->data['Beneficiary']['sector_id'] != '') {
      $awc_id = $this->Beneficiary->Awc->find('list', array(
        'conditions' => array(
          'Awc.sector_id' => $this->request->data['Beneficiary']['sector_id']
        ) ,
        'order' => array(
          'Awc.name'
        ) ,
      ));
    }

    $religion_id = $this->Beneficiary->Religion->find('list');
    $worker_id = "";
    if (@$this->request->data['Beneficiary']['worker_id'] != '') {
      $worker_id = $this->Beneficiary->Worker->find('list', array(
        'conditions' => array(
          'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
          'Worker.workertype_id' => 1
        ) ,
        'order' => array(
          'Worker.name'
        )
      ));
    }

    $helper_id = "";
    if (@$this->request->data['Beneficiary']['helper_id'] != '') {
      $helper_id = $this->Beneficiary->Worker->find('list', array(
        'conditions' => array(
          'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
          'Worker.workertype_id' => 2
        ) ,
        'order' => array(
          'Worker.name'
        )
      ));
    }

    $is_pvtg = array(
      'N' => 'No',
      'Y' => 'Yes'
    );
    $this->set(compact('is_pvtg', 'is_rch_mcts', 'sector_id', 'gp_id', 'caste', 'husband_govt', 'mobile_belong', 'bank_id', 'branch_id', 'is_bpl', 'is_disability', 'religion_id', 'awc_id', 'worker_id', 'helper_id'));
  }

  public

  function edit($id)
  {

    $this->loadModel('Awc');

    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      if ($this->request->data['Beneficiary']['husband_govt'] == 'Yes') {
        $this->request->data['Beneficiary']['bank_id'] = 0;
        $this->request->data['Beneficiary']['branch_id'] = 0;
        $this->request->data['Beneficiary']['account_no'] = '';

      }

      $reg_date = $this->request->data['Beneficiary']['reg_date'];
      $reg_date = explode('/', $reg_date);
      $reg_date = $reg_date[2] . '-' . $reg_date[1] . '-' . $reg_date[0];
      $this->request->data['Beneficiary']['reg_date'] = $reg_date;
      $dob = NULL;
      if ($this->request->data['Beneficiary']['dob'] != "") {
        $dob = $this->request->data['Beneficiary']['dob'];
        $dob = explode('/', $dob);
        $dob = $dob[2] . '-' . $dob[1] . '-' . $dob[0];
        $this->request->data['Beneficiary']['dob'] = $dob;
      }

      $user = $this->Session->read('user_auth');
      $user_id = $user['User']['id'];
      $this->request->data['Beneficiary']['user_id'] = $user_id;
      if ($user_id == "") {
        $this->message("error", "Invalid User ! Please login again and try.");
      }
      else {
        $this->request->data['Beneficiary']['is_exit'] = 0;
        $birthdate = new DateTime($dob);
        $today = new DateTime('today');
        $agev = $birthdate->diff($today)->y;
        if ($this->request->data['Beneficiary']['age'] != '') {
          $agev = $this->request->data['Beneficiary']['age'];
        }

        if ($agev < 0 || $agev > 150) {
          $reg_date = $this->request->data['Beneficiary']['reg_date'];
          $reg_date = explode('-', $reg_date);
          $reg_date = $reg_date[2] . '/' . $reg_date[1] . '/' . $reg_date[0];
          $this->request->data['Beneficiary']['reg_date'] = $reg_date;
          if ($this->request->data['Beneficiary']['dob'] != "") {
            $dob = $this->request->data['Beneficiary']['dob'];
            $dob = explode('-', $dob);
            $dob = $dob[2] . '/' . $dob[1] . '/' . $dob[0];
            $this->request->data['Beneficiary']['dob'] = $dob;
          }

          $this->message('error', 'Age must be in between 19 and 45 !');
        }
        else {

          $this->request->data['Beneficiary']['is_check_suspect'] = 1;
          $this->request->data['Beneficiary']['suspect_reason'] = '';
          $this->request->data['Beneficiary']['suspect_action'] = '';
          $this->request->data['Beneficiary']['action_user_id'] = NULL;
          $this->request->data['Beneficiary']['action_date'] = NULL;
          $is_pvtg = 'N';
          $is_awc_pvtg = 0;
          $is_awc_pvtg = $this->Awc->find('count', array(
            'conditions' => array(
              'Awc.id' => $this->request->data['Beneficiary']['awc_id'],
              'Awc.is_pvtg' => 'Y'
            )
          ));
          if ($is_awc_pvtg > 0 && $this->request->data['Beneficiary']['caste'] == 'ST' && $this->request->data['Beneficiary']['is_pvtg'] == 'Y') {
            $this->request->data['Beneficiary']['is_pvtg'] = 'Y';
          }
          else {
            $this->request->data['Beneficiary']['is_pvtg'] = 'N';
          }

unset($this->Beneficiary->validate['account_no']);
          if ($this->Beneficiary->save($this->request->data)) {
            $this->Beneficiary->query("update beneficiaries set is_pvtg='" . $this->request->data['Beneficiary']['is_pvtg'] . "' where id='" . $id . "'");
            $this->message('success', 'Saved Successfully !');
            $this->redirect(array(
              'action' => 'index'
            ));
          }
          else {
            $reg_date = $this->request->data['Beneficiary']['reg_date'];
            $reg_date = explode('-', $reg_date);
            $reg_date = $reg_date[2] . '/' . $reg_date[1] . '/' . $reg_date[0];
            $this->request->data['Beneficiary']['reg_date'] = $reg_date;
            if ($this->request->data['Beneficiary']['dob'] != "") {
              $dob = $this->request->data['Beneficiary']['dob'];
              $dob = explode('-', $dob);
              $dob = $dob[2] . '/' . $dob[1] . '/' . $dob[0];
              $this->request->data['Beneficiary']['dob'] = $dob;
            }

            $this->message('error', 'Saving Failed !');
          }
        }
      }
    }

    $this->request->data = $this->Beneficiary->findById($id);
    $reg_date = $this->request->data['Beneficiary']['reg_date'];
    $reg_date = explode('-', $reg_date);
    $reg_date = $reg_date[2] . '/' . $reg_date[1] . '/' . $reg_date[0];
    $this->request->data['Beneficiary']['reg_date'] = $reg_date;
    $this->request->data['Beneficiary']['account_no1'] = $this->request->data['Beneficiary']['account_no'];
    if ($this->request->data['Beneficiary']['dob'] != '') {
      $dob = $this->request->data['Beneficiary']['dob'];
      $dob = explode('-', $dob);
      $dob = $dob[2] . '/' . $dob[1] . '/' . $dob[0];
      $this->request->data['Beneficiary']['dob'] = $dob;
    }

    $is_rch_mcts = array(
      '0' => 'RCH',
      '1' => 'MCTS'
    );
    $user = $this->Session->read('user_auth');
    $project_id = $user['Project']['id'];
    $sector_id = $this->Beneficiary->Sector->find('list', array(
      'conditions' => array(
        'Sector.project_id' => $user['Project']['id'],
      ) ,
      'order' => array(
        'Sector.name'
      ) ,
      'conditions' => array(
        'project_id' => $project_id
      )
    ));
    $gp_id = $this->Beneficiary->Gp->find('list', array(
      'order' => array(
        'Gp.name'
      ) ,
      'conditions' => array(
        'project_id' => $project_id
      )
    ));
    $caste = array(
      'General' => 'General',
      'OBC' => 'OBC',
      'ST' => 'ST',
      'SC' => 'SC',
      'Others' => 'Others'
    );
    $husband_govt = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $mobile_belong = array(
      'Self' => 'Self',
      'Husband' => 'Husband',
      'Parents' => 'Parents'
    );
    $bank_id = $this->Beneficiary->Bank->find('list', array(
      'order' => array(
        'Bank.name'
      ) ,
    ));
    $branch_id = '';
    if ($this->request->data['Beneficiary']['bank_id'] != '') {
      $branch_id = $this->Beneficiary->Branch->find('list', array(
        'conditions' => array(
          'Branch.bank_id' => $this->request->data['Beneficiary']['bank_id']
        ) ,
        'order' => array(
          'Branch.name'
        ) ,
      ));
    }

    $is_bpl = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $is_disability = array(
      'Yes' => 'Yes',
      'No' => 'No'
    );
    $awc_id = '';
    if (@$this->request->data['Beneficiary']['sector_id'] != '') {
      $awc_id = $this->Beneficiary->Awc->find('list', array(
        'conditions' => array(
          'Awc.sector_id' => $this->request->data['Beneficiary']['sector_id']
        ) ,
        'order' => array(
          'Awc.name'
        ) ,
      ));
    }

    $religion_id = $this->Beneficiary->Religion->find('list');
    $worker_id = "";
    if (@$this->request->data['Beneficiary']['worker_id'] != '') {
      $worker_id = $this->Beneficiary->Worker->find('list', array(
        'conditions' => array(
          'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
          'Worker.workertype_id' => 1
        ) ,
        'order' => array(
          'Worker.name'
        )
      ));
    }

    $helper_id = "";
    if (@$this->request->data['Beneficiary']['helper_id'] != '') {
      $helper_id = $this->Beneficiary->Worker->find('list', array(
        'conditions' => array(
          'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
          'Worker.workertype_id' => 2
        ) ,
        'order' => array(
          'Worker.name'
        )
      ));
    }

    $is_pvtg = array(
      'N' => 'No',
      'Y' => 'Yes'
    );
    $this->set(compact('is_pvtg', 'is_rch_mcts', 'sector_id', 'gp_id', 'caste', 'husband_govt', 'mobile_belong', 'bank_id', 'branch_id', 'is_bpl', 'is_disability', 'religion_id', 'awc_id', 'worker_id', 'helper_id'));
  }

  public

  function delete($id)
  {
    $this->Beneficiary->delete($id);
    $this->message('success', 'Deleted Successfully !');
    $this->redirect(array(
      'action' => 'index'
    ));
  }

  public

  function loadbranches($id)
  {
    $this->layout = NULL;
    $branch_id = $this->Beneficiary->Branch->find('list', array(
      'conditions' => array(
        'Branch.bank_id' => $id
      ) ,
      'order' => array(
        'Branch.name'
      ) ,
    ));
    $this->set(compact('branch_id'));
  }

  public

  function loadawcs($id)
  {
    $this->layout = NULL;
    $awc_id = $this->Beneficiary->Awc->find('list', array(
      'conditions' => array(
        'Awc.sector_id' => $id
      ) ,
      'order' => array(
        'Awc.name'
      ) ,
    ));
    $this->set(compact('awc_id'));
  }

  public

  function loadworker($id)
  {
    $this->layout = NULL;
    $user = $this->Session->read('user_auth');
    $this->loadModel('Assignment');
    $worker_id = $this->Assignment->Worker->find('list', array(
      'conditions' => array(
        'Worker.awc_id' => $id,
        'Worker.workertype_id' => 1,
        'Worker.project_id' => $user['Project']['id'],
        "Worker.id in(select worker_id from assignments where is_removed=0 and awc_id='" . $id . "' and project_id='" . $user['Project']['id'] . "' order by id desc)",
      ) ,
      'order' => array(
        'Worker.name'
      ) ,
    ));
    $this->set(compact('worker_id'));
  }

  public

  function loadhelper($id)
  {
    $this->layout = NULL;
    $helper_id = $this->Beneficiary->Worker->find('list', array(
      'conditions' => array(
        'Worker.awc_id' => $id,
        'Worker.workertype_id' => 2
      ) ,
      'order' => array(
        'Worker.name'
      ) ,
    ));
    $this->set(compact('helper_id'));
  }

  public

  function calage($age)
  {
    $this->layout = NULL;
    $age = explode('-', $age);
    $age = $age[2] . '-' . $age[1] . '-' . $age[0];
    $birthdate = new DateTime($age);
    $today = new DateTime('today');
    $age = $birthdate->diff($today)->y;
    echo $age;
    exit();
  }

  public

  function confirmsuspect($id)
  {
    $this->layout = NULL;
    $u = $this->Session->read('user_auth');
    $this->Beneficiary->id = $id;
    $this->Beneficiary->saveField('suspect_action', 'CONFIRMED');
    $this->Beneficiary->saveField('action_user_id', $u['User']['id']);
    $this->Beneficiary->saveField('action_date', date("Y-m-d"));
    $this->Beneficiary->saveField('is_suspect', 0);
    echo "Confirmed Successfully !";
    exit();
  }

  public

  function rejectsuspect($id)
  {
    $this->layout = NULL;
    $u = $this->Session->read('user_auth');
    $this->Beneficiary->id = $id;
    $this->Beneficiary->saveField('suspect_action', 'REJECTED');
    $this->Beneficiary->saveField('action_user_id', $u['User']['id']);
    $this->Beneficiary->saveField('action_date', date("Y-m-d"));
    echo "Rejected Successfully !";
    exit();
  }

  public

  function firstverify($id)
  {
  }

  // //////////////////////////////////////

  public

  function view($id)
  {
    $this->loadModel('Delivery');
    $data = $this->Beneficiary->findById($id);
    $this->set(compact('data'));
  }

  public

  function returnlive($id)
  {

    //  $this->layout=NULL;

    $this->loadModel('Delivery');
    $this->loadModel('Pregnency');
    $live_birth_reg = 0;
    $live_birth_del = 0;
    $live_birth_total = 0;
    $live_birth_reg = $this->Beneficiary->findById($id);
    $live_birth_reg = $live_birth_reg['Beneficiary']['no_of_live_birth'];
    $this->Delivery->recursive = - 1;
    $d = $this->Delivery->find('all', array(
      'conditions' => array(
        'Delivery.beneficiary_id' => $id,
      ) ,
      'order' => array(
        'Delivery.id'
      )
    ));


    $this->Pregnency->recursive=-1;
    $e=$this->Pregnency->find('all',array(
      'conditions'=>array(
        'Pregnency.beneficiary_id'=>$id
      ),
      'order'=>array(
        'Pregnency.id'=>'DESC'
      ),
      //'limit'=>1
    ));

    foreach($e as $e1){
      if(strtoupper($e1['Pregnency']['exit_reason']) == 'INFANT DEATH'){
        $live_birth_del=$live_birth_del + 1;
      }
    }

    foreach($d as $d1) {
      if ($d1['Delivery']['outcome'] == 'Single Live Birth') {
        $live_birth_del = $live_birth_del + 1;
      }

  //    if ($d1['Delivery']['outcome'] == 'Infant Death') {
  //      $live_birth_del = $live_birth_del + 1;
//      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] == 'Yes' && $d1['Delivery']['child2_live_birth'] == 'Yes') {
        $live_birth_del = $live_birth_del + 2;
      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] != 'Yes' && $d1['Delivery']['child2_live_birth'] == 'Yes') {
        $live_birth_del = $live_birth_del + 1;
      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] == 'Yes' && $d1['Delivery']['child2_live_birth'] != 'Yes') {
        $live_birth_del = $live_birth_del + 1;
      }
    }

    // $live_birth_total=$live_birth_reg + $live_birth_del;

    $live_birth_total = $live_birth_del;
    return $live_birth_total;

    //  exit();

  }

  public

  function loadispvtg($id)
  {
    $this->layout = NULL;
    $this->loadModel('Awc');
    $cnt = $this->Awc->find('count', array(
      'conditions' => array(
        'Awc.is_pvtg' => 'Y',
        'Awc.id' => $id
      )
    ));
    if ($cnt > 0) {
      echo "SHOW";
    }
    else {
      echo "HIDE";
    }

    exit();
  }

  // /////////////////////////
  public  function maternaldeath($id)
  {
    $this->layout = NULL;
    $this->loadModel('Pregnency');
    $this->Pregnency->query("update pregnencies set is_exit=1,exit_reason='MATERNAL DEATH',exit_date=curdate() where id=$id");
    exit();
  }
///////////////////////////
public function mcdeath($id)
{
  $this->layout = NULL;
  $this->loadModel('Pregnency');
  $this->Pregnency->query("update pregnencies set is_exit=1,exit_reason='MISCARRIAGE',exit_date=curdate() where id=$id");
  exit();
}

  // /////////////////////////

  public

  function suspect_report()
  {
    $this->loadModel('Pregnency');
    $this->loadModel('Pinstallment');
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      if ($this->request->data['Beneficiary']['exit_reason'] != '') {
        $ben_id = $this->request->data['Beneficiary']['id'];
        $exit_reason = $this->request->data['Beneficiary']['exit_reason'];
        if ($ben_id != '' && $exit_reason != '') {
          $this->loadModel('Pregnency');
          $pregnency_id = '';
          $pregnency_id = $this->Pregnency->find('first', array(
            'conditions' => array(
              'Pregnency.beneficiary_id' => $ben_id
            ) ,
            'order' => array(
              'Pregnency.id' => 'DESC'
            )
          ));
          $pregnency_id = $pregnency_id['Pregnency']['id'];
          $this->Pregnency->id = $pregnency_id;
          $this->Pregnency->saveField('is_exit', 1);
          $this->Pregnency->saveField('exit_reason', $exit_reason);
          $this->Pregnency->saveField('exit_date', date('Y-m-d'));
          $this->message('success', 'Exit Details Saved Successfully !');
        }
      }
    }

    $datas = "";
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      $sql_name = "";
      if ($this->request->data['Beneficiary']['name'] != '') {
        $sql_name = "Beneficiary.name like '%" . $this->request->data['Beneficiary']['name'] . "%'";
      }

      $sql_rch_mcts_no = "";
      if ($this->request->data['Beneficiary']['rch_mcts_no'] != '') {
        $sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->request->data['Beneficiary']['rch_mcts_no'] . "'";
      }

      $sql_account_no = "";
      if ($this->request->data['Beneficiary']['account_no'] != '') {
        $sql_account_no = "Beneficiary.account_no='" . $this->request->data['Beneficiary']['account_no'] . "'";
      }

      $sql_gp_id = "";
      if ($this->request->data['Beneficiary']['gp_id'] != '') {
        $sql_gp_id = "Beneficiary.gp_id='" . $this->request->data['Beneficiary']['gp_id'] . "'";
      }

      $sql_awc_id = "";
      if ($this->request->data['Beneficiary']['awc_id'] != '') {
        $sql_awc_id = "Beneficiary.awc_id='" . $this->request->data['Beneficiary']['awc_id'] . "'";
      }

      $sql_sector_id = "";
      if ($this->request->data['Beneficiary']['sector_id'] != '') {
        $sql_sector_id = "Beneficiary.sector_id='" . $this->request->data['Beneficiary']['sector_id'] . "'";
      }

      $sql_date = "";
      if ($this->request->data['Beneficiary']['from_date'] != '' && $this->request->data['Beneficiary']['to_date'] != '') {

        // Code changed by Tanmaya.

        $from_date = $this->date2DB($this->request->data['Beneficiary']['from_date']);
        $to_date = $this->date2DB($this->request->data['Beneficiary']['to_date']);
        $sql_date = "Beneficiary.reg_date between '" . $from_date . "' and '" . $to_date . "'";
      }

      $sql_husband = "";
      if ($this->request->data['Beneficiary']['husband_govt'] != '') {
        $sql_husband = "Beneficiary.husband_govt = '" . $this->request->data['Beneficiary']['husband_govt'] . "'";
      }

      $sql_is_suspect = "";
      if ($this->request->data['Beneficiary']['is_suspect'] != '' && $this->request->data['Beneficiary']['is_suspect'] != 2) {
        $sql_is_suspect = "Beneficiary.is_suspect = '" . $this->request->data['Beneficiary']['is_suspect'] . "'";
      }

      $sql_is_pvtg = "";
      if ($this->request->data['Beneficiary']['is_pvtg'] != '') {
        $sql_is_pvtg = "Beneficiary.is_pvtg='" . $this->request->data['Beneficiary']['is_pvtg'] . "'";
      }

      $user = $this->Session->read('user_auth');
      $sql = "";
      if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
        $sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
      }

      $sql_in_scheme = "";
      if ($this->request->data['Beneficiary']['in_scheme'] == "1" || $this->request->data['Beneficiary']['in_scheme'] == "") {
        $sql_in_scheme = "Beneficiary.husband_govt = 'No' and Beneficiary.age >= 19";
      }

      if ($this->request->data['Beneficiary']['in_scheme'] == "0") {
        $sql_in_scheme = "Beneficiary.husband_govt = 'Yes' or Beneficiary.age < 19";
      }

      $datas = $this->Beneficiary->find('all', array(
        'conditions' => array(
          $sql,
          $sql_name,
          $sql_rch_mcts_no,
          $sql_account_no,
          $sql_gp_id,
          $sql_awc_id,
          $sql_sector_id,
          $sql_husband,
          "Beneficiary.is_suspect" => 1,
          $sql_is_pvtg,
          $sql_in_scheme,
          $sql_date
        ) ,
        'order' => array(
          'Beneficiary.id' => 'DESC'
        )
      ));
      $this->set(compact('datas'));
    }

    $user = $this->Session->read('user_auth');
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Gp.project_id='" . $user['Project']['id'] . "'";
    }

    $gp_id = $this->Beneficiary->Gp->find('list', array(
      'conditions' => array(

        // 'Gp.id in(select gp_id from beneficiaries)',

        $sqlcond1,
      ) ,
      'order' => array(
        'Gp.name'
      )
    ));
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
    }

    $sector_id = $this->Beneficiary->Sector->find('list', array(
      'conditions' => array(
        $sqlcond1

        // 'Sector.id in(select sector_id from beneficiaries)'

      ) ,
      'order' => array(
        'Sector.name'
      )
    ));
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Awc.project_id='" . $user['Project']['id'] . "'";
    }

    $awc_id = $this->Beneficiary->Awc->find('list', array(
      'conditions' => array(

        // 'Awc.id in(select awc_id from beneficiaries)'

        $sqlcond1
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $husband_govt = array(
      'No' => 'No',
      'Yes' => 'Yes'
    );
    $is_suspect = array(
      '2' => 'All',
      '0' => 'No',
      '1' => 'Yes',
    );
    $exit_reasons = array(
      'MATERNAL DEATH' => 'MATERNAL DEATH',
      'INFANT DEATH' => 'INFANT DEATH',
      'MISCARRIAGE' => 'MISCARRIAGE',

      //  'STILL BIRTH'=>'STILL BIRTH',

      'MIGRATION' => 'MIGRATION'
    );
    $is_pvtg = array(
      'N' => 'No',
      'Y' => 'Yes'
    );
    $in_scheme = array(
      '0' => 'No',
      '1' => 'Yes',
    );
    $this->set(compact('in_scheme', 'is_pvtg', 'datas', 'gp_id', 'sector_id', 'awc_id', 'husband_govt', 'is_suspect', 'exit_reasons'));
  }

  // ////////////////////////////////

  public

  function loadawcs_search($id)
  {
    $this->layout = NULL;
    $this->loadModel('Awc');
    $awc_id = $this->Awc->find('list', array(
      'conditions' => array(
        'Awc.sector_id' => $id
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $this->set(compact('awc_id'));
  }

  ////////////////////////////////////////
  public function filterd($id){
    $this->layout=NULL;
    $this->loadModel('Pregnency');
    $this->loadModel('Verify');

    $this->Pregnency->recursive=-1;
    $preg_id=$this->Pregnency->find('first',array(
      'conditions'=>array(
        'Pregnency.beneficiary_id'=>$id
      ),
      'order'=>array(
        'Pregnency.id'=>'DESC'
      )
    ));
    $preg_id=$preg_id['Pregnency']['id'];

$this->Verify->recursive=-1;
$cnt=$this->Verify->find('count',array(
  'conditions'=>array(
    'Verify.pregnency_id'=>$preg_id,
    'Verify.beneficiary_id'=>$id
  ),
));

echo $cnt;
    exit();
  }
}

<?php
App::uses('AppControler', 'Controller');
class PregnenciesController extends AppController

{
	public $components = array(

		'Paginator',
		'Flash',
		'Session'
	);
	public

	function beforeFilter()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}
	}

	public

	function add($id)
	{
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$pp_exit = 0;
			$pp_exit = $this->Pregnency->find('count', array(
				'conditions' => array(
					'Beneficiary.id' => $id,
					'Pregnency.is_exit' => 1,
					'Pregnency.exit_reason' => 'MATERNAL DEATH'
				)
			));
			//print_r($pp_exit); exit;
			if(isset($pp_exit) && $pp_exit > 0){
				$this->message('error', 'Pregnancy add is not possible.');
				$this->redirect(array('action' => 'index'));
				exit();
			}

			$pp_exit1 = $this->Pregnency->find('count', array(
				'conditions' => array(
					'Beneficiary.id' => $id,
					'Pregnency.is_exit' => 0
				)
			));
			//print_r($pp_exit1); exit;
			if(isset($pp_exit1) && $pp_exit1 > 0){
				$this->message('error', 'Pregnancy add is not possible.');
				$this->redirect(array('action' => 'index'));
				exit();
			}

			if ($this->request->data['Pregnency']['age'] < 19 || $this->request->data['Pregnency']['age'] > 45) {
				$this->message('error', 'Please Provide Valid Age ! Age should be in between 19 to 45');
				?>
					<script type="text/javascript">
						alert("Please Provide Valid Age ! Age should be in between 19 to 45");
					</script>
				<?php
			}
			else {
				$this->request->data['Pregnency']['beneficiary_id'] = $id;
				$lmp_date = $this->request->data['Pregnency']['lmp_date'];
				$lmp_date = explode("/", $lmp_date);
				$lmp_date1 = $lmp_date;
				$lmp_date = $lmp_date[2] . '-' . $lmp_date[1] . '-' . $lmp_date[0];
				$this->request->data['Pregnency']['lmp_date'] = $lmp_date;
				$first_install_date = "";
				$first_install_date = mktime(0, 0, 0, $lmp_date1[1] + 6, $lmp_date1[0], $lmp_date1[2]);
				$first_install_date = date("Y-m-d", $first_install_date);
				$this->request->data['Pregnency']['first_install_date'] = $first_install_date;
				$preg_reg_date = $this->request->data['Pregnency']['preg_reg_date'];
				$preg_reg_date = explode("/", $preg_reg_date);
				$preg_reg_date = $preg_reg_date[2] . '-' . $preg_reg_date[1] . '-' . $preg_reg_date[0];
				$this->request->data['Pregnency']['preg_reg_date'] = $preg_reg_date;
				$scheme_reg_date = $this->request->data['Pregnency']['scheme_reg_date'];
				$scheme_reg_date = explode("/", $scheme_reg_date);
				$scheme_reg_date = $scheme_reg_date[2] . '-' . $scheme_reg_date[1] . '-' . $scheme_reg_date[0];
				$this->request->data['Pregnency']['scheme_reg_date'] = $scheme_reg_date;
				$exp_dod = $this->request->data['Pregnency']['lmp_date'];
				$old_date = explode("-", $exp_dod);
				$new_date = mktime(0, 0, 0, $old_date[1] + 9, $old_date[2] + 10, $old_date[0]);
				$new_date = date("Y-m-d", $new_date);
				$this->request->data['Pregnency']['exp_dod'] = $new_date;
				$preg_no = 1;
				$count = $this->Pregnency->find('count', array(
					'conditions' => array(
						'Pregnency.beneficiary_id' => $id
					)
				));
				if ($count == 0) {
					$preg_no = 1;
				}
				else {
					$preg_no = $count + 1;
				}

				$ben_detail = $this->Pregnency->Beneficiary->find('first', array(
					'conditions' => array(
						'Beneficiary.id' => $id
					) ,
				));

				//	if ($ben_detail['Awc']['is_pvtg'] == 'N' && $count == 2) {
				//	$this->message('error', 'No more pregnancy details can be added !');
				// }
				// else {

				$this->request->data['Pregnency']['preg_no'] = $preg_no;
				if ($this->Pregnency->save($this->request->data)) {

					// Saving in pinstallment

					$pregnency_id = $this->Pregnency->getLastInsertID();
					$this->loadModel('Pinstallment');
					$this->request->data['Pinstallment']['beneficiary_id'] = $this->request->data['Pregnency']['beneficiary_id'];
					$this->request->data['Pinstallment']['pregnency_id'] = $pregnency_id;
					$this->request->data['Pinstallment']['preg_no'] = $this->request->data['Pregnency']['preg_no'];
					$this->request->data['Pinstallment']['installment_no'] = 1;
					$this->request->data['Pinstallment']['installment_date'] = $this->request->data['Pregnency']['first_install_date'];
					$this->Pinstallment->save($this->request->data);

					// End of saving in pinstallment

					$this->message('success', 'Saved Successfully !');
					$this->redirect(array(
						'controller' => 'beneficiaries',
						'action' => 'index'
					));
				}
				else {
					$this->message('error', 'Saving Failed !');
				}

				//	}

			}
		}

		$datas = $this->Pregnency->Beneficiary->findById($id);
		$total_live_birth = $this->returnlive($id);
		/*$def_date = date("d/m/Y", strtotime($datas['Beneficiary']['reg_date']));
		$this->set(compact('datas', 'total_live_birth', 'def_date'));*/
		
		$raw_regd_date = $datas['Beneficiary']['reg_date'];
		$regd_minus_eight_month =  date("d/m/Y", strtotime("-8 months", strtotime($raw_regd_date)));

		$def_date = date("d/m/Y", strtotime($datas['Beneficiary']['reg_date']));
		$this->set(compact('datas', 'total_live_birth', 'def_date', 'regd_minus_eight_month'));
	}

	public

	function edit($id)
	{
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			if ($this->request->data['Pregnency']['age'] < 19 || $this->request->data['Pregnency']['age'] >= 46) {
				$this->message('error', 'Please Provide Valid Age !');
				?>
					<script type="text/javascript">
						alert("Please Provide Valid Age !");
					</script>
				<?php
			}
			else {

				//	$this->request->data['Pregnency']['beneficiary_id']=$id;

				$lmp_date = $this->request->data['Pregnency']['lmp_date'];
				$lmp_date = explode("/", $lmp_date);
				$lmp_date1 = $lmp_date;
				$lmp_date = $lmp_date[2] . '-' . $lmp_date[1] . '-' . $lmp_date[0];
				$this->request->data['Pregnency']['lmp_date'] = $lmp_date;
				$first_install_date = "";
				$first_install_date = mktime(0, 0, 0, $lmp_date1[1] + 6, $lmp_date1[0], $lmp_date1[2]);
				$first_install_date = date("Y-m-d", $first_install_date);
				$this->request->data['Pregnency']['first_install_date'] = $first_install_date;
				$preg_reg_date = $this->request->data['Pregnency']['preg_reg_date'];
				$preg_reg_date = explode("/", $preg_reg_date);
				$preg_reg_date = $preg_reg_date[2] . '-' . $preg_reg_date[1] . '-' . $preg_reg_date[0];
				$this->request->data['Pregnency']['preg_reg_date'] = $preg_reg_date;
				$scheme_reg_date = $this->request->data['Pregnency']['scheme_reg_date'];
				$scheme_reg_date = explode("/", $scheme_reg_date);
				$scheme_reg_date = $scheme_reg_date[2] . '-' . $scheme_reg_date[1] . '-' . $scheme_reg_date[0];
				$this->request->data['Pregnency']['scheme_reg_date'] = $scheme_reg_date;
				$exp_dod = $this->request->data['Pregnency']['lmp_date'];
				$old_date = explode("-", $exp_dod);
				$new_date = mktime(0, 0, 0, $old_date[1] + 9, $old_date[2] + 10, $old_date[0]);
				$new_date = date("Y-m-d", $new_date);
				$this->request->data['Pregnency']['exp_dod'] = $new_date;
				if ($this->Pregnency->save($this->request->data)) {

					// Saving in pinstallment

					$pregnency_id = $id;
					$this->loadModel('Pinstallment');
					$pid = $this->Pinstallment->find('first', array(
						'conditions' => array(
							'Pinstallment.pregnency_id' => $id,
							'Pinstallment.installment_no' => 1,
						)
					));
					$pid = $pid['Pinstallment']['id'];
					$this->request->data['Pinstallment']['id'] = $pid;
					$this->request->data['Pinstallment']['pregnency_id'] = $pregnency_id;
					$this->request->data['Pinstallment']['installment_date'] = $this->request->data['Pregnency']['first_install_date'];
					$this->Pinstallment->save($this->request->data);

					// End of saving in pinstallment

					$this->message('success', 'Saved Successfully !');
					$this->redirect(array(
						'controller' => 'pregnencies',
						'action' => 'index'
					));
				}
				else {
					$this->message('error', 'Saving Failed !');
				}
			}
		}

		$this->request->data = $this->Pregnency->findById($id);
		$datas = $this->Pregnency->Beneficiary->findById($this->request->data['Beneficiary']['id']);
		$this->set(compact('datas'));
		$lmp_date = $this->request->data['Pregnency']['lmp_date'];
		$lmp_date = explode("-", $lmp_date);
		$lmp_date = $lmp_date[2] . '/' . $lmp_date[1] . '/' . $lmp_date[0];
		$this->request->data['Pregnency']['lmp_date'] = $lmp_date;
		//$preg_reg_date = $this->request->data['Pregnency']['preg_reg_date'];
		$preg_reg_date = $this->request->data['Pregnency']['scheme_reg_date'];
		$preg_reg_date = explode("-", $preg_reg_date);
		$preg_reg_date = $preg_reg_date[2] . '/' . $preg_reg_date[1] . '/' . $preg_reg_date[0];
		$this->request->data['Pregnency']['preg_reg_date'] = $preg_reg_date;
		//$scheme_reg_date = $this->request->data['Pregnency']['scheme_reg_date'];
		$scheme_reg_date = $this->request->data['Beneficiary']['reg_date'];
		$srd_for_lmp = $this->request->data['Pregnency']['scheme_reg_date'];
		$scheme_reg_date = explode("-", $scheme_reg_date);
		$scheme_reg_date = $scheme_reg_date[2] . '/' . $scheme_reg_date[1] . '/' . $scheme_reg_date[0];
		$this->request->data['Pregnency']['scheme_reg_date'] = $scheme_reg_date;
		$datas = $this->Pregnency->find('first',array(
			'conditions'=>array(
				'Pregnency.id'=>$id,
			),
			'order'=>array(
				'Pregnency.id'=>'DESC'
			),
			'limit'=>1
		));
		
		//echo " // ".$lmp_min_date_range = $this->request->data['Pregnency']['scheme_reg_date'];
		$a = date('Y-m-d', strtotime($srd_for_lmp));
		//$raw_regd_date = $datas['Beneficiary']['reg_date'];
		$lmp_min_date =  date("d/m/Y", strtotime("-8 months", strtotime($a)));
		$total_live_birth = $this->returnlive($datas['Beneficiary']['id']);
		$this->set(compact('total_live_birth', 'scheme_reg_date', 'lmp_min_date'));
	}

	public

	function calc_scheme_date($str ='')
	{
		$this->layout = NULL;
		$old_date = explode("-", $str);
		$new_date = mktime(0, 0, 0, $old_date[1] + 6, $old_date[0], $old_date[2]);
		$new_date = date("d/m/Y", $new_date);
		echo $new_date;
		exit();
	}

	public

	function calc_edd($str ='')
	{
		$this->layout = NULL;
		$old_date = explode("-", $str);
		if(isset($old_date) && is_array($old_date) && count($old_date) > 0 ){
			$new_date = mktime(0, 0, 0, $old_date[1] + 9, $old_date[0] + 10, $old_date[2]);
			$new_date = date("d/m/Y", $new_date);
			echo $new_date;
			exit();
		}
	}

	public

	function index()
	{
		$this->layout = 'admin';
		$this->loadModel('Awc');
		$user = $this->Session->read('user_auth');
		$sqlcond1 = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$sqlcond1 = "Awc.project_id ='" . $user['Project']['id'] . "'";
		}

		$awc_id = $this->Awc->find('list', array(
			'conditions' => array(
				$sqlcond1

				// 'Awc.id in(select awc_id from beneficiaries)'

			) ,
			'order' => array(
				'Awc.name'
			)
		));
		$this->set(compact('awc_id'));
	}

	// //////////////////////////////////////////

	public

	function index_ajax()
	{
		$this->layout = 'ajax';
		$sql_name = "";
		$sql_rch_mcts_no = "";
		$sql_account_no = "";
		$sql_awc_id = "";
		$name   = '';
		$rch_mcts_no = '';
		$account_no = '';
		$awc_id = '';
		if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
			$name = $this->params['named']['name'];
			$sql_name = "Beneficiary.name like '%" . $name . "%'";
		}

		if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
			$rch_mcts_no = $this->params['named']['rch_mcts_no'];
			$sql_rch_mcts_no = "Beneficiary.rch_mcts_no like '%" . $rch_mcts_no . "%'";
		}

		if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
			$account_no = $this->params['named']['account_no'];
			$sql_account_no = "Beneficiary.account_no like '%" . $account_no . "%'";
		}

		if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
			$awc_id = $this->params['named']['awc_id'];
			$sql_awc_id = "Beneficiary.awc_id = '" . $awc_id . "'";
		}

		$user = $this->Session->read('user_auth');
		$sql = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		if (isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != '') {
			$this->layout = 'export_xls';
			if ($this->params['named']['reqType'] == 'XLS') {
				$this->set('file_type', 'xls');
				$this->set('file_name', 'beneficiaries_pregnancy_' . date('d_m_Y') . '.xls');
			}
			else
			if ($this->params['named']['reqType'] == 'DOC') {
				$this->set('file_type', 'doc');
				$this->set('file_name', 'beneficiaries_pregnancy_' . date('d_m_Y') . '.doc');
			}

			$this->set('is_excel', 'Y');
			$limit = array(
				'limit' => 2000,
				'maxLimit' => 2000
			);
		}

		$this->paginate = array(
			'conditions' => array(
				$sql,
				$sql_name,
				$sql_rch_mcts_no,
				$sql_account_no,
				$sql_awc_id,
				//'Beneficiary.id in(select beneficiary_id from pregnencies)'
			) ,
			'order' => array(
				'Pregnency.is_approved',
				'Pregnency.id' => 'DESC'
			) ,
			'limit' => 10,
			//'maxLimit' => 1000,
		);
		$datas = $this->paginate('Pregnency');
		$this->set(array(
			'datas' => $datas,
			'sql_name' => $sql_name,
			'sql_rch_mcts_no' => $sql_rch_mcts_no,
			'sql_account_no' => $sql_account_no,
			'sql_awc_id' => $sql_awc_id,
			'name'			=> $name,
			'rch_mcts_no'	=> $rch_mcts_no,
			'account_no'	=> $account_no,
			'awc_id'		=> $awc_id,			
		));
		//$this->set(compact('datas', 'sql_name', 'sql_rch_mcts_no', 'sql_account_no', 'sql_awc_id'));
	}

	// //////////////////////////////////////////////////

	public

	function approve_preg($id)
	{
		$this->layout = NULL;
		$user = $this->Session->read('user_auth');
		$this->Pregnency->id = $id;
		$this->Pregnency->saveField('is_approved', 1);
		$this->Pregnency->saveField('approved_date', date("Y-m-d"));
		$this->Pregnency->saveField('user_id', $user['User']['id']);
		echo "Approved Successfully !";
		exit();
	}
}

<?php
App::uses('AppControler','Controller');

class PaymentsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session','PhpExcel');
	public $uses=array('String','Payment');

public function beforeFilter(){

}
	public function index(){
		$this->response->disableCache();
		if($this->Session->read('user_auth') == ''){
			$this->redirect(array(
				'controller'=>'dashboard',
				'action'=>'login'
			));
		}
		$this->loadModel('Payment');
		$sql_name 		 	= "";
		$sql_rch_mcts_no 	= "";
		$sql_sector_id 		= "";
		$sql_awc_id			= "";
		$sql_bank_type		= "";
		$sql_is_approved	= "";
		$sql_installment	= "";
		$sql_is_paid		= "";
		if($this->request->is(array('post','put'))){
			if($this->request->data['Beneficiary']['rch_mcts_no'] != ''){
				$sql_rch_mcts_no="Beneficiary.rch_mcts_no = '".$this->request->data['Beneficiary']['rch_mcts_no']."'";
			}
			if($this->request->data['Beneficiary']['name'] != ''){
				$sql_name="Beneficiary.name like '%".$this->request->data['Beneficiary']['name']."%'";
			}
			if($this->request->data['Beneficiary']['sector_id'] != ''){
				$sql_sector_id="Beneficiary.sector_id = '".$this->request->data['Beneficiary']['sector_id']."'";
			}
			if($this->request->data['Beneficiary']['awc_id'] != ''){
				$sql_awc_id="Beneficiary.awc_id = '".$this->request->data['Beneficiary']['awc_id']."'";
			}
			if($this->request->data['Beneficiary']['bank_type'] != ''){
				$sql_bank_type="Beneficiary.bank_id in(select id from banks where reg_file_format='".$this->request->data['Beneficiary']['bank_type']."')";
			}
			$sql_is_approved="";
			if($this->request->data['Beneficiary']['is_approved'] != ''){
				$ia="";
				if($this->request->data['Beneficiary']['is_approved'] == "Yes"){
					$sql_is_approved="Pinstallment.is_payment_approve=1";
				}
				if($this->request->data['Beneficiary']['is_approved'] == "No"){
					$sql_is_approved="Pinstallment.is_payment_approve !=1";
				}
			}
			$this->loadModel('Pinstallment');
			$user=$this->Session->read('user_auth');
			$sqlcond1="";
			if($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA' ){
				$sqlcond1="Beneficiary.user_id in(select id from users where project_id='".$user['Project']['id']."')";
			}
			$datas=$this->Pinstallment->find('all',array(
				'conditions'=>array(
					$sqlcond1,
					$sql_rch_mcts_no,
					$sql_name,
					$sql_sector_id,
					$sql_awc_id,
					$sql_bank_type,
					'Pinstallment.installment_no'=>$this->request->data['Beneficiary']['installment'],
					'Pinstallment.installment_date <= curdate()',
					'Pinstallment.is_payment_approve'	=> 0,
					'Pregnency.is_approved'=>1,
					'Pregnency.is_exit'=>0,
					$sql_is_approved
				),
				'order'=>array(
					'Pinstallment.id'=>'DESC'
				)
			));
			$user=$this->Session->read('user_auth');
			//If approve all is pressed
			$this->loadModel('Verify');
			if($this->request->data['button'] == 'approve_all'){
				foreach($datas as $data){
					$el_payment=0;
					$el_for2=0;
					if($data['Pinstallment']['installment_no'] == 1){
						$el_payment=$this->Verify->find('count',array(
							'conditions'=>array(
								'Verify.beneficiary_id'	=> $data['Beneficiary']['id'],
								'Verify.pregnency_id'	=> $data['Pregnency']['id'],
								'Verify.pregnency_no'	=> $data['Pinstallment']['installment_no'],
								'Verify.value !='		=> ''
							)
						));
					}
					if($data['Pinstallment']['installment_no'] == 2){
						$el_check_1=$this->Verify->find('count',array(
							'conditions'=>array(
								'Verify.beneficiary_id'=>$data['Beneficiary']['id'],
								'Verify.pregnency_id'=>$data['Pregnency']['id'],
								'Verify.pregnency_no'=>$data['Pinstallment']['installment_no'],
								'Verify.value !='=>'0##0##0',
								'Verify.eligibility_id >= 8 and Verify.eligibility_id <= 21'
							)
						));
						//The above must be 13
						$el_check_2=$this->Verify->find('count',array(
							'conditions'=>array(
								'Verify.beneficiary_id'=>$data['Beneficiary']['id'],
								'Verify.pregnency_id'=>$data['Pregnency']['id'],
								'Verify.pregnency_no'=>$data['Pinstallment']['installment_no'],
								'Verify.value !='=>'0##0##0',
								'Verify.eligibility_id >= 22 and Verify.eligibility_id <= 36'
							)
						));
						if($el_check_1 >= 13 && $el_check_2 >= 6){
							$el_for2=1;
						}
					}

					if($data['Pinstallment']['installment_no'] == 1 && $el_payment == 6 || $data['Pinstallment']['installment_no'] == 2 && $el_for2 == 1){
						$this->Pinstallment->id=$data['Pinstallment']['id'];
						$this->Pinstallment->saveField('is_payment_approve',1);
						$this->Pinstallment->saveField('approved_by',$user['User']['id']);
						$this->Pinstallment->saveField('approved_date',date('Y-m-d'));
						$this->Pinstallment->saveField('payment_status','Payment Approved');
					}
				}
			}
		}
		$this->loadModel('Sector');
		$sqlcond1="";
		$user=$this->Session->read('user_auth');
		if($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA' ){
			$sqlcond1="Sector.project_id='".$user['Project']['id']."'";
		}
		$sector_id=$this->Sector->find('list',array(
			'conditions'=>array(
				$sqlcond1,
			),
			'order'=>array(
				'Sector.name'
			)
		));
	  	$installment=array(
			'1'=>'First Installment',
			'2'=>'Second Installment'
		);
		$is_approved=array(
			'Yes'=>'Yes',
			'No'=>'No'
		);
		$is_paid=array(
			0=>'No',
			1=>'Yes',
			3 => 'File Generated'
		);
		$bank_type=array(
			'SBI'=>'SBI',
			'NSBI'=>'NON SBI'
		);
		$this->set(compact('installment','is_approved','is_paid','sector_id','bank_type'));
	}
	public function indexAjax(){
		$this->layout 	= 'ajax';
		$this->loadModel('Pinstallment');
		$rch_mcts_no 	= '';
		$name 			= '';
		$sector_id 		= '';
		$awc_id 		= '';
		$bank_type 		= '';
		$is_approved 	= '';
		$installment 	= '';
		$is_paid 		= '';
		$condition 		= array(
			0 => 'Pinstallment.installment_date <= curdate()',
			'Pregnency.is_approved'		=> 1,
			'Pregnency.is_exit'			=> 0,
		);
		//print_r($this->params['named']);
		$user=$this->Session->read('user_auth');
		if($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA' ){
			$project_id = $user['Project']['id'];
			$condition += array(1=> "Beneficiary.user_id in(select id from users where project_id=$project_id)");
		}	
			
	    if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != "") {
	        $rch_mcts_no = $this->params['named']['rch_mcts_no'];
	        $condition += array('Beneficiary.rch_mcts_no'	=> $rch_mcts_no);
	    }
	    if (isset($this->params['named']['name']) && $this->params['named']['name'] != "") {
	        $name = $this->params['named']['name'];
	        $condition += array(2 => "Beneficiary.name LIKE '%$name%'");
	    }		
	    if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != "") {
	        $sector_id = $this->params['named']['sector_id'];
	        $condition += array('Beneficiary.sector_id'	=> $sector_id);
	    }		
	    if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != "") {
	        $awc_id = $this->params['named']['awc_id'];
	        $condition += array('Beneficiary.awc_id'	=> $awc_id);
	    }		
		
	    if (isset($this->params['named']['is_approved']) && $this->params['named']['is_approved'] != "") {
	        $is_approved = $this->params['named']['is_approved'];
	        if($is_approved == "Yes"){
	        	$condition += array('Pinstallment.is_payment_approve'		=> 1);
	        }else if($is_approved == "No"){
	        	$condition += array('Pinstallment.is_payment_approve !='	=> 1);
	        }
	    }		

    	if(isset($this->params['named']['is_paid']) && (int)$this->params['named']['is_paid']==0){
    		$is_paid = $this->params['named']['is_paid'];
		    if (isset($this->params['named']['bank_type']) && $this->params['named']['bank_type'] != "") {
		        $bank_type = $this->params['named']['bank_type'];
		        $condition += array(3 => "Beneficiary.bank_id in(select id from banks where reg_file_format='$bank_type')");
		    }    			
		    if (isset($this->params['named']['installment']) && $this->params['named']['installment'] != "") {
		        $installment = $this->params['named']['installment'];
		        $condition += array('Pinstallment.installment_no'		=> $installment);
		        if($installment == 1){
		        	$condition += array(4 => "Pinstallment.pregnency_id IN (SELECT pregnency_id FROM view_first_verify WHERE pregnency_no=$installment AND totalverify =6 )");
		        }else if($installment == 2){
					$condition += array(4 => "Pinstallment.pregnency_id IN (SELECT pregnency_id FROM view_second_verify WHERE pregnency_no=$installment AND firstcnt >= 13 AND secondcnt >= 6)");
		        }
		    }
    	}else if(isset($this->params['named']['is_paid']) && $this->params['named']['is_paid']==1){
    		$is_paid = $this->params['named']['is_paid'];	
    	}
	        
	    //$condition += array('Pinstallment.is_paid'		=> $is_paid);
		if(isset($this->params['named']['is_paid']) && $this->params['named']['is_paid']!=3){ 
			$condition += array('Pinstallment.is_paid'		=> $is_paid);
		}else{
			$condition += array(2 => "Pinstallment.id IN (SELECT pinstallment_id FROM payments WHERE is_paid=0 AND is_approved=1 AND pinstallment_id IS NOT NULL)");	
		}
	    
        if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','payment_report_'.date('d-m-Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','payment_report_'.date('d-m-Y').'.doc');
            }
            $this->set('is_excel','Y');         
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 10);
        }    
		//print_r($condition);
//       debug($condition);
		$this->paginate = array(
			'recursive'		=> -1,
			'joins'			=> array(
			    array(
			    	'table' 		=> 'beneficiaries',
			        'alias' 		=> 'Beneficiary',
			        'type' 			=> 'left',
			        'conditions' 	=> array(
			            'Pinstallment.beneficiary_id = Beneficiary.id'
			        )
			    ),
			    array(
			    	'table' 		=> 'pregnencies',
			        'alias' 		=> 'Pregnency',
			        'type' 			=> 'left',
			        'conditions' 	=> array(
			            'Pinstallment.pregnency_id = Pregnency.id'
			        )
			    ),				
			),
			'conditions'	=> $condition,
			'fields'		=> array(
				'Beneficiary.id',
				'Beneficiary.name',
				'Pregnency.id',
				'Pregnency.preg_no',
				'Pregnency.lmp_date',
				'Pregnency.preg_reg_date',
				'Pregnency.scheme_reg_date',
				'Pinstallment.id',
				'Pinstallment.is_paid',
				'Pinstallment.installment_no',
				'Pinstallment.installment_date',
				'Pinstallment.payment_status',
				'Pinstallment.payment_date',
				'Pinstallment.is_payment_approve',
			),
			'order'			=> array(
				'Pinstallment.id'=>'DESC'
			)
		)+$limit;	
		$datas = $this->paginate('Pinstallment');    

		//$log = $this->Pinstallment->getDataSource()->getLog(false, false);
		//debug($log);

		$this->set(array(
			'datas'			=> $datas,
			'rch_mcts_no'	=> $rch_mcts_no,
			'name'			=> $name,
			'sector_id'		=> $sector_id,
			'awc_id'		=> $awc_id,
			'bank_type'		=> $bank_type,
			'is_approved'	=> $is_approved,
			'installment'	=> $installment,
			'is_paid'		=> $is_paid,
		));	    		    	    	    	    	    	    	    		
	}
public function generatefile($inst){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
	$this->layout=NULL;

$datas=$this->Payment->Pregnency->find('all',array(
	'conditions'=>array(
		'Pregnency.is_approved'=>1,
		'Pregnency.preg_no'=>$inst
	)
));

  echo "File Generated Successfully !";
	exit();
}

public function payment_approve($id){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
	$this->layout=NULL;
	$this->loadModel('Pinstallment');
	$this->Pinstallment->id=$id;
	$this->Pinstallment->saveField('is_payment_approve',1);
	$user=$this->Session->read('user_auth');
	$this->Pinstallment->saveField('approved_by',$user['User']['id']);
	$this->Pinstallment->saveField('approved_date',date('Y-m-d'));
	$this->Pinstallment->saveField('payment_status','Payment Approved');
	?>
<label class="btn btn-warning btn-sm hide_pdf">Approved</label>
	<?php
	exit();
}

public function payment_reject($id){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
	$this->layout=NULL;
	$this->loadModel('Pinstallment');
	$this->Pinstallment->id=$id;
	//$this->Pinstallment->saveField('is_payment_approve',2);
	$this->Pinstallment->query("update pinstallments set is_payment_approve=2 where id=$id");
	$user=$this->Session->read('user_auth');
	$this->Pinstallment->saveField('approved_by',NULL);
	$this->Pinstallment->saveField('approved_date',NULL);
	$this->Pinstallment->saveField('payment_status','Rejected');
	?>
<button class="btn btn-warning btn-sm hide_pdf" type="button" name="button" onclick="payment_approve(<?php echo $id; ?>)">Approve</button>
	<?php
	exit();
}

public function cron_generate_tran_file_nsbi(){
	$this->layout=NULL;
	$this->loadModel('Pregnency');
	$this->loadModel('Branch');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('District');
		$datas=$this->Pinstallment->find('all',array(
			'conditions'=>array(
				"Beneficiary.bank_id in(select id from banks where reg_file_format='NSBI')",
				"Pinstallment.is_payment_approve"=>1,
				"Pregnency.is_exit != 1",
				"Pinstallment.id not in(select pinstallment_id from payments where pinstallment_id is not null)",
			),
			'order'=>array(
				'Beneficiary.id'
			)
		));

		$file_name="MAMTA_MAMTAUPLD_".date("dmYHis");
		$this->PhpExcel->createWorksheet();
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'beni_inst_eligible_id')
            ->setCellValue('B1', 'PAYMENT_PRODUCT_CODE')
						->setCellValue('C1', 'INSTRUMENT_REF_NO')
						->setCellValue('D1', 'CUSTOMER_ACCOUNT_NO')
						->setCellValue('E1', 'INSTRUMENT_AMOUT')
						->setCellValue('F1', 'PAY_TO')
						->setCellValue('G1', 'BENEFICAIRY_ACCOUNT_NO')
						->setCellValue('H1', 'IFSC_CODE')
						->setCellValue('I1', 'PAYMENT_INSTRUMENT_DATE')
						->setCellValue('J1', 'R30C1')
						->setCellValue('K1', 'EMAIL_ID')
						->setCellValue('L1', 'R9C1')
						->setCellValue('M1', 'PHONE');
$m=2;

		foreach($datas as $data){
			$this->Payment->create();
			$this->request->data["Payment"]["beneficiary_id"]=$data['Pregnency']['beneficiary_id'];
			$this->request->data["Payment"]["pregnency_id"]=$data['Pregnency']['id'];
			$this->request->data["Payment"]["installment_no"]=$data['Pinstallment']['installment_no'];
			$this->request->data["Payment"]["pinstallment_id"]=$data['Pinstallment']['id'];
      $this->request->data["Payment"]["request_date"]=date("Y-m-d");
			$this->request->data["Payment"]["is_approved"]=1;
			$this->request->data["Payment"]["is_paid"]=0;
			//$this->request->data["Payment"]["user_id"]=$user['User']['id'];
			if($this->request->data["Payment"]["installment_no"] == 1){
				$this->request->data["Payment"]["amount"]=3000;
			}
			if($this->request->data["Payment"]["installment_no"] == 2){
				$this->request->data["Payment"]["amount"]=2000;
			}
			$this->request->data["Payment"]["file_name"]=$file_name;
			$this->request->data["Payment"]["uuid"]=time().rand(1111,9999);
			$this->request->data["Payment"]["name"]=$data['Beneficiary']['name'];
			$this->request->data["Payment"]["mail_id"]=$data['Beneficiary']['mail_id'];
			$this->request->data["Payment"]["mobile_no"]=$data['Beneficiary']['mobile_no'];
			$this->request->data["Payment"]["instrument_date"]=$data['Pinstallment']['approved_date'];
			$this->request->data["Payment"]["account_no"]=$data['Beneficiary']['account_no'];
			$branch_details="";
			$branch_details=$this->Branch->findById($data['Beneficiary']['branch_id']);
			$this->request->data["Payment"]["branch_name"]=$branch_details['Branch']['name'];
			$this->request->data["Payment"]["ifsc"]=$branch_details['Branch']['ifsc'];
		  $this->Payment->save($this->request->data);
			$from_account="";
$d=$this->District->find('first',array(
	'conditions'=>array(
		"District.id in(select district_id from projects where id in(select project_id from awcs where id='".$data['Beneficiary']['awc_id']."'))"
	)
));
$d=trim($d['District']['name']);
if($d == 'BARGARH' || $d == 'SUNDARGARH'){
	$from_account="150005500799";
}else{
	$from_account="150005500798";
}
			$objPHPExcel->setActiveSheetIndex(0)
			            ->setCellValue('A'.$m, $data["Pinstallment"]["id"])
			            ->setCellValue('B'.$m, 'N')
									->setCellValue('C'.$m, $data["Pinstallment"]["id"])
									->setCellValue('D'.$m, $from_account)
									->setCellValue('E'.$m, $this->request->data["Payment"]["amount"])
									->setCellValue('F'.$m, $this->request->data["Payment"]["name"])
									->setCellValue('G'.$m, $this->request->data["Payment"]["account_no"])
									->setCellValue('H'.$m, $this->request->data["Payment"]["ifsc"])
									->setCellValue('I'.$m, date('d/m/Y'))
									->setCellValue('J'.$m, $this->request->data["Payment"]["uuid"])
									->setCellValue('K'.$m, $this->request->data["Payment"]["mail_id"])
									->setCellValue('L'.$m, $this->request->data["Payment"]["uuid"])
									->setCellValue('M'.$m, $this->request->data["Payment"]["mobile_no"]);
		$m++;
		}
		if($m > 2){
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'csv')->setDelimiter(',')->setEnclosure(' ')->setLineEnding("\r\n");
		  $objWriter->save(WWW_ROOT.'files/csv/'.$file_name.'.csv');
			$objWriter->save('C:/ICICI/Output/'.$file_name.'.csv');
		}

	exit();
}

public function cron_response_tran_file_nsbi(){
	$this->layout=NULL;
	$this->loadModel('Pregnency');
	$this->loadModel('Branch');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('Logsbank');
	$this->loadModel('Ilogsbank');
	$this->loadModel('Incentive');
	$dir = "C:/ICICI/Reports/";

if (is_dir($dir)){
  if ($dh = opendir($dir)){
    while (($file = readdir($dh)) !== false){
											if($file != '' && $file !='.' && $file != '..'){
												if(substr($file, 0, 14) != 'MAMTA_UPREJECT'){
												$handle = fopen($dir.$file, "r");
												$first_row = false;
												$final_ata = array();
												$headers = array();
$headers=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P');
														while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
														if($first_row) {
															$headers = $data;
															$first_row = false;
														} else {
															$final_ata[] = array_combine($headers, array_values($data));
														}
														}
													//Updating Payment Table
foreach($final_ata as $f){
$is_worker=0;
if(substr($f['L'],0,6) == 'WORKER'){
	$this->Ilogsbank->create();
	$this->request->data['Ilogsbank']['file_name']=$file;
	$this->request->data['Ilogsbank']['bank_type']='NSBI';
	$this->request->data['Ilogsbank']['a']=$f['A'];
	$this->request->data['Ilogsbank']['b']=$f['B'];
	$this->request->data['Ilogsbank']['c']=$f['C'];
	$this->request->data['Ilogsbank']['d']=$f['D'];
	$this->request->data['Ilogsbank']['e']=$f['E'];
	$this->request->data['Ilogsbank']['f']=$f['F'];
	$this->request->data['Ilogsbank']['g']=$f['G'];
	$this->request->data['Ilogsbank']['h']=$f['H'];
	$this->request->data['Ilogsbank']['i']=$f['I'];
	$this->request->data['Ilogsbank']['j']=$f['J'];
	$this->request->data['Ilogsbank']['k']=$f['K'];
	$this->request->data['Ilogsbank']['l']=$f['L'];
	$this->request->data['Ilogsbank']['m']=$f['M'];
	$this->request->data['Ilogsbank']['n']=$f['N'];
	$this->request->data['Ilogsbank']['o']=$f['O'];
	$this->request->data['Ilogsbank']['p']=$f['P'];
	$this->Ilogsbank->save($this->request->data);
}else{
	  $this->Logsbank->create();
		$this->request->data['Logsbank']['file_name']=$file;
		$this->request->data['Logsbank']['bank_type']='NSBI';
		$this->request->data['Logsbank']['a']=$f['A'];
		$this->request->data['Logsbank']['b']=$f['B'];
		$this->request->data['Logsbank']['c']=$f['C'];
		$this->request->data['Logsbank']['d']=$f['D'];
		$this->request->data['Logsbank']['e']=$f['E'];
		$this->request->data['Logsbank']['f']=$f['F'];
		$this->request->data['Logsbank']['g']=$f['G'];
		$this->request->data['Logsbank']['h']=$f['H'];
		$this->request->data['Logsbank']['i']=$f['I'];
		$this->request->data['Logsbank']['j']=$f['J'];
		$this->request->data['Logsbank']['k']=$f['K'];
		$this->request->data['Logsbank']['l']=$f['L'];
		$this->request->data['Logsbank']['m']=$f['M'];
		$this->request->data['Logsbank']['n']=$f['N'];
		$this->request->data['Logsbank']['o']=$f['O'];
		$this->request->data['Logsbank']['p']=$f['P'];
    $this->Logsbank->save($this->request->data);
}

if(substr($f['L'],0,6) == 'WORKER'){
	$payment_date='';
	$payment_date=trim($f['I']);
	$payment_date=explode('/',$payment_date);
	$payment_date=$payment_date[2].'-'.$payment_date[1].'-'.$payment_date[0];

	$incentive_id=$f['A'];

	$this->Incentive->id=$incentive_id;
	$this->Incentive->saveField('paid_status',$f['P']);
	$this->Incentive->saveField('payment_date',$payment_date);
	$this->Incentive->saveField('bank_tran_no',$f['O']);
	$this->Incentive->saveField('bank_remark',$f['N']);
	if(trim($f['P']) == 'Paid'){
		$this->Incentive->saveField('is_paid',1);
	}
	if(trim($f['P']) == 'Cancelled'){
		$this->Incentive->saveField('is_paid',2);
	}
	//if(trim($f['P']) == 'Message Not Received from Bene Bank'){
	//	$this->Incentive->saveField('is_paid',3);
	//}

}else{
$pinstallment_id="";
$payment_date='';
$payment_date=trim($f['I']);
$payment_date=explode('/',$payment_date);
$payment_date=$payment_date[2].'-'.$payment_date[1].'-'.$payment_date[0];

$pinstallment_id=$f['A'];
$this->Pinstallment->id=$pinstallment_id;
$this->Pinstallment->saveField('payment_status',$f['P']);
$this->Pinstallment->saveField('payment_date',$payment_date);
$this->Pinstallment->saveField('bank_payment_status',$f['P']);
$this->Pinstallment->saveField('banktranno',$f['O']);
$this->Pinstallment->saveField('bankremark',$f['N']);
if(trim($f['P']) == 'Paid'){
	$this->Pinstallment->saveField('is_paid',1);
}
if(trim($f['P']) == 'Cancelled'){
	$this->Pinstallment->saveField('is_paid',2);
}
if(trim($f['P']) == 'Message Not Received from Bene Bank'){
	$this->Pinstallment->saveField('is_paid',3);
}
}

if(substr($f['L'],0,6) != 'WORKER'){
$payment=$this->Payment->find('first',array(
	'conditions'=>array(
		'Payment.pinstallment_id'=>$pinstallment_id
	)
));
$payment_id="";
$payment_id=$payment['Payment']['id'];
$this->Payment->id=$payment_id;
$this->Payment->saveField('payment_status',$f['P']);
$this->Payment->saveField('payment_date',$payment_date);
$this->Payment->saveField('banktranno',$f['O']);
$this->Payment->saveField('bankremark',$f['N']);
if(trim($f['P']) == 'Paid'){
	$this->Payment->saveField('is_paid',1);
}
if(trim($f['P']) == 'Cancelled'){
	$this->Payment->saveField('is_paid',2);
}
//if(trim($f['P']) == 'Message Not Received from Bene Bank'){
//	$this->Payment->saveField('is_paid',3);
//}
}
}
													//Payment Table Updated
													//Move the CSV File to processed
													fclose($handle);
rename($dir.$file,WWW_ROOT.DS.'files/csv/processed/'.$file);
													//Move Completed
													unset($headers);
													unset($final_ata);
												}else{
													//Rejected Files
													$handle = fopen($dir.$file, "r");
													$first_row = false;
													$final_ata = array();
													$headers = array();
	$headers=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P');
															while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
															if($first_row) {
																$headers = $data;
																$first_row = false;
															} else {
																$final_ata[] = array_combine($headers, array_values($data));
															}
															}
														//Updating Payment Table
	foreach($final_ata as $f){

		$this->Payment->query("delete from payments where pinstallment_id='".$f['B']."'");
	}
	fclose($handle);
rename($dir.$file,WWW_ROOT.DS.'files/csv/rejected/'.$file);
	//Move Completed
	unset($headers);
	unset($final_ata);
												}
											}
    }
    closedir($dh);
  }
}

exit();
}
////////////////////////////////////////////////
public function cron_generate_tran_file_sbi(){
	$this->layout=NULL;
	$this->loadModel('Pregnency');
	$this->loadModel('Branch');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('District');
		$datas=$this->Pinstallment->find('all',array(
			'conditions'=>array(
				"Beneficiary.bank_id in(select id from banks where reg_file_format != 'NSBI')",
				"Pinstallment.is_payment_approve"=>1,
				"Pregnency.is_exit != 1",
				"Pinstallment.id not in(select pinstallment_id from payments)",
				'Pinstallment.is_payment_approve'=>1
			),
			'order'=>array(
				'Beneficiary.id'
			)
		));

		$file_name="sbi_".date("dmYHis");
		$this->PhpExcel->createWorksheet();
$objPHPExcel = new PHPExcel();
/*$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'beni_inst_eligible_id')
            ->setCellValue('B1', 'PAYMENT_PRODUCT_CODE')
						->setCellValue('C1', 'INSTRUMENT_REF_NO')
						->setCellValue('D1', 'CUSTOMER_ACCOUNT_NO')
						->setCellValue('E1', 'INSTRUMENT_AMOUT')
						->setCellValue('F1', 'PAY_TO')
						->setCellValue('G1', 'BENEFICAIRY_ACCOUNT_NO')
						->setCellValue('H1', 'IFSC_CODE')
						->setCellValue('I1', 'PAYMENT_INSTRUMENT_DATE')
						->setCellValue('J1', 'R30C1')
						->setCellValue('K1', 'EMAIL_ID')
						->setCellValue('L1', 'R9C1')
						->setCellValue('M1', 'PHONE');*/
$m=1;

		foreach($datas as $data){
			$this->Payment->create();
			$this->request->data["Payment"]["beneficiary_id"]=$data['Pregnency']['beneficiary_id'];
			$this->request->data["Payment"]["pregnency_id"]=$data['Pregnency']['id'];
			$this->request->data["Payment"]["installment_no"]=$data['Pinstallment']['installment_no'];
			$this->request->data["Payment"]["pinstallment_id"]=$data['Pinstallment']['id'];
      $this->request->data["Payment"]["request_date"]=date("Y-m-d");
			$this->request->data["Payment"]["is_approved"]=1;
			$this->request->data["Payment"]["is_paid"]=0;
			//$this->request->data["Payment"]["user_id"]=$user['User']['id'];
			if($this->request->data["Payment"]["installment_no"] == 1){
				$this->request->data["Payment"]["amount"]=3000;
			}
			if($this->request->data["Payment"]["installment_no"] == 2){
				$this->request->data["Payment"]["amount"]=2000;
			}
			$this->request->data["Payment"]["file_name"]=$file_name;
			$this->request->data["Payment"]["uuid"]=time().rand(1111,9999);
			$this->request->data["Payment"]["name"]=$data['Beneficiary']['name'];
			$this->request->data["Payment"]["mail_id"]=$data['Beneficiary']['mail_id'];
			$this->request->data["Payment"]["mobile_no"]=$data['Beneficiary']['mobile_no'];
			$this->request->data["Payment"]["instrument_date"]=$data['Pinstallment']['approved_date'];
			$this->request->data["Payment"]["account_no"]=$data['Beneficiary']['account_no'];
			$branch_details="";
			$branch_details=$this->Branch->findById($data['Beneficiary']['branch_id']);
			$this->request->data["Payment"]["branch_name"]=$branch_details['Branch']['name'];
			$this->request->data["Payment"]["ifsc"]=$branch_details['Branch']['ifsc'];
		  $this->Payment->save($this->request->data);
			$from_account="";
$d=$this->District->find('first',array(
	'conditions'=>array(
		"District.id in(select district_id from projects where id in(select project_id from awcs where id='".$data['Beneficiary']['awc_id']."'))"
	)
));
$d=trim($d['District']['name']);
if($d == 'BARGARH' || $d == 'SUNDARGARH'){
	$from_account="36282917052";
}else{
	$from_account="36282899870";
}
			$objPHPExcel->setActiveSheetIndex(0)
			            ->setCellValue('A'.$m, $m)
			            ->setCellValue('B'.$m, '283063')
									->setCellValue('C'.$m, 'MAMATA')
									->setCellValue('D'.$m, $from_account)
									->setCellValue('E'.$m, 'DCR')
									->setCellValue('F'.$m, date('d/m/Y'))
									->setCellValue('G'.$m, $this->request->data["Payment"]["amount"])
									->setCellValue('H'.$m, $this->request->data["Payment"]["name"])
									->setCellValue('I'.$m, 'STATE BANK OF INDIA')
									->setCellValue('J'.$m, $this->request->data["Payment"]["ifsc"])
									->setCellValue('K'.$m, $this->request->data["Payment"]["account_no"])
									->setCellValue('L'.$m, $this->request->data["Payment"]["mail_id"])
									->setCellValue('M'.$m, $this->request->data["Payment"]["mobile_no"])
									->setCellValue('N'.$m, $data["Pinstallment"]["id"])
									->setCellValue('O'.$m, '');

		$m++;
		}
		if($m > 1){
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'csv')->setDelimiter(',')->setEnclosure(' ')->setLineEnding("\r\n");
		  $objWriter->save(WWW_ROOT.'files/csv/'.$file_name.'.csv');
			$objWriter->save('C:/ZFT/SBI283063_outtray/'.$file_name.'.csv');
		}

	exit();
}
//////////////////////////////////////////////
public function cron_response_tran_file_sbi(){
	$this->layout=NULL;
	$this->loadModel('Pregnency');
	$this->loadModel('Branch');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('Logssbibank');
	$this->loadModel('Incentive');
	$this->loadModel('Worker');
	$this->loadModel('Ilogssbibank');
	$dir = "C:/ZFT/sbi283063_intray.DECRYPTED/";

if (is_dir($dir)){
  if ($dh = opendir($dir)){
    while (($file = readdir($dh)) !== false){
											if($file != '' && $file !='.' && $file != '..'){
												$handle = fopen($dir.$file, "r");
												$first_row = false;
												$final_ata = array();
												$headers = array();
$headers=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R');
														while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
														if($first_row) {
															$headers = $data;
															$first_row = false;
														} else {
															$final_ata[] = array_combine($headers, array_values($data));
														}
														}
													//Updating Payment Table
foreach($final_ata as $f){
if($f['O'] == 'WORKER'){
	$this->Ilogssbibank->create();
	$this->request->data['Ilogssbibank']['file_name']=$file;
	$this->request->data['Ilogssbibank']['bank_type']='SBI';
	$this->request->data['Ilogssbibank']['a']=$f['A'];
	$this->request->data['Ilogssbibank']['b']=$f['B'];
	$this->request->data['Ilogssbibank']['c']=$f['C'];
	$this->request->data['Ilogssbibank']['d']=$f['D'];
	$this->request->data['Ilogssbibank']['e']=$f['E'];
	$this->request->data['Ilogssbibank']['f']=$f['F'];
	$this->request->data['Ilogssbibank']['g']=$f['G'];
	$this->request->data['Ilogssbibank']['h']=$f['H'];
	$this->request->data['Ilogssbibank']['i']=$f['I'];
	$this->request->data['Ilogssbibank']['j']=$f['J'];
	$this->request->data['Ilogssbibank']['k']=$f['K'];
	$this->request->data['Ilogssbibank']['l']=$f['L'];
	$this->request->data['Ilogssbibank']['m']=$f['M'];
	$this->request->data['Ilogssbibank']['n']=$f['N'];
	$this->request->data['Ilogssbibank']['o']=$f['O'];
	$this->request->data['Ilogssbibank']['p']=$f['P'];
	$this->request->data['Ilogssbibank']['q']=$f['Q'];
	$this->request->data['Ilogssbibank']['r']=$f['R'];
	$this->Ilogssbibank->save($this->request->data);
}else{
	$this->Logssbibank->create();
	$this->request->data['Logssbibank']['file_name']=$file;
	$this->request->data['Logssbibank']['bank_type']='SBI';
	$this->request->data['Logssbibank']['a']=$f['A'];
	$this->request->data['Logssbibank']['b']=$f['B'];
	$this->request->data['Logssbibank']['c']=$f['C'];
	$this->request->data['Logssbibank']['d']=$f['D'];
	$this->request->data['Logssbibank']['e']=$f['E'];
	$this->request->data['Logssbibank']['f']=$f['F'];
	$this->request->data['Logssbibank']['g']=$f['G'];
	$this->request->data['Logssbibank']['h']=$f['H'];
	$this->request->data['Logssbibank']['i']=$f['I'];
	$this->request->data['Logssbibank']['j']=$f['J'];
	$this->request->data['Logssbibank']['k']=$f['K'];
	$this->request->data['Logssbibank']['l']=$f['L'];
	$this->request->data['Logssbibank']['m']=$f['M'];
	$this->request->data['Logssbibank']['n']=$f['N'];
	$this->request->data['Logssbibank']['o']=$f['O'];
	$this->request->data['Logssbibank']['p']=$f['P'];
	$this->request->data['Logssbibank']['q']=$f['Q'];
	$this->request->data['Logssbibank']['r']=$f['R'];
	$this->Logssbibank->save($this->request->data);
}



$pinstallment_id="";
$payment_date='';
$payment_date=trim($f['P']);
$payment_date=explode('/',$payment_date);
$payment_date=$payment_date[2].'-'.$payment_date[1].'-'.$payment_date[0];

if($f['O'] == 'WORKER'){
	$incentive_id=$f['N'];
	$this->Incentive->id=$incentive_id;
	$this->Incentive->saveField('paid_status',$f['Q']);
	$this->Incentive->saveField('payment_date',$payment_date);
	$this->Incentive->saveField('bank_tran_no',$f['R']);
	$this->Incentive->saveField('bank_remark',$f['Q']);
	if(trim($f['Q']) == 'SUCCESS'){
		$this->Incentive->saveField('is_paid',1);
	}
	if(trim($f['Q']) == 'FAILURE'){
		$this->Incentive->saveField('is_paid',2);
	}
	if(trim($f['Q']) == ''){
		$this->Incentive->saveField('is_paid',3);
	}
}else{
$pinstallment_id=$f['N'];
$this->Pinstallment->id=$pinstallment_id;
$this->Pinstallment->saveField('payment_status',$f['Q']);
$this->Pinstallment->saveField('payment_date',$payment_date);
$this->Pinstallment->saveField('bank_payment_status',$f['Q']);
$this->Pinstallment->saveField('banktranno',$f['R']);
$this->Pinstallment->saveField('bankremark',$f['Q']);
if(trim($f['Q']) == 'SUCCESS'){
	$this->Pinstallment->saveField('is_paid',1);
}
if(trim($f['Q']) == 'FAILURE'){
	$this->Pinstallment->saveField('is_paid',2);
}
if(trim($f['Q']) == ''){
	$this->Pinstallment->saveField('is_paid',3);
}
}

if($f['O'] != 'WORKER'){
$payment=$this->Payment->find('first',array(
	'conditions'=>array(
		'Payment.pinstallment_id'=>$pinstallment_id
	)
));
$payment_id="";
$payment_id=$payment['Payment']['id'];
$this->Payment->id=$payment_id;
$this->Payment->saveField('payment_status',$f['Q']);
$this->Payment->saveField('payment_date',$payment_date);
$this->Payment->saveField('banktranno',$f['R']);
$this->Payment->saveField('bankremark',$f['Q']);
if(trim($f['Q']) == 'SUCCESS'){
	$this->Payment->saveField('is_paid',1);
}
if(trim($f['Q']) == 'FAILURE'){
	$this->Payment->saveField('is_paid',2);
}
if(trim($f['Q']) == ''){
	$this->Payment->saveField('is_paid',3);
}
}
}
													//Payment Table Updated
													//Move the CSV File to processed
													fclose($handle);
rename($dir.$file,WWW_ROOT.DS.'files/csv/processed/'.$file);
													//Move Completed
													unset($headers);
													unset($final_ata);

											}
    }
    closedir($dh);
  }
}

exit();
}
//////////////////////////////////////////////
public function icron_generate_tran_file_nsbi(){
	$this->layout=null;
	$this->loadModel('Worker');
	$this->loadModel('Incentive');
	$this->loadModel('Ilogsbank');
$this->Incentive->recursive=2;
$datas=$this->Incentive->find('all',array(
	'conditions'=>array(
		'Incentive.is_paid'=>0,
		"Incentive.paid_status != 'FILE GENERATED'",
		"Worker.bank_id in(select id from banks where reg_file_format='NSBI')",
	),
	'order'=>array(
		'Incentive.id'
	)
));

$file_name="MAMTA_MAMTAUPLD_".date("dmYHis");
$this->PhpExcel->createWorksheet();
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A1', 'beni_inst_eligible_id')
				->setCellValue('B1', 'PAYMENT_PRODUCT_CODE')
				->setCellValue('C1', 'INSTRUMENT_REF_NO')
				->setCellValue('D1', 'CUSTOMER_ACCOUNT_NO')
				->setCellValue('E1', 'INSTRUMENT_AMOUT')
				->setCellValue('F1', 'PAY_TO')
				->setCellValue('G1', 'BENEFICAIRY_ACCOUNT_NO')
				->setCellValue('H1', 'IFSC_CODE')
				->setCellValue('I1', 'PAYMENT_INSTRUMENT_DATE')
				->setCellValue('J1', 'R30C1')
				->setCellValue('K1', 'EMAIL_ID')
				->setCellValue('L1', 'R9C1')
				->setCellValue('M1', 'PHONE');
$m=2;

foreach($datas as $data){
	$d=trim($data['Worker']['Project']['district_id']);
	if($d == 22 || $d == 23){
		$from_account="150005500799";
	}else{
		$from_account="150005500798";
	}
	$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A'.$m, $data["Incentive"]["id"])
							->setCellValue('B'.$m, 'N')
							->setCellValue('C'.$m, $data["Incentive"]["id"])
							->setCellValue('D'.$m, $from_account)
							->setCellValue('E'.$m, $data['Incentive']['amount'])
							->setCellValue('F'.$m, $data['Worker']['name'])
							->setCellValue('G'.$m, $data['Worker']['account_no'])
							->setCellValue('H'.$m, $data['Worker']['Branch']['ifsc'])
							->setCellValue('I'.$m, date('d/m/Y'))
							->setCellValue('J'.$m, 'WORKER-'.time())
							->setCellValue('K'.$m, '')
							->setCellValue('L'.$m,'WORKER-'.time())
							->setCellValue('M'.$m, $data["Worker"]["mobile_no"]);

							$this->Incentive->id=$data["Incentive"]["id"];
							$this->Incentive->saveField('paid_status','FILE GENERATED');
$m++;
}
if($m > 2){
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'csv')->setDelimiter(',')->setEnclosure(' ')->setLineEnding("\r\n");
	$objWriter->save(WWW_ROOT.'files/csv/'.$file_name.'.csv');
	$objWriter->save('C:/ICICI/Output/'.$file_name.'.csv');
}
	exit();
}
/////////////////////////////////////////////
public function icron_generate_tran_file_sbi(){
	$this->layout=null;
	$this->loadModel('Worker');
	$this->loadModel('Incentive');
	$this->loadModel('Ilogsbank');
$this->Incentive->recursive=2;
$datas=$this->Incentive->find('all',array(
	'conditions'=>array(
		'Incentive.is_paid'=>0,
		"Incentive.paid_status != 'FILE GENERATED'",
		"Worker.bank_id in(select id from banks where reg_file_format != 'NSBI')",
	),
	'order'=>array(
		'Incentive.id'
	)
));

$file_name="sbi_".date("dmYHis");
$this->PhpExcel->createWorksheet();
$objPHPExcel = new PHPExcel();
$m=1;

foreach($datas as $data){
	$d=trim($data['Worker']['Project']['district_id']);
	if($d == 22 || $d == 23){
		$from_account="36282917052";
	}else{
		$from_account="36282899870";
	}
	$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A'.$m, $m)
							->setCellValue('B'.$m, '283063')
							->setCellValue('C'.$m, 'MAMATA')
							->setCellValue('D'.$m, $from_account)
							->setCellValue('E'.$m, 'DCR')
							->setCellValue('F'.$m, date('d/m/Y'))
							->setCellValue('G'.$m, $data['Incentive']['amount'])
							->setCellValue('H'.$m, $data['Worker']['name'])
							->setCellValue('I'.$m, 'STATE BANK OF INDIA')
							->setCellValue('J'.$m, $data['Worker']['Branch']['ifsc']) //I am here
							->setCellValue('K'.$m, $data['Worker']['account_no'])
							->setCellValue('L'.$m, '')
							->setCellValue('M'.$m, $data["Worker"]["mobile_no"])
							->setCellValue('N'.$m, $data["Incentive"]["id"])
							->setCellValue('O'.$m, 'WORKER');

							$this->Incentive->id=$data["Incentive"]["id"];
							$this->Incentive->saveField('paid_status','FILE GENERATED');
$m++;
}
if($m > 1){
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'csv')->setDelimiter(',')->setEnclosure(' ')->setLineEnding("\r\n");
	$objWriter->save(WWW_ROOT.'files/csv/'.$file_name.'.csv');
	$objWriter->save('C:/ZFT/SBI283063_outtray/'.$file_name.'.csv');
}
	exit();
}
/////////////////////////////////////////////
public function loadawcs($id){
	$this->layout=NULL;
  $this->loadModel("Awc");
	$awc_id=$this->Awc->find('list',array(
		'conditions'=>array(
			'Awc.sector_id'=>$id
		),
		'order'=>array(
			'Awc.name'
		)
	));
	$this->set(compact('awc_id'));
}
}

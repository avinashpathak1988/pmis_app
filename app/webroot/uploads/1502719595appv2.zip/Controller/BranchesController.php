<?php
App::uses('AppControler','Controller');

class BranchesController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

	public function beforeFilter(){
		$this->response->disableCache();
		if($this->Session->read('user_auth') == ''){
			$this->redirect(array(
				'controller'=>'dashboard',
				'action'=>'login'
			));
		}
	}
	
public function index(){
  $datas=$this->Branch->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
    $ex=$this->Branch->find('count',array(
      'conditions'=>array(
        'Branch.name'=>$this->request->data['Branch']['name'],
        'Branch.code'=>$this->request->data['Branch']['code'],
      ),
    ));
    if($ex > 0){
      $this->message('error','Branch Name and Code already exists !');
    }

    $ex=$this->Branch->find('count',array(
      'conditions'=>array(
        'Branch.bank_id'=>$this->request->data['Branch']['bank_id'],
        'Branch.code'=>$this->request->data['Branch']['code'],
      ),
    ));
    if($ex > 0){
      $this->message('error','Bank Name and Branch Code already exists !');
    }

    $ex=$this->Branch->find('count',array(
      'conditions'=>array(
        'Branch.bank_id'=>$this->request->data['Branch']['bank_id'],
        'Branch.name'=>$this->request->data['Branch']['name'],
      ),
    ));
    if($ex > 0){
      $this->message('error','Branch Name and Bank Name already exists !');
    }
    if($ex <= 0){
      if($this->Branch->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
    }
  }

$bank_id=$this->Branch->Bank->find('list',array(
  'order'=>array(
    'Bank.name'
  ),
));
  $this->set(compact('bank_id'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Branch->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $bank_id=$this->Branch->Bank->find('list',array(
    'order'=>array(
      'Bank.name'
    ),
  ));
    $this->set(compact('bank_id'));
  $this->request->data=$this->Branch->findById($id);
}

public function delete($id){
  $this->Branch->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

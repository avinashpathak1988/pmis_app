<?php
App::uses('AppControler','Controller');

class UsersController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

  public function beforeFilter(){
  	$this->response->disableCache();
  	if($this->Session->read('user_auth') == ''){
  		$this->redirect(array(
  			'controller'=>'dashboard',
  			'action'=>'login'
  		));
  	}
  }

public function index(){
  $datas=$this->User->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
    if($this->request->data['User']['usertype_id'] == 3){
      $this->request->data['User']['project_id']=0;
    }
    if($this->request->data['User']['usertype_id'] != 3 && $this->request->data['User']['usertype_id'] != 4){
      $this->request->data['User']['district_id']=0;
      $this->request->data['User']['project_id']=0;
    }
      if($this->User->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
$designation_id=$this->User->Designation->find('list',array(
  'order'=>array(
    'Designation.name'
  )
));
$usertype_id=$this->User->Usertype->find('list',array(
  'order'=>array(
    'Usertype.name'
  )
));
$district_id=$this->User->District->find('list',array(
  'order'=>array(
    'District.name'
  )
));

$this->set(compact('designation_id','usertype_id','district_id'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
    if($this->request->data['User']['usertype_id'] == 3){
      $this->request->data['User']['project_id']=0;
    }
    if($this->request->data['User']['usertype_id'] != 3 && $this->request->data['User']['usertype_id'] != 4){
      $this->request->data['User']['district_id']=0;
      $this->request->data['User']['project_id']=0;
    }
      if($this->User->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
$designation_id=$this->User->Designation->find('list',array(
  'order'=>array(
    'Designation.name'
  )
));
$usertype_id=$this->User->Usertype->find('list',array(
  'order'=>array(
    'Usertype.name'
  )
));
$district_id=$this->User->District->find('list',array(
  'order'=>array(
    'District.name'
  )
));

$this->set(compact('designation_id','usertype_id','district_id','project_id'));
$this->request->data=$this->User->findById($id);
$this->request->data['User']['password1']=$this->request->data['User']['password'];
$project_id=$this->User->Project->find('list',array(
  'conditions'=>array(
    'Project.district_id'=>$this->request->data['User']['district_id']
  ),
  'order'=>array(
    'Project.name'
  )
));
$this->set(compact('project_id'));
}

public function delete($id){
  $this->User->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

<?php
App::uses('AppControler', 'Controller');
class BeneficiariesController extends AppController

{
  public $components = array(

    'Paginator',
    'Flash',
    'Session'
  );  

  public function get_account_details()
  {
    $this->layout = 'ajax';
    $pinst_id = $this->params['named']['pinstid'];
    $this->loadModel('Beneficiary');
    $this->loadModel('Pinstallment');
    $this->loadModel('Bank');
    $this->loadModel('Branch');

    $pintDetails = $this->Pinstallment->find('first', array(
      //'recursive' => 2,
      'conditions' => array(
        'Pinstallment.id' => $pinst_id
      ),
      'fields' => array(
        'Beneficiary.bank_id',
        'Beneficiary.branch_id',
        'Beneficiary.account_no',
      )
    ));
    //debug($pintDetails);
    $bank_id    = $pintDetails['Beneficiary']['bank_id'];
    $branch_id  = $pintDetails['Beneficiary']['branch_id'];
    $account_no = $pintDetails['Beneficiary']['account_no'];
 
    //Get Bank Details 
    $bankList = $this->Bank->find('list');
    $branchList = $this->Branch->find('list', array(
      'conditions' => array(
        'Branch.bank_id' => $bank_id
      )
    ));
    $this->set(array('bankList' => $bankList, 'branchList' => $branchList, 'bank_id' => $bank_id, 'branch_id' => $branch_id, 'account_no' => $account_no, 'pinstid' => $pinst_id));
  }
  public function updatebankdetails()
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Pinstallment');

    $new_bank_id    = $this->params['named']['bankid'];
    $new_branch_id  = $this->params['named']['branchid'];
    $new_account    = $this->params['named']['acc'];
    $pinstid        = $this->params['named']['pinstid'];

    $getBenId = $this->Pinstallment->findById($pinstid);
    $getBeneficiaryId = $getBenId['Pinstallment']['beneficiary_id'];

    if(isset($new_bank_id) && isset($new_branch_id) && isset($new_account)){
        $this->Beneficiary->id = $getBeneficiaryId;
        $this->Beneficiary->saveField('bank_id', $new_bank_id);
        $this->Beneficiary->saveField('branch_id', $new_branch_id);
        $this->Beneficiary->saveField('account_no', $new_account);
        echo '1';
    }else{
        echo '0';
    } 

  }

  public function fix_awcid()
  {
    $this->autoRender = false;
    $this->loadModel('Worker');
    $this->loadModel('Awc');
    $this->loadModel('Assignment');

    $workers = $this->Worker->find('list', array('conditions' => array('awc_id' => '0'), 'order' => array('Worker.id' => 'ASC') ));
    //debug($workers); exit;
    foreach ($workers as $id => $name) {
      //echo $id ."  " . $name."<br>";
      $getAwc = $this->Assignment->find('first', array(
          'conditions' => array(
              'worker_id' => $id
          ),
          'fields' => array(
            'awc_id'
          )
      ));
      //debug($getAwc);

      $this->Worker->id = $id;
      if($this->Worker->saveField('awc_id', $getAwc['Assignment']['awc_id'])){
        echo "The AWW/AWH having ID ".$id ."  and NAME " . $name." is Updated. <br>";
      }else{
        echo "Updation Failed"."<br>";
      }
    }

  }
  /**
    * SECTOR MIGRATION
    */
  public function migrate_sectors($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Sector');
    $this->loadModel('MasterSector');

    $sectorList = $this->MasterSector->find('all');

    foreach ($sectorList as $sector) {
      $this->request->data['Sector']['id'] = $sector['MasterSector']['master_sector_id'];
      $this->request->data['Sector']['name'] = $sector['MasterSector']['sector_name'];
      $this->request->data['Sector']['district_id'] = $sector['MasterSector']['master_district_id'];
      $this->request->data['Sector']['block_id'] = $sector['MasterSector']['master_block_id'];
      $this->request->data['Sector']['gp_id'] = $sector['MasterSector']['master_grampanchayat_id'];
      $this->request->data['Sector']['project_id'] = $sector['MasterSector']['project_manager_id'];
      $this->request->data['Sector']['created'] = $sector['MasterSector']['created'];
      $this->request->data['Sector']['modified'] = $sector['MasterSector']['modified'];

      $this->Sector->create();
      $this->Sector->save($this->request->data['Sector']);
    }
  }
  /**
    * @@ CHANGE PAYMENT DATE FORMAT 
    */
  public function changePayment_date($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Payment');
    //$this->loadModel('MasterSector');

    $paymentList = $this->Payment->find('all', array(/*'limit' => 50*/));
    //debug($paymentList); exit;
    foreach ($paymentList as $data) {
      $oldPaymentDate = $data['Payment']['payment_date'];
      $explodeDate = explode('-',$oldPaymentDate);
      $newDate = $explodeDate[0]."-".$explodeDate[2]."-".$explodeDate[1];
      echo "NEW DATE =".$newDate."<br>";

      $this->Payment->id = $data['Payment']['id'];
      if($this->Payment->saveField('payment_date', $newDate)){
        echo "Date changed from ".$oldPaymentDate." To NEW DATE = ".$newDate."<br>";
      }
    }
  }
  /** 
    * @@ MIGRATE VERIFIES TABLE 
    **/
  public function migrate_verifies()
  {
    $this->autoRender = false;
    $this->loadModel('BeniInstMaster');
    $this->loadModel('Verify');
    //$this->loadModel('Assignment');
    $this->loadModel('User');
    //$this->loadModel('OffAccount');
    /*
    */
    $benDetails = $this->BeniInstMaster->find('all', array(
        'conditions' => array(
          //'beni_id' => '1265'
        ), 
        //'order' => 'ben_id',
        //'limit' => 10
    ));

    foreach ($benDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['BeniInstMaster']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));
      
      $arrayEligibilities = array(
        '47' => '2',
        '48' => '3',
        '49' => '4',
        '50' => '5',
        '51' => '6',
        '81' => '7'
      );
      // @@ GET VERIFIES DATA 
      $groupData                                       = $data['BeniInstMaster']['inst_condition_dates'];
      //echo "RAW CONDs = ".$groupData."<br />";
      if(isset($groupData) && $groupData !=''){
            $expgrpData                                      = explode(',', $groupData);
            $loop = 0;
            foreach ($expgrpData as $indiCond) {
                  //echo "DATA = ".$indiCond."<br>";
                  $expgrpData                                      = explode('#', $indiCond);
                  //debug($expgrpData);
                  $elig_id                                         = $expgrpData[0];
                  $newEligId                                       = $arrayEligibilities[$elig_id];
                  //echo "NEW ID = ".$newEligId; exit;
                  $eligDate                                        = $expgrpData[1];

                  // @@ Get User ID
                  $user_id                                         = $get_user_id_qry['User']['id'];

                  $this->request->data[$loop]['Verify']['id']             = $data['BeniInstMaster']['beni_inst_id'];
                  $this->request->data[$loop]['Verify']['beneficiary_id'] = $data['BeniInstMaster']['beni_id'];
                  $this->request->data[$loop]['Verify']['pregnency_id']   = $data['BeniInstMaster']['pregnancy_id'];
                  $this->request->data[$loop]['Verify']['eligibility_id'] = $newEligId;
                //  $this->request->data['Verify']['pregnency_no']   = '1';
                  $this->request->data[$loop]['Verify']['value']          = $eligDate;
                  $this->request->data[$loop]['Verify']['user_id']        = $user_id;
                  $this->request->data[$loop]['Verify']['created']        = $data['BeniInstMaster']['created'];
                  $this->request->data[$loop]['Verify']['modified']       = $data['BeniInstMaster']['modified'];

                  $this->Verify->query("INSERT INTO verifies 
                                          (id, 
                                          beneficiary_id, 
                                          pregnency_id, 
                                          eligibility_id, 
                                          pregnency_no, 
                                          value, 
                                          user_id, 
                                          created, 
                                          modified
                                          )
                                          VALUES
                                          (".$data['BeniInstMaster']['beni_inst_id'].", 
                                          ".$data['BeniInstMaster']['beni_id'].", 
                                          ".$data['BeniInstMaster']['pregnancy_id'].", 
                                          ".$newEligId.", 
                                          '1', 
                                          '".$eligDate."', 
                                          ".$user_id.", 
                                          '".$data['BeniInstMaster']['created']."', 
                                          '".$data['BeniInstMaster']['modified']."'
                                          )"
                  );

                  echo "INSERT INTO verifies 
                                          (id, 
                                          beneficiary_id, 
                                          pregnency_id, 
                                          eligibility_id, 
                                          pregnency_no, 
                                          value, 
                                          user_id, 
                                          created, 
                                          modified
                                          )
                                          VALUES
                                          (".$data['BeniInstMaster']['beni_inst_id'].", 
                                          ".$data['BeniInstMaster']['beni_id'].", 
                                          ".$data['BeniInstMaster']['pregnancy_id'].", 
                                          ".$newEligId.", 
                                          '1', 
                                          '".$eligDate."', 
                                          ".$user_id.", 
                                          '".$data['BeniInstMaster']['created']."', 
                                          '".$data['BeniInstMaster']['modified']."'
                                          )"."<br>----<br>";
                  /*debug($this->request->data[$loop]);
                  $this->Verify->save($this->request->data); //exit;*/
                  $loop++;
            }

          }

         // exit;
      //exit;
           /* debug($this->request->data['Verify']); 
            if($this->Verify->saveAll($this->request->data['Verify'])){
              echo "The beneficiary having ID=".$data['BeniInstMaster']['beni_id'].", And Preg ID =".$data['BeniInstMaster']['pregnancy_id']." is Successfully Inserted!"."<br>";
            }else{
              echo "There was something went Wrong";
            }*/
    }
        

        

  }
  public function migrate_verifies_fixation()
  {
    $this->autoRender = false;
    $this->loadModel('BeniInstMaster');
    $this->loadModel('Verify');
    //$this->loadModel('Assignment');
    $this->loadModel('User');
    //$this->loadModel('OffAccount');
    /*
    */
    $benDetails = $this->BeniInstMaster->query("SELECT * FROM beni_inst_masters WHERE is_conditions_approved='Y' AND 
                  beni_id IN (SELECT beneficiary_id FROM view_first_verify WHERE totalverify < 6) LIMIT 10");


    foreach ($benDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['beni_inst_masters']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));
     

      $arrayEligibilities = array(
        '47' => '2',
        '48' => '3',
        '49' => '4',
        '50' => '5',
        '51' => '6',
        '81' => '7'
      );
      // @@ GET VERIFIES DATA 
      $groupData                                       = $data['beni_inst_masters']['inst_condition_dates'];
      //echo "RAW CONDs = ".$groupData."<br />";
      if(isset($groupData) && $groupData !=''){
        echo $groupData;
            if (preg_match('47#',$groupData)){
              echo '47 missed';
            }else if (preg_match('48#',$groupData)){
              echo '48 missed';
            }elseif (preg_match('49#',$groupData)){
              echo '49 missed';
            }elseif (preg_match('50#',$groupData)){
              echo '50 missed';
            }else if (preg_match('51#',$groupData)){
              echo '51 missed';
            }else if (preg_match('81#',$groupData)){
              echo '81 missed';
            }else{
              echo 'done';
            } 

            exit;
            $expgrpData                                      = explode(',', $groupData);
            $loop = 0;
            foreach ($expgrpData as $indiCond) {
                  echo "DATA = ".$indiCond."<br>";
                  $expgrpData                                      = explode('#', $indiCond);
                  //debug($expgrpData);
                  $elig_id                                         = $expgrpData[0];
                  $newEligId                                       = $arrayEligibilities[$elig_id];
                  //echo "NEW ID = ".$newEligId; exit;
                  $eligDate                                        = $expgrpData[1];

                  // @@ Get User ID
                  $user_id                                         = $get_user_id_qry['User']['id'];

                  $this->request->data[$loop]['Verify']['id']             = $data['beni_inst_masters']['beni_inst_id'];
                  $this->request->data[$loop]['Verify']['beneficiary_id'] = $data['beni_inst_masters']['beni_id'];
                  $this->request->data[$loop]['Verify']['pregnency_id']   = $data['beni_inst_masters']['pregnancy_id'];
                  $this->request->data[$loop]['Verify']['eligibility_id'] = $newEligId;
                //  $this->request->data['Verify']['pregnency_no']   = '1';
                  $this->request->data[$loop]['Verify']['value']          = $eligDate;
                  $this->request->data[$loop]['Verify']['user_id']        = $user_id;
                  $this->request->data[$loop]['Verify']['created']        = $data['beni_inst_masters']['created'];
                  $this->request->data[$loop]['Verify']['modified']       = $data['beni_inst_masters']['modified'];

                  /*$this->Verify->query("INSERT INTO verifies 
                                          (id, 
                                          beneficiary_id, 
                                          pregnency_id, 
                                          eligibility_id, 
                                          pregnency_no, 
                                          value, 
                                          user_id, 
                                          created, 
                                          modified
                                          )
                                          VALUES
                                          (".$data['beni_inst_masters']['beni_inst_id'].", 
                                          ".$data['beni_inst_masters']['beni_id'].", 
                                          ".$data['beni_inst_masters']['pregnancy_id'].", 
                                          ".$newEligId.", 
                                          '1', 
                                          '".$eligDate."', 
                                          ".$user_id.", 
                                          '".$data['beni_inst_masters']['created']."', 
                                          '".$data['beni_inst_masters']['modified']."'
                                          )"
                  );*/

                  echo "INSERT INTO verifies 
                                          (id, 
                                          beneficiary_id, 
                                          pregnency_id, 
                                          eligibility_id, 
                                          pregnency_no, 
                                          value, 
                                          user_id, 
                                          created, 
                                          modified
                                          )
                                          VALUES
                                          (".$data['beni_inst_masters']['beni_inst_id'].", 
                                          ".$data['beni_inst_masters']['beni_id'].", 
                                          ".$data['beni_inst_masters']['pregnancy_id'].", 
                                          ".$newEligId.", 
                                          '1', 
                                          '".$eligDate."', 
                                          ".$user_id.", 
                                          '".$data['beni_inst_masters']['created']."', 
                                          '".$data['beni_inst_masters']['modified']."'
                                          )"."<br>----<br>";
                  /*debug($this->request->data[$loop]);
                  $this->Verify->save($this->request->data); //exit;*/
                  $loop++; 
            }
            exit;
          }

         // exit;
      //exit;
           /* debug($this->request->data['Verify']); 
            if($this->Verify->saveAll($this->request->data['Verify'])){
              echo "The beneficiary having ID=".$data['BeniInstMaster']['beni_id'].", And Preg ID =".$data['BeniInstMaster']['pregnancy_id']." is Successfully Inserted!"."<br>";
            }else{
              echo "There was something went Wrong";
            }*/
    }
        

        

  }

  public function fix_bankid()
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('OffAccount');

    $benDetails = $this->Beneficiary->find('all', array(
      'recursive' => -1,
      'conditions' => array(
        'Beneficiary.bank_id =' => '0'
      ),
      'order' => 'Beneficiary.id',
      'fields' => array(
        'id'
      ),
      'limit' => 2000
    )) ;

    foreach ($benDetails as $value) {
        $benaccDetails = $this->OffAccount->find('first', array(
          'recursive' => -1,
          'conditions' => array(
            'OffAccount.link_id' => $value['Beneficiary']['id']
          ),
          'order' => 'OffAccount.off_account_id',
          'fields' => array(
            'bank_id'
          ),
        )) ;

        $this->Beneficiary->id = $value['Beneficiary']['id'];
        $this->Beneficiary->saveField('bank_id', $benaccDetails['OffAccount']['bank_id']);
        echo "Beneficiiary having ID = ". $value['Beneficiary']['id'] . " assigned to bank ID - ".$benaccDetails['OffAccount']['bank_id']."<br>";
        //debug($benaccDetails);
    }

    //debug($benDetails);


  }

  public function migrate_beneficiary($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Beneficiarylive');
    $this->loadModel('Assignment');
    $this->loadModel('User');
    $this->loadModel('OffAccount');
    /*
    */
    $benDetails = $this->Beneficiarylive->find('all', array('conditions' => array(
      'ben_id >=' => '29127'
    ), 'order' => 'ben_id')) ;

    foreach ($benDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['Beneficiarylive']['project_id']
        ),
        'fields' => array(
          'id'
        )
      ));

      $get_branch_details = $this->OffAccount->find('first', array(
        'conditions' => array(
          'link_id' => $data['Beneficiarylive']['ben_id']
        ),
        'fields' => array(
          'branch_id',
          'bank_id'
        )
      ));
      
      $user_id = $get_user_id_qry['User']['id'];
        $this->request->data['Beneficiary']['id'] = $data['Beneficiarylive']['ben_id'];
        $this->request->data['Beneficiary']['name'] = $data['Beneficiarylive']['ben_name'];
        $this->request->data['Beneficiary']['is_rch_mcts'] = (isset($data['Beneficiarylive']['is_rch_mct']) && $data['Beneficiarylive']['is_rch_mct'] == 'RCH') ?'0' : '1';
        $this->request->data['Beneficiary']['rch_mcts_no'] = $data['Beneficiarylive']['rch_no'];
        $this->request->data['Beneficiary']['reg_date'] = $data['Beneficiarylive']['registration_date'];
        $this->request->data['Beneficiary']['husband_govt'] = $data['Beneficiarylive']['is_govt_emp'];
        $this->request->data['Beneficiary']['husband'] = $data['Beneficiarylive']['wife_daughter_of'];
        $this->request->data['Beneficiary']['village'] = $data['Beneficiarylive']['village_name'];
        $this->request->data['Beneficiary']['address'] = $data['Beneficiarylive']['address'];
        $this->request->data['Beneficiary']['sector_id'] = $data['Beneficiarylive']['master_sector_id'];
        $this->request->data['Beneficiary']['gp_id'] = $data['Beneficiarylive']['master_grampanchayat_id'];
        $this->request->data['Beneficiary']['awc_id'] = $data['Beneficiarylive']['awc_id'];
        $this->request->data['Beneficiary']['worker_id'] = $data['Beneficiarylive']['worker_aww_id'];
        $this->request->data['Beneficiary']['helper_id'] = $data['Beneficiarylive']['worker_awh_id'];
        $this->request->data['Beneficiary']['caste'] = $data['Beneficiarylive']['caste'];
        $this->request->data['Beneficiary']['no_of_live_birth'] = $data['Beneficiarylive']['no_live_birth'];
        $this->request->data['Beneficiary']['dob'] = date("Y-m-d",strtotime(str_replace("/", "-", $data['Beneficiarylive']['date_of_birth']))); 
        $this->request->data['Beneficiary']['age'] = $data['Beneficiarylive']['age'];
        $this->request->data['Beneficiary']['code'] = '';
        $this->request->data['Beneficiary']['mobile_no'] = $data['Beneficiarylive']['mobile_number'];
        $this->request->data['Beneficiary']['mobile_belong'] = $data['Beneficiarylive']['mobile_number_type'];
        $this->request->data['Beneficiary']['bank_id'] = $get_branch_details['OffAccount']['bank_id'];
        $this->request->data['Beneficiary']['branch_id'] = $get_branch_details['OffAccount']['branch_id'];
        $this->request->data['Beneficiary']['account_no'] = $data['Beneficiarylive']['bene_account'];
        $this->request->data['Beneficiary']['is_bpl'] = ucfirst($data['Beneficiarylive']['is_bpl']);
        $this->request->data['Beneficiary']['is_disability'] = $data['Beneficiarylive']['is_disabled'];
        $this->request->data['Beneficiary']['mail_id'] = $data['Beneficiarylive']['email_address'];
        $this->request->data['Beneficiary']['aadhar'] = $data['Beneficiarylive']['aadhaar_card'];
        $this->request->data['Beneficiary']['religion_id'] = $data['Beneficiarylive']['master_minority_id'];
        $this->request->data['Beneficiary']['is_pvtg'] = $data['Beneficiarylive']['is_pvtg'];
        $this->request->data['Beneficiary']['user_id'] = $user_id;
        $this->request->data['Beneficiary']['is_exit'] = $data['Beneficiarylive']['is_exit'];
        $this->request->data['Beneficiary']['is_check_suspect'] = '0';
        $this->request->data['Beneficiary']['is_suspect'] = $data['Beneficiarylive']['is_suspect'];
        $this->request->data['Beneficiary']['suspect_reason'] = '';
        $this->request->data['Beneficiary']['suspect_action'] = '';
        $this->request->data['Beneficiary']['action_user_id'] = $user_id;
        $this->request->data['Beneficiary']['action_date'] = $data['Beneficiarylive']['created'];
        $this->request->data['Beneficiary']['created'] = $data['Beneficiarylive']['created'];
        $this->request->data['Beneficiary']['modified'] = $data['Beneficiarylive']['modified'];

        //debug($this->data['Beneficiary']);
        if($this->Beneficiary->save($this->data['Beneficiary'])){
          echo "The beneficiary having ID=".$data['Beneficiarylive']['ben_id'].", And Name =".$data['Beneficiarylive']['ben_name']." is Successfully Inserted!"."<br>";
        }else{
          echo "There was something went Wrong";
        }
    }

  }

  /**
    * Migrate Pregnancy Data
    **/

  public function migrate_pregnancy($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Pregnency');
    $this->loadModel('PregnancyBeneficiary');
    $this->loadModel('BeniInstMaster');
    $this->loadModel('User');
    /*
    */
    $benDetails = $this->PregnancyBeneficiary->find('all', array('order' => array('id' => 'asc')/*, 'limit' => 100*/)) ;

    foreach ($benDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['PregnancyBeneficiary']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));

      $get_inst_details = $this->BeniInstMaster->find('first', array(
        'conditions' => array(
          'inst_number' => 1,
          'beni_id' => $data['PregnancyBeneficiary']['ben_id']
        ),
        'fields' => array(
          'inst_due_date'
        )
      ));
      if(isset($get_inst_details['BeniInstMaster']['inst_due_date']) && $get_inst_details['BeniInstMaster']['inst_due_date'] !=''){
        $inst_due_date = $get_inst_details['BeniInstMaster']['inst_due_date'];
      }else{
        $inst_due_date= NULL;
      }
      //debug($get_branch_details);


      $user_id = $get_user_id_qry['User']['id'];
        $this->request->data['Pregnency']['id'] = $data['PregnancyBeneficiary']['id'];
        $this->request->data['Pregnency']['beneficiary_id'] = $data['PregnancyBeneficiary']['ben_id'];
        $this->request->data['Pregnency']['lmp_date'] = $data['PregnancyBeneficiary']['lmp_date'];
        $this->request->data['Pregnency']['preg_reg_date'] = $data['PregnancyBeneficiary']['registration_date'];
        $this->request->data['Pregnency']['scheme_reg_date'] = $data['PregnancyBeneficiary']['scheme_registration_date'];
        $this->request->data['Pregnency']['exp_dod'] = $data['PregnancyBeneficiary']['delivery_date'];
        $this->request->data['Pregnency']['age'] = $data['PregnancyBeneficiary']['age'];
        $this->request->data['Pregnency']['preg_no'] = $data['PregnancyBeneficiary']['pregnancy_no'];
        $this->request->data['Pregnency']['is_approved'] = (isset($data['PregnancyBeneficiary']['is_approved']) && $data['PregnancyBeneficiary']['is_approved'] =='Y') ? '1' : '0';
        $this->request->data['Pregnency']['user_id'] = $user_id;
        $this->request->data['Pregnency']['approved_date'] = $data['PregnancyBeneficiary']['modified'];
        $this->request->data['Pregnency']['first_install_date'] = $inst_due_date;
        $this->request->data['Pregnency']['second_install_date'] = NULL;
        $this->request->data['Pregnency']['is_exit'] = $data['PregnancyBeneficiary']['is_exit'];
        $this->request->data['Pregnency']['exit_reason'] = $data['PregnancyBeneficiary']['exit_reason_id'];
        $this->request->data['Pregnency']['exit_date'] = $data['PregnancyBeneficiary']['exit_date'];
        $this->request->data['Pregnency']['created'] = $data['PregnancyBeneficiary']['created'];
        $this->request->data['Pregnency']['modified'] = $data['PregnancyBeneficiary']['modified'];

       // debug($this->data['Pregnency']);
        if($this->Pregnency->save($this->data['Pregnency'])){
          echo "The beneficiary having Preg ID=".$data['PregnancyBeneficiary']['id'].", And Ben ID =".$data['PregnancyBeneficiary']['ben_id']." is Successfully Inserted!"."<br>";
        }else{
          echo "There was something went Wrong";
        }
    }

  }

  public function migrate_payments()
  {
    $this->autoRender = false;
    $this->loadModel('BeniInstTransaction');
    $this->loadModel('Beneficiary');
    $this->loadModel('Pinstallment');
    $this->loadModel('BeniInstMaster');
    $this->loadModel('Branch');
    $this->loadModel('User');
    $this->loadModel('Payment');

    $bimDetails = $this->BeniInstMaster->find('all', array(
      'conditions' => array(
        'inst_number' => 1,
        'is_paid' => 'Y'
      ),
      //'order' => array('id' => 'asc'), 
      //'limit' => 10
      )) ;

    $loop=0;
    foreach ($bimDetails as $data) {
      $benDetails = $this->Beneficiary->findById($data['BeniInstMaster']['beni_id']);
      //debug($benDetails); exit;
      $benPInstallment = $this->Pinstallment->find('first', array(
        'conditions' => array(
          'Pinstallment.beneficiary_id' => $benDetails['Beneficiary']['id'],
          'Pinstallment.pregnency_id' => $data['BeniInstMaster']['pregnancy_id'],
          'Pinstallment.installment_no' => $data['BeniInstMaster']['inst_number'],
        ),
        'fields' => array(
          'Pinstallment.id'
        )
      ));
      //debug($benPInstallment);
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['BeniInstMaster']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));
      $user_id = $get_user_id_qry['User']['id'];

      //@@ GET BRANCH DETAILS
      $getBraDetails = $this->Branch->findById($benDetails['Beneficiary']['branch_id']);

      $this->request->data['Payment']['beneficiary_id'] = $data['BeniInstMaster']['beni_id'];
      $this->request->data['Payment']['name'] = $benDetails['Beneficiary']['name'];
      $this->request->data['Payment']['mail_id'] = $benDetails['Beneficiary']['mail_id'];
      $this->request->data['Payment']['mobile_no'] = $benDetails['Beneficiary']['mobile_no'];
      $this->request->data['Payment']['pregnency_id'] = $data['BeniInstMaster']['pregnancy_id'];
      $this->request->data['Payment']['installment_no'] = $data['BeniInstMaster']['inst_number'];
      $this->request->data['Payment']['pinstallment_id'] = $benPInstallment['Pinstallment']['id'];
      $this->request->data['Payment']['amount'] = '3000';
      $this->request->data['Payment']['instrument_date'] = $data['BeniInstMaster']['inst_due_date'];
      $this->request->data['Payment']['request_date'] = $data['BeniInstMaster']['inst_sys_gen_date'];
      $this->request->data['Payment']['is_approved'] = (isset($data['BeniInstMaster']['is_approved']) && $data['BeniInstMaster']['is_approved']=='Y')? '1' : '0';
      $this->request->data['Payment']['is_paid'] = (isset($data['BeniInstMaster']['is_paid']) && $data['BeniInstMaster']['is_paid']=='Y')? '1' : '0';
      $this->request->data['Payment']['user_id'] = $user_id;
      $this->request->data['Payment']['file_name'] = 'XYZ';
      $this->request->data['Payment']['branch_name'] = $getBraDetails['Branch']['name'];
      $this->request->data['Payment']['ifsc'] = $getBraDetails['Branch']['ifsc'];
      $this->request->data['Payment']['account_no'] = $benDetails['Beneficiary']['account_no'];
      $this->request->data['Payment']['uuid'] = $data['BeniInstMaster']['beni_id'];
      $this->request->data['Payment']['payment_date'] = $data['BeniInstMaster']['paid_date'];
      $this->request->data['Payment']['payment_status'] = (isset($data['BeniInstMaster']['is_paid']) && $data['BeniInstMaster']['is_paid']=='Y')? 'Paid' : NULL;
      $this->request->data['Payment']['bankremark'] = (isset($data['BeniInstMaster']['is_paid']) && $data['BeniInstMaster']['is_paid']=='Y')? 'SUCCESS' : NULL;
      $this->request->data['Payment']['created'] = $data['BeniInstMaster']['created'];
      $this->request->data['Payment']['modified'] = $data['BeniInstMaster']['modified'];

      // @@ INITIALIZE PAYMENT TABLE
      $this->Payment->create();
      if($this->Payment->save($this->data['Payment'])){
          echo "The beneficiary having Preg ID=".$data['BeniInstMaster']['pregnancy_id'].", And Ben ID =".$data['BeniInstMaster']['beni_id']." is Successfully Inserted!"."<br>";
      }else{
        echo "There was something went Wrong";
      }

    }
  } 

  /**
    * Migrate Pinstallment
    **/
  public function migrate_pinstallments($value='')
  {
    $this->autoRender = false;
    $this->loadModel('Beneficiary');
    $this->loadModel('Pinstallment');
    $this->loadModel('PregnancyBeneficiary');
    $this->loadModel('BeniInstMaster');
    $this->loadModel('BeniInstEligible');
    $this->loadModel('BeniInstResponse');
    $this->loadModel('User');
    /*
    */
    $benInstDetails = $this->BeniInstMaster->find('all', array('order' => array('beni_inst_id' => 'asc')/*, 'limit' => 150*/)) ;

    foreach ($benInstDetails as $data) {
      //debug($data); exit;
      $get_user_id_qry = $this->User->find('first', array(
        'conditions' => array(
          'project_id' => $data['BeniInstMaster']['project_manager_id']
        ),
        'fields' => array(
          'id'
        )
      ));

   /*   $get_inst_details = $this->BeniInstMaster->find('first', array(
        'conditions' => array(
          'inst_number' => 1,
          'beni_id' => $data['PregnancyBeneficiary']['ben_id']
        ),
        'fields' => array(
          'inst_due_date'
        )
      ));*/
      // @@ GET INSTALLMENT DUE DATE
      if(isset($get_inst_details['BeniInstMaster']['inst_due_date']) && $get_inst_details['BeniInstMaster']['inst_due_date'] !=''){
        $inst_due_date = $data['BeniInstMaster']['inst_due_date'];
      }else{
        $inst_due_date= NULL;
      }

      // @@ GET PAYMENT STATUS 
      if(isset($data['BeniInstMaster']['is_approved']) && $data['BeniInstMaster']['is_approved']=='Y' && $data['BeniInstMaster']['payment_status'] == 'SUCCESS'){
        $payment_status = 'Paid';
      }elseif(isset($data['BeniInstMaster']['is_approved']) && $data['BeniInstMaster']['is_approved']=='Y' && $data['BeniInstMaster']['payment_status'] != 'SUCCESS'){
        $payment_status = 'Payment Approved';
      }else{
        $payment_status = NULL;
      }


      // @@ GET BANK TRANSACTION REMARK
      $get_bank_remark = $this->BeniInstEligible->find('first' , array(
        'conditions' => array(
          'r9c1' => $data['BeniInstMaster']['beni_id']
        ),
        'fields' => array(
          'remark',
          'trans_date'
        ),
      ));
      if(isset($get_bank_remark['BeniInstEligible']['remark']) && $get_bank_remark['BeniInstEligible']['remark'] !=''){
        $trans_remark = $get_bank_remark['BeniInstEligible']['remark'];
      }else{
        $trans_remark = NULL;
      }

      //@@ GET PAID DATE
      if(isset($data['BeniInstMaster']['is_paid']) & $data['BeniInstMaster']['is_paid'] =='Y' && isset($data['BeniInstMaster']['is_approved']) && $data['BeniInstMaster']['is_approved'] == '1970-01-01'){
        $paid_date = $get_bank_remark['BeniInstEligible']['trans_date'];
      }else if(isset($data['BeniInstMaster']['is_paid']) & $data['BeniInstMaster']['is_paid'] =='Y' && isset($data['BeniInstMaster']['is_approved'])){
        $paid_date = $data['BeniInstMaster']['paid_date'];
      }else{
        $paid_date = NULL;
      }

      // @@ GET Bank REFERENCE NO
    /*  $get_bank_ref_no = $this->BeniInstResponse->find('first' , array(
        'conditions' => array(
          'r9c1' => $data['BeniInstMaster']['beni_id']
        ),
        'fields' => array(
          'payment_ref_no',
        ),
      ));
      if(isset($get_bank_ref_no['BeniInstResponse']['payment_ref_no']) && $get_bank_ref_no['BeniInstResponse']['payment_ref_no'] !=''){
        $trans_ref = $get_bank_ref_no['BeniInstResponse']['payment_ref_no'];
      }else{
        $trans_ref = '';
      }*/
  
      //@GET IS PAID STATUS


      //@@ Get USER ID FROM PROJECT ID
      $user_id = $get_user_id_qry['User']['id'];

        $this->request->data['Pinstallment']['id'] = $data['BeniInstMaster']['beni_inst_id'];
        $this->request->data['Pinstallment']['beneficiary_id'] = $data['BeniInstMaster']['beni_id'];
        $this->request->data['Pinstallment']['pregnency_id'] = $data['BeniInstMaster']['pregnancy_id'];
        $this->request->data['Pinstallment']['preg_no'] = '1';
        $this->request->data['Pinstallment']['installment_no'] = $data['BeniInstMaster']['inst_number'];
        $this->request->data['Pinstallment']['installment_date'] = $data['BeniInstMaster']['inst_due_date'];
        $this->request->data['Pinstallment']['is_payment_approve'] = (isset($data['BeniInstMaster']['is_conditions_approved']) && $data['BeniInstMaster']['is_conditions_approved'] =='Y') ? '1' : '0';
        $this->request->data['Pinstallment']['approved_by'] = $user_id;
        $this->request->data['Pinstallment']['approved_date'] = $data['BeniInstMaster']['created'];
        $this->request->data['Pinstallment']['payment_status'] = $payment_status;
        $this->request->data['Pinstallment']['payment_date'] = $paid_date;
        $this->request->data['Pinstallment']['bank_payment_status'] = $inst_due_date;
        $this->request->data['Pinstallment']['is_paid'] = (isset($data['BeniInstMaster']['is_paid']) && $data['BeniInstMaster']['is_paid'] =='Y') ? '1' : '0';
        $this->request->data['Pinstallment']['banktranno'] = NULL;
        $this->request->data['Pinstallment']['bankremark'] = $trans_remark;
        $this->request->data['Pinstallment']['created'] = $data['BeniInstMaster']['created'];
        $this->request->data['Pinstallment']['modified'] = $data['BeniInstMaster']['modified'];

        //debug($this->data['Pinstallment']);
         //if(isset($data['BeniInstMaster']['inst_number']) && $data['BeniInstMaster']['inst_number'] == 1){
            if($this->Pinstallment->save($this->data['Pinstallment'])){
              echo "The beneficiary having Preg ID=".$data['BeniInstMaster']['pregnancy_id'].", And Ben ID =".$data['BeniInstMaster']['beni_id']." is Successfully Inserted!"."<br>";
            }else{
              echo "There was something went Wrong";
            }
         // }
    }

  }

  /**
    * By : Tanmaya/15-03-2017
    * Info : RCH OR MCTS Number Validation
    **/
  public function search_mctno(){
        $this->autoRender = false;
        $this->loadModel('Beneficiary');
        $number = $this->params->query['mother_id'];
        $num_type = $this->params->query['num_type'];

        $getData = $this->Beneficiary->find('first', array(
          'recursive' => -1,
          'conditions' => array(
            'rch_mcts_no' => $number
          )
        ));
        if(isset($getData) && is_array($getData) && count($getData) > 0 ){
          echo "1";
        }else{
          echo "0";
        }
    }

    public function ben_history()
    {
      $this->layout = 'ajax';
      $this->loadModel('Beneficiary');
      $this->loadModel('Pregnency');
      $uid = $this->params->query['uid'];

      $data = $this->Beneficiary->find('all', array(
        'conditions' => array(
          "Beneficiary.id in(select beneficiary_id from pregnencies where id=$uid)"
        )
      ));

      //debug($data);
      $this->set(array(
        'datas' => $data[0]
      ));

    }

  public

  function beforeFilter()
  {
    $this->response->disableCache();
    $user = $this->Session->read('user_auth');
    if ($this->Session->read('user_auth') == '') {
      $this->redirect(array(
        'controller' => 'dashboard',
        'action' => 'login'
      ));
    }
  }

  public function index()
  {
    $this->loadModel('Pregnency');
    $this->loadModel('Pinstallment');
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      if ($this->request->data['Beneficiary']['exit_reason'] != '') {
        $ben_id = $this->request->data['Beneficiary']['id'];
        $exit_reason = $this->request->data['Beneficiary']['exit_reason'];
        if ($ben_id != '' && $exit_reason != '') {
          $this->loadModel('Pregnency');
          $pregnency_id = '';
          $pregnency_id = $this->Pregnency->find('first', array(
            'conditions' => array(
              'Pregnency.beneficiary_id' => $ben_id
            ) ,
            'order' => array(
              'Pregnency.id' => 'DESC'
            )
          ));
          $pregnency_id = $pregnency_id['Pregnency']['id'];
          $this->Pregnency->id = $pregnency_id;
          $this->Pregnency->saveField('is_exit', 1);
          $this->Pregnency->saveField('exit_reason', $exit_reason);
          $this->Pregnency->saveField('exit_date', date('Y-m-d'));
          $this->message('success', 'Exit Details Saved Successfully !');
        }
      }
    }

    $datas = "";
    $user = $this->Session->read('user_auth');
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Gp.project_id='" . $user['Project']['id'] . "'";
    }

    if ($user['Designation']['name'] != 'CDPO' && $user['Designation']['name'] != 'PA') {
      $gp_id = '';
    }
    else {
      $gp_id = $this->Beneficiary->Gp->find('list', array(
        'conditions' => array(

          // 'Gp.id in(select gp_id from beneficiaries)',

          $sqlcond1,
        ) ,
        'order' => array(
          'Gp.name'
        )
      ));
    }

    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Sector.project_id='" . $user['Project']['id'] . "'";
    }

    $sector_id = $this->Beneficiary->Sector->find('list', array(
      'conditions' => array(
        $sqlcond1

        // 'Sector.id in(select sector_id from beneficiaries)'

      ) ,
      'order' => array(
        'Sector.name'
      )
    ));
    $sqlcond1 = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sqlcond1 = "Awc.project_id='" . $user['Project']['id'] . "'";
    }

    /*  $awc_id = $this->Beneficiary->Awc->find('list', array(
    'conditions' => array(

    // 'Awc.id in(select awc_id from beneficiaries)'

    $sqlcond1
    ) ,
    'order' => array(
    'Awc.name'
    )
    )); */
    $awc_id = '';
    //$user = $this->Session->read('user_auth');
    //if (isset($this->request->data['Beneficiary']['sector_id']) && $this->request->data['Beneficiary']['sector_id'] != '') {
      $awc_id = $this->Beneficiary->Awc->find('list', array(
        'conditions' => array(
          'Awc.project_id' => $user['Project']['id']
        ) ,
        'order' => array(
          'Awc.name'
        )
      ));
    //}

    $husband_govt = array(
      'No' => 'No',
      'Yes' => 'Yes'
    );
    $is_suspect = array(
      '2' => 'All',
      '0' => 'No',
      '1' => 'Yes',
    );
    $exit_reasons = array(
      'INFANT DEATH' => 'INFANT DEATH',
      'MISCARRIAGE' => 'MISCARRIAGE',
      //'MIGRATION' => 'MIGRATION'
    );
    $is_pvtg = array(
      'N' => 'No',
      'Y' => 'Yes'
    );
    $in_scheme = array(
      '0' => 'No',
      '1' => 'Yes',
    );

    $this->set(compact('in_scheme', 'is_pvtg', 'datas', 'gp_id', 'sector_id', 'awc_id', 'husband_govt', 'is_suspect', 'exit_reasons'));
  }

  // ///////////////////////////////////////

  public

  function index_ajax()
  {
    $this->layout = 'ajax';
    $sql_name = "";
    $name     = '';
    $rch_mcts_no = '';
    $account_no  = '';
    $gp_id       = '';
    $awc_id      = '';
    $sector_id   = '';
    $from_date   = '';
    $to_date     = '';
    $husband_govt = '';
    $is_suspect  = '';
    $is_pvtg     = '';
    $in_scheme   = '';
    if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
        $name = $this->params['named']['name'];
      $sql_name = "Beneficiary.name like '%" . $name . "%'";
    }

    $sql_rch_mcts_no = "";
    if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
        $rch_mcts_no = $this->params['named']['rch_mcts_no'];
      $sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $rch_mcts_no . "'";
    }
    $sql_account_no = "";
    if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
        $account_no = $this->params['named']['account_no'];
      $sql_account_no = "Beneficiary.account_no='" . $account_no . "'";
    }

    $sql_gp_id = "";
    if (isset($this->params['named']['gp_id']) && $this->params['named']['gp_id'] != '') {
        $gp_id = $this->params['named']['gp_id'];
      $sql_gp_id = "Beneficiary.gp_id='" . $gp_id . "'";
    }

    $sql_awc_id = "";
    if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
        $awc_id = $this->params['named']['awc_id'];
      $sql_awc_id = "Beneficiary.awc_id='" . $awc_id . "'";
    }

    $sql_sector_id = "";
    if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
        $sector_id = $this->params['named']['sector_id'];
      $sql_sector_id = "Beneficiary.sector_id='" . $sector_id . "'";
    }

    $sql_date = ""; 
    if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '' && isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
            $from_date = $this->params['named']['from_date'];
            $to_date = $this->params['named']['to_date'];

      $sql_date = "Beneficiary.reg_date between '" . date('Y-m-d', strtotime($from_date)) . "' and '" . date('Y-m-d', strtotime($to_date)) . "'";
    }

    $sql_husband = "";
    if (isset($this->params['named']['husband_govt']) && $this->params['named']['husband_govt'] != '') {
        $husband_govt = $this->params['named']['husband_govt'];
      $sql_husband = "Beneficiary.husband_govt = '" . $husband_govt . "'";
    }

    $sql_is_suspect = "";
    if (isset($this->params['named']['is_suspect']) && $this->params['named']['is_suspect'] != '' && $this->params['named']['is_suspect'] != 2) {
        $is_suspect = $this->params['named']['is_suspect'];
      $sql_is_suspect = "Beneficiary.is_suspect = '" . $is_suspect . "'";
    }

    $sql_is_pvtg = "";
    if (isset($this->params['named']['is_pvtg']) && $this->params['named']['is_pvtg'] != '') {
        $is_pvtg = $this->params['named']['is_pvtg'];
      $sql_is_pvtg = "Beneficiary.is_pvtg='" . $is_pvtg . "'";
    }

    $user = $this->Session->read('user_auth');
    $sql = "";
    if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
      $sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
    }

    $sql_in_scheme = "";
    if (isset($this->params['named']['in_scheme']) && $this->params['named']['in_scheme'] == "1" || $this->params['named']['in_scheme'] == "") {
        $in_scheme = $this->params['named']['in_scheme'];
      $sql_in_scheme = "Beneficiary.husband_govt = 'No' and Beneficiary.age >= 19 and Beneficiary.age <= 45";
    }

    if (isset($this->params['named']['in_scheme']) && $this->params['named']['in_scheme'] == "0") {
        $in_scheme = $this->params['named']['in_scheme'];
      $sql_in_scheme = "(Beneficiary.husband_govt = 'Yes' or Beneficiary.age < 19 or Beneficiary.age > 45)";
    }


    //////////////////////////////

    // /////Download//////////////////////

    if (isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != '') {
      $this->layout = 'export_xls';
      if ($this->params['named']['reqType'] == 'XLS') {
        $this->set('file_type', 'xls');
        $this->set('file_name', 'beneficiaries' . date('d_m_Y') . '.xls');
      }
      else
      if ($this->params['named']['reqType'] == 'DOC') {
        $this->set('file_type', 'doc');
        $this->set('file_name', 'beneficiaries' . date('d_m_Y') . '.doc');
      }

      $this->set('is_excel', 'Y');
      $limit = array(
        'limit' => 2000,
        'maxLimit' => 2000
      );
    }
    else {
      $limit = array(
        'limit' => 100
      );
    }

    // //End Download//////////////////////

    $this->paginate = array(
      'conditions' => array(
        $sql,
        $sql_name,
        $sql_rch_mcts_no,
        $sql_account_no,
        $sql_gp_id,
        $sql_awc_id,
        $sql_sector_id,
        $sql_husband,
        $sql_is_suspect,
        $sql_is_pvtg,
        $sql_in_scheme,
        $sql_date
      ) ,
      'order' => array(
        'Beneficiary.id' => 'DESC'
      ) ,
      'maxLimit' => 2000,
    ) + $limit;
    $datas = $this->paginate('Beneficiary');
   /* debug($datas);*/
    $this->set(compact('datas', 'sql', 'sql_name', 'sql_rch_mcts_no', 'sql_account_no', 'sql_gp_id', 'sql_awc_id', 'sql_sector_id', 'sql_husband'));
    $this->set(compact('sql_is_suspect', 'sql_is_pvtg', 'sql_in_scheme', 'sql_date'));
    $this->set(array(
        'name'          => $name,
        'rch_mcts_no'   => $rch_mcts_no,
        'account_no'    => $account_no,
        'gp_id'         => $gp_id,
        'awc_id'        => $awc_id,
        'sector_id'     => $sector_id,
        'from_date'     => $from_date,
        'to_date'       => $to_date,
        'husband_govt'  => $husband_govt,   
        'is_suspect'    => $is_suspect, 
        'is_pvtg'       => $is_pvtg,   
        'in_scheme'     => $in_scheme, 
    ));  
  }

  // ///////////////////////////////////////

  public

function add()
{
  /*echo '<div class="alert alert-danger" style="background:red;padding:7px;text-align:center;color:white;font-weight:bold;border-radius:6px">Currently, Beneficiary Registration is Closed.</div>'; exit();*/
    $this->layout = 'admin';
    $this->loadModel('Awc');
    $this->loadModel('Beneficiary');
    $session = $this->Session->read('user_auth');
    $project_id = $session['User']['project_id'];
    if ($this->request->is(array(
        'post',
        'put'
    ))) {
        $uniqueAccountCheck = $this->Beneficiary->findByAccountNo($this->request->data['Beneficiary']['account_no']);
        if (isset($uniqueAccountCheck) && count($uniqueAccountCheck) > 0) {
            $this->message('error', 'Account No should be Unique.');
        }
        else {
            if ($this->request->data['Beneficiary']['account_no'] == $this->request->data['Beneficiary']['account_no1']) {
                if ($this->request->data['Beneficiary']['husband_govt'] == 'Yes') {
                    $this->request->data['Beneficiary']['bank_id'] = 0;
                    $this->request->data['Beneficiary']['branch_id'] = 0;
                    $this->request->data['Beneficiary']['account_no'] = '';
                }

                if (isset($this->request->data['Beneficiary']['reg_date']) && $this->request->data['Beneficiary']['reg_date'] != '') {
                    $this->request->data['Beneficiary']['reg_date'] = date('Y-m-d', strtotime($this->request->data['Beneficiary']['reg_date']));
                }

                $dob = NULL;
                if (isset($this->request->data['Beneficiary']['dob']) && $this->request->data['Beneficiary']['dob'] != '') {
                    $this->request->data['Beneficiary']['dob'] = date('Y-m-d', strtotime($this->request->data['Beneficiary']['dob']));
                    $dob = $this->request->data['Beneficiary']['dob'];
                }

                $user = $this->Session->read('user_auth');
                $user_id = $user['User']['id'];
                $this->request->data['Beneficiary']['user_id'] = $user_id;
                if ($user_id == "") {
                    $this->message("error", "Invalid User ! Please login again and try.");
                }
                else {
                    $this->request->data['Beneficiary']['is_exit'] = 0;
                    $birthdate = new DateTime($dob);
                    $today = new DateTime('today');
                    $agev = $birthdate->diff($today)->y;
                    if ($this->request->data['Beneficiary']['age'] != '') {
                        $agev = $this->request->data['Beneficiary']['age'];
                    }

                    if ($agev < 0 || $agev > 150) {
                        $this->message('error', 'Age must be in between 19 and 45 !');
                    }
                    else {
                        $this->request->data['Beneficiary']['is_check_suspect'] = 1;

                        // Find if PVTG//

                        $is_pvtg = 'N';
                        $is_awc_pvtg = 0;
                        $is_awc_pvtg = $this->Awc->find('count', array(
                            'conditions' => array(
                                'Awc.id' => $this->request->data['Beneficiary']['awc_id'],
                                'Awc.is_pvtg' => 'Y'
                            )
                        ));
                        if ($is_awc_pvtg > 0 && $this->request->data['Beneficiary']['caste'] == 'ST' && $this->request->data['Beneficiary']['is_pvtg'] == 'Y') {
                            $this->request->data['Beneficiary']['is_pvtg'] = 'Y';
                        }
                        else {
                            $this->request->data['Beneficiary']['is_pvtg'] = 'N';
                        }

                        // End of finding if PVTG//

                        if ($this->Beneficiary->save($this->request->data)) {
                            $this->Beneficiary->query("update beneficiaries set is_pvtg='" . $this->request->data['Beneficiary']['is_pvtg'] . "' where id='" . $this->Beneficiary->getLastInsertId() . "'");
                            $this->message('success', 'Saved Successfully !');
                            $this->redirect(array(
                                'action' => 'index'
                            ));
                        }
                        else {
                            $this->message('error', 'Saving Failed !');
                        }
                    }
                }
            } //account no match end
            else {
                $this->message('error', 'Account no Should be Matched.');
            }
        } //unique Account No
    }

    $is_rch_mcts = array(
        '0' => 'RCH',
        '1' => 'MCTS'
    );
    $user = $this->Session->read('user_auth');
    $sector_id = $this->Beneficiary->Sector->find('list', array(
        'conditions' => array(
            'Sector.project_id' => $user['Project']['id'],
        ) ,
        'order' => array(
            'Sector.name'
        ) ,
        'conditions' => array(
            'project_id' => $project_id
        )
    ));
    $gp_id = $this->Beneficiary->Gp->find('list', array(
        'order' => array(
            'Gp.name'
        ) ,
        'conditions' => array(
            'project_id' => $project_id
        )
    ));
    $caste = array(
        'General' => 'General',
        'OBC' => 'OBC',
        'ST' => 'ST',
        'SC' => 'SC',
        'Others' => 'Others'
    );
    $husband_govt = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $mobile_belong = array(
        'Self' => 'Self',
        'Husband' => 'Husband',
        'Parents' => 'Parents'
    );
    $bank_id = $this->Beneficiary->Bank->find('list', array(
        'order' => array(
            'Bank.name'
        ) ,
    ));
    $branch_id = '';
    if (isset($this->request->data['Beneficiary']['bank_id']) && $this->request->data['Beneficiary']['bank_id'] != '') {
        $branch_id = $this->Beneficiary->Branch->find('list', array(
            'conditions' => array(
                'Branch.bank_id' => $this->request->data['Beneficiary']['bank_id']
            ) ,
            'order' => array(
                'Branch.name'
            ) ,
        ));
    }

    $is_bpl = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $is_disability = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $awc_id = '';
    $user = $this->Session->read('user_auth');
    //if (@$this->request->data['Beneficiary']['sector_id'] != '') {
        $awc_id = $this->Beneficiary->Awc->find('list', array(
            'conditions' => array(
                'Awc.project_id' => $user['Project']['id']
            ) ,
            'order' => array(
                'Awc.name'
            ) ,
        ));
    //}

    $religion_id = $this->Beneficiary->Religion->find('list');
    $worker_id = "";
    if (@$this->request->data['Beneficiary']['worker_id'] != '') {
        $worker_id = $this->Beneficiary->Worker->find('list', array(
            'conditions' => array(
                'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
                'Worker.workertype_id' => 1
            ) ,
            'order' => array(
                'Worker.name'
            )
        ));
    }

    $helper_id = "";
    if (@$this->request->data['Beneficiary']['helper_id'] != '') {
        $helper_id = $this->Beneficiary->Worker->find('list', array(
            'conditions' => array(
                'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
                'Worker.workertype_id' => 2
            ) ,
            'order' => array(
                'Worker.name'
            )
        ));
    }

    $is_pvtg = array(
        'N' => 'No',
        'Y' => 'Yes'
    );
    $this->set(compact('is_pvtg', 'is_rch_mcts', 'sector_id', 'gp_id', 'caste', 'husband_govt', 'mobile_belong', 'bank_id', 'branch_id', 'is_bpl', 'is_disability', 'religion_id', 'awc_id', 'worker_id', 'helper_id'));
}

  public function edit($id){
	  $this->layout = 'admin';
        $this->loadModel('Awc');
        $this->loadModel('Beneficiary');
        if ($this->request->is(array('post', 'put'))) {
            $uniqueAccountCheck = $this->Beneficiary->findByAccountNo($this->request->data['Beneficiary']['account_no']);
            if (isset($uniqueAccountCheck) && count($uniqueAccountCheck) > 0) {
                $this->message('error', 'Account No should be Unique.');
            }
            else {
                if ($this->request->data['Beneficiary']['account_no'] == $this->request->data['Beneficiary']['account_no1']) {
                    if ($this->request->data['Beneficiary']['husband_govt'] == 'Yes') {
                        $this->request->data['Beneficiary']['bank_id'] = 0;
                        $this->request->data['Beneficiary']['branch_id'] = 0;
                        $this->request->data['Beneficiary']['account_no'] = '';
                    }

                    if (isset($this->data['Beneficiary']['reg_date']) && $this->data['Beneficiary']['reg_date'] != '') {
                        $this->request->data['Beneficiary']['reg_date'] = date('Y-m-d', strtotime($this->data['Beneficiary']['reg_date']));
                    }

                    if (isset($this->data['Beneficiary']['dob']) && $this->data['Beneficiary']['dob'] != '') {
                        $this->request->data['Beneficiary']['dob'] = date('Y-m-d', strtotime($this->data['Beneficiary']['dob']));
                        $dob = $this->request->data['Beneficiary']['dob'];
                    }

                    $user = $this->Session->read('user_auth');
                    $user_id = $user['User']['id'];
                    $this->request->data['Beneficiary']['user_id'] = $user_id;
                    if ($user_id == "") {
                        $this->message("error", "Invalid User ! Please login again and try.");
                    }
                    else {
                        $this->request->data['Beneficiary']['is_exit'] = 0;
                        $birthdate = new DateTime($dob);
                        $today = new DateTime('today');
                        $agev = $birthdate->diff($today)->y;
                        if ($this->request->data['Beneficiary']['age'] != '') {
                            $agev = $this->request->data['Beneficiary']['age'];
                        }

                        if ($agev < 0 || $agev > 150) {
                            $this->message('error', 'Age must be in between 19 and 45 !');
                        }
                        else {
                            $this->request->data['Beneficiary']['is_check_suspect'] = 1;
                            $this->request->data['Beneficiary']['suspect_reason'] = '';
                            $this->request->data['Beneficiary']['suspect_action'] = '';
                            $this->request->data['Beneficiary']['action_user_id'] = NULL;
                            $this->request->data['Beneficiary']['action_date'] = NULL;
                            $is_pvtg = 'N';
                            $is_awc_pvtg = 0;
                            $is_awc_pvtg = $this->Awc->find('count', array(
                                'conditions' => array(
                                    'Awc.id' => $this->request->data['Beneficiary']['awc_id'],
                                    'Awc.is_pvtg' => 'Y'
                                )
                            ));
                            if ($is_awc_pvtg > 0 && $this->request->data['Beneficiary']['caste'] == 'ST' && $this->request->data['Beneficiary']['is_pvtg'] == 'Y') {
                                $this->request->data['Beneficiary']['is_pvtg'] = 'Y';
                            }
                            else {
                                $this->request->data['Beneficiary']['is_pvtg'] = 'N';
                            }

                            unset($this->Beneficiary->validate['account_no']);

                            // debug($this->request->data); exit;

                            if ($this->Beneficiary->save($this->request->data)) {
                                $this->Beneficiary->query("update beneficiaries set is_pvtg='" . $this->request->data['Beneficiary']['is_pvtg'] . "' where id='" . $id . "'");
                                $this->message('success', 'Saved Successfully !');
                                $this->redirect(array(
                                    'action' => 'index'
                                ));
                            }
                            else {
                                $this->message('error', 'Saving Failed !');
                            }
                        }
                    }
                }else {
                  $this->message('error', 'Account no Should be Matched.');
                }
            }
        } // POST
    

    $this->request->data = $this->Beneficiary->findById($id);
    $this->request->data['Beneficiary']['account_no1'] = $this->request->data['Beneficiary']['account_no'];
    $is_rch_mcts = array(
        '0' => 'RCH',
        '1' => 'MCTS'
    );
    $user = $this->Session->read('user_auth');
    $project_id = $user['Project']['id'];
    $sector_id = $this->Beneficiary->Sector->find('list', array(
        'conditions' => array(
            'Sector.project_id' => $user['Project']['id'],
        ) ,
        'order' => array(
            'Sector.name'
        ) ,
        'conditions' => array(
            'project_id' => $project_id
        )
    ));
    $gp_id = $this->Beneficiary->Gp->find('list', array(
        'order' => array(
            'Gp.name'
        ) ,
        'conditions' => array(
            'project_id' => $project_id
        )
    ));
    $caste = array(
        'General' => 'General',
        'OBC' => 'OBC',
        'ST' => 'ST',
        'SC' => 'SC',
        'Others' => 'Others'
    );
    $husband_govt = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $mobile_belong = array(
        'Self' => 'Self',
        'Husband' => 'Husband',
        'Parents' => 'Parents'
    );
    $bank_id = $this->Beneficiary->Bank->find('list', array(
        'order' => array(
            'Bank.name'
        ) ,
    ));
    $branch_id = '';

    if ($this->request->data['Beneficiary']['bank_id'] != '') {
        $branch_id = $this->Beneficiary->Branch->find('list', array(
            'conditions' => array(
                'Branch.bank_id' => $this->request->data['Beneficiary']['bank_id']
            ) ,
            'order' => array(
                'Branch.name'
            ) ,
        ));
    }

    $is_bpl = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $is_disability = array(
        'Yes' => 'Yes',
        'No' => 'No'
    );
    $awc_id = '';
    $user = $this->Session->read('user_auth');
    //if (@$this->request->data['Beneficiary']['sector_id'] != '') {
        $awc_id = $this->Beneficiary->Awc->find('list', array(
            'conditions' => array(
                'Awc.project_id' => $user['Project']['id']
            ) ,
            'order' => array(
                'Awc.name'
            ) ,
        ));
    //}

    $religion_id = $this->Beneficiary->Religion->find('list');
    $worker_id = "";

    if (@$this->request->data['Beneficiary']['worker_id'] != '') {
        $worker_id = $this->Beneficiary->Worker->find('list', array(
            'conditions' => array(
                'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
                'Worker.workertype_id' => 1
            ) ,
            'order' => array(
                'Worker.name'
            )
        ));
    }

    $helper_id = "";

    if (@$this->request->data['Beneficiary']['helper_id'] != '') {
        $helper_id = $this->Beneficiary->Worker->find('list', array(
            'conditions' => array(
                'Worker.awc_id' => $this->request->data['Beneficiary']['awc_id'],
                'Worker.workertype_id' => 2
            ) ,
            'order' => array(
                'Worker.name'
            )
        ));
    }

    $is_pvtg = array(
        'N' => 'No',
        'Y' => 'Yes'
    );
    $this->set(compact('is_pvtg', 'is_rch_mcts', 'sector_id', 'gp_id', 'caste', 'husband_govt', 'mobile_belong', 'bank_id', 'branch_id', 'is_bpl', 'is_disability', 'religion_id', 'awc_id', 'worker_id', 'helper_id'));
  }

  public

  function delete($id)
  {
    $this->Beneficiary->delete($id);
    $this->message('success', 'Deleted Successfully !');
    $this->redirect(array(
      'action' => 'index'
    ));
  }

  public

  function loadbranches($id)
  {
    $this->layout = NULL;
    $branch_id = $this->Beneficiary->Branch->find('list', array(
      'conditions' => array(
        'Branch.bank_id' => $id
      ) ,
      'order' => array(
        'Branch.name'
      ) ,
    ));
    $this->set(compact('branch_id'));
  }

  public function loadawcs($id){ 
    $this->layout = 'ajax';
    $awc_id = $this->Beneficiary->Awc->find('list', array(
      'conditions' => array(
        'Awc.sector_id' => $id
      ) ,
      'order' => array(
        'Awc.name'
      ) ,
    ));
    $this->set(compact('awc_id'));
  }

  public

  function loadworker($id)
  {
    $this->layout = NULL;
    $user = $this->Session->read('user_auth');

    //echo "##".$id."  ###".$user['Project']['id']."<br>"; exit;
    $this->loadModel('Assignment');
    $worker_id = $this->Assignment->Worker->find('list', array(
      'conditions' => array(
        'Worker.awc_id' => $id,
        'Worker.workertype_id' => 1,
        'Worker.project_id' => $user['Project']['id'],
        "Worker.id in(select worker_id from assignments where is_removed=0 and awc_id='" . $id . "' and project_id='" . $user['Project']['id'] . "' order by id desc)",
      ) ,
      'order' => array(
        'Worker.name'
      ) ,
    ));
    $this->set(compact('worker_id'));
  }

  public

  function loadhelper($id)
  {
    $this->layout = NULL;
    $helper_id = $this->Beneficiary->Worker->find('list', array(
      'conditions' => array(
        'Worker.awc_id' => $id,
        'Worker.workertype_id' => 2
      ) ,
      'order' => array(
        'Worker.name'
      ) ,
    ));
    $this->set(compact('helper_id'));
  }

  public

  function calage($age)
  {
    $this->layout = NULL;
    $age = explode('-', $age);
    $age = $age[2] . '-' . $age[1] . '-' . $age[0];
    $birthdate = new DateTime($age);
    $today = new DateTime('today');
    $age = $birthdate->diff($today)->y;
    echo $age;
    exit();
  }

  public

  function confirmsuspect($id)
  {
    $this->layout = NULL;
    $u = $this->Session->read('user_auth');
    $this->Beneficiary->id = $id;
    $this->Beneficiary->saveField('suspect_action', 'CONFIRMED');
    $this->Beneficiary->saveField('action_user_id', $u['User']['id']);
    $this->Beneficiary->saveField('action_date', date("Y-m-d"));
    $this->Beneficiary->saveField('is_suspect', 0);
    echo "Confirmed Successfully !";
    exit();
  }

  public

  function rejectsuspect($id)
  {
    $this->layout = NULL;
    $u = $this->Session->read('user_auth');
    $this->Beneficiary->id = $id;
    $this->Beneficiary->saveField('suspect_action', 'REJECTED');
    $this->Beneficiary->saveField('action_user_id', $u['User']['id']);
    $this->Beneficiary->saveField('action_date', date("Y-m-d"));
    echo "Rejected Successfully !";
    exit();
  }

  public

  function firstverify($id)
  {
  }

  // //////////////////////////////////////

  public

  function view($id)
  {
    $this->loadModel('Delivery');
    $data = $this->Beneficiary->findById($id);
    $this->set(compact('data'));
  }

  public  function get_bene_details($rch)
  {
    $this->layout = 'ajax';
    $this->loadModel('Delivery');
    $data = $this->Beneficiary->findByRchMctsNo($rch);
    if(isset($data) && is_array($data) && count($data) > 0){
      $this->set(compact('data'));
    }else{
      echo '<script>$(".show_rch_details").empty(); $(".rch_get_details").val(""); alert("Sorry ! This RCh or MCTS Number not found in Database."); </script>';
    }
  }


  public

  function returnlive($id)
  {

    //  $this->layout=NULL;

    $this->loadModel('Delivery');
    $this->loadModel('Pregnency');
    $live_birth_reg = 0;
    $live_birth_del = 0;
    $live_birth_total = 0;
    $live_birth_reg = $this->Beneficiary->findById($id);
    $live_birth_reg = $live_birth_reg['Beneficiary']['no_of_live_birth'];
    $this->Delivery->recursive = - 1;
    $d = $this->Delivery->find('all', array(
      'conditions' => array(
        'Delivery.beneficiary_id' => $id,
      ) ,
      'order' => array(
        'Delivery.id'
      )
    ));


    $this->Pregnency->recursive=-1;
    $e=$this->Pregnency->find('all',array(
      'conditions'=>array(
        'Pregnency.beneficiary_id'=>$id
      ),
      'order'=>array(
        'Pregnency.id'=>'DESC'
      ),
      //'limit'=>1
    ));

    foreach($e as $e1){
      if(strtoupper($e1['Pregnency']['exit_reason']) == 'INFANT DEATH'){
        $live_birth_del=$live_birth_del + 1;
      }
    }

    foreach($d as $d1) {
      if ($d1['Delivery']['outcome'] == 'Single Live Birth') {
        $live_birth_del = $live_birth_del + 1;
      }

  //    if ($d1['Delivery']['outcome'] == 'Infant Death') {
  //      $live_birth_del = $live_birth_del + 1;
//      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] == 'Yes' && $d1['Delivery']['child2_live_birth'] == 'Yes') {
        $live_birth_del = $live_birth_del + 2;
      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] != 'Yes' && $d1['Delivery']['child2_live_birth'] == 'Yes') {
        $live_birth_del = $live_birth_del + 1;
      }

      if ($d1['Delivery']['outcome'] == 'Twin Live Birth' && $d1['Delivery']['child1_live_birth'] == 'Yes' && $d1['Delivery']['child2_live_birth'] != 'Yes') {
        $live_birth_del = $live_birth_del + 1;
      }
    }

    // $live_birth_total=$live_birth_reg + $live_birth_del;

    $live_birth_total = $live_birth_del;
    return $live_birth_total;

    //  exit();

  }

  public

  function loadispvtg($id)
  {
    $this->layout = NULL;
    $this->loadModel('Awc');
    $cnt = $this->Awc->find('count', array(
      'conditions' => array(
        'Awc.is_pvtg' => 'Y',
        'Awc.id' => $id
      )
    ));
    if ($cnt > 0) {
      echo "SHOW";
    }
    else {
      echo "HIDE";
    }

    exit();
  }

  // /////////////////////////
  public  function maternaldeath($id)
  {
    $this->layout = NULL;
    $this->loadModel('Pregnency');
    $this->Pregnency->query("update pregnencies set is_exit=1,exit_reason='MATERNAL DEATH',exit_date=curdate() where id=$id");
    exit();
  }
  public  function migration($id){
      $this->layout = NULL;
      $this->loadModel('Pregnency');
      $this->Pregnency->query("update pregnencies set is_exit=0, is_migration=1, mig_pending_at='PA' where id=$id");
      exit();
  }
  public  function migration_reject($id){
      $this->layout = NULL;
      $this->loadModel('Pregnency');
      $this->Pregnency->query("update pregnencies set is_exit=0, is_migration=0, mig_pending_at='' where id=$id");
      exit();
  }

  public  function migration_dpc($id){
      $this->layout = NULL;
      $this->loadModel('Pregnency');
      $this->Pregnency->query("update pregnencies set is_exit=0, is_migration=1, mig_pending_at='DPC' where id=$id");
      exit();
  }
  public  function migration_cdpo($id){
      $this->layout = NULL;
      $this->loadModel('Pregnency');
      $this->Pregnency->query("update pregnencies set is_exit=1, exit_reason='MIGRATION', exit_date=curdate(), is_migration=2, mig_pending_at='' where id=$id");
      exit();
  }

  public function migration_report() {
        $this->loadModel('Beneficiary');
        $this->loadModel('Payment');
        $this->loadModel('Pregnency');
        $this->loadModel('Pinstallment');
        $this->LoadModel('District');
        $this->LoadModel('Sector');
        $this->LoadModel('Awc');
        $this->LoadModel('Project');
        $this->LoadModel('Delivery');
        $user = $this->Session->read('user_auth');
        $datas = array();
        $project_id = '';
        $sector_id = '';
        $awc_id = '';


        /**
         *  Tanmaya Code Start
         * Purpose : To set Filters and Serch criteria proper
         * */
        $sql_cond1 = "";
        if ($user['Designation']['name'] == 'DPC') {
            $sql_cond1 = "District.id='" . $user['District']['id'] . "'";
            $this->request->data['Report']['district_id'] = $user['District']['id'];
            $this->request->data['Report']['project_id'] = $this->data['Report']['project_id'];

            $project_id = $this->Project->find('list', array(
                'conditions' => array(
                    'district_id' => $user['District']['id']
                ),
                'order' => array(
                    'Project.name'
                )
            ));
        }

        if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
            $sql_cond1 = "District.id in(select district_id from users where project_id='" . $user['Project']['id'] . "')";
            $this->request->data['Report']['district_id'] = $user['District']['id'];
            $this->request->data['Report']['project_id'] = $user['Project']['id'];

            $project_id = $this->Project->find('list', array(
                'conditions' => array(
                    'district_id' => $user['District']['id']
                ),
                'order' => array(
                    'Project.name'
                )
            ));
            $sector_id = $this->Sector->find('list', array(
                'conditions' => array(
                    'project_id' => $user['Project']['id']
                ),
                'order' => array(
                    'Sector.name'
                )
            ));
        }

        $district_id = $this->District->find('list', array(
            'conditions' => array(
                $sql_cond1
            ),
            'order' => array(
                'District.name'
            )
        ));
        // Pre-Select the AWC List
        if (isset($this->data['Report']['district_id']) && $this->data['Report']['district_id'] != '') {
            $project_id = $this->Project->find('list', array(
                'conditions' => array(
                    'district_id' => $this->data['Report']['district_id']
                ),
                'order' => array(
                    'Project.name'
                )
            ));
        }
        // Pre-Select the Project List
        if ((isset($this->data['Report']['project_id']) && $this->data['Report']['project_id'] != '') || (isset($sql_cond1) && $sql_cond1 != '' )) {
            $project_id = $this->Project->find('list', array(
                'conditions' => array(
                    'district_id' => $this->data['Report']['district_id']
                ),
                'order' => array(
                    'Project.name'
                )
            ));
            $sector_id = $this->Sector->find('list', array(
                'conditions' => array(
                    'project_id' => $this->data['Report']['project_id']
                ),
                'order' => array(
                    'Sector.name'
                )
            ));
        }
        // Pre-Select the AWC List
        if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
            $awc_id = $this->Awc->find('list', array(
                'conditions' => array(
                    'sector_id' => $this->data['Report']['sector_id']
                ),
                'order' => array(
                    'Awc.name'
                )
            ));
        }
        // Pre-Select the Project List
        if (isset($this->data['Report']['sector_id']) && $this->data['Report']['sector_id'] != '') {
            $sector_id = $this->Sector->find('list', array(
                'conditions' => array(
                    'project_id' => $this->data['Report']['project_id']
                ),
                'order' => array(
                    'Sector.name'
                )
            ));
        }
        /** /End of tanmaya code* */
        $exit_reason = array(
            'MATERNAL DEATH' => 'MATERNAL DEATH',
            'INFANT DEATH' => 'INFANT DEATH',
            'MISCARRIAGE' => 'MISCARRIAGE',
            'STILL BIRTH' => 'STILL BIRTH',
            'MIGRATION' => 'MIGRATION',
            'AUTO' => 'ALL DUE PAID'
        );
        // Changes for IIIT
        $this->request->data['Report']['to_date'] = date('d-m-Y', strtotime("-1 days"));
        $this->set(compact('district_id', 'project_id', 'awc_id', 'sector_id', 'exit_reason', 'datas'));
    }

    public function migration_report_ajax() {
        $this->loadModel('Beneficiary');
        $this->loadModel('Payment');
        $this->loadModel('Pregnency');
        $this->loadModel('Pinstallment');
        $this->LoadModel('District');
        $this->LoadModel('Sector');
        $this->LoadModel('Awc');
        $this->LoadModel('Project');
        $this->LoadModel('Delivery');
        $datas = array();
        $this->layout = 'ajax';
        $user = $this->Session->read('user_auth');
        $name = '';
        $rch_mcts_no = '';
        $district_id = '';
        $project_id = '';
        $sector_id = '';
        $awc_id = '';
        $exit_reason = '';
        $from_date = '';
        $to_date = '';
        $account_no = '';

        $dynamic_limit = '';

        $dynamic_limit = "";
        if (isset($this->params['named']['perpagelimit']) && $this->params['named']['perpagelimit'] != '') {
            $dynamic_limit = $this->params['named']['perpagelimit'];
        }else{
            $dynamic_limit = 100;
        }

        $sql = "";
        if ($user['Designation']['name'] == "CDPO" || $user['Designation']['name'] == 'PA') {
            $sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
        }

        $sql_name = "";
        if (isset($this->params['named']['name']) && $this->params['named']['name'] != '') {
            $name = $this->params['named']['name'];
            $sql_name = "Beneficiary.name LIKE '%" . $this->params['named']['name'] . "%'";
        }

        $sql_rch_mcts_no = "";
        if (isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != '') {
            $rch_mcts_no = $this->params['named']['rch_mcts_no'];
            $sql_rch_mcts_no = "Beneficiary.rch_mcts_no='" . $this->params['named']['rch_mcts_no'] . "'";
        }


        $sql_district_id = "";
        if (isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != '') {
            $district_id = $this->params['named']['district_id'];
            $sql_district_id = "Beneficiary.user_id in(select id from users where district_id='" . $this->params['named']['district_id'] . "')";
        }

        $sql_project_id = "";
        if (isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != '') {
            $project_id = $this->params['named']['project_id'];
            $sql_project_id = "Beneficiary.user_id in(select id from users where project_id='" . $this->params['named']['project_id'] . "')";
        }

        $sql_sector_id = "";
        if (isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != '') {
            $sector_id = $this->params['named']['sector_id'];
            $sql_sector_id = "Beneficiary.sector_id='" . $this->params['named']['sector_id'] . "'";
        }

        $sql_awc_id = "";
        if (isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != '') {
            $awc_id = $this->params['named']['awc_id'];
            $sql_awc_id = "Beneficiary.awc_id ='" . $this->params['named']['awc_id'] . "'";
        }


        $sql_from_date = "";
        /*if (isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != '') {
            $from_date = $this->params['named']['from_date'];
            $sql_from_date = "Pregnency.exit_date >='" . date('Y-m-d', strtotime($this->params['named']['from_date'])) . "'";
        }*/
        $sql_to_date = "";
        /*if (isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != '') {
            $to_date = $this->params['named']['to_date'];
            $sql_to_date = "Pregnency.exit_date <= '" . date('Y-m-d', strtotime($this->params['named']['to_date'])) . "'";
        }*/
        $sql_account_no = "";
        if (isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != '') {
            $account_no = $this->params['named']['account_no'];
            $sql_account_no = "Beneficiary.account_no='" . $this->params['named']['account_no'] . "'";
        }
        $sql_exit_reason = "";
        if (isset($this->params['named']['exit_reason']) && $this->params['named']['exit_reason'] != '') {
            $exit_reason = $this->params['named']['exit_reason'];
            $sql_exit_reason = "Pregnency.exit_reason='" . $this->params['named']['exit_reason'] . "'";
        }

        if (isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != '') {
            $this->layout = 'export_xls';
            if ($this->params['named']['reqType'] == 'XLS') {
                $this->set('file_type', 'xls');
                $this->set('file_name', 'Beneficiaries_details_' . date('d_m_Y') . '.xls');
            } else if ($this->params['named']['reqType'] == 'DOC') {
                $this->set('file_type', 'doc');
                $this->set('file_name', 'Beneficiaries_details_' . date('d_m_Y') . '.doc');
            }
            $this->set('is_excel', 'Y');
            $limit = array('limit' => 2000, 'maxLimit' => 2000);
        } else {
            $limit = array('limit' => $dynamic_limit, 'maxLimit' => 2000);
        }
        $this->paginate = array(
            'conditions' => array(
                'Pregnency.is_migration IN(1, 2)',
                //'Beneficiary.husband_govt' => 'No',
                $sql,
                $sql_name,
                $sql_rch_mcts_no,
                $sql_district_id,
                $sql_project_id,
                $sql_sector_id,
                $sql_awc_id,
                $sql_account_no,
                $sql_exit_reason,
                $sql_to_date,
                $sql_from_date
            ),
            'order' => array(
                'Pregnency.preg_reg_date'
            )
                ) + $limit;

        $datas = $this->paginate('Pregnency');
/*$log = $this->Pregnency->getDataSource()->getLog(false, false);
        debug($log);*/
        $this->set(compact('datas'));
        $this->set(array(
            'name' => $name,
            'rch_mcts_no' => $rch_mcts_no,
            'district_id' => $district_id,
            'project_id' => $project_id,
            'sector_id' => $sector_id,
            'awc_id' => $awc_id,
            'account_no' => $account_no,
            'exit_reason' => $exit_reason,
            'from_date' => $from_date,
            'to_date' => $to_date,
            'dynamic_limit' => $dynamic_limit
        ));
    }

///////////////////////////
public function mcdeath($id)
{
  $this->layout = NULL;
  $this->loadModel('Pregnency');
  $this->Pregnency->query("update pregnencies set is_exit=1,exit_reason='MISCARRIAGE',exit_date=curdate() where id=$id");
  exit();
}

  // /////////////////////////

    public function suspect_report(){
        $this->loadModel('District');
        $this->loadModel('Project');
        if ($this->request->is(array('post','put'))) {
            if (isset($this->request->data['Beneficiary']['exit_reason']) && $this->request->data['Beneficiary']['exit_reason'] != '') {
                $ben_id = $this->request->data['Beneficiary']['id'];
                $exit_reason = $this->request->data['Beneficiary']['exit_reason'];
                if ($ben_id != '' && $exit_reason != '') {
                    $this->loadModel('Pregnency');
                    $pregnency_id = '';
                    $pregnency_id = $this->Pregnency->find('first', array(
                        'conditions' => array(
                            'Pregnency.beneficiary_id' => $ben_id
                        ) ,
                        'order' => array(
                            'Pregnency.id' => 'DESC'
                        )
                    ));
                    $pregnency_id = $pregnency_id['Pregnency']['id'];
                    $this->Pregnency->id = $pregnency_id;
                    $this->Pregnency->saveField('is_exit', 1);
                    $this->Pregnency->saveField('exit_reason', $exit_reason);
                    $this->Pregnency->saveField('exit_date', date('Y-m-d'));
                    $this->message('success', 'Exit Details Saved Successfully !');
                }
            }
        }
        $user = $this->Session->read('user_auth');
        $distCond = array();
        if (isset($user['User']['district_id']) && (int)$user['User']['district_id'] != 0) {
            $distCond = array('District.id' => $user['User']['district_id']);
        }
        $districtList = $this->District->find('list', array(
            'recursive'     => -1,
            'conditions'    => $distCond,
            'fields'        => array(
                'District.id',
                'District.name',
            ),
            'order'         => array(
                'District.name'
            )
        ));
        if (isset($user['User']['district_id']) && (int)$user['User']['district_id'] == 0){
            $districtList = array('' => '-- Select District --')+$districtList;
        }
        if (isset($user['User']['project_id']) && (int)$user['User']['project_id'] != 0) {
            $distCond = array('Project.id' => $user['User']['project_id']);
            $projectList = $this->Project->find('list', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Project.id'   => $user['User']['project_id'],
                ),
                'fields'        => array(
                    'Project.id',
                    'Project.name',
                ),
                'order'         => array(
                    'Project.name',
                ),
            ));            
        }else{
            $projectList = array(''=>'-- Select Project Location --');
        }        
        /** /End of tanmaya code**/
        $husband_govt = array(
            'No' => 'No',
            'Yes' => 'Yes'
        );
        $is_suspect = array(
            '2' => 'All',
            '0' => 'No',
            '1' => 'Yes',
        );
        $exit_reasons = array(
            'MATERNAL DEATH' => 'MATERNAL DEATH',
            'INFANT DEATH' => 'INFANT DEATH',
            'MISCARRIAGE' => 'MISCARRIAGE',
            //'STILL BIRTH'=>'STILL BIRTH',
            'MIGRATION' => 'MIGRATION'
        );
        $is_pvtg = array(
            'N' => 'No',
            'Y' => 'Yes'
        );
        $in_scheme = array(
            '0' => 'No',
            '1' => 'Yes',
        );
        $this->set(compact('in_scheme', 'is_pvtg', 'districtList', 'projectList', 'husband_govt', 'is_suspect', 'exit_reasons'));
    }
    public function suspect_report_ajax(){
        $this->layout = 'ajax';
        $user = $this->Session->read('user_auth');
        $condition      = array('Beneficiary.is_suspect' => 1);
        $name           = '';
        $rch_mcts_no    = '';
        $account_no     = '';
        $district_id    = '';
        $project_id     = '';
        $sector_id      = '';
        $gp_id          = '';
        $awc_id         = '';
        $from_date      = '';
        $to_date        = '';    
        $is_suspect     = '';  
        $is_pvtg        = ''; 
        $in_scheme      = '';
        /*
        if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
        $sql = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
            $condition += array(0 => "Beneficiary.user_id in(select id from users where project_id=)");
        }  
        */
        if(isset($this->params['named']['name']) && $this->params['named']['name'] != ''){
            $name = $this->params['named']['name'];
            $condition += array(1 => "Beneficiary.name LIKE '%$name%'");
        }
        if(isset($this->params['named']['rch_mcts_no']) && $this->params['named']['rch_mcts_no'] != ''){
            $rch_mcts_no = $this->params['named']['rch_mcts_no'];
            $condition += array('Beneficiary.rch_mcts_no'   => $rch_mcts_no);
        }
        if(isset($this->params['named']['account_no']) && $this->params['named']['account_no'] != ''){
            $account_no = $this->params['named']['account_no'];
            $condition += array('Beneficiary.account_no'   => $account_no);
        }
        if(isset($this->params['named']['district_id']) && $this->params['named']['district_id'] != ''){
            $district_id = $this->params['named']['district_id'];
            $condition += array(2 => "Beneficiary.user_id IN(select id from users where district_id=$district_id)");
        }
        if(isset($this->params['named']['project_id']) && $this->params['named']['project_id'] != ''){
            $project_id = $this->params['named']['project_id'];
            $condition += array(3 => "Beneficiary.user_id in(select id from users where project_id=$project_id)");
        } 
        if(isset($this->params['named']['sector_id']) && $this->params['named']['sector_id'] != ''){
            $sector_id = $this->params['named']['sector_id'];
            $condition += array('Beneficiary.sector_id'     => $sector_id);
        }
        if(isset($this->params['named']['gp_id']) && $this->params['named']['gp_id'] != ''){
            $gp_id = $this->params['named']['gp_id'];
            $condition += array('Beneficiary.gp_id'     => $gp_id);
        }
        if(isset($this->params['named']['gp_id']) && $this->params['named']['gp_id'] != ''){
            $gp_id = $this->params['named']['gp_id'];
            $condition += array('Beneficiary.gp_id'     => $gp_id);
        }
        if(isset($this->params['named']['awc_id']) && $this->params['named']['awc_id'] != ''){
            $awc_id = $this->params['named']['awc_id'];
            $condition += array('Beneficiary.awc_id'     => $awc_id);
        }
        if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
            $from_date = $this->params['named']['from_date'];
            $condition += array('Beneficiary.reg_date >='     => date('Y-m-d', strtotime($from_date)));
        }
        if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
            $to_date = $this->params['named']['to_date'];
            $condition += array('Beneficiary.reg_date <='     => date('Y-m-d', strtotime($to_date)));
        }
        if(isset($this->params['named']['husband_govt']) && $this->params['named']['husband_govt'] != ''){
            $husband_govt = $this->params['named']['husband_govt'];
            $condition += array('Beneficiary.husband_govt'     => $husband_govt);
        }
        if(isset($this->params['named']['is_suspect']) && $this->params['named']['is_suspect'] != '' && $this->params['named']['is_suspect'] != 2){
            $is_suspect = $this->params['named']['is_suspect'];
            $condition += array('Beneficiary.is_suspect'     => $is_suspect);
        }
        if(isset($this->params['named']['is_pvtg']) && $this->params['named']['is_pvtg'] != ''){
            $is_pvtg = $this->params['named']['is_pvtg'];
            $condition += array('Beneficiary.is_pvtg'     => $is_pvtg);
        } 
        if(isset($this->params['named']['in_scheme']) && ((int)$this->params['named']['in_scheme'] == 1 || $this->params['named']['in_scheme'] == '')){
            $in_scheme = $this->params['named']['in_scheme'];
            $condition += array(
                'Beneficiary.husband_govt'      => 'No',
                'Beneficiary.age >='            => 19
            );
        }
        if(isset($this->params['named']['in_scheme']) && (int)$this->params['named']['in_scheme'] == 0){
            $in_scheme = $this->params['named']['in_scheme'];
            $condition += array(
                'Beneficiary.husband_govt'     => 'Yes',
                'Beneficiary.age <'            => 19
            );
        } 
                                                                                                                     
        if(isset($this->params['named']['reqType']) && $this->params['named']['reqType'] != ''){
            $this->layout='export_xls';
            if($this->params['named']['reqType']=='XLS'){
                $this->set('file_type','xls');
                $this->set('file_name','suspect_report_'.date('d-m-Y').'.xls');
            }else if($this->params['named']['reqType']=='DOC'){
                $this->set('file_type','doc');
                $this->set('file_name','suspect_report_'.date('d-m-Y').'.doc');
            }
            $this->set('is_excel','Y');         
            $limit = array('limit' => 2000,'maxLimit'   => 2000);
        }else{
            $limit = array('limit'  => 10);
        }
        $this->paginate = array(
            'conditions' => $condition,
            'order' => array(
                'Beneficiary.id' => 'DESC'
            )
        )+$limit;
        $this->set(array(
            'datas'         => $this->paginate('Beneficiary'),
            'name'          => $name,
            'rch_mcts_no'   => $rch_mcts_no,
            'account_no'    => $account_no,
            'district_id'   => $district_id,
            'project_id'    => $project_id,
            'sector_id'     => $sector_id,
            'gp_id'         => $gp_id,
            'awc_id'        => $awc_id,
            'from_date'     => $from_date,
            'to_date'       => $to_date,    
            'is_suspect'    => $is_suspect,  
            'is_pvtg'       => $is_pvtg, 
            'in_scheme'     => $in_scheme,            
        ));
    }
    public function loadprojects(){
        $this->autoRender = false;
        $this->loadModel('Project');
        if(isset($this->data['district_id']) && (int)$this->data['district_id'] != 0){
            $data = $this->Project->find('list', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Project.district_id'   => $this->data['district_id'],
                ),
                'fields'        => array(
                    'Project.id',
                    'Project.name',
                ),
                'order'         => array(
                    'Project.name',
                ),
            ));
            if(is_array($data) && count($data)>0){
                echo '<option value="">-- Select Project Location --</option>';
                foreach($data as $key=>$val){
                    echo '<option value="'.$key.'">'.$val.'</option>';
                }
            }else{
                echo '<option value="">-- Select Project Location --</option>';
            }
        }else{
            echo '<option value="">-- Select Project Location --</option>';
        }
    }
    public function loadsectors(){
        $this->autoRender = false;
        $this->loadModel('Sector');
        if(isset($this->data['project_id']) && (int)$this->data['project_id'] != 0){
            $data = $this->Sector->find('list', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Sector.project_id'   => $this->data['project_id'],
                ),
                'fields'        => array(
                    'Sector.id',
                    'Sector.name',
                ),
                'order'         => array(
                    'Sector.name',
                ),
            ));
            if(is_array($data) && count($data)>0){
                echo '<option value="">-- Select Sector --</option>';
                foreach($data as $key=>$val){
                    echo '<option value="'.$key.'">'.$val.'</option>';
                }
            }else{
                echo '<option value="">-- Select Sector --</option>';
            }
        }else{
            echo '<option value="">-- Select Sector --</option>';
        }        
    }
    public function loadgp(){
        $this->autoRender = false;
        $this->loadModel('Gp');
        if(isset($this->data['project_id']) && (int)$this->data['project_id'] != 0){
            $data = $this->Gp->find('list', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Gp.project_id'   => $this->data['project_id'],
                ),
                'fields'        => array(
                    'Gp.id',
                    'Gp.name',
                ),
                'order'         => array(
                    'Gp.name',
                ),
            ));
            if(is_array($data) && count($data)>0){
                echo '<option value="">-- Select GP --</option>';
                foreach($data as $key=>$val){
                    echo '<option value="'.$key.'">'.$val.'</option>';
                }
            }else{
                echo '<option value="">-- Select GP --</option>';
            }
        }else{
            echo '<option value="">-- Select GP --</option>';
        }         
    }
    public function getawcs(){
        $this->autoRender = false;
        $this->loadModel('Awc');
        if(isset($this->data['sector_id']) && (int)$this->data['sector_id'] != 0){
            $data = $this->Awc->find('list', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Awc.sector_id'   => $this->data['sector_id'],
                ),
                'fields'        => array(
                    'Awc.id',
                    'Awc.name',
                ),
                'order'         => array(
                    'Awc.name',
                ),
            ));
            if(is_array($data) && count($data)>0){
                echo '<option value="">-- Select AWC --</option>';
                foreach($data as $key=>$val){
                    echo '<option value="'.$key.'">'.$val.'</option>';
                }
            }else{
                echo '<option value="">-- Select AWC --</option>';
            }
        }else{
            echo '<option value="">-- Select AWC --</option>';
        }         
    }
  // ////////////////////////////////

  public

  function loadawcs_search($id)
  {
    $this->layout = NULL;
    $this->loadModel('Awc');
    $awc_id = $this->Awc->find('list', array(
      'conditions' => array(
        'Awc.sector_id' => $id
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $this->set(compact('awc_id'));
  }

  ////////////////////////////////////////
  public function filterd($id){
    $this->layout=NULL;
    $this->loadModel('Pregnency');
    $this->loadModel('Verify');

    $this->Pregnency->recursive=-1;
    $preg_id=$this->Pregnency->find('first',array(
      'conditions'=>array(
        'Pregnency.beneficiary_id'=>$id
      ),
      'order'=>array(
        'Pregnency.id'=>'DESC'
      )
    ));
    $preg_id=$preg_id['Pregnency']['id'];

$this->Verify->recursive=-1;
$cnt=$this->Verify->find('count',array(
  'conditions'=>array(
    'Verify.pregnency_id'=>$preg_id,
    'Verify.beneficiary_id'=>$id
  ),
));

echo $cnt;
    exit();
  }
}

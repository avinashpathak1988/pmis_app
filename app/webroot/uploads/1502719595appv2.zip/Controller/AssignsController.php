<?php
App::uses('AppControler','Controller');

class AssignsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
    $designation_id=$this->Assign->Designation->find('list',array(
      'order'=>array(
        'Designation.name'
      )
    ));
    $this->Assign->Menu->recursive=-1;
    $menu_id=$this->Assign->Menu->find('list',array(
      'conditions'=>array(
        'Menu.is_enable'=>1
      ),
      'order'=>array(
        'Menu.morder'
      )
    ));
    $this->set(compact('designation_id','menu_id'));
}

public function loadsubmenus($id,$designation_id){
	$this->layout=NULL;
  $submenu_id=$this->Assign->Submenu->find('all',array(
    'conditions'=>array(
      'Submenu.menu_id'=>$id,
      'Submenu.is_enable'=>1
    ),
    'order'=>array(
      'Submenu.morder'
    )
  ));
  $this->set(compact('submenu_id','designation_id'));
}

public function assign($designation_id,$submenu_id){
	$this->layout=NULL;
	$this->loadModel('Menu');
	$this->loadModel('Submenu');
$this->Assign->query("delete from assigns where designation_id='".$designation_id."' and submenu_id='".$submenu_id."'");
$menu_id=$this->Menu->find('first',array(
	'conditions'=>array(
		"Menu.id in(select menu_id from submenus where id='".$submenu_id."')"
	)
));
$menu_id=$menu_id['Menu']['id'];
		$this->Assign->create();
		$this->request->data['Assign']['designation_id']=$designation_id;
		$this->request->data['Assign']['submenu_id']=$submenu_id;
		$this->request->data['Assign']['menu_id']=$menu_id;
		$this->Assign->save($this->request->data);
	exit();
}

public function removemenu($designation_id,$submenu_id){
	$this->layout=NULL;
	$this->loadModel('Menu');
	$this->loadModel('Submenu');
$this->Assign->query("delete from assigns where designation_id='".$designation_id."' and submenu_id='".$submenu_id."'");
	exit();
}

}

<?php
App::uses('AppControler','Controller');

class SectorsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
  $user = $this->Session->read('user_auth');
  $condition = array();
    if ($user['Designation']['name'] == 'DPC') {
      $condition += array("Sector.district_id" => $user['District']['id']);
    }
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
      $condition += array("Sector.district_id" => $user['District']['id'], "Sector.project_id" => $user['Project']['id']);
    }
  $datas=$this->Sector->find('all', array(
    'conditions' =>  $condition
  ));
  $this->set(compact('datas'));
}


public function add(){
  $this->LoadModel('Project');
  $this->LoadModel('Blocks');
  $this->LoadModel('Gps');

  if($this->request->is(array('post','put'))){
      if($this->Sector->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $block_id='';
  $gp_id='';
  $project_id='';

  $user = $this->Session->read('user_auth');
  $d_condition = array();
    if ($user['Designation']['name'] == 'DPC') {
      $d_condition += array("District.id" => $user['District']['id']);
      $project_id = $this->Project->find('list', array(
        'conditions' => array(
          'district_id' => $user['District']['id']
        ) ,
        'order' => array(
          'Project.name'
        )
      ));
      $block_id = $this->Blocks->find('list', array(
        'conditions' => array(
          'district_id' => $user['District']['id']
        ) ,
        'order' => array(
          'Blocks.name'
        )
      ));
      $gp_id = $this->Gps->find('list', array(
        'conditions' => array(
          'district_id' => $user['District']['id']
        ) ,
        'order' => array(
          'Gps.name'
        )
      ));
      $this->request->data['Sector']['district_id'] = $user['District']['id'];

    }

  $district_id=$this->Sector->District->find('list',array(
    'conditions' => $d_condition,
    'order'=>array(
      'District.name'
    ),
  ));
  
  $this->set(compact('district_id','block_id','gp_id','project_id'));

}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Sector->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }

  $district_id=$this->Sector->District->find('list',array(
    'order'=>array(
      'District.name'
    ),
  ));

  $this->request->data=$this->Sector->findById($id);
  $block_id='';
  $block_id=$this->Sector->Block->find('list',array(
    'conditions'=>array(
      'Block.district_id'=>$this->request->data['Sector']['district_id'],
    ),
    'order'=>array(
      'Block.name'
    ),
  ));
  $gp_id='';
  $project_id='';
  $gp_id=$this->Sector->Gp->find('list',array(
    'conditions'=>array(
      'Gp.block_id'=>$this->request->data['Sector']['block_id'],
    ),
    'order'=>array(
      'Gp.name'
    ),
  ));
  $project_id=$this->Sector->Project->find('list',array(
    'conditions'=>array(
      'Project.district_id'=>$this->request->data['Sector']['district_id'],
    ),
    'order'=>array(
      'Project.name'
    ),
  ));
  $this->set(compact('district_id','block_id','gp_id','project_id'));
}

public function delete($id){
  $this->Sector->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

public function loadblocks($id){
  $this->layout=NULL;
  $block_id=$this->Sector->Block->find('list',array(
    'conditions'=>array(
      'Block.district_id'=>$id,
    ),
      'order'=>array(
        'Block.name'
      ),
    ));
    $this->set(compact('block_id'));
}

public function loadgps($id){
  $this->layout=NULL;
  $gp_id=$this->Sector->Gp->find('list',array(
    'conditions'=>array(
      'Gp.block_id'=>$id,
    ),
      'order'=>array(
        'Gp.name'
      ),
    ));
    $this->set(compact('gp_id'));
}

public function loadprojects($id){
  $this->layout=NULL;
  $project_id=$this->Sector->Project->find('list',array(
    'conditions'=>array(
      'Project.district_id'=>$id,
    ),
      'order'=>array(
        'Project.name'
      ),
    ));
    $this->set(compact('project_id'));
}

}

<?php
App::uses('AppControler','Controller');

class SuspectmastersController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function configuration(){
  if($this->request->is(array('post','put'))){
    if((integer)$this->request->data['Suspectmaster']['score'] <= 0 || (integer)$this->request->data['Suspectmaster']['score'] > 100){
      $this->message("error","Please provide valid score !");
    }else{
      if($this->Suspectmaster->save($this->request->data)){
        $this->message("success","Suspect Rule Saved Successfully !");
        $this->redirect(array('action'=>'configuration'));
      }else{
        $this->message("error","Saving Failed !");
      }
    }
  }
    $field_name=array(
      'rch_mcts_no'=>'RCH/MCTS No.',
      'name'=>'Name',
      'husband'=>'Husband/Father Name',
      'village'=>'Village',
      'address'=>'Address',
      'awc_id'=>'AWC',
      'caste'=>'Caste',
      'dob'=>'Date Of Birth',
      'age'=>'Age',
      'mobile_no'=>'Mobile No.',
      'account_no'=>'Bank Account No.',
      'mail_id'=>'E-Mail ID',
      'aadhaar'=>'AADHAR Card No.',
    );
    $datas=$this->Suspectmaster->find('all');
    $this->set(compact('field_name','datas'));
}

public function delete($id){
  $this->Suspectmaster->delete($id);
  $this->message("success","Deleted Successfully !");
  $this->redirect(array('action'=>'configuration'));
}

}

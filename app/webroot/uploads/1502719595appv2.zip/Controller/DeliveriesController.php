<?php
App::uses('AppControler', 'Controller');
class DeliveriesController extends AppController

{
    public $components = array(

        'Paginator',
        'Flash',
        'Session'
    );
    public

    function beforeFilter()
    {
        $this->response->disableCache();
        if ($this->Session->read('user_auth') == '') {
            $this->redirect(array(
                'controller' => 'dashboard',
                'action' => 'login'
            ));
        }
    }
    public function addDayswithdate($date,$days){
        $date = strtotime("+".$days." days", strtotime($date));
        return  date("d/m/Y", $date);
    }
    
    public function getlmpdate($rchmcts='')
    {
      $this->autoRender = false;
      $this->loadModel('Beneficiary');
      $this->loadModel('Pregnency');
      $pregdata = $this->Pregnency->find('first',array(
        'recursive' => 2,
        'conditions'=>array(
          'Beneficiary.rch_mcts_no'=>$rchmcts
        ),
        'fields' => array(
          'Pregnency.lmp_date'
        )
      ));
      if(isset($pregdata['Pregnency']['lmp_date']) && $pregdata['Pregnency']['lmp_date'] !=''){
          $lmpDate = $this->addDayswithdate($pregdata['Pregnency']['lmp_date'], '0');
          $lmpPlusSixMonth = $this->addDayswithdate($pregdata['Pregnency']['lmp_date'], '180');
          $lmpPlusTenMonth = $this->addDayswithdate($pregdata['Pregnency']['lmp_date'], '310');
          return $lmpPlusSixMonth."###".$lmpPlusTenMonth."###".$lmpDate;
      }else{
        return '00/00/0000'."###".'00/00/0000';
      }

    }
    public function add($id='')
    {

    	$this->loadModel('Beneficiary');
$this->loadModel('Pinstallment');
$this->Pinstallment->recursive=2;
    	if(isset($id) && $id !=''){
    		$rch_mcts_no = $this->getUniqueno($id);
    		$id = base64_decode($id);
	    	$datas = $this->Pinstallment->find('first', array(
                'conditions' => array(
                    "Pinstallment.pregnency_id"=>$id
                ) ,
	         ));
        	$this->set('datas', $datas);
	    }else{
	    	$this->set('datas', array());
	    }

        if ($this->request->is(array('post','put'))) {
            $error = 0;
            $error_message = "";
            $beneficiary_id = "";
            $pregnency_id = "";
            $ben_exist = $this->Delivery->Beneficiary->find('count', array(
                'conditions' => array(
                    'rch_mcts_no' => $this->request->data['Delivery']['rch_mcts_no']
                )
            ));

            if ($ben_exist > 0) {
                $ben = $this->Delivery->Beneficiary->find('first', array(
                    'conditions' => array(
                        'rch_mcts_no' => $this->request->data['Delivery']['rch_mcts_no']
                    )
                ));
                $beneficiary_id = $ben['Beneficiary']['id'];
            }
            else {
                $error = 1;
                $error_message = "Invalid RCH/MCTS No. !";
            }

            $pregnency_id = "";
            $preg_no="";
            if ($beneficiary_id != '') {
                $preg = $this->Delivery->Pregnency->find('first', array(
                    'conditions' => array(
                        'Pregnency.beneficiary_id' => $beneficiary_id,
                    ) ,
                    'order' => array(
                        'Pregnency.id' => 'DESC'
                    ) ,
                ));
                $pregnency_id = $preg['Pregnency']['id'];
                $preg_no=$preg['Pregnency']['preg_no'];
            }

            if ($pregnency_id == "") {
                $error = 1;
                $error_message = "No Pregnency registration found !";
            }

            if ($this->request->data['Delivery']['outcome'] == "") {
                $error = 1;
                $error_message = "Please select outcome of delivery !";
            }

            if ($this->request->data['Delivery']['outcome'] != "Twin Live Birth") {
                $this->request->data['Delivery']['child2_gender'] = null;
                $this->request->data['Delivery']['child2_weight'] = null;
                $this->request->data['Delivery']['child2_live_birth'] = null;
            }
$sec_install="";
            if ($error == 0 && $error_message == "") {
                $dod = $this->request->data['Delivery']['dod'];
                $dod = explode("/", $dod);
                $dod1 = $dod;
                $dod = $dod[2] . '-' . $dod[1] . '-' . $dod[0];
                $this->request->data['Delivery']['dod'] = $dod;
                $this->request->data['Delivery']['brd'] = $dod;
                $this->request->data['Delivery']['beneficiary_id'] = $beneficiary_id;
                $this->request->data['Delivery']['pregnency_id'] = $pregnency_id;
                $this->Delivery->query("delete from deliveries where beneficiary_id='" . $beneficiary_id . "' and pregnency_id='" . $pregnency_id . "'");
                $sec_install = mktime(0, 0, 0, $dod1[1] + 10, $dod1[0], $dod1[2]);
                $sec_install = date('Y-m-d', $sec_install);
                if ($this->request->data['Delivery']['outcome'] == "Infant Death") {
                    $this->request->data['Delivery']['child1_live_birth']="Yes";
                    $this->Delivery->query("insert into exits values(null,'" . $beneficiary_id . "',1,curdate(),'AUTO EXIT','STILL BIRTH',now(),now())");
                    $this->Delivery->query("update pregnencies set is_exit=1,exit_reason='Infant Death',exit_date=curdate() where beneficiary_id='" . $beneficiary_id . "' and id='".$pregnency_id."'");
                }

                if ($this->request->data['Delivery']['outcome'] == "Still Birth") {
                    $this->request->data['Delivery']['child1_live_birth']="No";
                    $this->Delivery->query("insert into exits values(null,'" . $beneficiary_id . "',1,curdate(),'AUTO EXIT','STILL BIRTH',now(),now())");
                    $this->Delivery->query("update pregnencies set is_exit=1,exit_reason='Still Birth',exit_date=curdate() where beneficiary_id='" . $beneficiary_id . "' and id='".$pregnency_id."'");
                }
if ($this->request->data['Delivery']['outcome'] != "Infant Death" && $this->request->data['Delivery']['outcome'] != "Still Birth") {
                  $this->Delivery->query("update pregnencies set second_install_date='" . $sec_install . "' where beneficiary_id='" . $beneficiary_id . "' and id='" . $pregnency_id . "'");
                }
//Saving in pinstallment//
$this->loadModel('Pinstallment');
$this->Pinstallment->query("delete from pinstallments where beneficiary_id='".$beneficiary_id."' and pregnency_id='".$pregnency_id."' and preg_no='".$preg_no."' and installment_no=2");
$this->request->data['Pinstallment']['beneficiary_id']=$beneficiary_id;
$this->request->data['Pinstallment']['pregnency_id']=$pregnency_id;
$this->request->data['Pinstallment']['preg_no']=$preg_no;
$this->request->data['Pinstallment']['installment_no']=2;
$this->request->data['Pinstallment']['installment_date']=$sec_install;
$this->Pinstallment->save($this->request->data);
//End of Saving in pinstallment//
                if ($this->Delivery->save($this->request->data)) {
                    $this->message('Success', 'Saved Successfully !');
                    $this->redirect(array(
                        'controller' => 'deliveries',
                        'action' => 'index'
                    ));
                }
                else {
                    $dod = $this->request->data['Delivery']['dod'];
                    $dod = explode("-", $dod);
                    $dod = $dod[0] . '/' . $dod[1] . '/' . $dod[2];
                    $this->request->data['Delivery']['dod'] = $dod;
                    $this->message('error', 'Saving Failed !');
                }
            }
            else {
                $dod = $this->request->data['Delivery']['dod'];
                $this->request->data['Delivery']['dod'] = $dod;
                $this->message('error', $error_message);
            }


        }

        // iF Post Delivery Data Exists :: Tanmaya
        $checkPostDelivery = $this->Delivery->findByPregnencyId($id);
        if(isset($checkPostDelivery['Delivery']) && $checkPostDelivery['Delivery'] != ''){
	        $this->request->data['Delivery'] = $checkPostDelivery['Delivery'];
	        $this->request->data['Delivery']['dod'] = $this->DB2date($checkPostDelivery['Delivery']['dod']);
	    }
	    //End of //iF Post Delivery Data Exists

        $outcome = array(
            'Still Birth' => 'Still Birth',
            'Single Live Birth' => 'Single Live Birth',
            'Twin Live Birth' => 'Twin Live Birth',
            'Infant Death' => 'Infant Death',
        );
        $user=$this->Session->read('user_auth');
        if($user['Designation']['name'] == 'PA'){
          $outcome = array(
              //'Still Birth' => 'Still Birth',
              'Single Live Birth' => 'Single Live Birth',
              'Twin Live Birth' => 'Twin Live Birth',
              //'Infant Death' => 'Infant Death',
          );
        }
        if($user['Designation']['name'] == 'CDPO'){
          $outcome = array(
              'Still Birth' => 'Still Birth',
              'Single Live Birth' => 'Single Live Birth',
              'Twin Live Birth' => 'Twin Live Birth',
              'Infant Death' => 'Infant Death',
          );
        }
        $gender = array(
            'Male' => 'Male',
            'Female' => 'Female'
        );
        $live_birth = array(
            'Yes' => 'Yes',
            'No' => 'No'
        );
        $this->set(compact('outcome', 'gender', 'live_birth', 'rch_mcts_no'));
    }

    public	function index()
	{
		//$this->loadModel('Pregnency');
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$sql_name = "";
			$sql_rch_mcts_no = "";
			$sql_account_no = "";
			$sql_awc_id = "";
			if ($this->request->data['Beneficiary']['name'] != '') {
				$sql_name = "Beneficiary.name like '%" . $this->request->data['Beneficiary']['name'] . "%'";
			}

			if ($this->request->data['Beneficiary']['rch_mcts_no'] != '') {
				$sql_rch_mcts_no = "Beneficiary.rch_mcts_no like '%" . $this->request->data['Beneficiary']['rch_mcts_no'] . "%'";
			}

			if ($this->request->data['Beneficiary']['account_no'] != '') {
				$sql_account_no = "Beneficiary.account_no like '%" . $this->request->data['Beneficiary']['account_no'] . "%'";
			}

			if ($this->request->data['Beneficiary']['awc_id'] != '') {
				$sql_awc_id = "Beneficiary.awc_id = '" . $this->request->data['Beneficiary']['awc_id'] . "'";
			}
$sql="";
$user=$this->Session->read('user_auth');
if($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO'){
  $sql="Beneficiary.user_id in(select id from users where project_id='".$user['Project']['id']."')";
}

$sql_awc_id='';

if($this->request->data['Beneficiary']['awc_id'] != ''){
  $sql_awc_id="Beneficiary.awc_id='".$this->request->data['Beneficiary']['awc_id']."'";
}
			$datas = $this->Delivery->find('all', array(
				'conditions' => array(
              $sql,
              $sql_awc_id,
				) ,
				'order' => array(
					'Delivery.id'=>'DESC'
				),
        //'limit'=>2
			));

			$this->set(compact('datas'));
		}
		$user_sess = $this->Session->read('user_auth');
		$project_id = $user_sess['Project']['id'];
		$this->loadModel('Awc');
		$awc_id = $this->Awc->find('list', array(
			'conditions' => array(
				//'Awc.id in(select awc_id from beneficiaries)'
				'project_id' => $project_id
			) ,
			'order' => array(
				'Awc.name'
			),
			//'limit' => 100
		));
		$this->set(compact('awc_id'));
	}

///////////////////////////////////////////
public function loadbendetails($rch_mcts_no){
  $this->layout=NULL;
  $this->loadModel('Pinstallment');
  $this->loadModel('Beneficiary');
  $user=$this->Session->read('user_auth');

  $same_location=$this->Beneficiary->find('count',array(
    'conditions'=>array(
      'Beneficiary.rch_mcts_no'=>$rch_mcts_no,
      "Beneficiary.user_id in(select id from users where project_id='".$user['Project']['id']."')"
    )
  ));
  if($same_location <= 0){
    echo "<strong><font color=red>Beneficiary is not from your Project Location</font></strong>";
    exit();
  }


  $this->Pinstallment->recursive=2;
  $ben=$this->Pinstallment->find('count',array(
    'conditions'=>array(
      'Beneficiary.rch_mcts_no'=>$rch_mcts_no,
      'Pinstallment.installment_no'=>1,
      'Pinstallment.is_paid'=>1
    ),
    'order'=>array(
      'Pinstallment.pregnency_id'=>'DESC'
    )
  ));
  if($ben == 0){
    echo "<strong><font color=red>1st Installment Payment not received yet</font></strong>";
    exit();
  }else{
    $this->Pinstallment->recursive=2;
    $ben=$this->Pinstallment->find('first',array(
      'conditions'=>array(
        'Beneficiary.rch_mcts_no'=>$rch_mcts_no,
        'Pinstallment.installment_no'=>1,
          'Pinstallment.is_paid'=>1
      ),
      'order'=>array(
        'Pinstallment.pregnency_id'=>'DESC'
      )
    ));
  $this->set(compact('ben'));
}
}

public function fetchdeliverydetails($rch_mcts){
  $this->layout=NULL;
    $this->loadModel('Beneficiary');
    $this->loadModel('Pregnency');
    $b=$this->Beneficiary->find('first',array(
      'conditions'=>array(
        'Beneficiary.rch_mcts_no'=>$rch_mcts
      )
    ));
    $ben_id=$b['Beneficiary']['id'];

    $preg_id=$this->Pregnency->find('first',array(
      'conditions'=>array(
        'Beneficiary.id'=>$ben_id
      ),
      'order'=>array(
        'Pregnency.id'=>'DESC'
      )
    ));
    $preg_id=$preg_id['Pregnency']['id'];
    $data=$this->Delivery->find('first',array(
      'conditions'=>array(
        'Delivery.beneficiary_id'=>$ben_id,
        'Delivery.pregnency_id'=>$preg_id
      )
    ));
  //  echo "<pre>";
  if(isset($data['Pregnency']['id']) && $data['Pregnency']['id'] != ''){
    echo   base64_encode($data['Pregnency']['id']);
  }else{
    echo "";
  }
    exit();
}

}

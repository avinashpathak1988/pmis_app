<?php
App::uses('AppControler','Controller');

class GpsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
  $datas=$this->Gp->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
      if($this->Gp->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }

  $district_id=$this->Gp->District->find('list',array(
    'order'=>array(
      'District.name'
    ),
  ));
  $block_id='';
//  $block_id=$this->Gp->Block->find('list',array(
  //  'order'=>array(
//      'Block.name'
//    ),
//  ));
$project_id=$this->Gp->Project->find('list',array(
	'order'=>array(
		'Project.name'
	)
));
  $this->set(compact('district_id','block_id','project_id'));

}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Gp->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }

  $district_id=$this->Gp->District->find('list',array(
    'order'=>array(
      'District.name'
    ),
  ));

  $this->request->data=$this->Gp->findById($id);
  $block_id='';
  $block_id=$this->Gp->Block->find('list',array(
    'conditions'=>array(
      'Block.district_id'=>$this->request->data['Gp']['district_id'],
    ),
    'order'=>array(
      'Block.name'
    ),
  ));
	$project_id=$this->Gp->Project->find('list',array(
		'order'=>array(
			'Project.name'
		)
	));
	  $this->set(compact('district_id','block_id','project_id'));
}

public function delete($id){
  $this->Gp->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

public function loadblocks($id){
  $this->layout=NULL;
  $block_id=$this->Gp->Block->find('list',array(
    'conditions'=>array(
      'Block.district_id'=>$id,
    ),
      'order'=>array(
        'Block.name'
      ),
    ));
    $this->set(compact('block_id'));
}

}

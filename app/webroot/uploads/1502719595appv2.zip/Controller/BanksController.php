<?php
App::uses('AppControler','Controller');

class BanksController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
  $datas=$this->Bank->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
      if($this->Bank->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $reg_file_format=array(
    'NSBI'=>'NSBI',
    'SBI'=>'SBI'
  );
  $tran_file_format=array(
    'ICICI'=>'ICICI',
    'NICICI'=>'NICICI',
    'NO TRANS FILE GEN'=>'NO TRANS FILE GEN',
    'SBI'=>'SBI'
  );
  $is_group=array(
    '0'=>'No',
    '1'=>'Yes'
  );
  $this->set(compact('reg_file_format','tran_file_format','is_group'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Bank->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $reg_file_format=array(
    'NSBI'=>'NSBI',
    'SBI'=>'SBI'
  );
  $tran_file_format=array(
    'ICICI'=>'ICICI',
    'NICICI'=>'NICICI',
    'NO TRANS FILE GEN'=>'NO TRANS FILE GEN',
    'SBI'=>'SBI'
  );
  $is_group=array(
    '0'=>'No',
    '1'=>'Yes'
  );
  $this->set(compact('reg_file_format','tran_file_format','is_group'));
  $this->request->data=$this->Bank->findById($id);
}

public function delete($id){
  $this->Bank->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

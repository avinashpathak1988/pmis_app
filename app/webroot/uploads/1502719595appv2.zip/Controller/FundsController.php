<?php
App::uses('AppController', 'Controller');

class FundsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

	public function beforeFilter(){
			$this->response->disableCache();
			if($this->Session->read('user_auth') == ''){
				$this->redirect(array(
					'controller'=>'dashboard',
					'action'=>'login'
				));
			}
		}

	public function index(){
			$this->response->disableCache();
			if($this->Session->read('user_auth') == ''){
				$this->redirect(array(
					'controller'=>'dashboard',
					'action'=>'login'
				));
			}

      $datas=$this->Fund->find('all',array(
        'order'=>array(
          'tran_date'
        )
      ));
      $this->set(compact('datas'));
    }

public function add(){
  $user=$this->Session->read('user_auth');
  if($this->request->is(array('post','put'))){
    $tran_date=$this->request->data['Fund']['tran_date'];
    if($tran_date != ''){
      $tran_date=explode("/",$tran_date);
      $tran_date=$tran_date[2].'-'.$tran_date[1].'-'.$tran_date[0];
      $this->request->data['Fund']['tran_date']=$tran_date;
    }
    $this->request->data['Fund']['user_id']=$user['User']['id'];
    if($this->Fund->save($this->request->data)){
      $this->message('success','Saved Successfully !');
      $this->redirect(array('action'=>'index'));
    }else{
      $this->message('error','Saving Failed !');
    }
  }
  $bank=array(
    'SBI'=>'SBI',
    'ICICI'=>'ICICI'
  );
  $scheme=array(
    'MAMATA'=>'MAMATA',
    'IGMSY'=>'IGMSY'
  );
  $this->set(compact('bank','scheme'));
}
//////////////////////
public function history(){
  $this->loadModel('Beneficiary');
  $this->loadModel('Worker');
  $this->loadModel('Incentive');
  $this->loadModel('Payment');
  $this->loadModel('Pinstallment');
  $this->loadModel('Beneficiary');
  $this->loadModel('District');
  $this->loadModel('Project');
  $this->loadModel('Log');
	$this->loadModel('Bank');
	$this->loadModel('Branch');

if($this->request->is(array('post','put'))){
	$bank1=$this->request->data['Fund']['bank'];
	$scheme1=$this->request->data['Fund']['scheme'];

  $from_date="2016-02-10";
  $to_date=date("Y-m-d");
	if($this->request->data['Fund']['from_date'] != '' && $this->request->data['Fund']['to_date'] != ''){
		$from_date=$this->request->data['Fund']['from_date'];
		$from_date=explode("/",$from_date);
		$from_date=$from_date[2].'-'.$from_date[1].'-'.$from_date[0];

		$to_date=$this->request->data['Fund']['to_date'];
		$to_date=explode("/",$to_date);
		$to_date=$to_date[2].'-'.$to_date[1].'-'.$to_date[0];
	}
  $this->Log->query("truncate table logs");

//Fetch From Beneficiary//////
$this->Pinstallment->recursive=2;
$datas=$this->Pinstallment->find('all',array(
  'conditions'=>array(
    'Pinstallment.is_paid'=>1,
    'Pinstallment.is_payment_approve'=>1
  )
));
foreach($datas as $data){
$this->Log->create();
$this->request->data['Log']['bank']=$data['Beneficiary']['Bank']['reg_file_format'];
if($this->request->data['Log']['bank'] == 'NSBI'){
  $this->request->data['Log']['bank']='ICICI';
}
$dist_id="";
$dist_id=$this->District->find('first',array(
  'conditions'=>array(
    "District.id in(select district_id from users where id in(select user_id from beneficiaries where id='".$data['Beneficiary']['id']."'))"
  )
));
$district_id="";
$project_id="";
$district_id=$dist_id['District']['id'];
$project_id=$this->Project->find('first',array(
  'conditions'=>array(
    "Project.id in(select project_id from users where id in(select user_id from beneficiaries where id='".$data['Beneficiary']['id']."'))"
  )
));
$this->request->data['Log']['district_id']=$district_id;
$this->request->data['Log']['project_id']=$project_id['Project']['id'];
if($dist_id['District']['id'] == 22 || $dist_id['District']['id']==23){
  $this->request->data['Log']['scheme']='IGMSY';
}else{
  $this->request->data['Log']['scheme']='MAMATA';
}
$this->request->data['Log']['tdate']=$data['Pinstallment']['payment_date'];
if($data['Pinstallment']['installment_no'] == 1){
  $this->request->data['Log']['amount']=3000;
}
if($data['Pinstallment']['installment_no'] == 2){
  $this->request->data['Log']['amount']=2000;
}
$this->request->data['Log']['beneficiary_id']=$data['Pinstallment']['beneficiary_id'];
$this->request->data['Log']['worker_id']=0;
if($this->request->data['Log']['bank'] == $this->request->data['Fund']['bank'] && $this->request->data['Log']['scheme'] == $this->request->data['Fund']['scheme']){
$this->Log->save($this->request->data);
}
}
//Fetch From Worker/////
$datas=$this->Incentive->find('all',array(
	'conditions'=>array(
		'Incentive.is_paid'=>1
	)
));
foreach($datas as $data){
	$this->Log->create();
	$bank="";
	$scheme="";
	$bank=$this->Bank->find('first',array(
		'conditions'=>array(
			"Bank.id"=>$data['Worker']['bank_id']
		)
	));
	$bank=$bank['Bank']['reg_file_format'];
	if($bank == 'NSBI'){
	  $bank='ICICI';
	}
	$this->request->data['Log']['bank']=$bank;
	$this->request->data['Log']['project_id']=$data['Worker']['project_id'];
	$district_id="";
	$district_id=$this->District->find('first',array(
		'conditions'=>array(
			"District.id in(select district_id from projects where id='".$data['Worker']['project_id']."')"
		)
	));
	$district_id=$district_id['District']['id'];
	if($district_id == 22 || $district_id==23){
	  $this->request->data['Log']['scheme']='IGMSY';
	}else{
	  $this->request->data['Log']['scheme']='MAMATA';
	}
	$this->request->data['Log']['district_id']=$district_id;

	 $this->request->data['Log']['tdate']=$data['Incentive']['payment_date'];
	 $amount=0;
	 if($data['Worker']['workertype_id'] == 2){
		 $amount=100;
	 }
	 if($data['Worker']['workertype_id'] == 1){
		 $amount=200;
	 }
	 $this->request->data['Log']['amount']=$amount;
	  $this->request->data['Log']['beneficiary_id']=0;
		$this->request->data['Log']['worker_id']=$data['Worker']['id'];
		if($this->request->data['Log']['scheme'] == $this->request->data['Fund']['scheme'] && $bank == $this->request->data['Fund']['bank']){
		$this->Log->save($this->request->data);
	}
}

$datas="";
//$datas=$this->Log->find("all",array(
//	'order'=>'tdate'
//));

$this->set(compact('datas','from_date','to_date','bank1','scheme1'));
}

  $bank=array(
    'SBI'=>'SBI',
    'ICICI'=>'ICICI'
  );
  $scheme=array(
    'MAMATA'=>'MAMATA',
    'IGMSY'=>'IGMSY'
  );
  $this->set(compact('bank','scheme'));

}
///////////////////////////////
public function historyd($date,$bank,$scheme){
	$this->loadModel('Beneficiary');
	$this->loadModel('Worker');
	$this->loadModel('Incentive');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('Beneficiary');
	$this->loadModel('District');
	$this->loadModel('Project');
	$this->loadModel('Log');
	$this->loadModel('Bank');
	$this->loadModel('Branch');
	$districts=$this->District->find('all',array(
		'order'=>array(
			'District.name'
		)
	));
	$this->set(compact('date','bank','scheme','districts'));
}
///////////////////////////////
public function historyp($date,$bank,$scheme,$district_id){
	$this->loadModel('Beneficiary');
	$this->loadModel('Worker');
	$this->loadModel('Incentive');
	$this->loadModel('Payment');
	$this->loadModel('Pinstallment');
	$this->loadModel('Beneficiary');
	$this->loadModel('District');
	$this->loadModel('Project');
	$this->loadModel('Log');
	$this->loadModel('Bank');
	$this->loadModel('Branch');
	$projects=$this->Project->find('all',array(
		'conditions'=>array(
			'Project.district_id'=>$district_id
		),
		'order'=>array(
			'Project.name'
		)
	));
	$this->set(compact('date','bank','scheme','projects','district_id'));
}
}

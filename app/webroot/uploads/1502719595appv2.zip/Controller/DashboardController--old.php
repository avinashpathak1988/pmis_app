<?php
App::uses('AppController', 'Controller');
class DashboardController extends AppController
{
	public $components = array(
		'Paginator',
		'Flash',
		'Session'
	);
	public $uses = array(
		'User'
	);
	public

	function index()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}

		// //////////////////////////

		$user = $this->Session->read('user_auth');
		$this->loadModel('Beneficiary');
		$this->loadModel('Pregnency');
		$this->loadModel('Payment');
		$this->loadModel('Pinstallment');
		$this->loadModel('Incentive');
		$cond1 = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$cond1 = "Beneficiary.user_id in(select id from users where project_id='" . $user['Project']['id'] . "')";
		}

		$totb_registered = 0;
		$totb_registered = $this->Beneficiary->find('count', array(
			'conditions' => array(
				$cond1,
				"Beneficiary.husband_govt" => 'No',
				'Beneficiary.age >= 19'
			)
		));
		$this->set(compact('totb_registered'));
		$pregnency_registered = 0;
		$pregnency_registered_this_month = 0;
		$pregnency_registered = $this->Pregnency->find('count', array(
			'conditions' => array(
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45",
				$cond1,
			)
		));
		$from_date_global = date('Y') . '-' . date('m') . '-01';
		$to_date_global = date('Y') . '-' . date('m') . '-31';
		$pregnency_registered_this_month = $this->Pregnency->find('count', array(
			'conditions' => array(
				$cond1,
				"Pregnency.preg_reg_date between '" . $from_date_global . "' and '" . $to_date_global . "'",
				'Beneficiary.husband_govt' => 'No',
				"Beneficiary.age >= 19 AND Beneficiary.age <= 45"
			)
		));
		$this->set(compact('pregnency_registered', 'pregnency_registered_this_month'));
		$first_installment_paid = 0;
		$first_installment_paid = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 1,
				'Pinstallment.installment_no' => 1,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('first_installment_paid'));
		$second_installment_paid = 0;
		$second_installment_paid = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 1,
				'Pinstallment.installment_no' => 2,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('second_installment_paid'));
		$tot_trans_failed = 0;
		$tot_trans_failed = $this->Pinstallment->find('count', array(
			'conditions' => array(
				'Pinstallment.is_paid' => 2,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('tot_trans_failed'));
		$total_exits = 0;
		$total_exits = $this->Pregnency->find('count', array(
			'conditions' => array(
				'Beneficiary.husband_govt' => 'No',
				'Pregnency.is_exit' => 1,
				$cond1,
			)
		));
		$total_exits_this_month = 0;
		$total_exits_this_month = $this->Pregnency->find('count', array(
			'conditions' => array(
				'Pregnency.is_exit' => 1,
				"Pregnency.exit_date between '" . $from_date_global . "' and '" . $to_date_global . "'",
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('total_exits', 'total_exits_this_month'));
		$total_suspects = 0;
		$total_suspects = $this->Beneficiary->find('count', array(
			'conditions' => array(
				'Beneficiary.is_suspect' => 1,
				'Beneficiary.husband_govt' => 'No',
				$cond1,
			)
		));
		$this->set(compact('total_suspects'));
		$total_pvtg = 0;
		$total_pvtg = $this->Beneficiary->find('count', array(
			'conditions' => array(
				'Beneficiary.is_pvtg' => 'Y',
				$cond1,
			)
		));
		$this->set(compact('total_pvtg'));
		$installment1_approved = 0;
		$installment1_not_approved = 0;
		$installment1_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 1,
				'Pinstallment.is_payment_approve' => 1,
			)
		));
		$installment1_not_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 1,
				'Pinstallment.is_payment_approve' => 0,
			)
		));

		// $installment1_not_approved=$pregnency_registered-$installment1_approved;

		$this->set(compact('installment1_approved', 'installment1_not_approved'));
		$installment2_approved = 0;
		$installment2_not_approved = 0;
		$installment2_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 2,
				'Pinstallment.is_payment_approve' => 1,
			)
		));
		$installment2_not_approved = $this->Pinstallment->find('count', array(
			'conditions' => array(
				$cond1,
				'Beneficiary.husband_govt' => 'No',
				'Pinstallment.installment_no' => 2,
				'Pinstallment.is_payment_approve' => 0,
			)
		));

		// $installment2_not_approved=$pregnency_registered-$installment2_approved;

		$this->set(compact('installment2_approved', 'installment2_not_approved'));
		$aww_inc_received = 0;
		$cond1 = "";
		if ($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA') {
			$cond1 = " and project_id='" . $user['Project']['id'] . "'";
		}

		$aww_inc_received = $this->Incentive->find('count', array(
			'conditions' => array(
				'Incentive.is_paid' => 1,
				"Incentive.worker_id in(select id from workers where workertype_id=1" . $cond1 . ")"
			)
		));
		$this->set(compact('aww_inc_received'));
		$awh_inc_received = $this->Incentive->find('count', array(
			'conditions' => array(
				'Incentive.is_paid' => 1,
				"Incentive.worker_id in(select id from workers where workertype_id=2" . $cond1 . ")"
			)
		));
		$this->set(compact('awh_inc_received'));

		// //////////////////////////

	}

	public

	function login()
	{
		$this->layout = 'login';
		if ($this->request->is(array(
			'post',
			'put'
		))) {
			$user_id = $this->request->data['User']['user_id'];
			$password = $this->request->data['User']['password'];
			$captcha = $this->request->data['User']['captcha'];
			$captcha1 = $this->Session->read('captcha');
			if ($captcha != $captcha1) {
				$this->message('error', 'Invalid Captcha !');
			}
			else {
				$exist = 0;
				$exist = $this->User->find('count', array(
					'conditions' => array(
						'User.user_id' => $user_id,
						'User.password' => $password,
					)
				));
				if ($exist != 1) {
					$this->message('error', 'Invalid User Credential !');
				}
				else {
					$data = $this->User->find('first', array(
						'conditions' => array(
							'User.user_id' => $user_id,
							'User.password' => $password,
						)
					));
					$this->Session->write('user_auth', $data);
					$this->redirect(array(
						'controller' => 'dashboard',
						'action' => 'index'
					));
				}
			}
		}
	}

	public

	function captcha()
	{
		$this->layout = NULL;
		$string = rand(1111, 9999);
		$this->Session->write('captcha', $string);
		header("Content-type: image/png");

		// //////////////////

		$font = 80;
		$width = ImageFontWidth($font) * strlen($string);
		$height = ImageFontHeight($font);
		$im = @imagecreate($width, $height);
		$background_color = imagecolorallocate($im, 255, 255, 255); //white background
		$text_color = imagecolorallocate($im, 0, 0, 0); //black text
		imagestring($im, $font, 0, 0, $string, $text_color);
		imagepng($im);
		exit();
	}

	public function logout()
	{
		$this->Session->write('user_auth', '');
		session_destroy();
		$this->redirect(array(
			'controller' => 'dashboard',
			'action' => 'login'
		));
	}

	public function changeprofile()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}

		if ($this->request->is(array(
			'post',
			'put'
		))) {
			if ($this->User->save($this->request->data)) {
				$this->message('success', 'Saved Successfully !');
			}
			else {
				$this->message('error', 'Saving Failed !');
			}
		}

		$user = $this->Session->read('user_auth');
		$this->request->data = $this->User->findById($user['User']['id']);
	}

	public function changepassword()
	{
		$this->response->disableCache();
		if ($this->Session->read('user_auth') == '') {
			$this->redirect(array(
				'controller' => 'dashboard',
				'action' => 'login'
			));
		}

		if ($this->request->is(array(
			'post',
			'put'
		))) {
			if ($this->User->save($this->request->data)) {
				$this->message('success', 'Saved Successfully !');
			}
			else {
				$this->message('error', 'Saving Failed !');
			}
		}

		$user = $this->Session->read('user_auth');
		$this->request->data = $this->User->findById($user['User']['id']);
	}
}
<?php
App::uses('AppControler','Controller');

class VerifiesController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function add($id){
  // Added by Tanmaya
  $this->loadModel('Pregnencies');
  $pregDetails = $this->Pregnencies->find('first', array(
    'conditions' => array(
      'id' => $id
    )
  ));
  $preg_reg_date = $pregDetails['Pregnencies']['preg_reg_date'];
  $preg_reg_date = $this->DB2date($preg_reg_date);
  $this->Set(array('preg_reg_date' => $preg_reg_date));
  // End of Tanmaya
$this->set('prid',$id);

  if($this->request->is(array('post','put'))){

		/*$fu=0;
		foreach($this->request->data['edata'] as $ed){
			if($ed != ''){
				$fu=$fu + 1;
			}
		}*/


    $user=$this->Session->read('user_auth');
    $ben_id=$this->Verify->Beneficiary->find('first',array(
      'conditions'=>array(
        "Beneficiary.id in(select beneficiary_id from pregnencies where id=$id)"
      ),
    ));
    $this->request->data['Verify']['pregnency_no']=1;
    if(count($this->request->data['edata'] > 0)){
      $eli=$this->Verify->Eligibility->find('all',array(
        'conditions'=>array(
          'Eligibility.installment_id'=>1
        ),
        'order'=>array(
          'Eligibility.id'
        ),
      ));
      $j=0;


      foreach($eli as $e){
          $this->Verify->query("delete from verifies where
          pregnency_id='".$id."' and
          pregnency_no=1 and
          eligibility_id='".$e['Eligibility']['id']."' and
          beneficiary_id='".$ben_id['Beneficiary']['id']."'");
          $this->Verify->query("insert into verifies(beneficiary_id, pregnency_id, eligibility_id, pregnency_no, value,  user_id, created, modified) values(
            '".$ben_id['Beneficiary']['id']."',
            '".$id."',
            '".$e['Eligibility']['id']."','1',
            '".$this->request->data['edata'][$j]."',
            '".$user['User']['id']."',now(),now())");
          $j++;
      }
      $this->message('success','Saved Successfully !');
      $this->redirect(array(
        'controller'=>'beneficiaries',
        'action'=>'index'
      ));

}

  }
	$this->loadModel('Pinstallment');
	$this->Pinstallment->recursive=2;
  $datas=$this->Pinstallment->find('first',array(
    'conditions'=>array(
      "Pinstallment.pregnency_id=$id"
    ),
  ));
  $this->set(compact('datas'));
  $els=$this->Verify->Eligibility->find('all',array(
    'conditions'=>array(
      'Eligibility.installment_id'=>1
    ),
    'order'=>array(
      'Eligibility.id'
    ),
  ));
  $this->set(compact('els'));
  $options=array(
    'Yes'=>'Yes',
    'No'=>'No'
  );
  $this->set(compact('options'));
  $exist_data=$this->Verify->find('all',array(
    'conditions'=>array(
      'Verify.pregnency_no'=>1,
      'Verify.pregnency_id'=>$id,
      'Verify.beneficiary_id'=>$datas['Beneficiary']['id']
    ),
    'order'=>array(
      'Verify.eligibility_id'
    ),
  ));
  $this->set(compact('exist_data'));
}

public function second($id){
	$pregnency_id=$id;
	$this->set(compact('pregnency_id'));
  $this->loadModel('Pregnencies');
  $pregDetails = $this->Pregnencies->find('first', array(
    'conditions' => array(
      'id' => $id
    )
  ));

  $preg_reg_date = $pregDetails['Pregnencies']['preg_reg_date'];
  $preg_reg_date = $this->DB2date($preg_reg_date);
  $this->Set(array('preg_reg_date' => $preg_reg_date));
  // End of Tanmaya


  if($this->request->is(array('post','put'))){
    //debug($this->data); exit;
    $user=$this->Session->read('user_auth');
    $ben_id=$this->Verify->Beneficiary->find('first',array(
      'conditions'=>array(
        "Beneficiary.id in(select beneficiary_id from pregnencies where id=$id)"
      ),
    ));
    $this->request->data['Verify']['pregnency_no']=1;
    if(count($this->request->data['edata'] > 0)){
      $eli=$this->Verify->Eligibility->find('all',array(
        'conditions'=>array(
          'Eligibility.installment_id'=>2
        ),
        'order'=>array(
          'Eligibility.id'
        ),
      ));
      $j=0;
      foreach($eli as $e){
          $this->Verify->query("delete from verifies where
          pregnency_id='".$id."' and
          pregnency_no=2 and
          eligibility_id='".$e['Eligibility']['id']."' and
          beneficiary_id='".$ben_id['Beneficiary']['id']."'");

          //Build a Hashed Data for Insert
          $edataOne = $this->request->data['edata'][$j] ? $this->request->data['edata'][$j] : 0;
          $edataTwo = $this->request->data['edata1'][$j] ? $this->request->data['edata1'][$j] : 0;
          $edataThree = $this->request->data['edata2'][$j] ? $this->request->data['edata2'][$j] : 0;
          $finalData = $edataOne."##".$edataTwo."##".$edataThree;

          $this->Verify->query("insert into verifies values(
            null,
            '".$ben_id['Beneficiary']['id']."',
            '".$id."',
            '".$e['Eligibility']['id']."',2,
            '".$finalData."',
            '".$user['User']['id']."',now(),now())");
          $j++;
      }

      //exit;
      $this->message('success','Saved Successfully !');
      $this->redirect(array(
        'controller'=>'beneficiaries',
        'action'=>'index'
      ));
    }
  }
	$this->loadModel('Pinstallment');
	$this->loadModel('Delivery');
	$this->Pinstallment->recursive=2;
  $datas=$this->Pinstallment->find('first',array(
    'conditions'=>array(
      "Pinstallment.pregnency_id=$id",
			'Pinstallment.installment_no'=>1
    ),
  ));
	$datas1=$this->Delivery->find('first',array(
    'conditions'=>array(
      "Delivery.pregnency_id=$id",
    ),
  ));

  $this->set(compact('datas','datas1'));
  $els=$this->Verify->Eligibility->find('all',array(
    'conditions'=>array(
      'Eligibility.installment_id'=>2
    ),
    'order'=>array(
      'Eligibility.id'
    ),
  ));
  $this->set(compact('els'));
  $options=array(
    'Yes'=>'Yes',
    'No'=>'No'
  );
  $this->set(compact('options'));
  $exist_data=$this->Verify->find('all',array(
    'conditions'=>array(
      'Verify.pregnency_no'=>2,
      'Verify.pregnency_id'=>$id,
      'Verify.beneficiary_id'=>$datas['Beneficiary']['id']
    ),
    'order'=>array(
      'Verify.eligibility_id'
    ),
  ));
  $this->set(compact('exist_data'));
}

}

<?php
App::uses('AppControler', 'Controller');
class WorkersController extends AppController

{
  public $components = array(

    'Paginator',
    'Flash',
    'Session'
  );
  public

  function beforeFilter()
  {
    $this->response->disableCache();
    if ($this->Session->read('user_auth') == '') {
      $this->redirect(array(
        'controller' => 'dashboard',
        'action' => 'login'
      ));
    }
  }

public

function index()
{
  $this->layout = 'admin';
  if ($this->request->is(array('post', 'put'))) {
    $sql = "";
    $sql1 = "";
    if (@$this->request->data['Worker']['project_id'] != "") {
      $sql = "Worker.project_id = '" . $this->request->data['Worker']['project_id'] . "'";
    }

    if (@$this->request->data['Worker']['workertype_id'] != "") {
      $sql1 = "Worker.workertype_id = '" . $this->request->data['Worker']['workertype_id'] . "'";
    }

    if ($sql == "" && $sql1 == "") {
      $this->message("error", "No Criteria Selected !");
    }
    else {
      /**
        * Added by Tanmeye to get Promary or Additional Type
        **/
      $this->Worker->bindModel(array(
            'belongsTo' => array(
                'Assignment' => array(
                    'className'  => 'Assignment',
                    'foreignKey' => 'id',
                ),
            )
        ));

      $datas = $this->Worker->find('all', array(
        'conditions' => array(
          $sql,
          $sql1,
        ) ,
        'order' => array(
          'Worker.name'
        ) ,
      ));
      $this->set(compact('datas'));
    }
  }

  $user = $this->Session->read('user_auth');
  $project_id = $this->Worker->Project->find('list', array(
    'conditions' => array(
      'Project.id' => $user['Project']['id'],
    ) ,
    'order' => array(
      'Project.name'
    ) ,
  ));
  $workertype_id = $this->Worker->Workertype->find('list');
  $this->set(compact('project_id', 'workertype_id'));

  //  $datas=$this->Worker->find('all');
  //  $this->set(compact('datas'));

}



    public  function add()
      {
        $this->layout = 'admin';
        $workertype_id = array();
        if ($this->request->is(array('post','put'))) {
          if ($this->request->data['Worker']['account_no'] != $this->request->data['Worker']['account_no1']) {
            $this->message('error', 'Bank Account No. and Confirm Account No. missmatch !');
          }
          else {

            // //<IF>ALREADY EXISTS</IF>

            $this->loadModel('Assignment');
            $cnt = $this->Worker->find('count', array(
              'conditions' => array(
                'Worker.awc_id' => $this->request->data['Worker']['awc_id'],
                'Worker.workertype_id' => $this->request->data['Worker']['workertype_id'],
                "Worker.id in(select worker_id from assignments where is_removed=0 and awc_id='" . $this->request->data['Worker']['awc_id'] . "')"
              )
            ));
            if ($cnt > 0) {
              $this->message('error', 'Already Assigned ! No more addition possible.');
            }
            else {

              // /////////////////////////

              $user = $this->Session->read('user_auth');
              $this->request->data['Worker']['project_id'] = $user['Project']['id'];
              if (isset($this->data['Worker']['dob']) && $this->data['Worker']['dob'] != '') {
                $this->request->data['Worker']['dob'] = date('Y-m-d', strtotime($this->data['Worker']['dob']));
              }

              if (isset($this->data['Worker']['doj']) && $this->data['Worker']['doj'] != '') {
                $this->request->data['Worker']['doj'] = date('Y-m-d', strtotime($this->data['Worker']['doj']));
              }

              if ($this->Worker->save($this->request->data)) {

                // Saving in assignments//

                $this->loadModel('Assignment');
                $this->request->data['Assignment']['worker_id'] = $this->Worker->getLastInsertID();
                $this->request->data['Assignment']['project_id'] = $user['Project']['id'];
                $this->request->data['Assignment']['awc_id'] = $this->request->data['Worker']['awc_id'];
                $this->request->data['Assignment']['assignment_type'] = 'Primary';
                $this->request->data['Assignment']['assignment_date'] = date('Y-m-d');
                $this->request->data['Assignment']['is_removed'] = 0;
                $this->Assignment->create();
                $this->Assignment->save($this->request->data);

                // Done//

                $this->message('success', 'Saved Successfully !');
                $this->redirect(array(
                  'action' => 'index'
                ));
              }
              else {
                $this->message('error', 'Saving Failed !');
              }
            }
          }
        }

        $this->loadModel('Awc');
        $this->loadModel('Workertype');
        if (isset($this->data['Worker']['awc_id']) && (int)$this->data['Worker']['awc_id'] != 0) {
          $awcdata = $this->Awc->find('first', array(
            'recursive' => - 1,
            'conditions' => array(
              'Awc.id' => $this->data['Worker']['awc_id'],
            ) ,
            'fields' => array(
              'Awc.awc_type'
            ) ,
          ));
          $cond = array();
		  //echo '###<span style="color:black">'.$awcdata['Awc']['awc_type'].'</span>';
          if (isset($awcdata['Awc']['awc_type']) && (int)$awcdata['Awc']['awc_type'] == 0) {
            $cond = array(
              'Workertype.id' => Configure::read('WORKERTYPE_AWW') ,
            );
          }
			//print_r($cond);
          $workertype_id = $this->Workertype->find('list', array(
            'recursive' => - 1,
            'conditions' => $cond,
            'fields' => array(
              'Workertype.id',
              'Workertype.name'
            ) ,
            'order' => array(
              'Workertype.name'
            )
          ));
        }

        $gender = array(
          //'Male' => 'Male',
          'Female' => 'Female'
        );
        $user = $this->Session->read('user_auth');
        $awc_id = $this->Worker->Awc->find('list', array(
          'conditions' => array(
            'Awc.project_id' => $user['Project']['id']
          ) ,
          'order' => array(
            'Awc.name'
          )
        ));
        $bank_id = $this->Worker->Bank->find('list', array(
          'order' => array(
            'Bank.name'
          )
        ));
        $branch_id = "";
        $this->set(compact('gender', 'workertype_id', 'awc_id', 'bank_id', 'branch_id'));
      }

    public function edit($id){
    	$this->layout = 'admin';
        $workertype_id = array();
        if ($this->request->is(array(
            'post',
            'put'
        ))) {
            if ($this->request->data['Worker']['account_no'] != $this->request->data['Worker']['account_no1']) {
                $this->message('error', 'Bank Account No. and Confirm Account No. missmatch !');
            }else {
                $user = $this->Session->read('user_auth');
                $this->request->data['Worker']['project_id'] = $user['Project']['id'];
                if(isset($this->data['Worker']['dob']) && $this->data['Worker']['dob'] != ''){
                    $this->request->data['Worker']['dob'] = date('Y-m-d', strtotime($this->data['Worker']['dob']));
                }
                if(isset($this->data['Worker']['doj']) && $this->data['Worker']['doj'] != ''){
                    $this->request->data['Worker']['doj'] = date('Y-m-d', strtotime($this->data['Worker']['doj']));
                }                
                if ($this->Worker->save($this->request->data)) {
                    $this->loadModel('Assignment');
                    $wd = $this->Assignment->find('first', array(
                        'conditions' => array(
                            'Assignment.worker_id' => $id,
                        ) ,
                        'order' => array(
                            'Assignment.id' => 'DESC'
                        )
                    ));
					if(isset($wd) && is_array($wd) && count($wd)>0){
						$this->request->data['Assignment']['id']                = $wd['Assignment']['id'];
						$this->request->data['Assignment']['worker_id']         = $id;
						$this->request->data['Assignment']['project_id']        = $user['Project']['id'];
						$this->request->data['Assignment']['awc_id']            = $this->request->data['Worker']['awc_id'];
						$this->request->data['Assignment']['assignment_type']   = 'Primary';
						$this->request->data['Assignment']['is_removed']        = 0;
						$this->Assignment->create();
						$this->Assignment->save($this->request->data);
					}
                    // Done//
                    $this->message('success', 'Saved Successfully !');
                    $this->redirect(array(
                        'action' => 'index'
                    ));
                }else {
                    $this->message('error', 'Saving Failed !');
                }
            }
        }
        $gender = array(
            //'Male' => 'Male',
            'Female' => 'Female'
        );
        $user = $this->Session->read('user_auth');
        $awc_id = $this->Worker->Awc->find('list', array(
            'conditions' => array(
                'Awc.project_id' => $user['Project']['id']
            ) ,
            'order' => array(
                'Awc.name'
            )
        ));
        $bank_id = $this->Worker->Bank->find('list', array(
            'order' => array(
                'Bank.name'
            )
        ));
        $branch_id = "";
        $this->request->data = $this->Worker->findById($id);
		//echo $id."##".$this->data['Worker']['awc_id'];
        if(isset($this->data['Worker']['awc_id']) && (int)$this->data['Worker']['awc_id'] != 0){
            $awcdata = $this->Worker->Awc->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Awc.id'    => $this->data['Worker']['awc_id'],
                ),
                'fields'        => array(
                    'Awc.awc_type'
                ),
            ));
            $cond = array();
            if(isset($awcdata['Awc']['awc_type']) && (int)$awcdata['Awc']['awc_type'] == 0){
                $cond = array(
                    'Workertype.id'     => Configure::read('WORKERTYPE_AWW'),
                );
            }
			echo '###<span style="color:black">'.$awcdata['Awc']['awc_type'].'</span>';
            $workertype_id = $this->Worker->Workertype->find('list', array(
                'recursive'     => -1,
                'conditions'    => $cond,
                'fields'        => array(
                    'Workertype.id',
                    'Workertype.name'
                ),
                'order' => array(
                    'Workertype.name'
                )                
            )); 
        }        
        $branch_id = $this->Worker->Branch->find('list', array(
            'conditions' => array(
                'Branch.bank_id' => $this->request->data['Worker']['bank_id'],
            ) ,
            'order' => array(
                'Branch.name'
            )
        ));

        $this->request->data['Worker']['account_no1'] = $this->request->data['Worker']['account_no'];
        $this->set(compact('gender', 'workertype_id', 'awc_id', 'bank_id', 'branch_id'));
    }

  public

  function delete($id)
  {
    $this->Worker->delete($id);
    $this->message('success', 'Deleted Successfully !');
    $this->redirect(array(
      'action' => 'index'
    ));
  }

  public

  function loadbranches($id)
  {
    $this->layout = null;
    $branch_id = $this->Worker->Branch->find('list', array(
      'conditions' => array(
        'Branch.bank_id' => $id,
      ) ,
      'action' => array(
        'Branch.name'
      )
    ));
    $this->set(compact('branch_id'));
  }

  public

  function charges()
  {
    $this->layout = 'admin';
    $user = $this->Session->read('user_auth');
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      $this->loadModel('Assignment');
      $worker_id = "";
      if ($this->request->data['Worker']['aww'] != '') {
        $worker_id = $this->request->data['Worker']['aww'];
      }

      if ($this->request->data['Worker']['awh'] != '') {
        $worker_id = $this->request->data['Worker']['awh'];
      }
      $assignDataCnt = $this->Assignment->find('count', array(
        'recursive'   => -1,
        'conditions'  => array(
          'Assignment.project_id'   => $user['Project']['id'],
          //'Assignment.worker_id'    => $worker_id,
          'Assignment.awc_id'       => $this->request->data['Worker']['to_awc_id'],
          'Assignment.is_removed'   => 0,
        ),
      ));
      if($assignDataCnt == 0){
        $this->request->data['Assignment']['project_id'] = $user['Project']['id'];
        $this->request->data['Assignment']['worker_id'] = $worker_id;
        $this->request->data['Assignment']['awc_id'] = $this->request->data['Worker']['to_awc_id'];
        $this->request->data['Assignment']['assignment_type'] = $this->request->data['Worker']['assignment_type'];
        $this->request->data['Assignment']['assignment_date'] = date('Y-m-d');

        $this->Assignment->create();
        if ($this->Assignment->save($this->request->data)) {
          $this->message('success', 'Saved Successfully !');

          $this->redirect(array(
            'action' => 'charges'
          ));
        }
        else {
          $this->message('error', 'Saving Failed !');
        }
      }else{
        $this->message('error', 'Worker already exist !');
      }
    }

    $awc_id = $this->Worker->Awc->find('list', array(
      'conditions' => array(
        'Awc.project_id' => $user['Project']['id']
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $aww = "";
    $awh = "";
    $assignment_type = array(
      //'Primary' => 'Primary',
      'Additional' => 'Additional'
    );
    $this->set(compact('awc_id', 'aww', 'awh', 'assignment_type'));
  }

  public

  function loadworkers($id)
  {
    $this->layout = null;
    $user = $this->Session->read('user_auth');
    $aww = $this->Worker->find('list', array(
      'conditions' => array(
        'Worker.workertype_id' => 1,
        'Worker.project_id' => $user['Project']['id'],
        'Worker.awc_id' => $id
      ) ,
      'order' => array(
        'Worker.name'
      )
    ));
    $awh = $this->Worker->find('list', array(
      'conditions' => array(
        'Worker.workertype_id' => 2,
        'Worker.project_id' => $user['Project']['id'],
        'Worker.awc_id' => $id
      ) ,
      'order' => array(
        'Worker.name'
      )
    ));
    $this->set(compact('aww', 'awh'));
  }

  public

  function loadworkers_existing($id)
  {
    $this->layout = null;
    $user = $this->Session->read('user_auth');
    $str = "";
    $this->loadModel('Assignment');
    $worker = $this->Assignment->find('first', array(
      'conditions' => array(
        'Worker.workertype_id' => 1,
        'Assignment.project_id' => $user['Project']['id'],
        'Assignment.awc_id' => $id,
        'Assignment.is_removed' => 0,
      ) ,
      'order' => array(
        'Assignment.id' => 'DESC'
      )
    ));
    if(isset($worker['Worker']['name'])){
      $str = "Worker : " . $worker['Worker']['name'] . "<br />";
    }
    $worker = $this->Assignment->find('first', array(
      'conditions' => array(
        'Worker.workertype_id' => 2,
        'Assignment.project_id' => $user['Project']['id'],
        'Assignment.awc_id' => $id,
        'Assignment.is_removed' => 0,
      ) ,
      'order' => array(
        'Assignment.id' => 'DESC'
      )
    ));
    if(isset($worker['Worker']['name'])){
      $str = $str . "Helper : " . $worker['Worker']['name'] . "<br />";
    }
    echo $str;
    exit();
  }

  public

  function import()
  {
    $this->layout = null;
    $this->loadModel('Assignment');
    $datas = $this->Worker->find('all', array(
      'conditions' => array(
        'Worker.id >= 118751',
        'Worker.awc_id > 0',
        'Worker.project_id > 0'
      ) ,
      'order' => array(
        'Worker.id'
      ) ,
    ));
    foreach($datas as $data) {
      $this->Assignment->query("insert into assignments values(
        null,'" . $data['Worker']['project_id'] . "','" . $data['Worker']['id'] . "','" . $data['Awc']['id'] . "',
        'Primary',curdate(),0,now(),now())");
    }

    echo "Imported";
    exit();
  }

  public

  function disengage()
  {
    $user = $this->Session->read('user_auth');
    $awc_id = $this->Worker->Awc->find('list', array(
      'conditions' => array(
        'Awc.project_id' => $user['Project']['id']
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $this->set(compact('awc_id'));
  }

  public

  function loadengagement($id)
  {
    $this->layout = NULL;
    $user = $this->Session->read('user_auth');
    $this->loadModel('Assignment');
    $datas = $this->Assignment->find('all', array(
      'conditions' => array(
        'Assignment.awc_id' => $id,
        'Assignment.project_id' => $user['Project']['id'],
        'Assignment.is_removed' => 0
      ) ,
      'order' => array()
    ));
    $this->set(compact('datas'));
  }

  public

  function disengagenow($id)
  {
    $this->layout = NULL;
    $this->loadModel('Assignment');
    $this->Assignment->id = $id;
    $this->Assignment->saveField('is_removed', 1);
    exit();
  }

  public

  function chargesn()
  {
    $user = $this->Session->read('user_auth');
    if ($this->request->is(array(
      'post',
      'put'
    ))) {
      $this->loadModel("Assignment");
      $this->request->data['Assignment']['project_id'] = $user['Project']['id'];
      $this->request->data['Assignment']['worker_id'] = $this->request->data['Worker']['worker_id'];
      $this->request->data['Assignment']['awc_id'] = $this->request->data['Worker']['to_awc_id'];
      $this->request->data['Assignment']['assignment_type'] = $this->request->data['Worker']['assignment_type'];
      $this->request->data['Assignment']['assignment_date'] = date('Y-m-d');
      $this->Assignment->create();
      $this->Assignment->save($this->request->data);
      $this->message('success', 'Saved Successfully !');
    }

    $workertype_id = $this->Worker->Workertype->find('list');
    $worker_id = "";
    $assignment_type = array(
      'Primary' => 'Primary',
      'Additional' => 'Additional'
    );
    $awc_id = $this->Worker->Awc->find('list', array(
      'conditions' => array(
        'Awc.project_id' => $user['Project']['id']
      ) ,
      'order' => array(
        'Awc.name'
      )
    ));
    $this->set(compact('workertype_id', 'worker_id', 'assignment_type', 'awc_id'));
  }

  public

  function loadworkersbytype($id)
  {
    $this->layout = NULL;
    $user = $this->Session->read('user_auth');
    $worker_id = $this->Worker->find('list', array(
      'conditions' => array(
        'Worker.id in(select worker_id from assignments where is_removed=1)',
        'Worker.project_id' => $user['Project']['id'],
        'Worker.workertype_id' => $id,
      ) ,
      'order' => array(
        'Worker.name'
      )
    ));
    $this->set(compact('worker_id'));
  }
    public function getWorkerType(){
        $this->autoRender = false;
        if(isset($this->data['awc_id']) && (int)$this->data['awc_id'] != 0){
            $this->loadModel('Awc');
            $this->loadModel('Workertype');
            $cond = array();
            $data = $this->Awc->find('first', array(
                'recursive'     => -1,
                'conditions'    => array(
                    'Awc.id'    => $this->data['awc_id'],
                ),
                'fields'        => array(
                    'Awc.awc_type'
                ),
            ));
            if(isset($data['Awc']['awc_type']) && (int)$data['Awc']['awc_type'] == 0){
                $cond = array(
                    'Workertype.id'     => Configure::read('WORKERTYPE_AWW'),
                );
            }
            $worker = $this->Workertype->find('list', array(
                'recursive'     => -1,
                'conditions'    => $cond,
                'fields'        => array(
                    'Workertype.id',
                    'Workertype.name'
                ),
            ));
            if(is_array($worker) && count($worker)>0){
                echo '<option value="">-- Select Worker Type --</option>';
                foreach($worker as $key=>$val){
                    echo '<option value="'.$key.'">'.$val.'</option>';
                }
            }else{
                echo '<option value="">-- Select Worker Type --</option>';
            }         
        }else{
            echo '<option value="">-- Select Worker Type --</option>';
        }
    }
}

<?php 
   /**
     * Hide Particular fields as per the user role .
     * Added by Tanmaya on 14-04-2017
     */
   $sess_data = $this->Session->read('user_auth');
   $desig_id = $sess_data['User']['designation_id'];
   ?>
<?php $dist_disp = (isset($desig_id) && $desig_id ==13) ? '' : 'style="display:none"'; ?>
<?php $proj_disp = (isset($desig_id) && ($desig_id ==13 || $desig_id ==9)) ? '' : 'style="display:none"'; ?>
<?php $sect_disp = (isset($desig_id) && ($desig_id ==13 || $desig_id ==8 || $desig_id ==9 || $desig_id ==10) ) ? '' : 'style="display:none"'; ?>
<?php $awc_disp = (isset($desig_id) && ($desig_id ==13 || $desig_id ==8 || $desig_id ==9 || $desig_id ==10) ) ? '' : 'style="display:none"'; 
   //End of Adding
   ?> 
<div class="row">
   <div class="col-sm-12">
      <div class="card-box">
         <h4 class="m-t-0 header-title"><b>Project  Wise Payment Statistics Report</b></h4>
         <div class="row">
            <div class="col-md-12">
               <?php
                  echo $this->Form->create('Report',array(
                  	'class'=>'form-horizontal'
                  	));
                  	?>
               <div class="col-md-3" <?php echo $dist_disp;?> >
                  <div class="form-group">
                     <div class="col-md-10">
                        <?php
                           echo $this->Form->input('district_id',array(
                               'div'=>false,
                               'label'=>false,
                               'required'=>false,
                               'class'=>'form-control',
                               
                               'empty'=>'-- Select District --',
                               'options'=>$district_id,
                               'onchange'=>'loadprojects(this.value)'
                             ));
                           ?><small class="text-purple"> Choose District</small>
                     </div>
                  </div>
               </div>
               <div class="col-md-3" <?php echo $proj_disp;?>>
                  <div class="form-group">
                     <div class="col-md-10" id="div_project">
                        <?php
                           echo $this->Form->input('project_id',array(
                               'div'=>false,
                               'label'=>false,
                               'required'=>false,
                               'class'=>'form-control',
                               
                               'empty'=>'-- Select Project Location --',
                               'options'=>$project_id
                             ));
                           ?><small class="text-purple"> Choose Project Location</small>
                     </div>
                  </div>
               </div>
               <div class="col-md-3" <?php echo $sect_disp; ?>>
                  <div class="form-group">
                     <div class="col-md-10" id="div_sector">
                        <?php
                           echo $this->Form->input('sector_id',array(
                               'div'=>false,
                               'label'=>false,
                               'required'=>false,
                               'class'=>'form-control',
                               
                               'empty'=>'-- Select Sector --',
                               'options'=>$sector_id,
                               'onchange'=>'loadawcs(this.value)'
                             ));
                           ?>
                        <small class="text-purple"> Choose Sector Name</small>
                     </div>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="form-group">
                     <div class="col-md-6" id="div_awc">
                        <?php
                           echo $this->Form->input('from_date',array(
                               'id'=>'from_date',
                               'div'=>false,
                               'label'=>false,
                               'required'=>false,
                               'class'=>'form-control',
                               
                               'data-date-format'=>'dd/mm/yyyy',
                             ));
                           ?><small class="text-purple"> From Date</small>
                     </div>
                     <div class="col-md-6" id="div_awc">
                        <?php
                        //echo "##".$prevDay;
                           echo $this->Form->input('to_date',array(
                               'id'=>'to_date',
                               'div'=>false,
                               'label'=>false,
                               'required'=>false,
                               'class'=>'form-control',
                               'placeholder' => isset($prevDay)?$prevDay:'',
                               'data-date-format'=>'dd/mm/yyyy',
                             ));
                           ?><small class="text-purple"> To Date</small>
                     </div>
                  </div>
               </div>
               <center>
                  <div class="form-group">
                     <div class="col-md-12">
                        <button type="submit" id="submit" class="btn btn-primary waves-effect waves-light btn-md">Submit</button>
                        <button type="button" onclick="clickSubmit()" name="button" class="btn btn-warning btn-sm">Reset</button>
                        <script type="text/javascript">
                           function clickSubmit() {
                             $("input, select").val("");
                             $("#submit").click();
                           }
                        </script>
                     </div>
                  </div>
               </center>
            </div>
         </div>
      </div>
   </div>
</div>
<?php
   echo $this->Form->end();
   ?>
<?php
   echo $this->Element('form_buttom');
   ?>
<?php echo $this->Element('table_header'); ?>
<div class="row" id="print_div">
   <div class="col-sm-12">
      <div class="card-box table-responsive">
         <center>
            <h3>PROJECT WISE PAYMENT STATISTICS REPORT</h3>
            <h4>Report Date: <?php echo date('d/M/Y'); ?></h4>
         </center>
         <table  id="datatable-buttons" class="table table-striped table-bordered">
            <thead>
               <tr>
                  <th>SL#</th>
                  <th>District</th>
                  <th>Project</th>
                  <th>Tot. Registered</th>
                  <th>Installment#1 Paid</th>
                  <th>Installment#2 Eligible</th>
                  <th>Installment#2 Paid</th>
                  <th>Tot. Exited</th>
               </tr>
            </thead>
            <tbody>
               <?php
                  App::import("Beneficiary");
                  App::import("District");
                  App::import("Project");
                  App::import("Sector");
                  App::import("Awc");
                  App::import('Pinstallment');
                  App::import('Pregnency');
                  App::import('Worker');
                  App::import('Incentive');
                  $this->District=new District();
                  $this->Project=new Project();
                  $this->Sector=new Sector();
                  $this->Awc=new Awc();
                  $this->Pinstallment=new Pinstallment();
                  $this->Beneficiary=new Beneficiary();
                  $this->Pregnency=new Pregnency();
                  $this->Worker=new Worker();
                  $this->Incentive=new Incentive();
                  $i=0;
                  foreach($datas as $data){
                  ?>
               <tr>
                  <td style="width:45px"><?php echo ++$i; ?></td>
                  <td><?php echo $data['District']['name']; ?></td>
                  <td>
                     <?php echo $data['Project']['name']; ?>
                  </td>
                  <td>
                     <?php
                        $sql="";
                        if($from_date != '' && $to_date != ''){
                          $sql="Pregnency.preg_reg_date between '".$from_date."' and '".$to_date."'";
                        }
                        $t=0;
                        $t=$this->Pregnency->find('count',array(
                          'conditions'=>array(
                            'Beneficiary.husband_govt'=>'No',
                            "Beneficiary.user_id in(select id from users where project_id='".$data['Project']['id']."')",
                            $sql
                          )
                        ));
                        echo $t;
                         ?>
                  </td>
                  <td>
                     <?php
                        $sql="";
                        if($from_date != '' && $to_date != ''){
                          $sql="Pinstallment.payment_date between '".$from_date."' and '".$to_date."'";
                        }
                        $t=0;
                        $t=$this->Pinstallment->find('count',array(
                          'conditions'=>array(
                            'Pinstallment.installment_no'=>1,
                            'Pinstallment.is_paid'=>1,
                            "Beneficiary.user_id in(select id from users where project_id='".$data['Project']['id']."')",
                            $sql
                          )
                        ));
                        echo $t;
                         ?>
                  </td>
                  <td>
                     <?php
                        $sql="";
                        if($from_date != '' && $to_date != ''){
                          $sql="Pinstallment.payment_date between '".$from_date."' and '".$to_date."'";
                        }
                        $t=0;
                        $t=$this->Pinstallment->find('count',array(
                          'conditions'=>array(
                            'Pinstallment.installment_no'=>2,
                            "Beneficiary.user_id in(select id from users where project_id='".$data['Project']['id']."')",
                            $sql
                          )
                        ));
                        echo $t;
                         ?>
                  </td>
                  <td>
                     <?php
                        $sql="";
                        if($from_date != '' && $to_date != ''){
                          $sql="Pinstallment.payment_date between '".$from_date."' and '".$to_date."'";
                        }
                        $t=0;
                        $t=$this->Pinstallment->find('count',array(
                          'conditions'=>array(
                            'Pinstallment.installment_no'=>2,
                            'Pinstallment.is_paid'=>1,
                            "Beneficiary.user_id in(select id from users where project_id='".$data['Project']['id']."')",
                            $sql
                          )
                        ));
                        echo $t;
                         ?>
                  </td>
                  <td>
                     <?php
                        $sql="";
                        if($from_date != '' && $to_date != ''){
                          $sql="Pregnency.exit_date between '".$from_date."' and '".$to_date."'";
                        }
                        $t=0;
                        $t=$this->Pregnency->find('count',array(
                          'conditions'=>array(
                            'Pregnency.is_exit'=>1,
                            "Beneficiary.user_id in(select id from users where project_id='".$data['Project']['id']."')",
                            $sql
                          )
                        ));
                        echo $t;
                        ?>
                  </td>
               </tr>
               <?php
                  }
                  ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<?php echo $this->Element('table_footer'); ?>
<script src="<?php echo $this->webroot; ?>theme/assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo $this->webroot; ?>theme/assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript">
   function loadprojects(str){
     $.get("<?php echo SITE; ?>reports/loadprojects/"+str,function(data){
       $("#div_project").html(data);
     });
   }
   
   $( function() {
     $( "#from_date" ).datepicker({
       dateFormat: 'dd/mm/yy',
         showButtonPanel: true,
         changeMonth: true,
         changeYear: true,
     });
     $( "#to_date" ).datepicker({
       dateFormat: 'dd/mm/yy',
         showButtonPanel: true,
         changeMonth: true,
         changeYear: true,
     });
   } );
</script>
<?php
App::uses('AppControler','Controller');

class SubmenusController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}

public function index(){
  $datas=$this->Submenu->find('all',array(
    'order'=>array(
      'Menu.morder'=>'ASC',
      'Submenu.morder'=>'ASC'
    )
  ));
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
    if($this->Submenu->save($this->request->data)){
      $this->message('success','Saved Successfully !');
      $this->redirect(array('action'=>'index'));
    }else{
      $this->message('error','Saving Failed !');
    }
  }
  $is_enable=array(
    '0'=>'In-Active',
    '1'=>'Active'
  );
  $menu_id=$this->Submenu->Menu->find('list',array(
    'conditions'=>array(
      'Menu.is_enable'=>1
    ),
    'order'=>array(
      'Menu.morder'
    )
  ));
  $this->set(compact('is_enable','menu_id'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
    if($this->Submenu->save($this->request->data)){
      $this->message('success','Saved Successfully !');
      $this->redirect(array('action'=>'index'));
    }else{
      $this->message('error','Saving Failed !');
    }
  }
  $is_enable=array(
    '0'=>'In-Active',
    '1'=>'Active'
  );
  $menu_id=$this->Submenu->Menu->find('list',array(
    'conditions'=>array(
      'Menu.is_enable'=>1
    ),
    'order'=>array(
      'Menu.morder'
    )
  ));
  $this->request->data=$this->Submenu->findById($id);
  $this->set(compact('is_enable','menu_id'));
}

public function delete($id){
  $this->Submenu->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

<?php
App::uses('AppControler','Controller');

class EligibilitiesController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

	public function beforeFilter(){
		$this->response->disableCache();
		if($this->Session->read('user_auth') == ''){
			$this->redirect(array(
				'controller'=>'dashboard',
				'action'=>'login'
			));
		}
	}
	
public function index(){
  $datas=$this->Eligibility->find('all');
  $this->set(compact('datas'));
}

public function add(){
  if($this->request->is(array('post','put'))){
      if($this->Eligibility->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $priority=array(
    '0'=>'LOW',
    '1'=>'HIGH'
  );
  $installment_id=$this->Eligibility->Installment->find('list',array(
    'order'=>array(
      'Installment.installment_no'
    )
  ));
  $this->set(compact('priority','installment_id'));
}

public function edit($id){
  if($this->request->is(array('post','put'))){
      if($this->Eligibility->save($this->request->data)){
        $this->message('success','Saved Successfully !');
        $this->redirect(array('action'=>'index'));
      }else{
          $this->message('error','Saving Failed !');
      }
  }
  $priority=array(
    '0'=>'LOW',
    '1'=>'HIGH'
  );
  $installment_id=$this->Eligibility->Installment->find('list',array(
    'order'=>array(
      'Installment.installment_no'
    )
  ));
  $this->set(compact('priority','installment_id'));
  $this->request->data=$this->Eligibility->findById($id);
}

public function delete($id){
  $this->Eligibility->delete($id);
  $this->message('success','Deleted Successfully !');
  $this->redirect(array('action'=>'index'));
}

}

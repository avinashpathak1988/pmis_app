<?php
App::uses('AppControler','Controller');

class JsonsController extends AppController{
	public $components = array('Session');

public function loadsectorsdata(){
  $this->layout=NULL;
  header("Content-type: text/json");
    $this->loadModel('Sector');
    $this->loadModel('Beneficiary');
    $user=$this->Session->read('user_auth');
    $output="";
    $cond1="";
    if($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA'){
    	$cond1="Sector.project_id in(select id from projects where id='".$user['Project']['id']."')";
    }
    $this->Sector->recursive=-1;
    $this->Beneficiary->recursive=-1;
    $datas=$this->Sector->find('all',array(
      'conditions'=>array(
       $cond1,
        "Sector.id in(select sector_id from beneficiaries where husband_govt='No')"
      ),
      'order'=>array(
        'Sector.name'
      )
    ));

foreach($datas as $data){
  $count=0;
  $cond2="";
  if($user['Designation']['name'] == 'CDPO' || $user['Designation']['name'] == 'PA'){
    $cond2="Beneficiary.user_id in(select id from users where project_id='".$user['Project']['id']."')";
  }
  $count=$this->Beneficiary->find('count',array(
    'conditions'=>array(
      'Beneficiary.sector_id'=>$data['Sector']['id'],
      'Beneficiary.husband_govt'=>'No',
      $cond2,
    )
  ));
  $output[$data['Sector']['name']]= $count;
}
//echo json_encode($output);
$x = time() * 1000;
$y = rand(0, 100);
$ret = array($x, $y);
echo json_encode($output);
    exit();
}

}

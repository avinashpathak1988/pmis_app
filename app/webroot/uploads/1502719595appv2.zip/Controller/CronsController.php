<?php
App::uses('AppControler','Controller');

class CronsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');
  public $uses=array('Suspectmaster','Awc','Bank','Beneficiary','District','Gp','Project','Worker');

public function index(){
  $this->layout=NULL;
  $datas=$this->Beneficiary->find('all',array(
    'conditions'=>array(
      'Beneficiary.is_check_suspect'=>1,
      'Beneficiary.is_exit'=>0,
      'Beneficiary.husband_govt'=>'No'
    ),
    'order'=>array(
      'Beneficiary.id'
    ),
  ));
  foreach($datas as $data){
    $is_suspect=0;
    $suspect_score=0;
    $suspect_reason="";
   /* $is_exist = $this->Beneficiary->find('count',array(
      'conditions'=>array(
        'Beneficiary.id !='=>$data['Beneficiary']['id'],
        "Beneficiary.name like '%".$data['Beneficiary']['name']."%'",
        "Beneficiary.husband like '%".$data['Beneficiary']['husband']."%'",
      ),
    ));
    if($is_exist > 0){
      $suspect_score=40;
        $suspect_reason="name****husband";
    }*/
    $is_exist=$this->Beneficiary->find('count',array(
      'conditions'=>array(
        'Beneficiary.id !='=>$data['Beneficiary']['id'],
        "Beneficiary.name like '%".$data['Beneficiary']['name']."%'",
        'Beneficiary.sector_id'=>$data['Beneficiary']['sector_id'],
        'Beneficiary.awc_id'=>$data['Beneficiary']['awc_id'],
      ),
    ));
    if($is_exist > 0){
      $suspect_score=30;
      $suspect_reason="name****awc";
    }

if($data['Beneficiary']['mobile_no'] != ''){
  $is_exist=$this->Beneficiary->find('count',array(
    'conditions'=>array(
      'Beneficiary.id !='=>$data['Beneficiary']['id'],
      //"Beneficiary.name like '%".$data['Beneficiary']['name']."%'",
      'Beneficiary.mobile_no'=>$data['Beneficiary']['mobile_no'],
    ),
  ));
  if($is_exist > 0){
    $suspect_score=80;
    $suspect_reason="name****mobile";
  }
}


  $is_exist=$this->Beneficiary->find('count',array(
    'conditions'=>array(
      'Beneficiary.id !='=>$data['Beneficiary']['id'],
      'Beneficiary.bank_id'=>$data['Beneficiary']['bank_id'],
      'Beneficiary.branch_id'=>$data['Beneficiary']['branch_id'],
      'Beneficiary.account_no'=>$data['Beneficiary']['account_no'],
			"Beneficiary.account_no !='' and Beneficiary.bank_id !='' and Beneficiary.branch_id !=''"
    ),
  ));
  if($is_exist > 0){
    $suspect_score=40;
    $suspect_reason="bank****";
  }

  if($data['Beneficiary']['mail_id'] != ''){
    $is_exist=$this->Beneficiary->find('count',array(
      'conditions'=>array(
        'Beneficiary.id !='=>$data['Beneficiary']['id'],
        'Beneficiary.mail_id'=>$data['Beneficiary']['mail_id'],
      ),
    ));
    if($is_exist > 0){
      $suspect_score=60;
      $suspect_reason="email****";
    }
  }

  if($data['Beneficiary']['aadhar'] != ''){
    $is_exist=$this->Beneficiary->find('count',array(
      'conditions'=>array(
        'Beneficiary.id !='=>$data['Beneficiary']['id'],
        'Beneficiary.aadhar'=>$data['Beneficiary']['aadhar'],
      ),
    ));
    if($is_exist > 0){
      $suspect_score=80;
      $suspect_reason="aadhar****";
    }
  }
/*checking from old Database*/
$this->Beneficiary->setDataSource('old');
/*$is_exist=$this->Beneficiary->find('count',array(
	'conditions'=>array(
		"Beneficiary.ben_name like '%".$data['Beneficiary']['name']."%'",
		"Beneficiary.wife_daughter_of like '%".$data['Beneficiary']['husband']."%'",
	),
));
if($is_exist > 0){
	$suspect_score=40;
		$suspect_reason="name****husband";
}*/
$is_exist=$this->Beneficiary->find('count',array(
	'conditions'=>array(
		"Beneficiary.ben_name like '%".$data['Beneficiary']['name']."%'",
		'Beneficiary.awc_id'=>$data['Beneficiary']['awc_id'],
	),
));
if($is_exist > 0){
	$suspect_score=30;
	$suspect_reason="name****awc";
}
/*End of checking from old Database*/
$this->Beneficiary->setDataSource('default');
if($suspect_score > 0 && $suspect_reason != ''){
  $this->Beneficiary->query("update beneficiaries set
    is_check_suspect=0,
    is_suspect=1,
    suspect_reason='".$suspect_reason."' where id='".$data['Beneficiary']['id']."'");
}else{
  $this->Beneficiary->query("update beneficiaries set
    is_check_suspect=0,
    is_suspect=0 where id='".$data['Beneficiary']['id']."'");
}

  }
exit();
}

}

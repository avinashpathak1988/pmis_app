<?php
App::uses('AppControler','Controller');

class AwcsController extends AppController{
	public $components = array('Paginator', 'Flash', 'Session');

public function beforeFilter(){
	$this->response->disableCache();
	if($this->Session->read('user_auth') == ''){
		$this->redirect(array(
			'controller'=>'dashboard',
			'action'=>'login'
		));
	}
}
public function migration()
{
    $this->layout = 'admin';
    $this->loadModel('Sector');
    $this->loadModel('AwcManual');
    if($this->request->is(array('post','put'))) {
        $ep_awc_codename = $this->data['ep_awc_id'];
        $ep_awc_codename_splits = split(':', $ep_awc_codename);
        
        /*debug($ep_awc_codename_splits);
        echo "UPDATE awc_imports SET is_assign=1 WHERE awc_code='".$ep_awc_codename_splits[0]."' AND is_assign=0 ";
        exit;*/
        $this->AwcManual->id = $this->data['awc_id'];
        if($this->AwcManual->saveField('code' , $ep_awc_codename_splits[0])){
            $this->AwcManual->id = $this->data['awc_id'];
            if($this->AwcManual->saveField('name' , $ep_awc_codename_splits[1])){
                $this->Sector->query("UPDATE awc_imports SET is_assign=1 WHERE awc_code='".$ep_awc_codename_splits[0]."' AND is_assign=0 ");
                $this->message('success', 'Assigned Successfully !');
            }
        }else{
            $this->message('error', 'There was something went wrong !');
        }
    }

    $getAssignedList = $this->AwcManual->find('all', array(
        'conditions' => array(
            //'AwcManual.project_id' => $user['Project']['id'],
            'AwcManual.code IS NOT NULL'
        )
    ));
    $user = $this->Session->read('user_auth');
    $sectorList = $this->Sector->find('list', array(
        'conditions' => array(
            'project_id' => $user['Project']['id']
        ),
        'fields' => array(

        )
    ));
    $this->set(array('sectorList' => $sectorList, 'getAssignedList' => $getAssignedList));

}
public function getnativeawc($sector_id)
{
    $this->layout = 'ajax';
    $this->loadModel('AwcManual');
    $awc_id = $this->AwcManual->find('list', array(
        'conditions' => array(
            'AwcManual.sector_id' => $sector_id,
            'AwcManual.code IS NULL'
        ),
        'order' => array('AwcManual.name' => 'asc')
    ));
    $this->set('awc_id', $awc_id);

}
public function getepragatiawc($sector_id)
{
    $this->layout = 'ajax';
    $this->loadModel('AwcImport');
    $ep_awc_id = $this->AwcImport->find('list', array(
        'conditions' => array(
            'sector_id' => $sector_id,
            'is_assign' => 0
        ),
        'fields' => array(
            'name',
            'awc_name'
        ),
        'order' => array('AwcImport.awc_name' => 'asc')
    ));
    $this->set('ep_awc_id', $ep_awc_id);

}
public function index(){
    $this->layout = 'admin';
    if ($this->request->is(array('post', 'put'))) {
        $sql = "";
        $sql1 = "";
        $sql2 = "";
        $sql3 = "";
        $user = $this->Session->read('user_auth');
        $sql_cond1 = "";
        if ($user['Designation']['name'] == 'DPC') {
            $sql_cond1 = "Awc.project_id IN (SELECT project_id from users where district_id =".$user['District']['id']." )";
        }

        if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
			$sql_cond1 = "Awc.project_id='" . $user['Project']['id'] . "'";
        }

        if (@$this->request->data['Awc']['awc_type'] != '') {
            $sql = "Awc.awc_type = '" . $this->request->data['Awc']['awc_type'] . "'";
        }

        if (@$this->request->data['Awc']['project_id'] != '') {
            $sql1 = "Awc.project_id = '" . $this->request->data['Awc']['project_id'] . "'";
        }

        if (@$this->request->data['Awc']['gp_id'] != '') {
            $sql2 = "Awc.gp_id = '" . $this->request->data['Awc']['gp_id'] . "'";
        }

        if (@$this->request->data['Awc']['sector_id'] != '') {
            $sql3 = "Awc.sector_id = '" . $this->request->data['Awc']['sector_id'] . "'";
        }

        if ($sql == '' && $sql1 == '' && $sql2 == '' && $sql3 == '') {
            $this->message('error', 'Please provide some filter criteria !');
        }
        else {
            $datas = $this->Awc->find('all', array(
                'conditions' => array(
                    $sql_cond1,
                    $sql,
                    $sql1,
                    $sql2,
                    $sql3
                ) ,
                'order' => array(
                    'Awc.name'
                )
            ));
            $this->set(compact('datas'));
        }
    }

    $awc_type = array(
        '0' => 'Mini AWC',
        '1' => 'AWC'
    );
    $total = $this->Awc->find('count');
    $condu = "";
    $user = $this->Session->read('user_auth');
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condu = "Project.id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    if ($user['Designation']['name'] == 'DPC') {
        $condu = "Project.district_id in(select district_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $project_id = $this->Awc->Project->find('list', array(
        'conditions' => array(
            $condu
        ) ,
        'order' => array(
            'Project.name'
        )
    ));
    $condgp = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condgp = "Gp.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    if ($user['Designation']['name'] == 'DPC') {
        $condgp = "Gp.district_id in(select district_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $gp_id = $this->Awc->Gp->find('list', array(
        'conditions' => array(
            $condgp
        ) ,
        'order' => array(
            'Gp.name'
        )
    ));
    $condsector = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condsector = "Sector.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    if ($user['Designation']['name'] == 'DPC') {
        $condsector = "Sector.district_id in(select district_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $sector_id = $this->Awc->Sector->find('list', array(
        'conditions' => array(
            $condsector
        ) ,
        'order' => array(
            'Sector.name'
        )
    ));
    $this->set(compact('awc_type', 'project_id', 'gp_id', 'sector_id', 'total'));
}

/*public function index(){
$total=$this->Awc->find('count');
	$datas=$this->Awc->find('all',array(
	//	'limit'=>'100'
	));
	//echo "data set"; exit();
  $this->set(compact('datas','total'));
}*/

public function add(){
    $this->layout = 'admin';
    if ($this->request->is(array('post', 'put'))) {
        if ($this->Awc->save($this->request->data)) {
            $this->message('success', 'Saved Successfully !');
            $this->redirect(array(
                'action' => 'index'
            ));
        }
        else {
            $this->message('error', 'Saving Failed !');
        }
    }

    $awc_type = array(
        '0' => 'Mini AWC',
        '1' => 'AWC'
    );
    $condu = '';
    $project_cond = '';
    $sector_cond = '';
    $gp_cond = '';
    $user = $this->Session->read('user_auth');
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condu = "Project.id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    if ($user['Designation']['name'] == 'DPC') {
        $project_cond = "Project.district_id = " . $user['District']['id'] . " ";
        $sector_cond = "Sector.district_id = " . $user['District']['id'] . " ";
        $gp_cond = "Gp.district_id = " . $user['District']['id'] . " ";
    }

    $project_id = $this->Awc->Project->find('list', array(
        'conditions' => array(
            $condu,
            $project_cond,
        ) ,
        'order' => array(
            'Project.name'
        )
    ));
    $condgp = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condgp = "Gp.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $gp_id = $this->Awc->Gp->find('list', array(
        'conditions' => array(
            $condgp,
            $gp_cond
        ) ,
        'order' => array(
            'Gp.name'
        )
    ));
    $condsector = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condsector = "Sector.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $sector_id = $this->Awc->Sector->find('list', array(
        'conditions' => array(
            $condsector,
            $sector_cond
        ) ,
        'order' => array(
            'Sector.name'
        )
    ));
    $is_pvtg = array(
        'Y' => 'Yes',
        'N' => 'No'
    );
    $this->set(compact('awc_type', 'project_id', 'gp_id', 'sector_id', 'is_pvtg'));
}

public function edit($id){

    $this->layout = 'admin';
    if ($this->request->is(array('post', 'put'))) {
        if ($this->Awc->save($this->request->data)) {
            $this->message('success', 'Saved Successfully !');
            $this->redirect(array(
                'action' => 'index'
            ));
        }
        else {
            $this->message('error', 'Saving Failed !');
        }
    }

    $awc_type = array(
        '0' => 'Mini AWC',
        '1' => 'AWC'
    );
    $condu = '';
    $project_cond = '';
    $sector_cond = '';
    $gp_cond = '';
    $user = $this->Session->read('user_auth');
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condu = "Project.id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    if ($user['Designation']['name'] == 'DPC') {
        $project_cond = "Project.district_id = " . $user['District']['id'] . " ";
        $sector_cond = "Sector.district_id = " . $user['District']['id'] . " ";
        $gp_cond = "Gp.district_id = " . $user['District']['id'] . " ";
    }

    $project_id = $this->Awc->Project->find('list', array(
        'conditions' => array(
            $condu,
            $project_cond
        ) ,
        'order' => array(
            'Project.name'
        )
    ));
    $condgp = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condgp = "Gp.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $gp_id = $this->Awc->Gp->find('list', array(
        'conditions' => array(
            $condgp,
            $gp_cond
        ) ,
        'order' => array(
            'Gp.name'
        )
    ));
    $condsector = "";
    if ($user['Designation']['name'] == 'PA' || $user['Designation']['name'] == 'CDPO') {
        $condsector = "Sector.project_id in(select project_id from users where user_id='" . $user['User']['user_id'] . "')";
    }

    $sector_id = $this->Awc->Sector->find('list', array(
        'conditions' => array(
            $condsector,
            $sector_cond
        ) ,
        'order' => array(
            'Sector.name'
        )
    ));
    $is_pvtg = array(
        'Y' => 'Yes',
        'N' => 'No'
    );
    $this->set(compact('awc_type', 'project_id', 'gp_id', 'sector_id', 'is_pvtg'));
    $this->request->data = $this->Awc->findById($id);
}

public function delete($id){
  $this->Awc->delete($id);
  $this->message('success','Deleted Successfully !');
	?>
<script type="text/javascript">
	alert("Awc Deleted Successfully !");
</script>
	<?php
  $this->redirect(array('action'=>'index'));
}

}

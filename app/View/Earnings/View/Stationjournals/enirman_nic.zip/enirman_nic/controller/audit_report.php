
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?require_once("./common/meta_tags.php");?>
<title><?php echo $page_title?></title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<script language="javascript" type="text/javascript" src="javascripts/calendar.js"></script>
<script language="javascript" type="text/javascript" src="javascripts/block_ui.js"></script>




<style>
    font-family:Verdana, Geneva, sans-serif;
    font-size:14px;}

    #slidingDiv
    {
        display: none;
        overflow:auto;
        background-color: ;
        padding:0px;
        margin-top:10px;
    }
div.growlUI { background: url(images/ajax_process.gif) no-repeat; background-position: center center; height: 85px;font-size:13px; color: white;  }
div.growlUI h4, div.growlUI h5 {color: white; padding: 5px 5px 5px 10px; text-align: left !important;}
</style>
</head>
<body class="bodymain">
<input type="hidden" name="tcount" id="tcount" value="<?php echo $listing_cnt?>" />
<table border="0" cellspacing="0" cellpadding="0" align="center" class="maintable">
<? include_once ('common/header.php'); ?>
  <tr>
    <td colspan="2">
		<table align="center" cellpadding="" cellspacing="0" width="100%" id='detable'>
			<tr>
				<td valign="top" align="center">
                <?
                if(isset($_SESSION['updatemsg']) && $_SESSION['updatemsg'] != '')
                {
                ?>
                    <table width="98%" class="blu2b"  style="margin-bottom:5px; font-weight:bold; text-align:center;" >
                <?
                    echo "<tr><td height='5' align='center'><span class='blu5b'>".$_SESSION['updatemsg']."</span></td></tr>";
                ?>
                    </table>
                <? unset($_SESSION['updatemsg']);
                }
                ?>
					<!-- Content Area Starts -->
                    <form name="frmFMS" method="POST" action="" autocomplete="OFF">
					<table width="100%" cellpadding="4" cellspacing="0" border="0"  width="100%" class="entrytable">
                        <tr class="entrytabletr2">
                            <td align="left" class="blk1" width="20%">Form Name :</td>
                            <td align="left" class="blk1" width="20%">



<select name="form_name" id="form_name" class="" >
                <option value="">--Select Form--</option>
                <?   
                    $query_sql = "select distinct form_name FROM audit_log";
                    //$query_sql.= " ORDER BY power_no asc ";
                    //$query_sql.="where power_id NOT IN ('pmu','EIC')";
                    $res_deg = pg_query($query_sql);
                    if(@pg_num_rows($res_deg) != 0)
                    {
                        while($row_get_deg = pg_fetch_assoc($res_deg))
                        {           
                ?>              
                    <option value="<?php echo $row_get_deg['form_name']?>"><?php echo $row_get_deg['form_name']?></option>
                <?
                           
                        }
                    }
                ?>   
             </select>






                        </td>
                        <td align="center">
                            <input type="button" name="submit" value="Search" class="btn" onClick="javascript: getAuditReport();" />                                            
                        </td>                            
                    </tr>       
                    </table>
                    </form>
					<!-- Ends of Content Area -->
				</td>
			</tr>
			<tr>
				
			</tr>			
			<tr>
				
			</tr>            
            <tr>
				<td height="350" valign="top">
					<div id="audit_listing_div">
						
					</div>
				</td>
			</tr>
		</table>
	</td>
  </tr>
<? include_once ('common/footer.php'); ?>
</table>

<script language="javascript" type="text/javascript">
    function getAuditReport(){
        var formname = document.getElementById('form_name').value;
        if(formname != ''){
            var ajax = new AJAX();
            var arrParam = new Array();
            arrParam['formname'] = formname;
            ajax.getRequest('./controller/includeAuditReport.php', arrParam, showAudit);  
           
        }
        else{
            alert('Please Select Form Name')
             document.getElementById('audit_listing_div').innerHTML = '';
        }       
    }
    function showAudit(retVaL){
         document.getElementById('audit_listing_div').innerHTML = '';
        document.getElementById('audit_listing_div').innerHTML = retVaL;
    }
</script>

</body>
</html>

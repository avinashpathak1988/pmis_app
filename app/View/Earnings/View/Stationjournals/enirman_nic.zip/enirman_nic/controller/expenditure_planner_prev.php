<?php
$wid = (isset($_GET['wid']) && $_GET['wid'] != 0)?(int) $_GET['wid']:0;
$fisyear = (isset($_GET['fisyear']) && $_GET['fisyear'] != '' ? $_GET['fisyear'] : '') ;
$sess_user_id = $_SESSION["sess_user_id"];
if(isset($_GET['limit'])){
$limit=$_GET['limit'];
}

if(isset($_GET['limit']))
{
	$page1=$_GET['page1'];
}
$modified=date("Y-m-d H:i:s");

//Update Work allotment list
if(isset($_POST['submit']) && $_POST['submit'] == 'Update')
{
    extract($_POST);
    //echo "<pre>";print_r($_POST);exit;
	if(!empty($fisYearMonthArr)){
		foreach($fisYearMonthArr as $key => $val){
			$yearMonArr = @explode("-",$val);
			//****************** check in pm_update_work_allotment entry for paricular month and year ***********************
			$check_is_updated = "SELECT * FROM pm_update_work_allotment WHERE uwa_work_id =".$wid;
			$check_is_updated.= " AND uwa_month =".$yearMonArr[1];
			$check_is_updated.= " AND uwa_year =".$yearMonArr[0];
			//echo $check_is_updated;
			$res_check_is_updated = pg_query($check_is_updated);
			$update_res = pg_fetch_assoc($res_check_is_updated);
			$count_check_is_updated = pg_num_rows($res_check_is_updated);
			//echo $count_check_is_updated;exit;
			
			$prop_exp = "prop_exp_".$yearMonArr[0]."_".$yearMonArr[1];
			$act_exp = "act_exp_".$yearMonArr[0]."_".$yearMonArr[1];
			$remarks = "remarks_".$yearMonArr[0]."_".$yearMonArr[1];
			$misc_exp = "misc_exp_".$yearMonArr[0]."_".$yearMonArr[1];
			$expanditure_update = "expanditure_update_".$yearMonArr[0]."_".$yearMonArr[1];
			//echo $prop_exp.'<br/>'.$$prop_exp.'<br/>'.$remarks;exit;
			$update_res['exp_amount'] = ($update_res['exp_amount']!= '')?$update_res['exp_amount']:'NULL';
			$update_res['act_amount'] = ($update_res['act_amount']!= '')?$update_res['act_amount']:'NULL';
			$update_res['uwa_remarks'] = ($update_res['uwa_remarks']!= '')?$update_res['uwa_remarks']:'';
			$update_res['misc_amount'] = ($update_res['misc_amount']!= '')?$update_res['misc_amount']:'NULL';
			
			
			$$prop_exp =  ($$prop_exp != '')?$$prop_exp:'NULL';
			$$act_exp =  ($$act_exp != '')?$$act_exp:'NULL';
			$$remarks =  ($$remarks != '')?$$remarks:'';
			$$misc_exp =  ($$misc_exp != '')?$$misc_exp:'NULL';
			$$expanditure_update =  ($$expanditure_update != '')?$$expanditure_update:NULL;
            //echo "ggg-".$$prop_exp."<br>";
			/*echo "##".$expanditure_update;
			echo "###".$$expanditure_update."<br>";*/
			//echo $expanditure_update_2015_04
			//echo $$expanditure_update_2016-02;
			
			//echo $prop_exp.'<br/>'.$act_exp.'<br/>'.$remarks;exit;
			
			$$remarks = addslashes($$remarks);
			$$remarks = addQuoteMS($$remarks);
			//echo $yearMonArr[1];exit;
			
			if(trim($$prop_exp)!= 'NULL')
				$exp_updation_status = 'Y'; 
			else
				$exp_updation_status = 'N';
			if((int)$$act_exp > 0 || trim($$remarks)!= '')
				$act_updation_status = 'Y';
			else
				$act_updation_status = 'N';
				
			if($count_check_is_updated > 0){
				//=====================================================================================
				if($update_res['exp_amount'] != $$prop_exp || $update_res['act_amount'] !=$$act_exp || $update_res['misc_amount'] !=$$misc_exp || $update_res['uwa_remarks'] !=$$remarks){
					$select_query = "SELECT * FROM pm_update_work_allotment WHERE  uwa_work_id =".$wid." AND uwa_month =".$yearMonArr[1]." AND uwa_year =".$yearMonArr[0]."";
					//echo $select_query; exit;
					$select_query_res = pg_query($select_query);
					autit_log('pm_update_work_allotment' ,pg_fetch_assoc($select_query_res) ,'Before Update', $page_title);
				}
				//=====================================================================================
				$update_exe_proccess_detail = " UPDATE pm_update_work_allotment SET";
				$update_exe_proccess_detail.= "  exp_amount = ".$$prop_exp." ";
				$update_exe_proccess_detail.= ",  act_amount = ".$$act_exp." ";
				$update_exe_proccess_detail.= ",  misc_amount = ".$$misc_exp." ";
				$update_exe_proccess_detail.= ",  uwa_remarks = '".$$remarks."'";
				$update_exe_proccess_detail.= ",  exp_updation_status = '".$exp_updation_status."'";
				$update_exe_proccess_detail.= ",  act_updation_status = '".$act_updation_status."'";
				$update_exe_proccess_detail.= ",  uwa_date_added = now() ";
				$update_exe_proccess_detail.= ",  expanditure_update =now()";
				//priviously add this
				//$update_exe_proccess_detail.= ",  expanditure_update ='".$act_updation_status."'";
				$update_exe_proccess_detail.= ",  modified ='".$modified."' ";
				$update_exe_proccess_detail.= "  WHERE  uwa_work_id =".$wid;
				$update_exe_proccess_detail.= " AND uwa_month =".$yearMonArr[1];
				$update_exe_proccess_detail.= " AND uwa_year =".$yearMonArr[0];
				 //echo $update_exe_proccess_detail;exit;
				
				pg_query($update_exe_proccess_detail);
				//=====================================================================================
				if($update_res['exp_amount'] != $$prop_exp || $update_res['act_amount'] !=$$act_exp || $update_res['misc_amount'] !=$$misc_exp || $update_res['uwa_remarks'] !=$$remarks){
					$select_query = "SELECT * FROM pm_update_work_allotment WHERE  uwa_work_id =".$wid." AND uwa_month =".$yearMonArr[1]." AND uwa_year =".$yearMonArr[0]."";
					//echo $select_query;exit;
					$select_query_res = pg_query($select_query);
					autit_log('pm_update_work_allotment' ,pg_fetch_assoc($select_query_res) ,'After Update', $page_title);
				}
				//=====================================================================================
				$get_disallow_work_sql = "UPDATE allow_work_update set is_enable = 0 WHERE work_id = ".$wid." ";
				//echo $get_disallow_work_sql;exit;
				pg_query($get_disallow_work_sql);
				 //exit();
			}else{
				//Get allotment ID
				$uwa_id = getAllotmentID($wid);
				$expenditure_incured = '';
				$physical_achive_made = '';
				$physical_work_progress = 0.00;
				$during_work_progress = 0.00;
				$post_work_progress = 0;
				
				$insert_exe_proccess_detail =  " INSERT INTO pm_update_work_allotment ";
				$insert_exe_proccess_detail .= " (uwa_wa_id,uwa_month,uwa_year,expenditure_incured,physical_achive_made,physical_work_progress,during_work_progress,post_work_progress,uwa_remarks,uwa_date_added,updated_by,exp_amount,act_amount,misc_amount,exp_updation_status,act_updation_status,physical_progress_status,uwa_work_id,modified)";
				$insert_exe_proccess_detail .= " VALUES ";
				$insert_exe_proccess_detail .= " ($uwa_id,".$yearMonArr[1].",".$yearMonArr[0].",'".$expenditure_incured."','".$physical_achive_made."',$physical_work_progress,$during_work_progress,$post_work_progress,'".$$remarks."',now(),$sess_user_id,".$$prop_exp.",".$$act_exp.",".$$misc_exp.",'".$exp_updation_status."','".$act_updation_status."','N',$wid,'$modified') ";
				 //echo $insert_exe_proccess_detail;

				pg_query($insert_exe_proccess_detail);
				//=====================================================================================
				if($update_res['exp_amount'] != $$prop_exp || $update_res['act_amount'] !=$$act_exp || $update_res['misc_amount'] !=$$misc_exp || $update_res['uwa_remarks'] !=$$remarks){
					$select_query = "SELECT * FROM pm_update_work_allotment WHERE  uwa_work_id =".$wid." AND uwa_month =".$yearMonArr[1]." AND uwa_year =".$yearMonArr[0]."";
					//echo $select_query;exit;
					$select_query_res = pg_query($select_query);
					autit_log('pm_update_work_allotment' ,pg_fetch_assoc($select_query_res) ,'After Update', $page_title);
				}
				//=====================================================================================
				//exit();
			}
		}
		//exit;
	}
	//echo $update_exe_proccess_detail;
	//exit;
	$update_msg = "Financial updation detail has been saved successfully.";
    $msg = "Financial updation detail has been saved successfully.";
    $msg= base64_encode($msg);



	if(isset($update_msg) && $update_msg != '')
	{
		echo '<table width="98%" class="blu1b" style="margin-bottom:5px; font-weight:bold; text-align:center;" >';
			echo "<tr><td height='5' align='center'><img src='images/tick.png'> &nbsp;<span class='blu2b'>".$update_msg."</span></td></tr>";
		echo '</table>';
	}


    //echo "###".$update_msg;

    // /work_updated_id=6078
    //Old Url : header("Location: index.php?page=192&work_updated_id=".$wid."&limit=".$limit."&page1=".$page1."&msg=".urlencode($msg)."&xpworkid=".$wid);
	//header("Location: index.php?page=192&work_updated_id=".$wid."&msg=".urlencode($msg));	
    //exit(0);    	
	
}

//get work detail
$get_work_sql = "SELECT * FROM pm_works WHERE work_id = ".$wid." ";
$get_work_res = pg_query($get_work_sql);
$get_work_cnt = pg_num_rows($get_work_res);
if($get_work_cnt > 0)
{
	extract(pg_fetch_assoc(pg_query($get_work_sql)));
}
//$get_allow_work_sql = "SELECT * FROM allow_work_update";
// $get_allow_work_sql = "SELECT * FROM allow_work_update WHERE work_id = ".$wid." ";
// $get_allow_work_res = pg_query($get_allow_work_sql);
// $get_allow_work_cnt = pg_num_rows($get_allow_work_res);

include_once ('./view/expenditure_planner_prev.html');
?>


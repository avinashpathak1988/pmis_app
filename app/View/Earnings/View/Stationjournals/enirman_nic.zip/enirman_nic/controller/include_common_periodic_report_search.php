<script type="text/javascript">
	$(document).ready(function(){
		$("#toMonth").change(function(){
			var toMonthVal = parseInt($(this).val());
			$("#fromMonth").val(toMonthVal);
		})
		$("#toYear").change(function(){
			var toYearVal = parseInt($(this).val());
			$("#fromYear").val(toYearVal);
		})
	})
</script>					
					<tr>
							<td>
								<table width="100%" cellspacing="2" cellpadding="4" style="margin-bottom:20px;"  border="0" align="left" class="searchtable">
									<tr bgcolor="">
										<td align="left" colspan="5">
											<table cellpadding="2" cellspacing="1" border="0" width="100%">
																							
												<tr>
                                                    <td align="left" class="blk1" width="15%" style="display: none">From Month/Year:</td>
                                                    <td align="left" class="blk1" style="display: none">	
                                                        <?php  DateSelector("from",0,$fromMonth,$fromYear); ?> 
                                                    </td>
                                                    <td align="left" class="blk1">Month/Year:</td>
                                                    <td align="left" class="blk1"  >	
                                                        <?php  DateSelector("to",0,$toMonth,$toYear); ?> 
                                                    </td>                                                    
                                                </tr>
                                                <tr>
													<td align="left" class="blk2" valign="top">Scheme  :</td>
													<td align="left" colspan="3" class="blk2">														 
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"  >
                                                            <tr>
<?php
                                    //print_r($scharr);
                                    $query_fund = "SELECT * FROM pm_fund order by fund_name";
                                    $res_fund = pg_query($query_fund);
									if(@pg_num_rows($res_fund)!= 0)
									{
										while($row_fund = pg_fetch_assoc($res_fund))
										{  
?>			  
                                                                <td width="20%">
                                                                    <input type="checkbox" name="scharr[]" class="abstractcls" value="<?php echo $row_fund['fund_id']?>" <?if(isset($scharr) && in_array($row_fund['fund_id'],$scharr)){?>checked = "checked" <?}?> >&nbsp;<?php echo $row_fund['fund_name']?>
                                                                 </td>
											  
<?php
											$breaker++;
											if($breaker == 2)
											{
												echo "</tr><tr>";
												$breaker = 0;
											}

										}
?>
                                                        </tr>	
<?php
									}  
  ?>								
                                                     </table> 
												  </td>                                                    
                                                </tr>
                                                                                            
                                                <tr>
													<td align="left" class="blk1">Wing :</td>
													<td align="left" class="blk1"  >														
														<select name="wings_id" id="wings_id" class="tbox">
<?php
if($_SESSION["sess_power_id"] != 'CE'){
?>															
															<option value="0">--All Wing--</option>
<?php }
?>
															
<?php
    $wing_sql = "SELECT * FROM pm_wings ";
	if($_SESSION["sess_power_id"] == 'CE'){
		$wing_sql.= " WHERE wings_id = ".$_SESSION["sess_wings_id"]." ";
	}
    $wing_res = pg_query($wing_sql);    
    if(@pg_num_rows($wing_res) != 0)
    {
        while($row_wing = pg_fetch_assoc($wing_res))
        {
?>
															 <option value="<?php echo $row_wing['wings_id']?>" <?php echo ($wings_id == $row_wing['wings_id'])? 'selected="selected"': '' ?>><?php echo $row_wing['wings_name']?></option>
<?php
	}
     }	
?>
														</select>
													</td>
												</tr>                                                                                           
												<tr>
													<td align="left" class="blk1">Circle :</td>
													<td align="left" class="blk1"  >
														<input type="hidden" id="circle_id_hide" value="Circle" />
														<select name="circle_id" id="circle_id" class="tbox" onChange="getDivisionSearch(this.value);">
<?php
if($session_power == 'EIC' || $session_power == 'CE')
{
?>
                                <option value="0">--All Circle--</option>
<?php
}
else
{
    $circle_name = "";
    $cid = 0;
    //Get circle name from DB

    
    $query_user_cid = "SELECT district_id AS distid, division_id AS divid, circle_id AS cid FROM pm_auth_user";
    $query_user_cid.= " WHERE user_id = ".$session_user_id;
    $res_user_cid = pg_query($query_user_cid);
    if(@pg_num_rows($res_user_cid) != 0)
        @extract(pg_fetch_assoc($res_user_cid));
}
    //Get circle name from DB
    
    $query = "SELECT * FROM circle WHERE is_active = 'Y' ";
    if($cid != 0)
        $query.= " AND circle_id = ".$cid;
    $query.= " ORDER BY circle_name";
    $res_circle = pg_query($query);
    if(@pg_num_rows($res_circle) != 0)
    {
        while($row_circle = pg_fetch_assoc($res_circle))
        {
?>
                                <option value="<?php echo $row_circle['circle_id']?>" <?php echo ($circle_id == $row_circle['circle_id'])? 'selected="selected"': '' ?>><?php echo $row_circle['circle_name']?></option>
<?
        }
    }
?>
                            </select>
                        </td>
                        <td align="left" class="blk1" >Division :</td>
                        <td align="left" class="blk1">
                        <div id="division_list">
                        <input type="hidden" id="division_id_hide" value="Division" />
<?

if($session_power == 'EIC' || $session_power == 'CE')
{
    if($submit == 'Show')
    {
?>
                            <select name="division_id" class="tbox"  id="division_id" class="tbox" >
                                <option value="0">--Select--</option>
<?
        if($circle_id != 0)
        {
            $query = "SELECT * FROM division";
            $query .= " WHERE circle_id = $circle_id";

            $res = @pg_query($query);
            if(@pg_num_rows($res)!= 0)
            {
                while($row = pg_fetch_assoc($res))
                {
?>
                                <option value="<?php echo $row["division_id"]?>" <?php echo ($row['division_id'] == $division_id)? 'selected="selected"': '' ?>>
<? 
                     $sub_query = "SELECT division_name FROM division WHERE division_id = ".$row['division_id'];
                     @extract(pg_fetch_assoc(pg_query($sub_query)));  
                     echo $division_name;
?>
                                </option>
<?
                }
            }
        }
?>
                            </select>
<?
    }
    else
    {
?>         
                            <select id="division_id" name="division_id" disabled="disabled" class="tbox" >
                                <option value="0">--Select--</option>
                            </select>
<?
    }
}
else
{
    //Get all Division name from database
    if($cid != 0 )
    {
        $query = "SELECT * FROM division";
        if($session_power == 'SE')
            $query.= " WHERE circle_id = ".$cid;
        else
            $query.= " WHERE division_id = ".$divid;
    }
    $query.= " ORDER BY division_name ";
    $res = @pg_query($query);
    if(@pg_num_rows($res)!= 0)
    {
?>
                            <select name="division_id" class="tbox"  id="division_id"  style="width:200px" OnChange="getDistrictSearch(this.value);">
<?
if($session_power == 'EIC' || $session_power == 'CE' || $session_power == 'SE')
{
?> 
                                <option value="0">--Select--</option>
<?
}
        while($row = pg_fetch_assoc($res))
        {
?>
                                <option value="<?php echo $row["division_id"]?>" <?php echo ($row['division_id'] == $division_id)? 'selected="selected"': '' ?>>
<? 
              
             $sub_query = "SELECT division_name FROM division WHERE division_id = ".$row['division_id'];
             @extract(pg_fetch_assoc(pg_query($sub_query)));  
             echo $division_name;
?>
                                </option>
<?
        }
    }
?>
                            </select>
<?
}
?>            
                            </div>
                        </td>
					</tr>
					<tr>
						<td class="blk2">Sub Division : </td>
						<td>
							<div id="SubdivList">
<?
if($submit == 'Show')
{
		if($division_id !=0)
		{
						$get_sub_div_sql = "SELECT * FROM subdivision WHERE division_id = ".$division_id." ";
						if($session_power == 'AE')
						{		
							$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
						}	
						if($session_power == 'JE')
						{		
							$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
						}						
						$get_sub_div_res = pg_query($get_sub_div_sql);
				if(@pg_num_rows($get_sub_div_res)!= 0)
				{
?>
							<select name="sub_division_id" class="tbox"  id="sub_division_id"  style="width:200px" onchange="javascript : getsectionname(this.value);">
								
<?
if($session_power != 'JE' && $session_power != 'AE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>
<?
						while($get_sub_div_row = pg_fetch_assoc($get_sub_div_res))
						{
    
?>
								 <option value="<?php echo $get_sub_div_row["sub_division_id"]?>" <?php echo ($get_sub_div_row["sub_division_id"] == $sub_division_id)? 'selected="selected"':'' ?>><?php echo $get_sub_div_row['sub_division_name']?></option>
<?

						}
				}
   
?>
						        </select>
<?
		}
		else
		{
?>	
						       <select name="sub_division_id"  id="sub_division_id"   disabled="disabled">
									<option value="0">--Select Sub Division--</option>		
							</select>
<?
		}
}
else
{
		$get_sub_div_sql = "SELECT * FROM subdivision WHERE division_id = ".$_SESSION["session_division_id"]." ";
		if($session_power == 'AE')
		{		
			$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		}
		if($session_power == 'JE')
		{		
			$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		}		
		//echo $get_sub_div_sql;
		$get_sub_div_res = pg_query($get_sub_div_sql);		
		if(@pg_num_rows($get_sub_div_res)!= 0)
		{
?>

					<select name="sub_division_id" class="tbox"  id="sub_division_id"  style="width:200px" onchange="javascript : getsectionname(this.value);">
<?
if($session_power != 'JE' && $session_power != 'AE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>						
<?
				while($get_sub_div_row = pg_fetch_assoc($get_sub_div_res))
				{

?>
						 <option value="<?php echo $get_sub_div_row["sub_division_id"]?>" <?php echo ($get_sub_div_row["sub_division_id"] == $_SESSION["session_sub_division_id"])? 'selected="selected"':'' ?>><?php echo $get_sub_div_row['sub_division_name']?></option>
<?

				}
?>
					 </select>		
<?
		}
		else
		{
?>	
						       <select name="sub_division_id"  id="sub_division_id"   disabled="disabled">
									<option value="0">--Select Sub Division--</option>		
							</select>
<?
		}


}
?>
							</div>
						</td>
						<td class="blk2">Section : </td>
						<td>
							<div id="sectiondivList">
							
<?															
if($submit == 'Show')
{
		
		if($sub_division_id !=0)
		{		
				$get_section_sql = "SELECT * FROM section WHERE sub_division_id = ".$sub_division_id." ";
				if($session_power == 'JE')
				{		
					$get_section_sql .= " AND section_id = ".$_SESSION["session_section_id"]." ";
				}				
				$get_section_res = pg_query($get_section_sql);
				if(@pg_num_rows($get_section_res)!= 0)
				{
?>
						<select name="section_id" class="tbox"  id="section_id"  style="width:200px">
<?
if($session_power != 'JE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>							
<?
								while($get_section_row = pg_fetch_assoc($get_section_res))
								{
    
?>
										<option value="<?php echo $get_section_row["section_id"]?>" <?php echo ($get_section_row["section_id"] == $section_id)? 'selected="selected"':'' ?> ><?php echo $get_section_row['section_name']?></option>
<?

								}
				}
   
?>
						</select>							
<?
		}
		else
		{
?>
							
							
							
								<select name="section_id"  id="section_id"   disabled="disabled">
									<option value="0">--Select Section--</option>		
								</select>
								
<?
		}
}
else
{
	
		$get_section_sql = "SELECT * FROM section WHERE sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		if($session_power == 'JE')
		{		
			$get_section_sql .= " AND section_id = ".$_SESSION["session_section_id"]." ";
		}		
		$get_section_res = pg_query($get_section_sql);
		if(@pg_num_rows($get_section_res)!= 0)
		{
?>
				<select name="section_id" class="tbox"  id="section_id"  style="width:200px">
<?
if($session_power != 'JE')
{
?>				
								<option value="0">--Select--</option>
<?
}
?>								
<?
						while($get_section_row = pg_fetch_assoc($get_section_res))
						{

?>
								<option value="<?php echo $get_section_row["section_id"]?>" <?php echo ($get_section_row["section_id"] == $_SESSION["session_section_id"])? 'selected="selected"':'' ?> ><?php echo $get_section_row['section_name']?></option>
<?

						}
		

?>
				</select>			
<?
		}
		else
		{
?>	
				<select name="section_id"  id="section_id"   disabled="disabled">
					<option value="0">--Select Section--</option>		
				</select>
<?
		}


}
?>								
							</div>
						</td>
					</tr>					
					
					
					
					
					
					<tr>	

								</tr>
                    
								<tr>
										
								</tr>
							</table>										
										
										
										
										</td>
									</tr>

									<tr>
										<td align="center" colspan="4">
											<input type="submit" name="submit" value="Show" class="btn" onClick="javascript:return validateForm();" />
											&nbsp;<input type="button" value="Reset" class="btn" onClick="javascript:self.location='index.php?page=233'" />
										</td>
									</tr>
								</table>
							</td>
						</tr>
<?php 
//echo '<pre>';
//print_r($_SESSION);
if(isset($_POST['submit']) && $_POST['submit'] == 'Save'){
    //$_SESSION['mobile'] = $_POST['mobile_no'];
    //print_r($_POST);exit;
    extract($_POST);
    //print_r($month);exit;
        //$insert_query = "insert into allow_work_update (user_id,year,month,work_id) values(".$user_id.",'".$year."','".$month."',".$work_id.")";
        //echo $insert_query;exit;
    foreach ($_POST['month'] as $month)
{
    $insert_query = "insert into allow_work_update (user_id,year,month,work_id) values(".$user_id.",'".$year."','".$month."',".$work_id.")";
    $select_res = pg_query($insert_query);
}
//exit;
        
        if($select_res){
            $_SESSION['updatemsg'] = "Data Inserted successfully";
            header('location:index.php?page=347');
        }else{
            $_SESSION['updatemsg'] = "Data failed to Insert";
            header('location:index.php?page=347');
        }
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?require_once("./common/meta_tags.php");?>
<title><?php echo $page_title?></title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<script language="javascript" type="text/javascript" src="javascripts/calendar.js"></script>
<script language="javascript" type="text/javascript" src="javascripts/block_ui.js"></script>




<style>
    font-family:Verdana, Geneva, sans-serif;
    font-size:14px;}

    #slidingDiv
    {
        display: none;
        overflow:auto;
        background-color: ;
        padding:0px;
        margin-top:10px;
    }
div.growlUI { background: url(images/ajax_process.gif) no-repeat; background-position: center center; height: 85px;font-size:13px; color: white;  }
div.growlUI h4, div.growlUI h5 {color: white; padding: 5px 5px 5px 10px; text-align: left !important;}
</style>
</head>
<body class="bodymain">
<input type="hidden" name="tcount" id="tcount" value="<?php echo $listing_cnt?>" />
<table border="0" cellspacing="0" cellpadding="0" align="center" class="maintable">
<? include_once ('common/header.php'); ?>
  <tr>
    <td colspan="2">
		<table align="center" cellpadding="" cellspacing="0" width="100%" id='detable'>
			<tr>
				<td valign="top" align="center">
                <?
                if(isset($_SESSION['updatemsg']) && $_SESSION['updatemsg'] != '')
                {
                ?>
                    <table width="98%" class="blu2b"  style="margin-bottom:5px; font-weight:bold; text-align:center;" >
                <?
                    echo "<tr><td height='5' align='center'><span class='blu5b'>".$_SESSION['updatemsg']."</span></td></tr>";
                ?>
                    </table>
                <? unset($_SESSION['updatemsg']);
                }
                ?>
					<!-- Content Area Starts -->
                    <form name="frmFMS" method="POST" action="" autocomplete="OFF">
					<table cellpadding="6" cellspacing="0" border="0"  align="center" width="100%">
						<tr>
							<td colspan="5" height="8px"></td>
						</tr>
						<tr>
                            <td>
                                <table width="100%" cellspacing="2" cellpadding="4" style="margin-bottom:20px;"  border="0" align="left" class="searchtable">
                                    <tr bgcolor="">
                                        <td align="left" colspan="5">
                                            <table cellpadding="2" cellspacing="1" border="0" width="100%">
                                                                                            
                                             <tr style="height:100px;">
                                                    
                                               <td align="left" class="blk1">Circle Name :</td>
                                                    <td align="left" class="blk1" colspan="3">
                                                         <select name="circle_id" id="circle_id" class="validate[required]" onchange="get_username(this.value)">
                                                            <option value="">--Select User--</option>
                                                            <?   
                                                                //$query_sql = "SELECT * from pm_auth_user WHERE power_id NOT IN('EIC','pmu') ORDER BY power_no ASC";
                                                                $circle_sql = "select * from circle order by circle_name asc";
                                                                //$query_sql.= " ORDER BY power_no asc ";
                                                                //$query_sql.="where power_id NOT IN ('pmu','EIC')";
                                                                $circle_deg = pg_query($circle_sql);
                                                                if(@pg_num_rows($circle_deg) != 0)
                                                                {
                                                                    while($circle_get_deg = pg_fetch_assoc($circle_deg))
                                                                    {           
                                                            ?>              
                                                                <option value="<?php echo $circle_get_deg['circle_id']?>"><?php echo $circle_get_deg['circle_name']?></option>
                                                            <?
                                                                       
                                                                    }
                                                                }
                                                            ?>   
                                                         </select>
                                                    </td>
                                             </tr>                                              
                                             <tr>
                                                    <td align="left" class="blk1">User Name :</td>
                                                    <td align="left" class="blk1" colspan="3">
                                                         <select name="user_id" id="user_id" class="validate[required]" onchange="get_workname(this.value)">
                                                            <option value="">--Select User--</option>
                                                            <!-- ss<?   
                                                                //$query_sql = "SELECT * from pm_auth_user WHERE power_id NOT IN('EIC','pmu') ORDER BY power_no ASC";
                                                                $query_sql = "SELECT * from pm_auth_user ORDER BY power_no ASC";
                                                                //$query_sql.= " ORDER BY power_no asc ";
                                                                //$query_sql.="where power_id NOT IN ('pmu','EIC')";
                                                                $res_deg = pg_query($query_sql);
                                                                if(@pg_num_rows($res_deg) != 0)
                                                                {
                                                                    while($row_get_deg = pg_fetch_assoc($res_deg))
                                                                    {           
                                                            ?>              
                                                                <option value="<?php echo $row_get_deg['user_id']?>"><?php echo $row_get_deg['user_name']?></option>
                                                            <?
                                                                       
                                                                    }
                                                                }
                                                            ?>   --> 
                                                         </select>
                                                    </td>
                                                                    
                                                    <td align="left" class="blk2">Year  :</td>
                                                    <td align="left">
                                                
    
<?php
function yearDropdownMenu($start_year, $end_year = null, $id='year', $selected=null) {
 
        // curret year as end year
 $end_year = is_null($end_year) ? date('Y') : $end_year;
 
 // the current year
        $selected = is_null($selected) ? date('Y') : $selected;
 
        // range of years 
        $r = range($start_year, $end_year);
 
        //create the HTML select
        $select = '<select name="'.$id.'" id="'.$id.'">';
        foreach( $r as $year )
        {
            $select .= "<option value=\"$year\"";
            $select .= ($year==$selected) ? ' selected="selected"' : '';
            $select .= ">$year</option>\n";
        }
        $select .= '</select>';
        return $select;
    }
    echo yearDropdownMenu(date('Y')-8);
?>                                  
                                                  </td>                                                 
                                                </tr>                                                                                           
                                <tr>
                                                    <td align="left" class="blk1">Month :</td>
                                                    <td align="left" class="blk1" colspan="3">
                                                          <select name="month[]" style="width:143px" multiple>
                                                            <option value="1">Janaury</option>
                                                            <option value="2">February</option>
                                                            <option value="3">March</option>
                                                            <option value="4">April</option>
                                                            <option value="5">May</option>
                                                            <option value="6">June</option>
                                                            <option value="7">July</option>
                                                            <option value="8">August</option>
                                                            <option value="9">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>
                                                            </select> 
                                                            </br><span style="color:red;">Use ctrl button for multiple select</span>
                                                    </td>
                                                                    
                                                    <td align="left" class="blk2">Project  :</td>
                                                    <td align="left">
                                                        <select name="work_id" id="work_id" class="tbox" >
                                                           <option value="">----All Works Code----</option>
                                               </select>
                                                  </td>                                                 
                                                </tr>  
                                                
                    
                    
                    
                    
                    <tr>    

                                </tr>
                    
                                <tr>
                                        
                                </tr>
                            </table>                                        
                                        
                                        
                                        
                                        </td>
                                    </tr>

                                    <tr>
                                        <td align="center" colspan="4">
                                        <input type="submit" name="submit" value="Save" class="btn"/>
                                        <input type="button" value="Reset" class="btn" onClick="javascript:self.location='index.php?page=347'"  />                                          
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>							

						<tr>
							<td colspan="5" height="8px"></td>
						</tr>
					</table>
                    </form>
					<!-- Ends of Content Area -->
				</td>
			</tr>
			<tr>
				
			</tr>			
			<tr>
				
			</tr>            
            <tr>
				<td height="350" valign="top">
					<div id="ajax_work_listing_div">
						
					</div>
				</td>
			</tr>
		</table>
	</td>
  </tr>
<? include_once ('common/footer.php'); ?>
</table>

<script language="javascript" type="text/javascript">
$(document).ready(function() {
    getUpdateworklisting();
});
		var obj;
		obj = document.frmFMS;
        function get_workname(userid){
            $.post("controller/add_update.php",
        {
            userid: userid,
        },
        function(data, status){//alert(data);
           $('#work_id').html(data);
        }); 
        }

         function get_username(circleid){
            $.post("controller/add_updateuser.php",
        {
            circleid: circleid,
        },
        function(data, status){//alert(data);
           $('#user_id').html(data);
        }); 
        }

        function getUpdateworklisting(){
            $.post("controller/include_update_work.php",
        {
            
        },
        function(data, status){
           $('#ajax_work_listing_div').html(data);
        });
            /*document.getElementById('ajax_work_listing_div').innerHTML = '<img src="./images/ajax-loader.gif"/>';
            var ajax = new AJAX();
            var arrParam = new Array();
            ajax.getRequest('./controller/include_update_work.php', arrParam, showResponseWorklisting);   */ 
        
        }
        /*function showResponseWorklisting(retVaL){
            document.getElementById('ajax_work_listing_div').innerHTML = '';
            document.getElementById('ajax_work_listing_div').innerHTML = retVaL;
        }*/
        function disableuserupdate(id,status){
            $.post("controller/disable_user_update.php",
            {
                id: id,
                status:status,
            },
            function(data, status){//alert(data);
                window.location.reload();
               
            }); 
        }
        function deleteuserupdate(id){
            $.post("controller/delete_user_update.php",
            {
                id: id,
            },
            function(data, status){//alert(data);
                window.location.reload();
               
            }); 
        }
</script>

</body>
</html>

<?
$pono = $_SESSION['sess_po_no'];

define("ISEXCEL", "Y");
define("ISPRINT", "N");

$query_Work_lising_sql = $_SESSION['session_ajax_listing_query'];
$work_list_res1 = pg_query($query_Work_lising_sql);
$filename ="work_detail_report_on_".date("d/m/Y");

header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=".$filename.".xls");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $page_title?></title>
<? include_once('common/connection_db.php'); ?>
<style type="text/css">
	body{
		background-color:#FFFFFF;
	}
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
	<tr>
		<td  align="center" class="blk2b">
           <h2>Department of Works, Government of Odisha</h2>
        </td>
 	</tr>     
	<tr>
		<td  align="left" class="blk2b">
            <h3><?php echo $page_title.$mssg.' On '.date('d/m/Y')?></h3>
        </td>
 	</tr>
  <tr>
    <td  align="left" class="blk2b">  
<?

          if($_SESSION["sess_dashboard_schemeid"] != 0){
          
?>
            <span class="vlt2b">Scheme :</span><span class="blk2b"><b><?php echo getFUND($_SESSION["sess_dashboard_schemeid"]).","?></b></span>
<?
                    }
          if($_SESSION["sess_dashboard_wingid"] != 0){
?>
             <span class="vlt2b">Wing  : </span><span class="blk2b"><b><?php echo getWingName($_SESSION["sess_dashboard_wingid"]).","?></b> </span>  

<?          
          }         
        
          if($_SESSION["sess_dashboard_circleid"] != 0){
?>
             <span class="vlt2b">Circle  : </span><span class="blk2b"><b><?php echo getCirname($_SESSION["sess_dashboard_circleid"]).","?></b></span>    &nbsp;   

<?          
          }  
          if($_SESSION["sess_dashboard_divisionid"] != 0){
?>          
             <span class="vlt2b">Division  : </span><span class="blk2b"><b><?php echo getDivname($_SESSION["sess_dashboard_divisionid"])?></b></span>  &nbsp;     
<?          
          }
?>                  

                    <br/>


        </td>
  </tr>
    
    <tr>
		<td align="center" valign="top" bgcolor="#FFFFFF">
			<table width="948" border="0" cellspacing="0" cellpadding="3">                
        	 	<tr>
             		<td>
             			 <table width="946" border="0" cellspacing="0" cellpadding="5" >
               				 <tr>
                  				<td align="center" valign="top">
                  					<!-- contents goes here -->
                          <table width="100%" cellspacing="1" cellpadding="4" border="1" >
                                    <tr>
                                      <td align="center"  class="blk2b" width="5%" class="blk2b"><b>Sl. No.</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Circle</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Division</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Name of the work</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>A/A Amount</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Agreement Amount</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Agency</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Date of commencement</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Stipulated date of completion</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Cumulative Expenditure up to previous financial Year</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Expenditure during the current financial year</b></td>
                                      <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Cumulative Expenditure</b></td>
<!--                                       <td align="center"    class="blk2b" width="8%" class="blk2b"><b>Physical Progress</b></td>           
 -->                                      </tr>
<?
  $cnt = 0;
   $totalaaamt = 0;
   $totalagramt = 0;
   $toatprevfyexp   = 0;
   $totcurrfyexp = 0;
   $grandexpamt = 0;
  while($row = pg_fetch_assoc($work_list_res1))
  {
    $cnt++;
    if($cnt%2==0)
    {
      $bgcolor='class="listtabletr2"';
    }
    else
    {
      $bgcolor='class="listtabletr3"';
    }
    
    $totalaaamt = $totalaaamt+$row['aaamount'];
    $totalagramt = $totalagramt+$row['AGGREMENT_AMOUNT'];
    $toatprevfyexp = $toatprevfyexp+$row['tot_prev_fy_exp'];
    $totcurrfyexp  = $totcurrfyexp+$row['tot_curr_fy_exp'];
    $grandexpamt  = $grandexpamt+$row['tot_prev_fy_exp']+$row['tot_curr_fy_exp'];

?>
                                          <tr  <?php echo $bgcolor?>>
                                            <td align="center" class="blk2" valign="top"><?php echo $cnt?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['circle_name']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['division_name']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['work_name']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['aamount']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['aggrement_amount']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo getCONName($row['work_id'])?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['work_commencement_date']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['work_completion_date']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['tot_prev_fy_exp']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['tot_curr_fy_exp']?></td>
                                            <td align="center" class="blk2" valign="top"><?php echo $row['tot_prev_fy_exp']+$row['tot_curr_fy_exp']?></td>
                                           <!--  <td align="center" class="blk2" valign="top">
                                                  <table width="100%" cellspacing="1" cellpadding="4" bgcolor="#FFFFFF" border="0">

                                  <?
                                  //SELECT DISTINCT epd_work_id,CONCAT  (epd_year, '-', epd_month,'-01') as date1 FROM pm_execution_process_details 

                                  $get_month_wise_achieve_sql = "SELECT TOP 1 MONTH(Q.date1) AS MONTHS,YEAR(Q.date1) AS YEARS FROM 
                                  ( SELECT DISTINCT epd_work_id,convert(date,((convert(varchar(4),epd_year)+'-'+convert(varchar(4),epd_month)+'-'+'01'))) as date1 
                                  FROM dbo.pm_execution_process_details
                                  WHERE epd_work_id= ".$row['work_id'].")Q
                                  ORDER BY Q.date1 DESC";
                                  $get_month_wise_achieve_res = pg_query($get_month_wise_achieve_sql);
                                  $get_month_wise_achieve_cnt = pg_num_rows($get_month_wise_achieve_res);
                                  if($get_month_wise_achieve_cnt > 0){
                                  ?>
                                          
                                          
                                          <tr bgcolor="#FFFFFF">
                                            <td align="left" colspan="4">
                                                <fieldset style="margin-bottom:10px;width:90%;">
                                                  
                                                  <table width="100%" border="1" cellpadding="6" cellspacing="1" class="listtable">
                                                    <tr>
                                                      <td align="left" style="padding-left:10px;" width="20%" bgcolor="#FFFFFF">Month</td>
                                                      <td align="left" style="padding-left:10px;" width="20%" bgcolor="#FFFFFF">Year</td>
                                                      <td align="left" style="padding-left:10px;" width="15%" bgcolor="#FFFFFF">Component</td>
                                                      <td align="left" style="padding-left:10px;" width="15%" bgcolor="#FFFFFF">Target Scope</td>
                                                      <td align="left" style="padding-left:10px;" width="20%" bgcolor="#FFFFFF">Cumulative Achievement</td>
                                                     </tr>
                                  <?
                                    while($get_month_wise_achieve_row = pg_fetch_assoc($get_month_wise_achieve_res))
                                    {
                                      $exe_process_detail_cnt = 0;
                                      $exe_process_detail_sql = "SELECT * FROM pm_execution_process_details WHERE epd_work_id =".$row['WORK_ID'];
                                      $exe_process_detail_sql.=" AND epd_month = ".$get_month_wise_achieve_row['MONTHS']." ";
                                      $exe_process_detail_sql.=" AND epd_year = ".$get_month_wise_achieve_row['YEARS']." ";
                                      $exe_process_detail_res = pg_query($exe_process_detail_sql);
                                      $exe_process_detail_cnt = pg_num_rows($exe_process_detail_res);
                                      $moncnt = 0;
                                      if($exe_process_detail_cnt > 0)
                                      {
                                        while($exe_process_detail_row = pg_fetch_assoc($exe_process_detail_res))
                                        {

                                              $cnt++;
                                              $moncnt++;
                                              if($cnt%2==0)
                                              {
                                                $bgcolor='class="listtabletr2"';
                                              }
                                              else
                                              {
                                                $bgcolor='class="listtabletr3"';
                                              }         
                                  ?>
                                                      <tr bgcolor="#FFFFFF">

                                  <?
                                          //get target value
                                          $ACTUALVAL = '';
                                          $check_is_updated = "SELECT epd_actual_value AS ACTUALVAL FROM pm_execution_process_details WHERE epd_work_id =".$row['WORK_ID'];
                                          $check_is_updated.= " AND epd_month =".$exe_process_detail_row['epd_month'];
                                          $check_is_updated.= " AND epd_year =".$exe_process_detail_row['epd_year'];
                                          $check_is_updated.= " AND epd_component_id =".$exe_process_detail_row['epd_component_id'];
                                          $check_is_updated.= " AND epd_subcomponent_id =".$exe_process_detail_row['epd_subcomponent_id'];  
                                          $res_check_is_updated = pg_query($check_is_updated);
                                          $count_check_is_updated = pg_num_rows($res_check_is_updated);
                                          if($count_check_is_updated > 0){
                                            @extract(pg_fetch_assoc($res_check_is_updated));
                                          }

                                          if($moncnt == 1){
                                          
                                  ?>
                                                            <td bgcolor="#FFFFFF" align="left" class="blu5b" valign="top" rowspan="<?php echo $exe_process_detail_cnt?>">
                                                                                         <label><? echo date("F", mktime(0, 0, 0, $exe_process_detail_row['epd_month']+1 , 0, 0))?></label>
                                                            </td>
                                                            <td bgcolor="#FFFFFF" align="left" class="blu5b" valign="top" rowspan="<?php echo $exe_process_detail_cnt?>">
                                                                                         <label><? echo $exe_process_detail_row['epd_year'];?></label>
                                                            </td>
                                  <?
                                          }
                                  ?>
                                                            <td align="left" class="blk2" width="15%">
                                                                                         <label><?echo getSubCompName($exe_process_detail_row['epd_subcomponent_id']);?></label>
                                                            </td>
                                  <?
                                    $TARGETVAL = '';
                                    $TARGETTODATE = '';
                                    $check_is_updated = "SELECT target_value AS TARGETVAL,CONVERT(DATE,target_to_date) AS TARGETTODATE FROM pm_target_detail WHERE target_work_id =".$row['WORK_ID'];
                                    $check_is_updated.= " AND target_comp_id =".$exe_process_detail_row['epd_component_id'];
                                    $check_is_updated.= " AND target_sub_comp_id =".$exe_process_detail_row['epd_subcomponent_id'];
                                    $res_check_is_updated = pg_query($check_is_updated);
                                    $count_check_is_updated = pg_num_rows($res_check_is_updated);
                                    if($count_check_is_updated > 0){
                                      @extract(pg_fetch_assoc($res_check_is_updated));
                                    }
                                    
                                  ?>
                                                            <td align="left" class="blk2">
                                                                                         <label><?echo $TARGETVAL;?></label>
                                                            </td>                         
                                                            <td align="left" class="blk2">
                                                                                         <label><?echo $ACTUALVAL;?></label>
                                                            </td>
                                                            
                                                            
                                                      
                                                      </tr>
                                  <?
                                  if($moncnt == $exe_process_detail_cnt){
                                  ?>
                                                      <tr bgcolor="#FFFFFF"><td colspan="5" height="1px"></td></tr>
                                  <?
                                            }
                                      
                                        }
                                      }
                                    }
                                  ?>
                                                      
                                                    
                                                  </table>
                                                </fieldset>                 
                                            </td>
                                          </tr> 

                                          <?}
                                          ?>

                                                  </table>



                                            </td>              
                                              </tr>
<?
    }
?>
                                          <tr  <?php echo $bgcolor?>>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"><b><?php echo $totalaaamt?></b></td>
                                            <td align="center" class="blk2" valign="top"><b><?php echo $totalagramt?></b></td>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"></td>
                                            <td align="center" class="blk2" valign="top"><b><?php echo $toatprevfyexp?></b></td>
                                            <td align="center" class="blk2" valign="top"><b><?php echo $totcurrfyexp?></b></td>
                                            <td align="center" class="blk2" valign="top"><b><?php echo $grandexpamt?></b></td>
                                            <td align="center" class="blk2" valign="top"></td>              
                                              </tr>

                             </table>
                         			
                  				</td>
               				 </tr>
               			</table>
					</td> -->
          		</tr>
        	</table>
        </td>
    </tr>
    
    
    
</table>
</body>
</html>

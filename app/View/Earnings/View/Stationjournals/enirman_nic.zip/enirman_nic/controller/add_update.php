<?php 
require_once("../common/globali.php");
if(isset($_POST)){
    extract($_POST);
        	//$workarray = array();
             $circle_query = "select * from pm_auth_user where user_id=".$userid."";
             //echo $circle_query;exit;
             $circle_res = pg_query($circle_query);
             extract(pg_fetch_array($circle_res));
             //echo $circle_id;exit;
             // $user_query = "select * from pm_auth_user where circle_id=".$circle_id."";
             // //echo $circle_query;exit;
             // $user_query_res = pg_query($user_query);
             // echo '<option value="">----All Works Code----</option>';
             // while($row = pg_fetch_array($user_query_res)){
             //    //echo $row['user_id'];
             //    $insert_query = "select * from pm_works where work_created_by=".$row['user_id']."";
             //    $select_res = pg_query($insert_query);
             //    if(pg_num_rows($select_res)>0){
             //        while($res=pg_fetch_array($select_res)){
             //            echo '<option value="'.$res['work_id'].'">'.$res['pcode'].'</option>'."\n";
             //        }
             //    }
             // }//exit;

            //$insert_query = "select * from pm_works where work_created_by=".$userid."";
            $insert_query = "select a.work_id, a.pcode from pm_works a left join pm_auth_user b on a.work_created_by = b.user_id where b.circle_id=".$circle_id." order by a.pcode asc";
            //echo $insert_query;exit;
            $select_res = pg_query($insert_query);
            echo '<option value="">-All Works Code-</option>';
            while($res=pg_fetch_array($select_res)){
            	echo '<option value="'.$res['work_id'].'">'.$res['pcode'].'</option>'."\n";
            }
            //echo $workarray;
}
?>
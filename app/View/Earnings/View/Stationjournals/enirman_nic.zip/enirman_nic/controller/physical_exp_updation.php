<?php
$wid = (isset($_GET['wid']) && $_GET['wid'] != 0)?(int) $_GET['wid']:0;
$sess_user_id = $_SESSION["sess_user_id"];

//Update Work allotment list
 $date=date("Y-m-d");
if(isset($_POST['summary']) && $_POST['summary'] == 'Save'){
	extract($_POST);
	$work_highlight = addslashes($work_highlight);
    $work_highlight = escapeSingleQuotes($work_highlight);
    $chk_highlight_sql = "SELECT work_highlight_id FROM pm_work_highlight WHERE work_id = ".$wid." ";
    $chk_highlight_res = pg_query($chk_highlight_sql);
    $chk_highlight_cnt = pg_num_rows($chk_highlight_res);
    if($chk_highlight_cnt > 0){
    	 //============================================================================================================
    	 $select_query = "SELECT * FROM pm_work_highlight WHERE work_id = ".$wid." ";
         $select_query_res = pg_query($select_query);
         autit_log('pm_work_highlight' ,pg_fetch_assoc($select_query_res) ,'Before Update', 'Overall target for the Project');
         //=============================================================================================================
		$update_sql = "UPDATE pm_work_highlight SET work_highlight = '".$work_highlight."'  WHERE work_id = ".$wid." ";
		pg_query($update_sql);
		//============================================================================================================
    	 $select_query = "SELECT * FROM pm_work_highlight WHERE work_id = ".$wid." ";
         $select_query_res = pg_query($select_query);
         autit_log('pm_work_highlight' ,pg_fetch_assoc($select_query_res) ,'After Update', 'Overall target for the Project');
         //=============================================================================================================
    }
    else{
		$insert_sql = "INSERT INTO pm_work_highlight(work_id,work_highlight)VALUES(".$wid.",'".$work_highlight."')";
		pg_query($insert_sql);	
    }	
	$msg = "Project summary has been saved successfully.";
	$msg= base64_encode($msg);
	header("Location: index.php?page=315&wid=".$wid."&msg=".urlencode($msg));	
	exit(0);   
}


if(isset($_POST['add']) && $_POST['add'] == 'Add New Month')
{
    extract($_POST);
    $wa_allot_id = getAllotmentID($wid);
    if($updationcnt == 0){
    	$updationdate = $add_year."-".$add_mon."-"."1";
    	$add_mon = date("m",strtotime("-1 second",strtotime($updationdate)));
    	$add_year = date("Y",strtotime("-1 second",strtotime($updationdate)));
    }
    //echo $updationdate."------".$add_mon."----".$add_year;exit;
        $add_exp_mon_sql = "select * from USP_INSERT_PHYSICAL_UPDATION_DETAILS(".$wid.",".$wa_allot_id.",".$add_mon.",".$add_year.")";
      
   // echo $add_exp_mon_sql;exit;
    $add_exp_mon_res = pg_query($add_exp_mon_sql);
    if($add_exp_mon_res){
	    $msg = "New month has been saved successfully.";
	    $msg= base64_encode($msg);
		header("Location: index.php?page=315&wid=".$wid."&msg=".urlencode($msg));	
	    exit(0);        	
    }else{
	    $msg = "There is a problem while adding a new month.";
	    $msg= base64_encode($msg);
		header("Location: index.php?page=315&wid=".$wid."&msg=".urlencode($msg));	
	    exit(0);     	
    }
}

if(isset($_POST['submit']) && $_POST['submit'] == 'Update')
{
    extract($_POST);
    if($wid != 0 && $upd_mon != 0 && $upd_year != 0){
    	//echo "<pre>";print_r($_POST);exit;
    	$uwa_id = getAllotmentID($wid);	
			$check_is_updated = "SELECT * FROM physical_updation_detail WHERE work_id =".$wid;
			$check_is_updated.= " AND month =".$upd_mon;
			$check_is_updated.= " AND year =".$upd_year;
			$res_check_is_updated = pg_query($check_is_updated);
			$count_check_is_updated = pg_num_rows($res_check_is_updated);
			//echo "<pre>";echo($check_is_updated);exit;
			$cumulative_target = "cumulative_target_".$upd_year."_".$upd_mon;
			$cumulative_ext_target = "cumulative_ext_target_".$upd_year."_".$upd_mon;
			$phy_progress = "phy_progress_".$upd_year."_".$upd_mon;
			$shortfall_reason = "shortfall_reason_".$upd_year."_".$upd_mon;

			$$cumulative_target =  ($$cumulative_target != '')?$$cumulative_target:'NULL';
			$$cumulative_ext_target =  ($$cumulative_ext_target != '')?$$cumulative_ext_target:'NULL';
			$$phy_progress =  ($$phy_progress != '')?$$phy_progress:'';
			$$shortfall_reason =  ($$shortfall_reason != '')?$$shortfall_reason:'NULL';
			//echo $prop_exp.'<br/>'.$act_exp.'<br/>'.$remarks;exit;
			$$cumulative_target = addslashes($$cumulative_target);
			$$cumulative_target = addQuoteMS($$cumulative_target);
			$$cumulative_ext_target = addslashes($$cumulative_ext_target);
			$$cumulative_ext_target = addQuoteMS($$cumulative_ext_target);
			$$phy_progress = addslashes($$phy_progress);
			$$phy_progress = addQuoteMS($$phy_progress);
			$$shortfall_reason = addslashes($$shortfall_reason);
			$$shortfall_reason = addQuoteMS($$shortfall_reason);
			

			if($count_check_is_updated > 0){
				/*$update_exe_proccess_detail = " UPDATE physical_updation_detail SET ";
				$update_exe_proccess_detail.= "  cumulative_target = '".$$cumulative_target."' ";
				$update_exe_proccess_detail.= ",update_exe_proccess_detail,  cumulative_ext_target = '".$$cumulative_ext_target."' ";
				$update_exe_proccess_detail.= ",  phy_progress = '".$$phy_progress."' ";
				$update_exe_proccess_detail.= ",  shortfall_reason = '".$$shortfall_reason."' ";
				$update_exe_proccess_detail.= ",  date_added = GETDATE() ";
				$update_exe_proccess_detail.= "  WHERE  work_id =".$wid;
				$update_exe_proccess_detail.= " AND month =".$upd_mon;
				$update_exe_proccess_detail.= " AND year =".$upd_year;*/
				//echo $update_exe_proccess_detail."<br/>";exit;
				//=====================================================================================
				$select_query = "SELECT * FROM physical_updation_detail WHERE work_id = $wid AND month = $upd_mon AND year = $upd_year";
		        $select_query_res = pg_query($select_query);
		        autit_log('physical_updation_detail' ,pg_fetch_assoc($select_query_res) ,'Before Update', 'Physical Target/Achievement Updation');
		        //======================================================================================
				$update_exe_proccess_detail = " UPDATE physical_updation_detail SET ";
				$update_exe_proccess_detail.= "  cumulative_target = '".$$cumulative_target."' ";
				$update_exe_proccess_detail.= ",  cumulative_ext_target = '".$$cumulative_ext_target."' ";
				$update_exe_proccess_detail.= ",  phy_progress = '".$$phy_progress."' ";
				$update_exe_proccess_detail.= ",  shortfall_reason = '".$$shortfall_reason."' ";
				$update_exe_proccess_detail.= ",  date_added = '$date' ";
				$update_exe_proccess_detail.= "  WHERE  work_id =".$wid;
				$update_exe_proccess_detail.= " AND month =".$upd_mon;
				$update_exe_proccess_detail.= " AND year =".$upd_year;
				//echo $update_exe_proccess_detail; exit();

			    pg_query($update_exe_proccess_detail);
			    //=====================================================================================
				$select_query = "SELECT * FROM physical_updation_detail WHERE work_id = $wid AND month = $upd_mon AND year = $upd_year";
		        $select_query_res = pg_query($select_query);
		        autit_log('physical_updation_detail' ,pg_fetch_assoc($select_query_res) ,'After Update', 'Physical Target/Achievement Updation');
		        //======================================================================================
			    //Disable user
			    //=================================================================
			    $get_disallow_work_sql = "UPDATE allow_work_update set is_enable = 0 WHERE work_id = ".$wid." and month = '".(int)$upd_mon."' and year = '".$upd_year."'";
				//echo $get_disallow_work_sql;exit;
				pg_query($get_disallow_work_sql);
				//=================================================================
				//Upload file to db of current Division of LOOP
				$inserted_id=array();
				if($_FILES['epd_photo']['name'] != '' && $_FILES['epd_photo']['size'] > 0)
				{
				    
					 $insert_photo_detail =  " INSERT INTO pm_execution_process_photo ";
					$insert_photo_detail .= " (epd_work_id,epd_wa_id,epd_month,epd_year,epd_photo,latitude,longitude)";
					$insert_photo_detail .= " VALUES ";
					    $insert_photo_detail .= " ($wid,$uwa_id,$upd_mon,$upd_year,'','','') ";
					 
					pg_query($insert_photo_detail);
					//collect all inserted id and save it in an array,SO that we can update each wa_id with the uploaded file name
					  $get_inserted_id_sql = "SELECT lastval() AS inserted_id";
					$get_inserted_id_res  = pg_query($get_inserted_id_sql);
					extract(pg_fetch_assoc($get_inserted_id_res)); //echo "--h--".$inserted_id;
					$inserted_id = $inserted_id;
					//Find extension and Rename file 
					 $fileName = "photo_".date("Y-m-d")."_".$inserted_id."-".rand();
					$ext ="";
					$actual_file_name = basename($_FILES['epd_photo']['name']);
					$ext= findextenson($actual_file_name);
					  $fileName = $fileName.'.'.$ext;
	    
					//upload file to server
					$path = "./writereaddata/exe_photo/".$fileName;
					//resize_image($_FILES['epd_photo']['tmp_name'], $path, 600, 600, false);echo "helo";
					chmod($path, 0666);
					 
					  move_uploaded_file($_FILES['epd_photo']['tmp_name'],$path);
					
					//==============================================================================
	   			    //$select_query = "SELECT * FROM pm_execution_process_photo WHERE epd_photo_id = ".$inserted_id; 
		        	//$select_query_res = pg_query($select_query);
		        	//autit_log('pm_execution_process_photo' ,pg_fetch_assoc($select_query_res) ,'Update', $page_title);
					//===============================================================================
					//Add File Name to Allotment Table
					  $query = "UPDATE  pm_execution_process_photo SET ";
					$query.= " epd_photo = '$fileName'";
					$query.= " WHERE epd_photo_id = ".$inserted_id; 
					 //echo $query;
					pg_query($query);
	    
				}



			}else{
				//Get allotment ID
					
				$insert_exe_proccess_detail =  " INSERT INTO physical_updation_detail ";
				$insert_exe_proccess_detail .= " (work_id,wa_id,month,year,cumulative_target,cumulative_ext_target,phy_progress,shortfall_reason,phy_updation_date,date_added)";
				$insert_exe_proccess_detail .= " VALUES ";
				$insert_exe_proccess_detail .= " ($wid,".$uwa_id.",".$upd_mon.",".$upd_year.",'".$$cumulative_target."','".$$cumulative_ext_target."','".$$phy_progress."','".$$shortfall_reason."',GETDATE(),GETDATE()) ";
				//echo $insert_exe_proccess_detail;exit;
				pg_query($insert_exe_proccess_detail);
			}
	
	
	    $msg = "Physical updation detail has been saved successfully.";
	    $msg= base64_encode($msg);
		header("Location: index.php?page=315&wid=".$wid."&msg=".urlencode($msg));	
	    exit(0);    
    }else{
 	    $msg = "Error while updating Physical updation detail.";
	    $msg= base64_encode($msg);
		header("Location: index.php?page=315&wid=".$wid."&msg=".urlencode($msg));	
	    exit(0);      	
    }	
	
}

//get work detail
$get_work_sql = "SELECT *,work_creation_date AS workcreationdate  FROM pm_works WHERE work_id = ".$wid." ";
$get_work_res = pg_query($get_work_sql);
$get_work_cnt = pg_num_rows($get_work_res);
if($get_work_cnt > 0)
{
	extract(pg_fetch_assoc(pg_query($get_work_sql)));
}
 
 
$addmonth = 0;
$addyear  = 0;
$addprevmonth = 0;
$addprevyear  = 0;

$get_mon_updation_sql = " select TOP 1 month AS addmonth,year AS addyear from physical_updation_detail ";
$get_mon_updation_sql.=" where work_id= ".$wid." ";
$get_mon_updation_sql.=" order by work_id,year desc,month desc";
$get_mon_updation_res = pg_query($get_mon_updation_sql);
$get_mon_updation_cnt = pg_num_rows($get_mon_updation_res);
if($get_mon_updation_cnt > 0){
	extract(pg_fetch_assoc(pg_query($get_mon_updation_sql)));
}else{
	//get the start date of work 
	$startyear = 0;
	//echo "--start--".$startyear = substr($workcreationdate,-4);
	 $startyear=date("Y",strtotime($workcreationdate));
}
$chk_highlight_sql = "SELECT work_highlight  FROM pm_work_highlight WHERE work_id = ".$wid." ";
$chk_highlight_res = pg_query($chk_highlight_sql);
$chk_highlight_cnt = pg_num_rows($chk_highlight_res);
if($chk_highlight_cnt > 0){
	@extract(pg_fetch_assoc($chk_highlight_res));
}
if($get_mon_updation_cnt > 0){
	$get_prev_mon_updation_sql = " select TOP 1 month AS addprevmonth,year AS addprevyear from dbo.physical_updation_detail ";
	$get_prev_mon_updation_sql.=" where work_id= ".$wid." ";
	$get_prev_mon_updation_sql.=" order by work_id,year ASC,month ASC";
	$get_prev_mon_updation_res = pg_query($get_prev_mon_updation_sql);
	$get_prev_mon_updation_cnt = pg_num_rows($get_prev_mon_updation_res);	
	extract(pg_fetch_assoc(mssql_query($get_prev_mon_updation_sql)));
	$lastupdationdate = $addprevyear."-".$addprevmonth."-"."01";
	$prevlastupdationdate = date("Y-m-t", strtotime($lastupdationdate."-2 month") );
	$setprevmon = date("n", strtotime($prevlastupdationdate));	
	$setprevyear = date("Y", strtotime($prevlastupdationdate));	
}


include_once ('./view/physical_exp_updation.html');
?>

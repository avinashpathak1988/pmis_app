<?
session_start();
require_once("../common/globali.php");
require_once("../common/meta_tags.php");
require_once("../common/sqlserver.php");
$circleid   = (isset($_GET['circleid']) && $_GET['circleid'] != 0)?(int) $_GET['circleid']:0;
$divisionid = (isset($_GET['divisionid']) && $_GET['divisionid'] != 0)?(int) $_GET['divisionid']:0;
$month = (isset($_GET['month']) && $_GET['month'] != 0)?(int) $_GET['month']:0;
$year = (isset($_GET['year']) && $_GET['year'] != 0)?(int) $_GET['year']:0;


//echo $circleid. " -- ".$divisionid." -- ".$month." -- ".$year."<br>";

//$get_performance_detail_sql = "select * from usp_division_performance_detail_report1('".$divisionid."','".$circleid."','".$month."','".$year."','".$_SESSION["sess_power_id"]."','".$_SESSION["sess_wings_id"]."');";
$get_performance_detail_sql = "select * from usp_division_performance_detail_report1('".$divisionid."','".$circleid."','".$month."','".$year."','".$_SESSION["sess_power_id"]."','0');";

//echo "##".$get_performance_detail_sql;
$get_performance_detail_res = pg_query($get_performance_detail_sql);
$get_performance_detail_cnt = pg_num_rows($get_performance_detail_res);
if($get_performance_detail_cnt > 0){
?>
                    <table width="100%" cellspacing="1" cellpadding="4"  class="listtable" border="0"   align="center">
                        <tr bgcolor="#FFFFCC" >
							<td class="blk2b" width="3%">#</td>
							<td align="left" class="blk2b" width="">Work Name</td>
							<td align="left" class="blk2b" width="">Project Type</td>
							<td align="left" class="blk2b" width="8%">Admin. Approval Date<br/>[ A/A Amount ]</td>
							<td align="left" class="blk2b" width="8%">Date of commencement</td>
							<td align="left" class="blk2b" width="8%">Date of completion</td>
							<td align="left" class="blk2b" width="8%">Manual Project Code</td>
							<td align="left" class="blk2b" width="8%">Alloted To</td>
							<!--
                            <td class="blk2b" width="15%">Achievement Status(Financial)</td>
                            <td class="blk2b" width="20%" align="center">Achievement(In Lakh)</td>
                            <td class="blk2b" width="20%" align="center">Remark</td>
                            <td class="blk2b" width="40%">Achievement Status(Physical)</td>
                            <td class="blk2b" width="20%" align="center">Physical Achievement</td>
							-->
							<td class="blk2b" width="15%">Achievement Status</td>
							<td class="blk2b">Detail</td>
						

                        </tr>
<?
	while($get_performance_detail_row = pg_fetch_assoc($get_performance_detail_res))
	{

    

        $count++;
        if($count%2==0)
        {
            $bgcolor='bgcolor="#F5F5F5"';
        }
        else
        {
            $bgcolor='bgcolor="F5F5F5"';
        }
?>
                        <tr <?php echo $bgcolor?>>
							<td class="blk1" align="center" valign="top"><?php echo $count?></td>
                          <td align="left" class="blk2"    valign="top"><span class="grn3b">Auto Project Code:</span><span class="blk2">&nbsp;&nbsp;<?php echo $get_performance_detail_row['pcode']?></span><br/><?php echo $get_performance_detail_row['work_name']?><br/><span class="grn2b">Name of Agency:</span><span class="blk2">&nbsp;&nbsp;<?php echo 	($get_performance_detail_row['work_id'])?></span><?if($_SESSION["sess_power_id"] == 'EIC'){?> <br/><a class="lnsky4b" href="javascript:void(0);" onclick="javascript:getConWorkDetail('<?php echo $get_performance_detail_row['agency_name']?>','<?php echo $get_performance_detail_row['work_id']?>');">[contractor work detail]</a>  <?}?><br/><span class="grn2b">Agreement Amount:</span><span class="blk2">&nbsp;&nbsp;<?php echo sprintf("%.2f",$get_performance_detail_row['aggrement_amount'])?></span>  </td>

						  <td align="left" class="blk2" valign="top"><?php echo $get_performance_detail_row['project_type_name']?></td>
						  <td align="left" class="blk2" valign="top"><?php echo date("d-m-Y", strtotime($get_performance_detail_row['work_creation_date']))?><br/>[<?php echo $get_performance_detail_row['aaamount']?>]</td>
						  <td align="left" class="blk2" valign="top"><?php echo date("d-m-Y", strtotime($get_performance_detail_row['work_commencement_date']))?></td>
						  <td align="left" class="blk2" valign="top"><?php echo date("d-m-Y", strtotime($get_performance_detail_row['work_completion_date']))?></td>
                          <td align="left" class="blk2" valign="top"><?php echo $get_performance_detail_row['project_code']?></td> 
						  <td align="left" class="blk2" valign="top" nowrap="nowrap">
					  
							<?php echo "<span class='blk3b'>"."Circle".'</span>'?><br/>	
							
							<?php echo "<span class='vlt2b'>"."[".getParamNameFromID($get_performance_detail_row['circle_id'], 'circle_id', 'circle_name', 'circle')."]".'</span>'?><br/>
							<?php echo "<span class='blk3b'>"."Division".'</span>'?><br/>	
							<?php echo "<span class='vlt2b'>"."[".getParamNameFromID($get_performance_detail_row['division_id'], 'division_id', 'division_name', 'division')."]".'</span>'?><br/>
							<?php echo "<span class='blk3b'>"."Sub Division".'</span>'?><br/>	
							<?php echo "<span class='vlt2b'>"."[".getParamNameFromID($get_performance_detail_row['sub_division_id'], 'sub_division_id', 'sub_division_name', 'subdivision')."]".'</span>'?><br/>
							<?php echo "<span class='blk3b'>"."Section".'</span>'?><br/>	
							<?php echo "<span class='vlt2b'>"."[".getParamNameFromID($get_performance_detail_row['section_id'], 'section_id', 'section_name', 'section')."]".'</span>'?><br/>
							<?php echo "<span class='blk3b'>"."Section User Name".'</span>'?><br/>	
							<?php echo "<span class='vlt2b'>"."[".getParamNameFromID($get_performance_detail_row['section_id'], 'section_id', 'section_name', 'section')."]".'</span>'?><br/>
							<?php echo "<span class='blk3b'>"."Mobile No".'</span>'?><br/>	
							<?php echo "<span class='vlt2b'>"."[".$get_performance_detail_row['mobile_no']."]".'</span>'?><br/>	
						  </td>	
							<!--
							<td class="blk1" align="center" valign="top"><?php echo ($get_performance_detail_row['fincial_report_update'] == 'Y')?'<img src="./images/tick3.gif"/>':'<img src="./images/delete.gif"/>'?></td>
							<td class="blk1" valign="top" align="center"><?php echo $get_performance_detail_row['actual_amount_fin']?></td>
							<td class="blk1" valign="top" align="center"><?php echo $get_performance_detail_row['remark']?></td>
							<td class="blk1" align="center" valign="top"><?php echo ($get_performance_detail_row['physical_report_update'] == 'Y')?'<img src="./images/tick3.gif"/>':'<img src="./images/delete.gif"/>'?></td>
							<td class="blk1" valign="top"><?php echo $get_performance_detail_row['actual_physical']?></td>
							-->
							<td valign="top">
								<table width="100%" bgcolor="#33CCFF" border="0" cellspacing="2" cellpadding="4">
									<tr bgcolor="#FFFFCC">
										<td class="blk2b">Physical</td>
										<td class="blk2b">Financial</td>
									</tr>
									<tr bgcolor="#FFFFFF">
		
		<?php         //echo "<pre>";
        $work_id = $get_performance_detail_row['work_id'];
        //print_r($work_id);
        $getphycomdate = "select phy_comp_date from pm_works_physical_completion where work_id = '$work_id'";
        $getphycomdate_res = pg_query($getphycomdate);
        //$data = pg_fetch_assoc($getphycomdate_res);
       // print_r($data);
        $i = 0;
        while($phydata = pg_fetch_assoc($getphycomdate_res))
    { $i++;
    	//echo $phydata['phy_comp_date']; ?>
    	<td class="blk1" align="center" valign="top"><?php echo ($phydata['phy_comp_date'] == '')?'<img src="./images/delete.gif"/>':'<img src="./images/tick3.gif"/>'?></td> 

   <?php } if($i==0){  ?>
       	<td class="blk1" align="center" valign="top"><?php echo ($phydata['phy_comp_date'] == '')?'<img src="./images/delete.gif"/>':'<img src="./images/tick3.gif"/>'?></td>
       	<?php } ?>
    
		<?php         //echo "<pre>";
        $work_id = $get_performance_detail_row['work_id'];
        //print_r($work_id);
        $getfincomdate = "select project_completion_date from pm_works_completion where work_id = '$work_id'";
        $getfincomdate_res = pg_query($getfincomdate);
        //$data = pg_fetch_assoc($getphycomdate_res);
       // print_r($data);
        $i = 0;
        while($findata = pg_fetch_assoc($getfincomdate_res))
    { $i++;
    	//echo $findata['project_completion_date'];
    	 ?>
    	<td class="blk1" align="center" valign="top"><?php echo ($findata['project_completion_date'] == '')?'<img src="./images/delete.gif"/>':'<img src="./images/tick3.gif"/>'?></td>

   <?php } if($i==0){  ?>
       	<td class="blk1" align="center" valign="top"><?php echo ($findata['project_completion_date'] == '')?'<img src="./images/delete.gif"/>':'<img src="./images/tick3.gif"/>'?></td>
       	<?php } ?>

									</tr>							
								</table>
							</td>
							<td align="center" class="blk2" valign="top">
<?
$wid = 0;
$wid = getAllotmentID($get_performance_detail_row['work_id']);
if($wid != 0)
{
?>
							<a href="javascript:void(0);"  onclick="javascript:NewPopupWindow('index.php?page=211&wa_id=<?php echo $get_performance_detail_row['work_id']?>', 950,650);"  class="hyperlink">Physical Detail</a>
<?
}
else
{
?>
							<a href="javascript:void(0);"  onclick="javascript:NewPopupWindow('index.php?page=35&id=<?php echo $get_performance_detail_row['work_id']?>', 950,650);"  class="hyperlink">Physical Detail</a>
<?
}
?>
                            <br/><br/>
 							<a href="javascript:void(0);"  onclick="javascript:getFinancialdetail('<?php echo $get_performance_detail_row['work_id']?>');"  class="hyperlink">Financial Detail</a>
                           
						  </td>	
						  <td></td>
						 </tr>
						 
						 
						<tr <?php echo $bgcolor?>>
                            <td colspan="10">
                                <div id="financial_div_<?php echo $get_performance_detail_row['work_id']?>">
                                    
                                </div>
                            </td>
                        </tr>
                       <tr <?php echo $bgcolor?>>
                            <td colspan="10">
                                <div id="breakup_div_<?php echo $get_performance_detail_row['work_id']?>">
                                    
                                </div>
                            </td>
                        </tr>
                       <tr <?php echo $bgcolor?>>
                            <td colspan="10">
                                <div id="prev_breakup_div_<?php echo $get_performance_detail_row['work_id']?>">
                                    
                                </div>
                            </td>
                        </tr>  						 
        
<?
    }
?>
                        
                    </table>
<?
}
?>
<?php
require_once("../common/globali.php");
/*error_reporting(E_ALL);
ini_set('display_error','1');
echo 'avinash';exit;*/
$query_Work_lising_sql = "select AWU.*,PAU.user_name,PW.pcode from allow_work_update AWU inner join pm_auth_user PAU on PAU.user_id=AWU.user_id inner join pm_works PW on PW.work_id=AWU.work_id order by id desc";
$work_list_res1 = pg_query($query_Work_lising_sql);
//print_r(pg_fetch_array($work_list_res1));
?>
<?php if(isset($work_list_res1) && pg_num_rows($work_list_res1)>0){?>
<table width="100%" cellspacing="1" cellpadding="4" bgcolor="#A8D5F4" border="0" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
		<thead>
			<tr class="listtabletr1" >
				<th align="center"  class="blk2b" >Sl. No.</th>
				<th align="left"    class="blk2b">User</th>
				<th align="left"    class="blk2b">Year</th>
				<th align="center"    class="blk2b">Month</th>
				<th align="left"    class="blk2b">Work</th>
				<th align="left"    class="blk2b">Action</th>
			</tr>
		</thead>
		<tbody>
			<?
				$cnt = 0;
				while($row = pg_fetch_array($work_list_res1))
				{
					$cnt++;
					//print_r($row);
			?>
			<tr style="background-color: #EFF7FD;">
				<td align="center" class="blk2" ><?php echo $cnt;?></th>
				<td align="left" class="blk2"><?php echo $row['user_name'];?></th>
				<td align="left" class="blk2"><?php echo $row['year'];?></th>
				<td align="left" class="blk2"><?php echo $monthName = date('F', mktime(0, 0, 0, $row['month'], 10))?></th>
				<td align="left" class="blk2"><?php echo $row['pcode'];?></th>
				<td align="left" class="blk2"><a href="javascript:void(0)" onclick="disableuserupdate('<?php echo $row['id']?>','<?php echo $row['is_enable']?>')" class="vlt2b"><?php echo isset($row['is_enable']) && $row['is_enable'] == 1?'Deactivate':'Activate';?></a></th>
<!-- 				<td align="left" class="blk2"><a href="javascript:void(0)" onclick="deleteuserupdate('<?php echo $row['id']?>')" class="btn">Delete</a></th>
 -->			</tr>
			<?php }?>
		</tbody>
</table>
<?php }?>

		
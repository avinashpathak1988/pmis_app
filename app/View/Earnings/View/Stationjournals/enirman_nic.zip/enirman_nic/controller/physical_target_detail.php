<?php
$wid = (isset($_GET['wid']) && $_GET['wid'] != 0)?(int) $_GET['wid']:0;
$project_type = (isset($_GET['project_type']) && $_GET['project_type'] != 0)?(int) $_GET['project_type']:0;
$sess_user_id = $_SESSION["sess_user_id"];

$get_highlight_detail_sql ="SELECT work_highlight FROM pm_work_highlight";
$get_highlight_detail_sql .=" WHERE work_id = $wid";
@extract(pg_fetch_assoc(pg_query($get_highlight_detail_sql)));
//echo $query_sum_allotment;

$date=date("Y-m-d");

//get component id
$get_comp_sql = "SELECT pps_id FROM pm_phy_progress_status WHERE pps_project_type = ".$project_type." ";
$get_comp_res = pg_query($get_comp_sql);
$get_comp_cnt = pg_num_rows($get_comp_res);
if($get_comp_cnt > 0){
    @extract(pg_fetch_assoc($get_comp_res));
}
//Update Work allotment list
if(isset($_POST['submit']) && $_POST['submit'] == 'Update')
{
    extract($_POST);
    //echo "<pre>";print_r($_POST); exit;
	
    
    $work_highlight = addslashes($work_highlight);
    $work_highlight = escapeSingleQuotes($work_highlight);
    $chk_highlight_sql = "SELECT work_highlight_id FROM pm_work_highlight WHERE work_id = ".$wid." ";
    $chk_highlight_res = pg_query($chk_highlight_sql);
    $chk_highlight_cnt = pg_num_rows($chk_highlight_res);
    if($chk_highlight_cnt > 0){
    	//============================================================================================================
    	 $select_query = "SELECT * FROM pm_work_highlight WHERE work_id = ".$wid." ";
         $select_query_res = pg_query($select_query);
         autit_log('pm_work_highlight' ,pg_fetch_assoc($select_query_res) ,'Before Update', 'Overall target for the Project');
         //=============================================================================================================

		$update_sql = "UPDATE pm_work_highlight SET work_highlight = '".$work_highlight."'  WHERE work_id = ".$wid." ";
		pg_query($update_sql);
		//============================================================================================================
    	 $select_query = "SELECT * FROM pm_work_highlight WHERE work_id = ".$wid." ";
         $select_query_res = pg_query($select_query);
         autit_log('pm_work_highlight' ,pg_fetch_assoc($select_query_res) ,'After Update', 'Overall target for the Project');
         //=============================================================================================================
    }
    else{
		$insert_sql = "INSERT INTO pm_work_highlight(work_id,work_highlight)VALUES(".$wid.",'".$work_highlight."')";
		pg_query($insert_sql);
		//============================================================================================================
    	 $select_query = "SELECT * FROM pm_work_highlight WHERE work_id = ".$wid." ";
         $select_query_res = pg_query($select_query);
         autit_log('pm_work_highlight' ,pg_fetch_assoc($select_query_res) ,'After Update', 'Overall target for the Project');
         //=============================================================================================================
	
    }	
	
	if(count($execution_process_list >0))
    {
			foreach($execution_process_list AS $keys => $vals)
			{  
				//echo $keys."  ".$vals;
			  $main_component = "main_component_".$vals;
				 if(isset($$main_component)){
					foreach($$main_component AS $main_key => $main_vals)

					{

									$check_is_updated = "SELECT * FROM pm_target_detail WHERE target_work_id =".$wid;
									$check_is_updated.= " AND target_comp_id =".$vals;
									$check_is_updated.= " AND target_sub_comp_id =".$main_vals;									
									$res_check_is_updated = pg_query($check_is_updated);
									$count_check_is_updated = pg_num_rows($res_check_is_updated);
									//echo $count_check_is_updated;exit;
									
									
									$prop_target = "target_".$wid."_".$vals."_".$main_vals;
									//echo $prop_target."<br/>";
									$prop_target_date = "target_date_".$wid."_".$vals."_".$main_vals;
									
									$$prop_target =  ($$prop_target != '')?$$prop_target:0;
									$$prop_target =  addslashes($$prop_target);
									$$prop_target =  escapeSingleQuotes($$prop_target);
									
									if($$prop_target_date != ''){
									    $$prop_target_date = date2mysql($$prop_target_date);
									}
									
									$wa_allot_id = getAllotmentID($wid);
									if($count_check_is_updated > 0)
									 {
									 	 $select_query = "SELECT * FROM pm_target_detail WHERE target_work_id = ".$wid." and target_comp_id=".$vals." and target_sub_comp_id=".$main_vals."";
    									 $select_query_res = pg_query($select_query);
    									 autit_log('pm_target_detail' ,pg_fetch_assoc($select_query_res) ,$_POST['submit'], $page_title);
										 $update_exe_proccess_detail = " UPDATE pm_target_detail SET";
										 $update_exe_proccess_detail.= "  target_value = '".$$prop_target."'";
										 $update_exe_proccess_detail.= ",  target_to_date = '".$$prop_target_date."'";
										 $update_exe_proccess_detail.= ",  target_updated_by =".$_SESSION["sess_user_id"]." ";
										 $update_exe_proccess_detail.= ",  target_update_date_added = '".$date."'";
										 $update_exe_proccess_detail.= "  WHERE  target_work_id =".$wid;
										 $update_exe_proccess_detail.= " AND target_comp_id =".$vals;
										 $update_exe_proccess_detail.= " AND target_sub_comp_id =".$main_vals;
										 pg_query($update_exe_proccess_detail);
										 //echo $update_exe_proccess_detail;         
										 //echo "<pre>";
									 }
									 else
									 {
										 $insert_exe_proccess_detail =  " INSERT INTO pm_target_detail ";
										 $insert_exe_proccess_detail .= " (target_work_id,target_wa_id,target_exe_process_id,target_project_type,target_comp_id,target_sub_comp_id,target_to_date,target_from_date,target_value,actual_value,actual_update_date,target_added_by,target_updated_by,target_date_added,target_update_date_added)";
										 $insert_exe_proccess_detail .= " VALUES ";
										 $insert_exe_proccess_detail .= " ($wid,$wa_allot_id,0,$project_type,$vals,$main_vals,'".$$prop_target_date."','".$date."','".$$prop_target."',0,'".$date."',".$_SESSION["sess_user_id"].",".$_SESSION["sess_user_id"].",'".$date."','".$date."') ";
										 //echo $insert_exe_proccess_detail;exit;
										 pg_query($insert_exe_proccess_detail);
									 }	
						
						
						
						///******************year month loop end
						
						
						
					}					
				 }

			}
			//exit;
	}
    
    
    $msg = "Physical Target Component Detail has been saved successfully.";
    $msg= base64_encode($msg);
	header("Location: index.php?page=212&wid=".$wid."&project_type=".$project_type."&msg=".urlencode($msg));	
    exit(0);    
    
    
    
    

	
}

//get work detail
$get_work_sql = "SELECT * FROM pm_works WHERE work_id = ".$wid." ";
$get_work_res = pg_query($get_work_sql);
$get_work_cnt = pg_num_rows($get_work_res);
if($get_work_cnt > 0)
{
	extract(pg_fetch_assoc(pg_query($get_work_sql)));
}
 
include_once ('./view/physical_target_detail.html');
?>

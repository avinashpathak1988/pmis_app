<script language="javascript" type="text/javascript">
function getSubdiv(divid)
{
		
		if(document.getElementById('sub_division_id'))
		{
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['divid'] = divid;
			arrParam['page'] = 'mu';
			ajax.getRequest('./controller/get_sub_division.php', arrParam, responseSubdivList);	
		}
	

}
function responseSubdivList(retVaL)
{
	document.getElementById('SubdivList').innerHTML = retVaL;
	
	resetSecData = '<select id="section_id" name="section_id" disabled="disabled">';
	resetSecData += '<option>--select section--</option>'; 
	resetSecData += '</select>';
	
	if(document.getElementById('sectiondivList'))
	{
		document.getElementById('sectiondivList').innerHTML = resetSecData;
	}
}

function getsectionname(subdivid)
{
	
		if(document.getElementById('section_id'))
		{
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['subdivid'] = subdivid;
			arrParam['page'] = 'mu';
			ajax.getRequest('./controller/get_section_name.php', arrParam, responseSectionList);	
		}
	

}
function responseSectionList(retVaL)
{
	document.getElementById('sectiondivList').innerHTML = retVaL;
}
// function button_Click(){
// 	var subDiv = document.getElementById('sub_division_id').value;
//     if(subDiv == ''){
//     	alert('Please choose the sub division');
//     }
// }
</script>
<?php 
$user=$_SESSION["sess_user_id"];
//echo "aaaa".$user;

 ?>

					<tr>
							<td>
								<table width="100%" cellspacing="2" cellpadding="4" style="margin-bottom:20px;"  border="0" align="left" class="searchtable">
									<tr bgcolor="">
										<td align="left" colspan="5">
											<table cellpadding="2" cellspacing="1" border="0" width="100%">
												<tr>
													<td align="left" class="blk1">Circle :</td>
													<td align="left" class="blk1"  >
														<input type="hidden" id="circle_id_hide" value="Circle" />
														<select name="circle_id" id="circle_id" class="tbox" onChange="getDivisionSearch(this.value);">
<?
if($_SESSION["sess_power_id"] == 'EIC' || $_SESSION["sess_power_id"] == 'CE')
{
?>
                                <option value="0">--Select--</option>
<?
}
else
{
    $circle_name = "";
    $cid = 0;
    //Get circle name from DB
     //echo "###user".$_session["sess_user_id"];
    //Previously add $_session["sess_user_id"] in place of $user;
    
    $query_user_cid = "select district_id as distid, division_id as divid, circle_id as cid from pm_auth_user";
    $query_user_cid.= " where user_id = ".$user;
    $res_user_cid = pg_query($query_user_cid);
    if(@pg_num_rows($res_user_cid) != 0)
        @extract(pg_fetch_assoc($res_user_cid));
}
    //Get circle name from DB
    
    $query = "select * from circle";
    if($cid != 0)
        $query.= " where circle_id = ".$cid;
    $query.= " ORDER BY circle_name";
    $res_circle = pg_query($query);
    if(@pg_num_rows($res_circle) != 0)
    {
        while($row_circle = pg_fetch_assoc($res_circle))
        {
?>
                                <option value="<?=$row_circle['circle_id']?>" <?=($circle_id == $row_circle['circle_id'])? 'selected="selected"': '' ?>><?=$row_circle['circle_name']?></option>
<?
        }
    }
?>
                            </select>
                        </td>
                        <td align="left" class="blk1" >Division :</td>
                        <td align="left" class="blk1">
                        <div id="division_list">
                        <input type="hidden" id="division_id_hide" value="Division" />
<?

if($_SESSION["sess_power_id"] == 'EIC' || $_SESSION["sess_power_id"] == 'CE')
{
    if($submit == 'Show')
    {
?>
                            <select name="division_id" class="tbox"  id="division_id" class="tbox" >
                                <option value="0">--Select--</option>
<?
        if($circle_id != 0)
        {
            $query = "SELECT * FROM division";
            $query .= " WHERE circle_id = $circle_id";
            echo $query;exit;

            $res = @pg_query($query);
            if(@pg_num_rows($res)!= 0)
            {
                while($row = pg_fetch_assoc($res))
                {
?>
                                <option value="<?=$row["division_id"]?>" <?=($row['division_id'] == $division_id)? 'selected="selected"': '' ?>>
<? 
                     $sub_query = "SELECT division_name FROM division WHERE division_id = ".$row['division_id'];
                     @extract(pg_fetch_assoc(pg_query($sub_query)));  
                     echo $division_name;
?>
                                </option>
<?
                }
            }
        }
?>
                            </select>
<?
    }
    else
    {
?>         
                            <select id="division_id" name="division_id" disabled="disabled" class="tbox" >
                                <option value="0">--Select--</option>
                            </select>
<?
    }
}
else
{
    //Get all Division name from database
    if($cid != 0 )
    {
        $query = "SELECT * FROM division";
        if($_SESSION["sess_power_id"] == 'SE')
            $query.= " WHERE circle_id = ".$cid;
        else
            $query.= " WHERE division_id = ".$divid;
    }
    $query.= " ORDER BY division_name ";
    $res = @pg_query($query);
    if(@pg_num_rows($res)!= 0)
    {
?>
                            <select name="division_id" class="tbox"  id="division_id"  style="width:200px" OnChange="getDistrictSearch(this.value);">
<?
if($_SESSION["sess_power_id"] == 'EIC' || $_SESSION["sess_power_id"] == 'CE' || $_SESSION["sess_power_id"] == 'SE' || $_SESSION["sess_power_id"] == 'EE') 
{
?> 
<?
}
        while($row = pg_fetch_assoc($res))
        {
?>
                                <option value="<?=$row["division_id"]?>" <?=($row['division_id'] == $division_id)? 'selected="selected"': '' ?>>
<? 
              
             $sub_query = "SELECT division_name FROM division WHERE division_id = ".$row['division_id'];
             @extract(pg_fetch_assoc(pg_query($sub_query)));  
             echo $division_name;
?>
                                </option>
<?
        }
    }
?>
                            </select>
<?
}
?>            
                            </div>
                        </td>
					</tr>
					<tr>
						<td class="blk2">Sub Division : </td>
						<td>
							<div id="SubdivList">
<?
if($submit == 'Show')
{
		if($division_id !=0)
		{
						$get_sub_div_sql = "SELECT * FROM subdivision WHERE division_id = ".$division_id." ";
						if($_SESSION["sess_power_id"] == 'AE')
						{		
							$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
						}	
						if($_SESSION["sess_power_id"] == 'JE')
						{		
							$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
						}						
						$get_sub_div_res = pg_query($get_sub_div_sql);
				if(@pg_num_rows($get_sub_div_res)!= 0)
				{
?>
							<select name="sub_division_id" class="tbox"  id="sub_division_id"  style="width:200px" onchange="javascript : getsectionname(this.value);">
								
<?
if($_SESSION["sess_power_id"] != 'JE' && $_SESSION["sess_power_id"] != 'AE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>
<?
						while($get_sub_div_row = pg_fetch_assoc($get_sub_div_res))
						{
    
?>
								 <option value="<?=$get_sub_div_row["sub_division_id"]?>" <?=($get_sub_div_row["sub_division_id"] == $sub_division_id)? 'selected="selected"':'' ?>><?=$get_sub_div_row['sub_division_name']?></option>
<?

						}
				}
   
?>
						        </select>
<?
		}
		else
		{
?>	
						       <select name="sub_division_id"  id="sub_division_id"   disabled="disabled">
									<option value="0">--Select Sub Division--</option>		
							</select>
<?
		}
}
else
{
		$get_sub_div_sql = "SELECT * FROM subdivision WHERE division_id = ".$_SESSION["session_division_id"]." ";
		if($_SESSION["sess_power_id"] == 'AE')
		{		
			$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		}
		if($_SESSION["sess_power_id"] == 'JE')
		{		
			$get_sub_div_sql .= " AND sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		}		
		//echo $get_sub_div_sql;
		$get_sub_div_res = pg_query($get_sub_div_sql);		
		if(@pg_num_rows($get_sub_div_res)!= 0)
		{
?>

					<select name="sub_division_id" class="tbox"  id="sub_division_id"  style="width:200px" onchange="javascript : getsectionname(this.value);">
<?
if($_SESSION["sess_power_id"] != 'JE' && $_SESSION["sess_power_id"] != 'AE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>						
<?
				while($get_sub_div_row = pg_fetch_assoc($get_sub_div_res))
				{

?>
						 <option value="<?=$get_sub_div_row["sub_division_id"]?>" <?=($get_sub_div_row["sub_division_id"] == $_SESSION["session_sub_division_id"])? 'selected="selected"':'' ?>><?=$get_sub_div_row['sub_division_name']?></option>
<?

				}
?>
					 </select>		
<?
		}
		else
		{
?>	
						       <select name="sub_division_id"  id="sub_division_id"   disabled="disabled">
									<option value="">--Select Sub Division--</option>		
							</select>
<?
		}


}
?>
							</div>
						</td>
						<td class="blk2">Section : </td>
						<td>
							<div id="sectiondivList">
							
<?															
if($submit == 'Show')
{
		
		if($sub_division_id !=0)
		{		
				$get_section_sql = "SELECT * FROM section WHERE sub_division_id = ".$sub_division_id." ";
				if($_SESSION["sess_power_id"] == 'JE')
				{		
					$get_section_sql .= " AND section_id = ".$_SESSION["session_section_id"]." ";
				}				
				$get_section_res = pg_query($get_section_sql);
				if(@pg_num_rows($get_section_res)!= 0)
				{
?>
						<select name="section_id" class="tbox"  id="section_id"  style="width:200px">
<?
if($_SESSION["sess_power_id"] != 'JE')
{
?>							
							<option value="0">--Select--</option>
<?
}
?>							
<?
								while($get_section_row = pg_fetch_assoc($get_section_res))
								{
    
?>
										<option value="<?=$get_section_row["section_id"]?>" <?=($get_section_row["section_id"] == $section_id)? 'selected="selected"':'' ?> ><?=$get_section_row['section_name']?></option>
<?

								}
				}
   
?>
						</select>							
<?
		}
		else
		{
?>
							
							
							
								<select name="section_id"  id="section_id"   disabled="disabled">
									<option value="0">--Select Section--</option>		
								</select>
								
<?
		}
}
else
{
	
		$get_section_sql = "SELECT * FROM section WHERE sub_division_id = ".$_SESSION["session_sub_division_id"]." ";
		if($_SESSION["sess_power_id"] == 'JE')
		{		
			$get_section_sql .= " AND section_id = ".$_SESSION["session_section_id"]." ";
		}		
		$get_section_res = pg_query($get_section_sql);
		if(@pg_num_rows($get_section_res)!= 0)
		{
?>
				<select name="section_id" class="tbox"  id="section_id"  style="width:200px">
<?
if($_SESSION["sess_power_id"] != 'JE')
{
?>				
								<option value="0">--Select--</option>
<?
}
?>								
<?
						while($get_section_row = pg_fetch_assoc($get_section_res))
						{

?>
								<option value="<?=$get_section_row["section_id"]?>" <?=($get_section_row["section_id"] == $_SESSION["session_section_id"])? 'selected="selected"':'' ?> ><?=$get_section_row['section_name']?></option>
<?

						}
		

?>
				</select>			
<?
		}
		else
		{
?>	
				<select name="section_id"  id="section_id"   disabled="disabled">
					<option value="0">--Select Section--</option>		
				</select>
<?
		}


}
?>								
							</div>
						</td>
					</tr>					
					
					
					
					
					
					<tr>	

								</tr>
                    
								<tr>
										
								</tr>
							</table>										
										
										
										
										</td>
									</tr>

									<tr>
										<td align="center" colspan="4">
											<input type="submit" name="assign" value="Assign" class="btn" />											
										</td>
									</tr>
								</table>
							</td>
						</tr>
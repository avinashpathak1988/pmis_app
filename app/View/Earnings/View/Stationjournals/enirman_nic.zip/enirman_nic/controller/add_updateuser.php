<?php 
require_once("../common/globali.php");
if(isset($_POST)){
    extract($_POST);


            $insert_query = "select * from pm_auth_user where circle_id=".$circleid." order by power_no";
            //echo $insert_query;exit;
            $select_res = pg_query($insert_query);
            echo '<option value="">----All User----</option>';
            while($res=pg_fetch_array($select_res)){
            	echo '<option value="'.$res['user_id'].'">'.$res['user_name'].'</option>'."\n";
            }
            //echo $workarray;
}
?>
<?php
App::uses('AppController', 'Controller');
/**
 * Reports Controller
 *
 * @property Reports $Reports
 */
class ReportsController extends AppController {
	function beforeFilter(){
		parent::beforeFilter();
		$reportsVar['m_user_type_id'] 		= $this->Auth->user('m_user_type_id');
		$reportsVar['m_agency_id'] 			= $this->Auth->user('m_agency_id');
		$reportsVar['m_district_id'] 		= $this->Auth->user('m_district_id');
		$this->set('reportsVar',$reportsVar);
    }
	
	
		function tallyReport(){

$this->layout = 'admin';	
$this->set('screen_title', 'Tally Report');
$this->loadModel('TallyData');
$data=$this->TallyData->find('all',array());
$this->set('reportData', $this->TallyData->find('all',array()));

 if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
           $this->layout='export_xls';
           $this->set('is_excel','Y');
        }
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
			$this->set('file_name','TallyReport.xls');
		}


}
	
	
	
	
	
	
	function moneyFormatIndia($num){
        $nums = explode(".",$num);
        if(count($nums)>2){
            return "0";
        }else{
        if(count($nums)==1){
            $nums[1]="00";
        }
        $num = $nums[0];
        $explrestunits = "" ;
        if(strlen($num)>3){
            $lastthree = substr($num, strlen($num)-3, strlen($num));
            $restunits = substr($num, 0, strlen($num)-3); 
            $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; 
            $expunit = str_split($restunits, 2);
            for($i=0; $i<sizeof($expunit); $i++){

                if($i==0)
                {
                    $explrestunits .= (int)$expunit[$i].","; 
                }else{
                    $explrestunits .= $expunit[$i].",";
                }
            }
            $thecash = $explrestunits.$lastthree;
        } else {
            $thecash = $num;
        }
        return $thecash.".".$nums[1]; 
        }
    } 
    public $components = array('ReportFilter');
    public function index(){}
    
    /*
     * Work Creation report
     */
    public function workCreationReport(){
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);
		$this->set('screen_title', 'Work Creation Report');
    }
    /*
     *Ajax version of Work Creation report
     */
    public function ajaxWorkCreationReport(){
		$this->layout = 'ajax';
		$this->set('screen_title', 'Work Creation Ajax Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular'); 	
		$condition 		    	= array();
		/*$condition2 		    = array();
		$condition3 		    = array();
		$condition4 		    = array();
		$benCondition 		    = array();
		$benStatCondition	    = array();*/
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';
		$master_awc_id              = '';
			
			
		if(isset($this->params['named']['m_search_type']) && $this->params['named']['m_search_type'] != '' && isset($this->params['named']['m_search']) && $this->params['named']['m_search'] != ''){
			$m_search_type 	= $this->params['named']['m_search_type'];
			$m_search		= $this->params['named']['m_search'];
			if($m_search_type == 'BLOCK'){
				$m_block_id	= $m_search;
			}else if($m_search_type == 'GRAMA'){
				$m_grampanchayat_id	= $m_search;
			}else if($m_search_type == 'VILLAGE'){
				$m_village_id = $m_search;
			}else if($m_search_type == 'WCRNO'){
				$work_creation_id = $m_search;
			}else if($m_search_type == 'PLAN'){
				$m_plan_id = $m_search;
			}else if($m_search_type == 'SECTOR'){
				$m_work_categ_id = $m_search;
			}else if($m_search_type == 'STRUCTURETYPE'){
				$m_particular_id = $m_search;
			}
		}
		
		//debug($this->params['named']);exit;
		
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];			
		}		
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
		}			
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
		}			
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		}			
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
		}				
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
		}				
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
		}				
			
			
		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($m_block_id) && $m_block_id != 0 ){
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($m_grampanchayat_id) && $m_grampanchayat_id != 0){
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($m_village_id) && $m_village_id != 0){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($m_work_categ_id) && $m_work_categ_id != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($m_particular_id) && $m_particular_id != 0){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($m_plan_id) && $m_plan_id != 0){
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
	
		if(isset($work_creation_id) && $work_creation_id != 0){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}
		$this->paginate=array(
			'recursive' => -1,
			'joins' => array(
				array(
					'table' => 'work_process_details',
					'alias' => 'WorkProcessDetail',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id'),					
				),						
				array(
					'table' => 'm_plans',
					'alias' => 'MPlan',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
				),
				array(
					'table' => 'm_work_categs',
					'alias' => 'MWorkCateg',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
				),
				array(
					'table' => 'm_scheme_types',
					'alias' => 'MWorkSchemeType',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
				),
				array(
					'table' => 'm_particulars',
					'alias' => 'MParticular',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
				),
				array(
					'table' => 'm_grampanchayats',
					'alias' => 'MGramPanchayat',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
				),
				array(
					'table' => 'm_blocks',
					'alias' => 'MBlock',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
				),
				array(
					'table' => 'm_villages',
					'alias' => 'MVillage',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
				),
				array(
					'table' => 'users',
					'alias' => 'User',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
				),	
				array(
					'table' => 'work_creation_funds',
					'alias' => 'WorkCreationFund',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
				),	
			),
			'fields'     => array(
				'WorkCreation.*',
				'MPlan.m_plan_nm',
				'MBlock.m_block_nm',
				'MGramPanchayat.m_grampanchayat_nm',
				'MVillage.m_village_nm',
				'MWorkCateg.m_work_categ_nm',
				'MParticular.m_particular_nm',
				'WorkProcessDetail.work_process_id',
				
			),
			'limit'     => $page_limit,
			'maxLimit'  => $page_limit,
			'order'     => array(
				'WorkCreation.work_reference_no' => 'asc'
			),
			'conditions'=> $condition
		);
		$reportData = $this->paginate('WorkCreation');
	    $this->set(array(
			'reportDatas'           	=> $reportData,
			'page_limit'  	    		=> $page_limit
		));
    }
	public function AjaxDashboardReport(){
		$this->layout = 'ajax';
		$this->loadModel('WorkCreation');
		$this->loadModel('User');
		$this->set('screen_title', 'Work Creation Ajax Report');
		$tdate = date("Y-m-d");
		$tableheight = "10px";
		//****************************************************************************************************
		$condition = array();
		if(isset($this->params['named']['srh_txt']) && $this->params['named']['srh_txt'] != ''){
			$srhfield = $this->params['named']['srh_txt'];
			$condition	+= array(
								'OR' => array(
									array(
										'OR' => array(
											'MBlock.m_block_nm LIKE '=>"%$srhfield%",			
										)
									),
									array(
										'OR' => array(
											'MGrampanchayat.m_grampanchayat_nm LIKE '=>"%$srhfield%",			
										)
									),
									array(
										'OR' => array(
											'MVillage.m_village_nm LIKE '=>"%$srhfield%",			
										)
									),
								)										 
							);
		}
        if($this->Auth->user('m_desg_id') == Configure::read('JEDESGID')){
            $condition	+= array('WorkAssignDetail.assign_to_user_id'		=> $this->Auth->user('user_id'));
        }
		if($this->Auth->user('m_desg_id') == Configure::read('AEDESGID')){
			$userArr = $this->User->find('list',array(
													'recursive'		=> -1,
													'conditions'	=> array(
																			'User.ref_user_id'	=> $this->Auth->user('user_id'),	 
																		),
													'fields'		=> array(
																			'User.user_id',	 
																		),
												));
			$userList = implode(',',$userArr);
			$condition += array(
							"WorkAssignDetail.assign_to_user_id IN ($userList)",
						); 
		}
        if((int)$this->Session->read('Auth.User.m_agency_id') != 0){
            $condition	+= array('WorkCreation.work_agency_id ='	=>	$this->Session->read('Auth.User.m_agency_id'));
        }		
		//***************************condition for work Feasibilty Intiation pending**************************
        $fipending = array();
        $fipendingcondition	= array(
								'WorkCreation.work_creation_id !='		=>	"0",
								'WorkCreation.is_feasibly'				=>	"N",
							);
		$fipendingcondition = array_merge($fipendingcondition, $condition);
        $fipending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
														'joins'		=>array(
																			array(
																				'table' => 'work_assign_details',
																				'alias' => 'WorkAssignDetail',
																				'type' => 'inner',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																			),															
																			array(
																				'table' => 'work_process_breakups',
																				'alias' => 'WorkProcessBreakup',
																				'type' => 'left',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																			),
																			array(
																				'table' => 'm_blocks',
																				'alias' => 'MBlock',
																				'type' => 'inner',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																			),
																			array(
																				'table' => 'm_grampanchayats',
																				'alias' => 'MGrampanchayat',
																				'type' => 'inner',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																			),
																			array(
																				'table' => 'm_villages',
																				'alias' => 'MVillage',
																				'type' => 'inner',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																			),
																			array(
																				'table' => 'm_work_categs',
																				'alias' => 'MWorkCateg',
																				'type' => 'inner',
																				'foreignKey' => false,
																				'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																			),																			
																		),
                                                        'conditions'=> $fipendingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),		
                                                ));
		//***************************condition for work Feasibilty Intiation pending**************************
		//***************************condition for work Feasibilty Approval pending**************************
        $fapending = array();
        $fapendingcondition	= array(
								'WorkCreation.work_creation_id !='		=>	"0",
								'WorkCreation.is_feasibly'				=>	"Y",
							);
		$fapendingcondition = array_merge($fapendingcondition, $condition);
        $fapending = $this->WorkCreation->find('all',array(
													'recursive'	=> -1,
													'joins'=>array(
																array(
																	'table' => 'work_assign_details',
																	'alias' => 'WorkAssignDetail',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																),														
																array(
																	'table' => 'work_process_breakups',
																	'alias' => 'WorkProcessBreakup',
																	'type' => 'left',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																),
																array(
																	'table' => 'm_blocks',
																	'alias' => 'MBlock',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																),
																array(
																	'table' => 'm_grampanchayats',
																	'alias' => 'MGrampanchayat',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																),
																array(
																	'table' => 'm_villages',
																	'alias' => 'MVillage',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																),
																array(
																	'table' => 'm_work_categs',
																	'alias' => 'MWorkCateg',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																),																	
															),
													'conditions'	=> $fapendingcondition,
													'fields'	=> array(
																		'WorkCreation.work_creation_id',
																		'WorkCreation.work_reference_no',
																		'WorkCreation.m_block_id',
																		'WorkCreation.m_grampanchayat_id',
																		'WorkCreation.m_village_id',
																		'MBlock.m_block_nm',
																		'MGrampanchayat.m_grampanchayat_nm',
																		'MVillage.m_village_nm',
																		'MWorkCateg.m_work_categ_nm',
																		'WorkProcessBreakup.process_name',
																	),				
												));
        //***************************condition for work Feasibilty Approval pending**************************
		//***************************condition for work Budget Preparation pending**************************
        $bppending = array();
        $bppendingcondition	= array(
								'WorkCreation.work_creation_id !='		=>	"0",
								'WorkCreation.is_feasibly'				=>	"Y",
								'WorkProcessDetail.is_est_initiated'	=>	"N",
							);
		$bppendingcondition = array_merge($bppendingcondition, $condition);
        $bppending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																	
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $bppendingcondition,
														'fields'	=> array(
																		'WorkCreation.work_creation_id',
																		'WorkCreation.work_reference_no',
																		'WorkCreation.m_block_id',
																		'WorkCreation.m_grampanchayat_id',
																		'WorkCreation.m_village_id',
																		'MBlock.m_block_nm',
																		'MGrampanchayat.m_grampanchayat_nm',
																		'MVillage.m_village_nm',
																		'MWorkCateg.m_work_categ_nm',
																		'WorkProcessBreakup.process_name',
																	),														
                                                )); 
        //***************************condition for work Budget Preparation pending**************************
		//***************************condition for work Budget Verification pending**************************
        $bvpending = array();
        $bvpendingcondition	= array(
								'WorkCreation.work_creation_id !='		=> "0",
								'WorkCreation.is_feasibly'				=> "Y",
								'WorkProcessDetail.is_est_initiated'	=> "Y",
								'WorkProcessDetail.is_est_verified'		=> "N",
							);
		$bvpendingcondition = array_merge($bvpendingcondition, $condition);
        $bvpending = $this->WorkCreation->find('all',array(
													'recursive'	=> -1,
													'joins'=>array(
																array(
																	'table' => 'work_assign_details',
																	'alias' => 'WorkAssignDetail',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																),
																array(
																	'table' => 'work_process_breakups',
																	'alias' => 'WorkProcessBreakup',
																	'type' => 'left',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																),																	
                                                                array(
                                                                    'table' => 'work_process_details',
                                                                    'alias' => 'WorkProcessDetail',
                                                                    'type' => 'inner',
                                                                    'foreignKey' => false,
                                                                    'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                ),
																array(
																	'table' => 'm_blocks',
																	'alias' => 'MBlock',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																),
																array(
																	'table' => 'm_grampanchayats',
																	'alias' => 'MGrampanchayat',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																),
																array(
																	'table' => 'm_villages',
																	'alias' => 'MVillage',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																),
																array(
																	'table' => 'm_work_categs',
																	'alias' => 'MWorkCateg',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																),																	
																
															),
													'conditions'	=> $bvpendingcondition,
													'fields'	=> array(
																	'WorkCreation.work_creation_id',
																	'WorkCreation.work_reference_no',
																	'WorkCreation.m_block_id',
																	'WorkCreation.m_grampanchayat_id',
																	'WorkCreation.m_village_id',
																	'MBlock.m_block_nm',
																	'MGrampanchayat.m_grampanchayat_nm',
																	'MVillage.m_village_nm',
																	'MWorkCateg.m_work_categ_nm',
																	'WorkProcessBreakup.process_name',
																),												  
                                              ));  
        //***************************condition for work Budget Verification pending**************************
        //***************************condition for work Budget Approval pending**************************
        $bapending = array();
        $bapendingcondition	= array(
								'WorkCreation.work_creation_id !='		=>	"0",
								'WorkCreation.is_feasibly'				=>	"Y",
								'WorkProcessDetail.is_est_initiated'	=>	"Y",
								'WorkProcessDetail.is_est_verified'		=>	"Y",
								'WorkProcessDetail.is_est_approved'		=>	"N",
							);
		$bapendingcondition = array_merge($bapendingcondition, $condition);
        $bapending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																		
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $bapendingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),															
                                                    )); 
        //***************************condition for work Budget Approval pending**************************
        //***************************condition for work Technical Sanction Verification pending**************************
        $tsvpending = array();
        $tsvpendingcondition	= array(
									'WorkCreation.work_creation_id !='			=>	"0",
									'WorkCreation.is_feasibly'					=>	"Y",
									'WorkProcessDetail.is_est_initiated'		=>	"Y",
									'WorkProcessDetail.is_est_verified'			=>	"Y",
									'WorkProcessDetail.is_est_approved'			=>	"Y",
									'WorkProcessDetail.is_tech_sanc_verified'	=>	"N",
								);
		$tsvpendingcondition = array_merge($tsvpendingcondition, $condition);
        $tsvpending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																		
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $tsvpendingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),														
                                                    )); 
        //***************************condition for work Technical Sanction Verification pending**************************
        //***************************condition for work Technical Sanction Approval pending**************************
        $tsapending = array();
        $tsapendingcondition	= array(
									'WorkCreation.work_creation_id !='				=>	"0",
									'WorkCreation.is_feasibly'						=>	"Y",
									'WorkProcessDetail.is_est_initiated'			=>	"Y",
									'WorkProcessDetail.is_est_verified'				=>	"Y",
									'WorkProcessDetail.is_est_approved'				=>	"Y",
									'WorkProcessDetail.is_tech_sanc_verified'		=>	"N",
									'WorkProcessDetail.is_tech_sanc_approved'		=>	"N",
								);

		$tsapendingcondition = array_merge($tsapendingcondition, $condition);
        $tsapending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
															
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																		
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $tsapendingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),														
                                                    ));
        //***************************condition for work Technical Sanction Approval pending**************************
        //***************************condition for work Adm. Approval pending**************************
        $aapending = array();
        $aapendingcondition	= array(
								'WorkCreation.work_creation_id !='				=>	"0",
								'WorkCreation.is_feasibly'						=>	"Y",
								'WorkProcessDetail.is_est_initiated'			=>	"Y",
								'WorkProcessDetail.is_est_verified'				=>	"Y",
								'WorkProcessDetail.is_est_approved'				=>	"Y",
								'WorkProcessDetail.is_tech_sanc_verified'		=>	"Y",
								'WorkProcessDetail.is_tech_sanc_approved'		=>	"Y",
								'WorkProcessDetail.is_adm_app_done'				=>	"N",
							);
		$aapendingcondition = array_merge($aapendingcondition, $condition);
        $aapending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																		
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $aapendingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),														
                                                    )); 
        //***************************condition for work Adm. Approval pending**************************
        //***************************condition for work mode of execution pending**************************
        $mepending = array();
        $mependingcondition	= array(
								'WorkCreation.work_creation_id !='			=>	"0",
								'WorkCreation.is_feasibly'					=>	"Y",
								'WorkProcessDetail.is_est_initiated'		=>	"Y",
								'WorkProcessDetail.is_est_verified'			=>	"Y",
								'WorkProcessDetail.is_adm_app_done'			=>	"Y",
								'WorkProcessDetail.is_mode_of_exe_done'		=>	"N",
							);
		$mependingcondition = array_merge($mependingcondition, $condition);
        $mepending = $this->WorkCreation->find('all',array(
                                                        'recursive'	=> -1,
                                                        'joins'=>array(
																	array(
																		'table' => 'work_assign_details',
																		'alias' => 'WorkAssignDetail',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'work_process_breakups',
																		'alias' => 'WorkProcessBreakup',
																		'type' => 'left',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																	),																		
                                                                    array(
                                                                        'table' => 'work_process_details',
                                                                        'alias' => 'WorkProcessDetail',
                                                                        'type' => 'inner',
                                                                        'foreignKey' => false,
                                                                        'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')	
                                                                    ),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                                ),
                                                        'conditions'	=> $mependingcondition,
														'fields'	=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),														
                                                    )); 
        //***************************condition for work mode of execution pending**************************
		//***************************condition for work bidder selection pending**************************
        $bspending = array();
        $bspendingcondition	= array(
								'WorkCreation.work_creation_id !='			=>	"0",
								'WorkCreation.is_feasibly'					=>	"Y",
								'WorkProcessDetail.is_est_initiated'		=>	"Y",
								'WorkProcessDetail.is_est_verified'			=>	"Y",
								'WorkProcessDetail.is_adm_app_done'			=>	"Y",
								'WorkProcessDetail.is_mode_of_exe_done'		=>	"Y",
								'WorkProcessDetail.is_bidder_selected'		=>	"N",
							);
		$bspendingcondition = array_merge($bspendingcondition, $condition);
        $bspending = $this->WorkCreation->find('all',array(
                                                    'recursive'	=> -1,
                                                    'joins'=>array(
																array(
																	'table' => 'work_assign_details',
																	'alias' => 'WorkAssignDetail',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																),
																array(
																	'table' => 'work_process_breakups',
																	'alias' => 'WorkProcessBreakup',
																	'type' => 'left',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																),																	
                                                                array(
                                                                    'table' => 'work_process_details',
                                                                    'alias' => 'WorkProcessDetail',
                                                                    'type' => 'inner',
                                                                    'foreignKey' => false,
                                                                    'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
                                                                ),
																array(
																	'table' => 'm_blocks',
																	'alias' => 'MBlock',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																),
																array(
																	'table' => 'm_grampanchayats',
																	'alias' => 'MGrampanchayat',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																),
																array(
																	'table' => 'm_villages',
																	'alias' => 'MVillage',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																),
																array(
																	'table' => 'm_work_categs',
																	'alias' => 'MWorkCateg',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																),																	
																
                                                            ),
                                                    'conditions'	=> $bspendingcondition,
													'fields'		=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),													
                                                ));  
        //***************************condition for work bidder selection pending**************************
		//***************************condition for work agreement finalization pending**************************
        $afpending = array();
        $afpendingcondition	= array(
								'WorkCreation.work_creation_id !='				=>	"0",
								'WorkCreation.is_feasibly'						=>	"Y",
								'WorkProcessDetail.is_est_initiated'			=>	"Y",
								'WorkProcessDetail.is_est_verified'				=>	"Y",
								'WorkProcessDetail.is_adm_app_done'				=>	"Y",
								'WorkProcessDetail.is_mode_of_exe_done'			=>	"Y",
								'WorkProcessDetail.is_bidder_selected'			=>	"Y",
								'WorkProcessDetail.is_agreement_finalized'		=>	"N",
							);
		$afpendingcondition = array_merge($afpendingcondition, $condition);
        $afpending = $this->WorkCreation->find('all',array(
                                                    'recursive'	=> -1,
                                                    'joins'=>array(
																array(
																	'table' => 'work_assign_details',
																	'alias' => 'WorkAssignDetail',
																	'type' => 'inner',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkAssignDetail.work_creation_id')				
																),
																array(
																	'table' => 'work_process_breakups',
																	'alias' => 'WorkProcessBreakup',
																	'type' => 'left',
																	'foreignKey' => false,
																	'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id')				
																),																	
                                                                  array(
                                                                      'table' => 'work_process_details',
                                                                      'alias' => 'WorkProcessDetail',
                                                                      'type' => 'inner',
                                                                      'foreignKey' => false,
                                                                      'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id')				
																	),
																	array(
																		'table' => 'm_blocks',
																		'alias' => 'MBlock',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id')				
																	),
																	array(
																		'table' => 'm_grampanchayats',
																		'alias' => 'MGrampanchayat',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_grampanchayat_id = MGrampanchayat.m_grampanchayat_id')				
																	),
																	array(
																		'table' => 'm_villages',
																		'alias' => 'MVillage',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id')				
																	),
																	array(
																		'table' => 'm_work_categs',
																		'alias' => 'MWorkCateg',
																		'type' => 'inner',
																		'foreignKey' => false,
																		'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
																	),																	
																	
                                                              ),
                                                    'conditions'	=> $afpendingcondition,
													'fields'		=> array(
																			'WorkCreation.work_creation_id',
																			'WorkCreation.work_reference_no',
																			'WorkCreation.m_block_id',
																			'WorkCreation.m_grampanchayat_id',
																			'WorkCreation.m_village_id',
																			'MBlock.m_block_nm',
																			'MGrampanchayat.m_grampanchayat_nm',
																			'MVillage.m_village_nm',
																			'MWorkCateg.m_work_categ_nm',
																			'WorkProcessBreakup.process_name',
																		),													
                                                ));
        //***************************condition for work agreement finalization pending************************** 		
        $this->set(array(
					'tdate' 		=> $tdate,
					'fipending'		=> $fipending,
					'fapending'     => $fapending,
					'bppending'     => $bppending,
					'bvpending'     => $bvpending,
					'bapending' 	=> $bapending,
					'tsvpending'    => $tsvpending,
					'tsapending'    => $tsapending,
					'aapending'     => $aapending,
					'mepending'     => $mepending,
					'bspending'     => $bspending,
					'afpending'   	=> $afpending,
					'tableheight'   => $tableheight,
					
                ));
    }
	public function deviationReport(){
		$this->layout = 'admin';	
		$this->set('screen_title', 'Deviation Report');
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);		
    }
    /*
     *Ajax version of Work Creation report
     */
    public function ajaxDeviationReport(){
		$this->layout = 'ajax';
		$this->set('screen_title', 'Work Creation Ajax Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular'); 	
		$condition 		    		= array();
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';
		$master_awc_id              = '';
		if(isset($this->params['named']['m_search_type']) && $this->params['named']['m_search_type'] != '' && isset($this->params['named']['m_search']) && $this->params['named']['m_search'] != ''){
			$m_search_type 	= $this->params['named']['m_search_type'];
			$m_search		= $this->params['named']['m_search'];
			if($m_search_type == 'BLOCK'){
				$m_block_id	= $m_search;
			}else if($m_search_type == 'GRAMA'){
				$m_grampanchayat_id	= $m_search;
			}else if($m_search_type == 'VILLAGE'){
				$m_village_id = $m_search;
			}else if($m_search_type == 'WCRNO'){
				$work_creation_id = $m_search;
			}else if($m_search_type == 'PLAN'){
				$m_plan_id = $m_search;
			}else if($m_search_type == 'SECTOR'){
				$m_work_categ_id = $m_search;
			}else if($m_search_type == 'STRUCTURETYPE'){
				$m_particular_id = $m_search;
			}
		}		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
		if(isset($this->params['named']['m_fund_id']) && $this->params['named']['m_fund_id'] != ''){
			$m_fund_id       = $this->params['named']['m_fund_id'];
			$condition+=array('WorkCreationFund.m_fund_id'=>$m_fund_id);
		}		
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}

		$this->paginate=array(
			'recursive' => -1,
			'joins' => array(
				array(
					'table' => 'work_process_breakups',
					'alias' => 'WorkProcessBreakup',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.work_creation_id = WorkProcessBreakup.work_creation_id'),					
				),				
				array(
					'table' => 'work_process_details',
					'alias' => 'WorkProcessDetail',
					'type' => 'left',
					'foreignKey' => false,
					'conditions'=> array('WorkProcessBreakup.work_process_breakup_id = WorkProcessDetail.work_process_breakup_id'),					
				),						
				array(
					'table' => 'm_plans',
					'alias' => 'MPlan',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
				),
				array(
					'table' => 'm_work_categs',
					'alias' => 'MWorkCateg',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
				),
				array(
					'table' => 'm_scheme_types',
					'alias' => 'MWorkSchemeType',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
				),
				array(
					'table' => 'm_particulars',
					'alias' => 'MParticular',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
				),
				array(
					'table' => 'm_grampanchayats',
					'alias' => 'MGramPanchayat',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
				),
				array(
					'table' => 'm_blocks',
					'alias' => 'MBlock',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
				),
				array(
					'table' => 'm_villages',
					'alias' => 'MVillage',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
				),
				array(
					'table' => 'users',
					'alias' => 'User',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
				),	
				array(
					'table' => 'work_creation_funds',
					'alias' => 'WorkCreationFund',
					'type' => 'inner',
					'foreignKey' => false,
					'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
				),	
			),
			'fields'     => array(
				'WorkCreation.*',
				'MBlock.m_block_nm',
				'MGramPanchayat.m_grampanchayat_nm',
				'MVillage.m_village_nm',				
				'MPlan.m_plan_nm',
				'MWorkCateg.m_work_categ_nm',
				'MParticular.m_particular_nm',
				'WorkProcessDetail.work_process_id',
				'WorkProcessBreakup.work_process_breakup_id',
				
			),
			'limit'     => $page_limit,
			'maxLimit'  => $page_limit,
			'order'     => array(
				'WorkCreation.work_reference_no' => 'asc'
			),
			'conditions'=> $condition
		);
		$reportData = $this->paginate('WorkCreation');
	    $this->set(array(
			'reportDatas'       => $reportData,
			'page_limit'  	    => $page_limit
		));
	}	
	public function AjaxShowDeviationReport($work_creation_id = 0,$work_process_breakup_id=0,$work_process_id = 0){
		$this->layout = 'admin';	
		$this->set('screen_title', 'Deviation Report');
		$page_limit   = 50;
		$this->loadModel('BoqFinalEstimationDetail'); 	
		$condition 		    	= array();
		if(isset($work_creation_id) && (int)$work_creation_id != 0){
			$condition+=array('BoqFinalEstimationDetail.work_creation_id'	=>	$work_creation_id );
		}
		if(isset($work_process_breakup_id) && (int)$work_process_breakup_id != 0){
			$condition+=array('BoqFinalEstimationDetail.work_process_breakup_id'	=>	$work_process_breakup_id );
		}
		if(isset($work_process_id) && (int)$work_process_id != 0){
			$condition+=array('BoqFinalEstimationDetail.work_process_id'	=>	$work_process_id );
		}			
		$reportDatas = $this->BoqFinalEstimationDetail->find('all',array(
			'fields'		=> array(
				'BoqFinalEstimationDetail.m_item_type_id',
				'BoqFinalEstimationDetail.m_item_id',
				'BoqFinalEstimationDetail.est_qty',
				'BoqFinalEstimationDetail.est_rate',
				'BoqFinalEstimationDetail.est_amt',
				'BoqFinalEstimationDetail.est_id',
				'BoqFinalEstimationDetail.est_desc',
				'BoqFinalEstimationDetail.work_creation_id',
				'BoqFinalEstimationDetail.work_process_id',
			),
			'limit'     => $page_limit,
			'maxLimit'  => $page_limit,
			'order'     => array(
				'BoqFinalEstimationDetail.work_creation_id' => 'asc'
			),
			'conditions'=> $condition
		));
		$this->set(array(
			'reportDatas'				=> $reportDatas,
			'page_limit'  				=> $page_limit,
			'work_creation_id' 			=> $work_creation_id,
			'work_process_id'			=> $work_process_id,
			'work_process_breakup_id'	=> $work_process_breakup_id,
		));
    }
	public function report() {
		$this->layout = 'admin';
		
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);
		
	}
	public function ProgressTracker() {
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);
	}
	public function AjaxProgressTracker() {
		$this->layout = 'admin';
		$this->layout = 'ajax';
		$this->set('screen_title', 'Work Progess Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular'); 	
		$condition 		    	= array();
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';
		$master_awc_id              = '';
		
		if(isset($this->params['named']['m_search_type']) && $this->params['named']['m_search_type'] != '' && isset($this->params['named']['m_search']) && $this->params['named']['m_search'] != ''){
			$m_search_type 	= $this->params['named']['m_search_type'];
			$m_search		= $this->params['named']['m_search'];
			if($m_search_type == 'BLOCK'){
				$m_block_id	= $m_search;
			}else if($m_search_type == 'GRAMA'){
				$m_grampanchayat_id	= $m_search;
			}else if($m_search_type == 'VILLAGE'){
				$m_village_id = $m_search;
			}else if($m_search_type == 'WCRNO'){
				$work_creation_id = $m_search;
			}else if($m_search_type == 'PLAN'){
				$m_plan_id = $m_search;
			}else if($m_search_type == 'SECTOR'){
				$m_work_categ_id = $m_search;
			}else if($m_search_type == 'STRUCTURETYPE'){
				$m_particular_id = $m_search;
			}
		}		
		
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];			
		}		
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
		}			
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
		}			
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		}			
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
		}				
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
		}				
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
		}
		
		
		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($m_block_id) && $m_block_id != 0 ){
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($m_grampanchayat_id) && $m_grampanchayat_id != 0){
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($m_village_id) && $m_village_id != 0){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($m_work_categ_id) && $m_work_categ_id != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($m_particular_id) && $m_particular_id != 0){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($m_plan_id) && $m_plan_id != 0){
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
	
		if(isset($work_creation_id) && $work_creation_id != 0){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}
		
		//***************condition for search option start ********************//
		
		if(isset($this->params['named']['srh_txt']) && $this->params['named']['srh_txt'] != ''){
			$srh_txt      = $this->params['named']['srh_txt'];
			$condition+=array('WorkCreation.work_creation_id !='	=>	"0");
			$srhfieldarr = Array();
			$innercondition = Array();
			$srhfieldarr = explode(" ",$srh_txt);
			$condition1   = array();
			$condition2    = array();
			$totcondition    = array();
			
			
		}
		
		
		//***************condition for search option end ***********************//
		
		
		
		
		
		
		
		$this->paginate=array(
					'recursive' => -1,
					'joins' => array(
						
									array(
										'table' => 'work_process_details',
										'alias' => 'WorkProcessDetail',
										'type' => 'left',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id'),					
									),						
									array(
										'table' => 'm_plans',
										'alias' => 'MPlan',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
									),
									array(
										'table' => 'm_work_categs',
										'alias' => 'MWorkCateg',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
									),
									array(
										'table' => 'm_scheme_types',
										'alias' => 'MWorkSchemeType',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
									),
									array(
										'table' => 'm_particulars',
										'alias' => 'MParticular',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
									),
									array(
										'table' => 'm_grampanchayats',
										'alias' => 'MGramPanchayat',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
									),
									array(
										'table' => 'm_blocks',
										'alias' => 'MBlock',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
									),
									array(
										'table' => 'm_villages',
										'alias' => 'MVillage',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
									),
									array(
										'table' => 'users',
										'alias' => 'User',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
									),	
									array(
										'table' => 'work_creation_funds',
										'alias' => 'WorkCreationFund',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
									),	
					),
					'fields'     => array(
														'WorkCreation.*',
														'MPlan.m_plan_nm',
														'MBlock.m_block_nm',
														'MGramPanchayat.m_grampanchayat_nm',
														'MVillage.m_village_nm',
														'MWorkCateg.m_work_categ_nm',
														'MParticular.m_particular_nm',
														'WorkProcessDetail.work_process_id',
														'WorkProcessDetail.is_est_initiated',
														'WorkProcessDetail.is_est_approved',
														'WorkProcessDetail.is_tech_sanc_approved',
														'WorkProcessDetail.is_adm_app_done',
														'WorkProcessDetail.is_mode_of_exe_done',
														'WorkProcessDetail.is_response_to_nit_done',
														'WorkProcessDetail.is_bidder_selected',
														'WorkProcessDetail.is_agreement_finalized',
														'WorkProcessDetail.is_project_completed',
														'WorkProcessDetail.is_full_payment_done',
														'WorkProcessDetail.is_uc_submitted',
														'WorkProcessDetail.is_cc_submitted',
														
													),
					'limit'     => $page_limit,
					'maxLimit'  => $page_limit,
					'order'     => array(
													 'WorkCreation.work_reference_no' => 'asc'
													 ),
					'conditions'=> $condition
				);
		$reportData = $this->paginate('WorkCreation');
	    
	    $this->set(array(
			    'reportDatas'           	=> $reportData,
			    'page_limit'  	    		=> $page_limit
			    )
		);
	}
    public function WorkCompleteReport(){
		$this->layout = 'admin';	
		$this->set('screen_title', 'Work Completion Report');
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);
    }	
	
	public function AjaxWorkCompleteReport() {
		$this->layout = 'ajax';
		$this->set('screen_title', 'Work Progess Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular'); 	
		$condition 		    	= array();
		/*$condition2 		    = array();
		$condition3 		    = array();
		$condition4 		    = array();
		$benCondition 		    = array();
		$benStatCondition	    = array();*/
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';
		$master_awc_id              = '';
			
		
		if(isset($this->params['named']['m_search_type']) && $this->params['named']['m_search_type'] != '' && isset($this->params['named']['m_search']) && $this->params['named']['m_search'] != ''){
			$m_search_type 	= $this->params['named']['m_search_type'];
			$m_search		= $this->params['named']['m_search'];
			if($m_search_type == 'BLOCK'){
				$m_block_id	= $m_search;
			}else if($m_search_type == 'GRAMA'){
				$m_grampanchayat_id	= $m_search;
			}else if($m_search_type == 'VILLAGE'){
				$m_village_id = $m_search;
			}else if($m_search_type == 'WCRNO'){
				$work_creation_id = $m_search;
			}else if($m_search_type == 'PLAN'){
				$m_plan_id = $m_search;
			}else if($m_search_type == 'SECTOR'){
				$m_work_categ_id = $m_search;
			}else if($m_search_type == 'STRUCTURETYPE'){
				$m_particular_id = $m_search;
			}
		}
		
		//debug($this->params['named']);
		
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];			
		}		
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
		}			
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
		}			
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		}			
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
		}				
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
		}				
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
		}				
			
			
		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($m_block_id) && $m_block_id != 0 ){
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($m_grampanchayat_id) && $m_grampanchayat_id != 0){
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($m_village_id) && $m_village_id != 0){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($m_work_categ_id) && $m_work_categ_id != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($m_particular_id) && $m_particular_id != 0){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($m_plan_id) && $m_plan_id != 0){
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
	
		if(isset($work_creation_id) && $work_creation_id != 0){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}
		
		$condition+=array('WorkCreation.work_creation_id !='	=>	"0");
		$condition+=array('WorkProcessDetail.is_project_completed ='	=>'Y');
		
		
		//***************condition for search option start ********************//
		
	
		
		//***************condition for search option end ***********************//
		
		$this->paginate=array(
					'recursive' => -1,
					'joins' => array(
						
									array(
										'table' => 'work_process_details',
										'alias' => 'WorkProcessDetail',
										'type' => 'left',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id'),					
									),						
									array(
										'table' => 'm_plans',
										'alias' => 'MPlan',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
									),
									array(
										'table' => 'm_work_categs',
										'alias' => 'MWorkCateg',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
									),
									array(
										'table' => 'm_scheme_types',
										'alias' => 'MWorkSchemeType',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
									),
									array(
										'table' => 'm_particulars',
										'alias' => 'MParticular',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
									),
									array(
										'table' => 'm_grampanchayats',
										'alias' => 'MGramPanchayat',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
									),
									array(
										'table' => 'm_blocks',
										'alias' => 'MBlock',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
									),
									array(
										'table' => 'm_villages',
										'alias' => 'MVillage',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
									),
									array(
										'table' => 'users',
										'alias' => 'User',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
									),	
									array(
										'table' => 'work_creation_funds',
										'alias' => 'WorkCreationFund',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
									),	
					),
					'fields'     => array(
														'WorkCreation.*',
														'MPlan.m_plan_nm',
														'MBlock.m_block_nm',
														'MGramPanchayat.m_grampanchayat_nm',
														'MVillage.m_village_nm',														
														'MWorkCateg.m_work_categ_nm',
														'MParticular.m_particular_nm',
														'WorkProcessDetail.work_process_id',
														'WorkProcessDetail.is_est_initiated',
														'WorkProcessDetail.is_est_approved',
														'WorkProcessDetail.is_tech_sanc_approved',
														'WorkProcessDetail.is_adm_app_done',
														'WorkProcessDetail.is_mode_of_exe_done',
														'WorkProcessDetail.is_response_to_nit_done',
														'WorkProcessDetail.is_bidder_selected',
														'WorkProcessDetail.is_agreement_finalized',
														'WorkProcessDetail.is_project_completed',
														'WorkProcessDetail.is_full_payment_done',
														'WorkProcessDetail.is_uc_submitted',
														'WorkProcessDetail.is_cc_submitted',
														
													),
					'limit'     => $page_limit,
					'maxLimit'  => $page_limit,
					'order'     => array(
													 'WorkCreation.work_reference_no' => 'asc'
													 ),
					'conditions'=> $condition
				);
		$reportData = $this->paginate('WorkCreation');
		 if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
           $this->layout='export_xls';
           $this->set('is_excel','Y');
        }
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
			$this->set('file_name','WorkCompleteReport.xls');
		}
	    
	    $this->set(array(
			    'reportDatas'           	=> $reportData,
			    'page_limit'  	    		=> $page_limit
			    )
		);
	}
	
	public function WorkDelayReport() {
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);		
	}	
	public function AjaxWorkDelayReport() {
		$this->layout = 'ajax';
		$this->set('screen_title', 'Work Delay Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular');
		$this->loadModel('MParticular');
		$this->loadModel('WorkAgreementDetail');
		$condition 		    	= array();
		/*$condition2 		    = array();
		$condition3 		    = array();
		$condition4 		    = array();
		$benCondition 		    = array();
		$benStatCondition	    = array();*/
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';

		
		$currdate = '';
		$currdate = date("Y-m-d");
		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
		if(isset($this->params['named']['m_fund_id']) && $this->params['named']['m_fund_id'] != ''){
			$m_fund_id       = $this->params['named']['m_fund_id'];
			$condition+=array('WorkCreationFund.m_fund_id'=>$m_fund_id);
		}		
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}
		
		$condition+=array('WorkCreation.work_creation_id !='	=>	"0");
		$condition+=array('WorkProcessDetail.is_project_completed ='	=>'N');
		$condition+=array('WorkAgreementDetail.completion_date <'	=> $currdate);
		//***************condition for search option start ********************//
		
		if(isset($this->params['named']['srh_txt']) && $this->params['named']['srh_txt'] != ''){
			$srh_txt      = $this->params['named']['srh_txt'];
			
			
			$srhfieldarr = Array();
			$innercondition = Array();
			$srhfieldarr = explode(" ",$srh_txt);
			$condition1   = array();
			$condition2    = array();
			$totcondition    = array();
			
			if(isset($srhfieldarr[0]) && $srhfieldarr[0]!= '' && !isset($srhfieldarr[1])){
				$condition+=array(
					'OR' => array(
						array(
							'OR' => array(
								'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
							) 
						),
					 
						array(
							'OR' => array(
								'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						
						
					)
				);
			}
			
			if(isset($srhfieldarr[1]) && $srhfieldarr[1]!= '' && !isset($srhfieldarr[2])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

														   
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							 
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
						  
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
														
							
						)
					);                
				
			}                
			
		   if(isset($srhfieldarr[2]) && $srhfieldarr[2]!= '' && !isset($srhfieldarr[3])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[2]%",                                        								
								) 
							),                                

															
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							 
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
						
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
														   
							
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),

																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
														
							
						)
					);                
				
			}                
			if(isset($srhfieldarr[3]) && $srhfieldarr[3]!= '' && !isset($srhfieldarr[4])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[2]%",                                        								
								) 
							),                                
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[3]%",                                        								
								) 
							),
															
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                
							
							
							
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                               
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                                                
							
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),
																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                        						
							
						)
					);                
				
			}		
		}
		
		
		//***************condition for search option end ***********************//
		
		$this->paginate=array(
					'recursive' => -1,
					'joins' => array(
						
									array(
										'table' => 'work_process_details',
										'alias' => 'WorkProcessDetail',
										'type' => 'left',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id'),					
									),						
									array(
										'table' => 'm_plans',
										'alias' => 'MPlan',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
									),
									array(
										'table' => 'm_work_categs',
										'alias' => 'MWorkCateg',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
									),
									array(
										'table' => 'm_scheme_types',
										'alias' => 'MWorkSchemeType',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
									),
									array(
										'table' => 'm_particulars',
										'alias' => 'MParticular',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
									),
									array(
										'table' => 'm_grampanchayats',
										'alias' => 'MGramPanchayat',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
									),
									array(
										'table' => 'm_blocks',
										'alias' => 'MBlock',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
									),
									array(
										'table' => 'm_villages',
										'alias' => 'MVillage',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
									),
									array(
										'table' => 'users',
										'alias' => 'User',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
									),	
									array(
										'table' => 'work_creation_funds',
										'alias' => 'WorkCreationFund',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
									),
									array(
										'table' => 'work_agreement_details',
										'alias' => 'WorkAgreementDetail',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkAgreementDetail.work_creation_id = WorkCreation.work_creation_id'),					
									),									
									
									
					),
					'fields'     => array(
														'WorkCreation.*',
														'MPlan.m_plan_nm',
														'MWorkCateg.m_work_categ_nm',
														'MParticular.m_particular_nm',
														'WorkProcessDetail.work_process_id',
														'WorkProcessDetail.is_est_initiated',
														'WorkProcessDetail.is_est_approved',
														'WorkProcessDetail.is_tech_sanc_approved',
														'WorkProcessDetail.is_adm_app_done',
														'WorkProcessDetail.is_mode_of_exe_done',
														'WorkProcessDetail.is_response_to_nit_done',
														'WorkProcessDetail.is_bidder_selected',
														'WorkProcessDetail.is_agreement_finalized',
														'WorkProcessDetail.is_project_completed',
														'WorkProcessDetail.is_full_payment_done',
														'WorkProcessDetail.is_uc_submitted',
														'WorkProcessDetail.is_cc_submitted',
														'WorkAgreementDetail.commencement_date',
														'WorkAgreementDetail.completion_date',
													),
					'limit'     => $page_limit,
					'maxLimit'  => $page_limit,
					'order'     => array(
													 'WorkCreation.work_reference_no' => 'asc'
													 ),
					'conditions'=> $condition
				);
		$reportData = $this->paginate('WorkCreation');
	    
	    $this->set(array(
			    'reportDatas'           	=> $reportData,
			    'page_limit'  	    		=> $page_limit
			    )
		);		
	}
	public function StageCompleteReport(){
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);		
	}
	public function AjaxStageCompleteReport(){
		$this->layout = 'ajax';
		$this->set('screen_title', 'Stage Complete Report');
		$page_limit   = 50;
		$this->loadModel('WorkCreation');
		$this->loadModel('MVillage');	
		$this->loadModel('MWorkCateg');
		$this->loadModel('MParticular');
		$this->loadModel('MParticular');
		$this->loadModel('WorkAgreementDetail');
		$condition 		    	= array();
		/*$condition2 		    = array();
		$condition3 		    = array();
		$condition4 		    = array();
		$benCondition 		    = array();
		$benStatCondition	    = array();*/
		$m_work_categ_id         	= '';
		$master_district_id         = '';
		$master_sector_id           = '';
		$master_grampanchayat_id    = '';

		
		$currdate = '';
		$currdate = date("Y-m-d");
		
		if(isset($this->params['named']['m_user_type_id']) && $this->params['named']['m_user_type_id'] != '' ){
			$m_user_type_id       = $this->params['named']['m_user_type_id'];
			$condition+=array('WorkCreation.work_user_type_id'=>$m_user_type_id);
		}
		if(isset($this->params['named']['m_agency_id']) && $this->params['named']['m_agency_id'] != ''){
			$m_agency_id       = $this->params['named']['m_agency_id'];
			$condition+=array('WorkCreation.work_agency_id'=>$m_agency_id);
		}
		if(isset($this->params['named']['srh_from_date']) && $this->params['named']['srh_from_date'] != ''){
			$srh_from_date       = $this->date2DB($this->params['named']['srh_from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$srh_from_date);
		}
		if(isset($this->params['named']['srh_to_date']) && $this->params['named']['srh_to_date'] != ''){
			$srh_to_date      = $this->date2DB($this->params['named']['srh_to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='=>$srh_to_date);
		}
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != '' ){
			$m_block_id       = $this->params['named']['m_block_id'];
			$condition+=array('WorkCreation.m_block_id'=>$m_block_id);
		}
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != ''){
			$m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
			$condition+=array('WorkCreation.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		if(isset($this->params['named']['m_village_id']) && $this->params['named']['m_village_id'] != ''){
			$m_village_id       = $this->params['named']['m_village_id'];
			$condition+=array('WorkCreation.m_village_id'=>$m_village_id);
		}
		if(isset($this->params['named']['m_work_categ_id']) && $this->params['named']['m_work_categ_id'] != ''){
			$m_work_categ_id       = $this->params['named']['m_work_categ_id'];
			$condition+=array('WorkCreation.m_work_categ_id'=>$m_work_categ_id);
		}		
		if(isset($this->params['named']['m_particular_id']) && $this->params['named']['m_particular_id'] != ''){
			$m_particular_id      = $this->params['named']['m_particular_id'];
			$condition+=array('WorkCreation.m_particular_id'=>$m_particular_id);
		}		
		if(isset($this->params['named']['m_plan_id']) && $this->params['named']['m_plan_id'] != ''){
			$m_plan_id       = $this->params['named']['m_plan_id'];
			$condition+=array('WorkCreation.m_plan_id'=>$m_plan_id);
		}		
		if(isset($this->params['named']['m_scheme_type_id']) && $this->params['named']['m_scheme_type_id'] != ''){
			$m_scheme_type_id      = $this->params['named']['m_scheme_type_id'];
			$condition+=array('WorkCreation.m_scheme_type_id'=>$m_scheme_type_id);
		}		
		if(isset($this->params['named']['m_fund_id']) && $this->params['named']['m_fund_id'] != ''){
			$m_fund_id       = $this->params['named']['m_fund_id'];
			$condition+=array('WorkCreationFund.m_fund_id'=>$m_fund_id);
		}		
		if(isset($this->params['named']['work_creation_id']) && $this->params['named']['work_creation_id'] != ''){
		    $work_creation_id       = $this->params['named']['work_creation_id'];
		    $condition+=array('WorkCreation.work_creation_id'=>$work_creation_id);
		}
		if(isset($this->params['named']['page_limit']) && $this->params['named']['page_limit'] != ''){
			$page_limit                 = $this->params['named']['page_limit'];
		}
		
		$condition+=array('WorkCreation.work_creation_id !='	=>	"0");
		$condition+=array('WorkProcessDetail.is_project_completed ='	=>'N');
		$condition+=array('WorkAgreementDetail.completion_date <'	=> $currdate);
		//***************condition for search option start ********************//
		
		if(isset($this->params['named']['srh_txt']) && $this->params['named']['srh_txt'] != ''){
			$srh_txt      = $this->params['named']['srh_txt'];
			
			
			$srhfieldarr = Array();
			$innercondition = Array();
			$srhfieldarr = explode(" ",$srh_txt);
			$condition1   = array();
			$condition2    = array();
			$totcondition    = array();
			
			if(isset($srhfieldarr[0]) && $srhfieldarr[0]!= '' && !isset($srhfieldarr[1])){
				$condition+=array(
					'OR' => array(
						array(
							'OR' => array(
								'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
							) 
						),
					 
						array(
							'OR' => array(
								'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						array(
							'OR' => array(
								'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
							)
						),
						
						
					)
				);
			}
			
			if(isset($srhfieldarr[1]) && $srhfieldarr[1]!= '' && !isset($srhfieldarr[2])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

														   
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							 
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
						  
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
														
							
						)
					);                
				
			}                
			
		   if(isset($srhfieldarr[2]) && $srhfieldarr[2]!= '' && !isset($srhfieldarr[3])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[2]%",                                        								
								) 
							),                                

															
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							 
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
						
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
														   
							
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),

																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
														
							
						)
					);                
				
			}                
			if(isset($srhfieldarr[3]) && $srhfieldarr[3]!= '' && !isset($srhfieldarr[4])){
					$condition+=array(
						'OR' => array(
							array(
								'OR' => array(
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[0]%",								
								) 
							),                               
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[1]%",                                        								
								) 
							),

							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[2]%",                                        								
								) 
							),                                
							array(
								'OR' => array(
								
									'MWorkCateg.m_work_categ_nm LIKE '=> "%$srhfieldarr[3]%",                                        								
								) 
							),
															
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							array(
								'OR' => array(
									'MParticular.m_particular_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                
							
							
							
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),  
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),                                
							array(
								'OR' => array(
									'MBlock.m_block_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                               
							
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MGramPanchayat.m_grampanchayat_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                                                
							
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MVillage.m_village_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),
																						   
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[0]%",			
								)
							),                                
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[1]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[2]%",			
								)
							),
							array(
								'OR' => array(
									'MPlan.m_plan_nm LIKE '=>"%$srhfieldarr[3]%",			
								)
							),                                        						
							
						)
					);                
				
			}		
		}
		
		
		//***************condition for search option end ***********************//
		
		$this->paginate=array(
					'recursive' => -1,
					'joins' => array(
						
									array(
										'table' => 'work_process_details',
										'alias' => 'WorkProcessDetail',
										'type' => 'left',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.work_creation_id = WorkProcessDetail.work_creation_id'),					
									),						
									array(
										'table' => 'm_plans',
										'alias' => 'MPlan',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_plan_id = MPlan.m_plan_id'),					
									),
									array(
										'table' => 'm_work_categs',
										'alias' => 'MWorkCateg',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id'),					
									),
									array(
										'table' => 'm_scheme_types',
										'alias' => 'MWorkSchemeType',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_scheme_type_id = MWorkSchemeType.m_scheme_type_id'),					
									),
									array(
										'table' => 'm_particulars',
										'alias' => 'MParticular',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_particular_id = MParticular.m_particular_id'),					
									),
									array(
										'table' => 'm_grampanchayats',
										'alias' => 'MGramPanchayat',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_grampanchayat_id = MGramPanchayat.m_grampanchayat_id'),					
									),
									array(
										'table' => 'm_blocks',
										'alias' => 'MBlock',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_block_id = MBlock.m_block_id'),					
									),
									array(
										'table' => 'm_villages',
										'alias' => 'MVillage',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreation.m_village_id = MVillage.m_village_id'),					
									),
									array(
										'table' => 'users',
										'alias' => 'User',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('User.user_id = WorkCreation.work_created_by'),					
									),	
									array(
										'table' => 'work_creation_funds',
										'alias' => 'WorkCreationFund',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkCreationFund.work_creation_id = WorkCreation.work_creation_id'),					
									),
									array(
										'table' => 'work_agreement_details',
										'alias' => 'WorkAgreementDetail',
										'type' => 'inner',
										'foreignKey' => false,
										'conditions'=> array('WorkAgreementDetail.work_creation_id = WorkCreation.work_creation_id'),					
									),									
									
									
					),
					'fields'     => array(
														'WorkCreation.*',
														'MPlan.m_plan_nm',
														'MWorkCateg.m_work_categ_nm',
														'MParticular.m_particular_nm',
														'WorkProcessDetail.work_process_id',
														'WorkProcessDetail.is_est_initiated',
														'WorkProcessDetail.is_est_approved',
														'WorkProcessDetail.is_tech_sanc_approved',
														'WorkProcessDetail.is_adm_app_done',
														'WorkProcessDetail.is_mode_of_exe_done',
														'WorkProcessDetail.is_response_to_nit_done',
														'WorkProcessDetail.is_bidder_selected',
														'WorkProcessDetail.is_agreement_finalized',
														'WorkProcessDetail.is_project_completed',
														'WorkProcessDetail.is_full_payment_done',
														'WorkProcessDetail.is_uc_submitted',
														'WorkProcessDetail.is_cc_submitted',
														'WorkAgreementDetail.commencement_date',
														'WorkAgreementDetail.completion_date',
													),
					'limit'     => $page_limit,
					'maxLimit'  => $page_limit,
					'order'     => array(
													 'WorkCreation.work_reference_no' => 'asc'
													 ),
					'conditions'=> $condition
				);
		$reportData = $this->paginate('WorkCreation');
	    
	    $this->set(array(
			    'reportDatas'           	=> $reportData,
			    'page_limit'  	    		=> $page_limit
			    )
		);		
	}
	public function Form19Report(){
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);		
	}
	public function AjaxForm19Report(){
		$this->layout = 'ajax';
		$this->loadModel('Sanction');
		$this->set('screen_title', 'Work Progess Report');
		$condition 	= array();
		$fyear      = '';
		$m_fund_id  = '';
		if(isset($this->params['named']['fyear']) && $this->params['named']['fyear'] != '' ){
			$fyear       = $this->params['named']['fyear'];
			$condition	+= array('Sanction.fyear'=>$fyear);
		}
		if(isset($this->params['named']['fund']) && $this->params['named']['fund'] != ''){
			$m_fund_id   = $this->params['named']['fund'];
			$condition	+= array('Sanction.m_fund_id'=>$m_fund_id);
		}
		$this->paginate	 = array(
			'recursive' => -1,
			'fields'     => array(
				'Sanction.sanction_id',
				'Sanction.fyear',
				'Sanction.sanction_order_no',
				'Sanction.sanction_date',
			),
			'order'     => array(
				'Sanction.created' => 'asc'
			),
			'conditions'=> $condition,
		);
		$reportData = $this->paginate('Sanction');
		$this->set(array(
			'reportData'	=> $reportData,
			'fyear'			=> $fyear,
			'm_fund_id'		=> $m_fund_id,
		));
	}
    /*
	 * AJAX callbacks
     */
    public function ajaxReportCallbacks(){
		$this->layout = '';
		//$this->autoRender = false;
		$rId 		= (int)$this->params['named']['rId'];  
		$rType 		= $this->params['named']['rType'];
		
		$reportConfig['partByCat'] 		= array('element' => 'particular','targetColumn' => 'm_work_categ_id');
		$reportConfig['gpByBlk'] 		= array('element' => 'grampanch','targetColumn' => 'm_block_id');
		$reportConfig['vilByGp'] 		= array('element' => 'village','targetColumn' => 'm_grampanchayat_id');
		$reportConfig['schmByPlan'] 	= array('element' => 'scheme','targetColumn' => 'm_plan_id');
		$reportConfig['fundBySchme'] 	= array('element' => 'fund','targetColumn' => 'm_scheme_type_id');
		$reportConfig['agncyByAgncytyp']= array('element' => 'agency','targetColumn' => 'm_user_type_id');
		
		$f 				= $reportConfig[$rType]['element'];
		$targetColumn 	= $reportConfig[$rType]['targetColumn'];
		
		$this->set('rId',$rId);
		$this->set('f',$f);
		$this->set('targetColumn',$targetColumn);
    }
    public function sectorWiseReport(){
		$this->layout = 'admin';
		$globalmenunm = $this->getMenuNm(12);
		$this->set('globalmenunm', $globalmenunm);			
	}
	public function ajaxSectorWiseReport(){
		$this->layout = 'ajax';
	}
	
	public function allBlockList(){
		$this->layout = 'admin';
		//$this->autoRender = false;
		
		$this->loadModel('MDistrict');
		$distList       = $this->MDistrict->find('list',array(
								   'order'  => array('MDistrict.m_district_nm' => 'asc')
								   ));
		$this->set('distList', $distList);		
		
    }
	public function ajaxAllBlockList(){
		$this->layout = 'ajax';
		$condition      = array(); 
		$m_district_id      = 0;
		if(isset($this->params['named']['m_district_id']) && $this->params['named']['m_district_id'] != 0){
		    $m_district_id       = $this->params['named']['m_district_id'];
			$condition+=array('MBlock.m_district_id'=>$m_district_id);
		}
		$this->loadModel('MBlock');
		$this->paginate = array(
			'limit'     	=> 100,
			'conditions'    => $condition,
			'order'			=> array('MBlock.m_district_id'	=> 'Asc'),
		);
		$mBlocks = $this->paginate('MBlock');
		$this->set(array(
			'mBlocks'		=> $mBlocks,
			'm_district_id'	=> $m_district_id,
		));
		
		//debug($mBlocks);
    }
	
	
	
	public function allGpList(){
		$this->layout = 'admin';
		//$this->autoRender = false;
		$this->loadModel('MState');
		$this->loadModel('MDistrict');
		$this->loadModel('MBlock');		
		/*
			* Form Auto Loading
			*/
		   $stateList       = $this->MState->find('list',array(
								  'order'  => array('MState.m_state_nm' => 'asc')
								  ));
		   $this->set('stateList', $stateList);
		
		
		   $distList       = $this->MDistrict->find('list',array(								  
								  'order'  => array('MDistrict.m_district_nm' => 'asc')
								  ));
		   $this->set('distList', $distList);
	
		   $blockList       = $this->MBlock->find('list',array(
								  
								  'order'  => array('MBlock.m_block_nm' => 'asc')
								  ));
		   $this->set('blockList', $blockList);
    }
	public function ajaxAllGpList(){
		$this->layout = 'ajax';
		$condition      = array(); 
		$this->loadModel('MGrampanchayat');	
		$m_state_id = 0;
		$m_district_id = 0;
		$m_block_id = 0;
		
		
		if(isset($this->params['named']['m_state_id']) && $this->params['named']['m_state_id'] != 0){
		    $m_state_id       = $this->params['named']['m_state_id'];
			$condition+=array('MGrampanchayat.m_state_id'=>$m_state_id);
		}				
		
		if(isset($this->params['named']['m_district_id']) && $this->params['named']['m_district_id'] != 0){
		    $m_district_id       = $this->params['named']['m_district_id'];
			$condition+=array('MGrampanchayat.m_district_id'=>$m_district_id);
		}
		
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != 0){
		    $m_block_id       = $this->params['named']['m_block_id'];
			$condition+=array('MGrampanchayat.m_block_id'=>$m_block_id);
		}		
		
		
		$this->loadModel('MGrampanchayat');
		$this->paginate = array(
			'limit'     	=> 100,
			'conditions'    => $condition,
			'order'			=> array('MBlock.m_district_id'	=> 'Asc'),
		);
		$mGrampanchayats = $this->paginate('MGrampanchayat');
		$this->set(array(
			'mGrampanchayats'		=> $mGrampanchayats,
			'm_state_id'			=> $m_state_id,
			'm_district_id'			=> $m_district_id,
			'm_block_id'			=> $m_block_id,
		));
		
		
    }
	
	
	
	public function allVillageList(){
		$this->layout = 'admin';
		//$this->autoRender = false;
		$this->loadModel('MState');
		$this->loadModel('MDistrict');
		$this->loadModel('MBlock');
		$this->loadModel('MGrampanchayat');
		/*
			* Form Auto Loading
			*/
		   $stateList       = $this->MState->find('list',array(
								  'order'  => array('MState.m_state_nm' => 'asc')
								  ));
		   $this->set('stateList', $stateList);
		
		
		   $distList       = $this->MDistrict->find('list',array(								  
								  'order'  => array('MDistrict.m_district_nm' => 'asc')
								  ));
		   $this->set('distList', $distList);
	
		   $blockList       = $this->MBlock->find('list',array(
								  
								  'order'  => array('MBlock.m_block_nm' => 'asc')
								  ));
		   $this->set('blockList', $blockList);
			$gpList       = $this->MGrampanchayat->find('list',array(
								   'order'  => array('MGrampanchayat.m_grampanchayat_nm' => 'asc')
								   ));
			$this->set('gpList', $gpList);				   
    }
	public function ajaxAllVillageList(){
		$this->layout = 'ajax';
		$condition      = array(); 
		$this->loadModel('MVillage');	
		$m_state_id = 0;
		$m_district_id = 0;
		$m_block_id = 0;
		$m_grampanchayat_id = 0;
		
		if(isset($this->params['named']['m_state_id']) && $this->params['named']['m_state_id'] != 0){
		    $m_state_id       = $this->params['named']['m_state_id'];
			$condition+=array('MVillage.m_state_id'=>$m_state_id);
		}				
		
		if(isset($this->params['named']['m_district_id']) && $this->params['named']['m_district_id'] != 0){
		    $m_district_id       = $this->params['named']['m_district_id'];
			$condition+=array('MVillage.m_district_id'=>$m_district_id);
		}
		
		if(isset($this->params['named']['m_block_id']) && $this->params['named']['m_block_id'] != 0){
		    $m_block_id       = $this->params['named']['m_block_id'];
			$condition+=array('MVillage.m_block_id'=>$m_block_id);
		}
		if(isset($this->params['named']['m_grampanchayat_id']) && $this->params['named']['m_grampanchayat_id'] != 0){
		    $m_grampanchayat_id       = $this->params['named']['m_grampanchayat_id'];
			$condition+=array('MVillage.m_grampanchayat_id'=>$m_grampanchayat_id);
		}		
		
		
		//debug($this->params['named']);
		$this->loadModel('MVillage');
		$this->paginate = array(
			'limit'     	=> 200,
			'conditions'    => $condition,
			'order'			=> array('MVillage.m_district_id'	=> 'Asc'),
		);
		$mVillages = $this->paginate('MVillage');
		$this->set(array(
			'mVillages'		=> $mVillages,
			'm_state_id'			=> $m_state_id,
			'm_district_id'			=> $m_district_id,
			'm_block_id'			=> $m_block_id,
			'm_grampanchayat_id'	=> $m_grampanchayat_id,
		));
    }
	public function workReport(){
		$this->layout = 'admin';
		$globalmenunm = 5;
		$this->loadMOdel('MAgency');
		$this->loadMOdel('MWorkCateg');
		$condition = array('MAgency.m_user_type_id'	=> configure::read('ITDA'));
		if((int)$this->Auth->user('m_agency_id') != 0){
			$condition += array('MAgency.m_agency_id'	=> $this->Auth->user('m_agency_id'));
			$this->request->data['WorkReport']['m_agency_id'] = $this->Auth->user('m_agency_id');
		}
		$agencyData = $this->MAgency->find('list',array(
			'recursive'		=> -1,
			'conditions'	=> $condition,
			'fields'		=> array(
				'MAgency.m_agency_id',
				'MAgency.m_agency_name',
			),
			'order'			=> array(
				'MAgency.m_agency_name'		=> 'ASC',						 
			),
		));
		
		$agencyArr = array(''=>'--All--');
		if((int)$this->Auth->user('m_agency_id') == 0){
			$agencyArr += $agencyData;
			$agencyData = $agencyArr;
		}
		$sectorData = $this->MWorkCateg->find('list',array(
			'recursive'		=> -1,
			'fields'		=> array(
				'MWorkCateg.m_work_categ_id',
				'MWorkCateg.m_work_categ_nm',
			),
			'order'			=> array(
				'MWorkCateg.m_work_categ_nm'		=> 'ASC',					 
			),
		));
		$this->set(array(
			'globalmenunm'	=> $globalmenunm,
			'agencyData'	=> $agencyData,
			'sectorData'	=> $sectorData,
		));
	}
	public function workReportAjax(){
		$this->layout = 'ajax';
		$this->loadModel('WorkPlanner');
		$this->loadModel('WorkCreation');
		$this->loadModel('MAgency');
		$planCondition 			= array();
		$createCondition 		= array();
		$f_year 				= '';
		$m_agency_id 			= 0;
		$m_work_categ_id 		= 0;
		$m_work_sub_categ_id 	= 0;
		$m_plan_id				= 0;
		$m_scheme_type_id		= 0;
		$m_benificiary_id		= 0;
		$ben_capacity			= 0;
		$agencyCondition = array('MAgency.m_user_type_id'	=> configure::read('ITDA'));
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year = $this->params['named']['f_year'];
			$planCondition += array('WorkCreation.fyear'	=> $f_year);
			$createCondition += array('WorkCreation.fyear'	=> $f_year);
		}
		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$planCondition += array('WorkCreation.work_agency_id'		=> $m_agency_id);
			$createCondition += array('WorkCreation.work_agency_id'	=> $m_agency_id);
			$agencyCondition += array('MAgency.m_agency_id'			=> $m_agency_id);
		}
		if(isset($this->params['named']['m_work_categ_id']) && (int)$this->params['named']['m_work_categ_id'] != 0){
			$m_work_categ_id = $this->params['named']['m_work_categ_id'];
			$planCondition += array('WorkCreation.m_work_categ_id'		=> $m_work_categ_id);
			$createCondition += array('WorkCreation.m_work_categ_id'	=> $m_work_categ_id);
		}
		if(isset($this->params['named']['m_work_sub_categ_id']) && (int)$this->params['named']['m_work_sub_categ_id'] != 0){
			$m_work_sub_categ_id = $this->params['named']['m_work_sub_categ_id'];
			$planCondition += array('WorkCreation.m_work_sub_categ_id'		=> $m_work_sub_categ_id);
			$createCondition += array('WorkCreation.m_work_sub_categ_id'	=> $m_work_sub_categ_id);
		}
		if(isset($this->params['named']['m_plan_id']) && (int)$this->params['named']['m_plan_id'] != 0){
			$m_plan_id = $this->params['named']['m_plan_id'];
			$planCondition += array('WorkCreation.m_plan_id'		=> $m_plan_id);
			$createCondition += array('WorkCreation.m_plan_id'	=> $m_plan_id);
		}
		if(isset($this->params['named']['m_scheme_type_id']) && (int)$this->params['named']['m_scheme_type_id'] != 0){
			$m_scheme_type_id = $this->params['named']['m_scheme_type_id'];
			$planCondition += array('WorkCreation.m_scheme_type_id'		=> $m_scheme_type_id);
			$createCondition += array('WorkCreation.m_scheme_type_id'	=> $m_scheme_type_id);
		}
        if(isset($this->params['named']['m_benificiary_id']) && (int)$this->params['named']['m_benificiary_id'] != 0){
            $m_benificiary_id = $this->params['named']['m_benificiary_id'];
			$planCondition += array('WorkCreation.m_benificiary_id'		=> $m_benificiary_id);
			$createCondition += array('WorkCreation.m_benificiary_id'	=> $m_benificiary_id);			
        }
        if(isset($this->params['named']['ben_capacity']) && (int)$this->params['named']['ben_capacity'] != 0){
            $ben_capacity = $this->params['named']['ben_capacity'];
			$planCondition += array('WorkCreation.ben_capacity'		=> $ben_capacity);
			$createCondition += array('WorkCreation.ben_capacity'	=> $ben_capacity);			
        }
		$agencyData = $this->MAgency->find('list',array(
			'recursive'		=> -1,
			'conditions'	=> $agencyCondition,
			'fields'		=> array(
				'MAgency.m_agency_id',
				'MAgency.m_agency_name',
			),
			'order'			=> array(
				'MAgency.m_agency_name'		=> 'ASC',						 
			),
		));
		/*
		 *Query for work planned
		 */
		$planData = $this->WorkCreation->find('all',array(
			'recursive'		=> -1,
			'conditions'	=> $planCondition,
			'fields'		=> array(
				'WorkCreation.work_agency_id',
				'COUNT(WorkCreation.work_agency_id) AS WRKPLANCNT',					 
			),
			'group'			=> array(
				'WorkCreation.work_agency_id'						 
			),
		));
		$planArr = array();
		if(is_array($planData) && count($planData)>0){
			foreach($planData as $planKey=>$planVal){
				$planArr[$planVal['WorkCreation']['work_agency_id']] = $planVal[0]['WRKPLANCNT'];
			}
		}
		/*
		 *Query for work completed
		 */
		$completeCond = array('WorkCreation.is_work_completed'	=> 'Y');
		$completeCond = array_merge($completeCond,$createCondition);
		$workCompData = $this->WorkCreation->find('all',array(
			'recursive'		=> -1,
			'conditions'	=> $completeCond,
			'fields'		=> array(
				'WorkCreation.work_agency_id',
				'COUNT(WorkCreation.work_agency_id) AS WRKCNT',					 
			),
			'group'			=> array(
				'WorkCreation.work_agency_id'						 
			),
		));
		$workCompArr = array();
		if(is_array($workCompData) && count($workCompData)>0){
			foreach($workCompData as $workCompKey=>$workCompVal){
				$workCompArr[$workCompVal['WorkCreation']['work_agency_id']] = $workCompVal[0]['WRKCNT'];
			}
		}
		/*
		 *Query for work Not completed
		 */
		$notCompleteCond = array('WorkCreation.is_assign_je'	=> 'Y','WorkCreation.is_work_completed'	=> 'N');
		$notCompleteCond = array_merge($notCompleteCond,$createCondition);
		$workNotCompData = $this->WorkCreation->find('all',array(
			'recursive'		=> -1,
			'conditions'	=> $notCompleteCond,
			'fields'		=> array(
				'WorkCreation.work_agency_id',
				'COUNT(WorkCreation.work_agency_id) AS WRKCNT',					 
			),
			'group'			=> array(
				'WorkCreation.work_agency_id'						 
			),
		));
		$workNotCompArr = array();
		if(is_array($workNotCompData) && count($workNotCompData)>0){
			foreach($workNotCompData as $workNotCompKey=>$workNotCompVal){
				$workNotCompArr[$workNotCompVal['WorkCreation']['work_agency_id']] = $workNotCompVal[0]['WRKCNT'];
			}
		}
		/*
		 *Query for work Not Started
		 */
		$notStartCond = array('WorkCreation.is_assign_je'	=> 'N','WorkCreation.is_work_completed'	=> 'N');
		$notStartCond = array_merge($notStartCond,$createCondition);
		$workNotStartData = $this->WorkCreation->find('all',array(
			'recursive'		=> -1,
			'conditions'	=> $notStartCond,
			'fields'		=> array(
				'WorkCreation.work_agency_id',
				'COUNT(WorkCreation.work_agency_id) AS WRKCNT',					 
			),
			'group'			=> array(
				'WorkCreation.work_agency_id'						 
			),
		));
		$workNotStartArr = array();
		if(is_array($workNotStartData) && count($workNotStartData)>0){
			foreach($workNotStartData as $workNotStartKey=>$workNotStartVal){
				$workNotStartArr[$workNotStartVal['WorkCreation']['work_agency_id']] = $workNotStartVal[0]['WRKCNT'];
			}
		}		
		/*
		 *Query for work created/status
		 */		
		$workData = $this->WorkCreation->find('all',array(
			'recursive'		=> -1,
			'conditions'	=> $createCondition,
			'fields'		=> array(
				'WorkCreation.work_agency_id',
				'COUNT(WorkCreation.work_agency_id) AS WRKCNT',					 
			),
			'group'			=> array(
				'WorkCreation.work_agency_id'						 
			),
		));
		$workArr = array();
		if(is_array($workData) && count($workData)>0){
			foreach($workData as $workKey=>$workVal){
				$workArr[$workVal['WorkCreation']['work_agency_id']] = $workVal[0]['WRKCNT'];
			}
		}
        if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
            $this->layout='export_xls';
            $this->set('is_excel','Y');
        }
        if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
            $this->layout='export_xls';
            $this->set('is_excel','Y');
            $this->set('file_name','work_summary_report'.date('d_m_Y').'.xls');
        }  		
		$this->set(array(
			'agencyData'			=> $agencyData,
			'planArr'				=> $planArr,
			'workArr'				=> $workArr,
			'f_year'				=> $f_year,
			'm_agency_id'			=> $m_agency_id,
			'm_work_categ_id'		=> $m_work_categ_id,
			'm_work_sub_categ_id'	=> $m_work_sub_categ_id,
			'm_plan_id'				=> $m_plan_id,
			'm_scheme_type_id'		=> $m_scheme_type_id,
			'm_benificiary_id'		=> $m_benificiary_id,
			'ben_capacity'			=> $ben_capacity,
			'workCompArr'			=> $workCompArr,
			'workNotCompArr'		=> $workNotCompArr,
			'workNotStartArr'		=> $workNotStartArr,
		));
	}
	function workPlanReportDetailsAjax(){
		$this->layout = 'master';
		$this->loadModel('WorkCreation');
		$condition				= array();
		$limit					= array();
		$m_agency_id 			= 0;
		$agency_name 			= '';
		$f_year					= '';
		$m_work_categ_id		= 0;
		$m_work_sub_categ_id	= 0;
		$m_plan_id				= 0;
		$m_scheme_type_id		= 0;
		$m_benificiary_id		= 0;
		$ben_capacity			= 0;		
		$from_date				= '';
		$to_date				= '';
		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$condition += array('WorkCreation.work_agency_id'	=> $m_agency_id);
		}
		if(isset($this->params['named']['agency_name']) && $this->params['named']['agency_name'] != ''){
			$agency_name = $this->params['named']['agency_name'];
		}
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year 	= $this->params['named']['f_year'];
			$condition += array('WorkCreation.fyear'	=> $f_year);
		}
		if(isset($this->params['named']['m_work_categ_id']) && (int)$this->params['named']['m_work_categ_id'] != 0){
			$m_work_categ_id = $this->params['named']['m_work_categ_id'];
			$condition 		+= array('WorkCreation.m_work_categ_id'	=> $m_work_categ_id);
		}
		if(isset($this->params['named']['m_work_sub_categ_id']) && (int)$this->params['named']['m_work_sub_categ_id'] != 0){
			$m_work_sub_categ_id = $this->params['named']['m_work_sub_categ_id'];
			$condition 			+= array('WorkCreation.m_work_sub_categ_id'	=> $m_work_sub_categ_id);
		}
		if(isset($this->params['named']['m_plan_id']) && (int)$this->params['named']['m_plan_id'] != 0){
			$m_plan_id = $this->params['named']['m_plan_id'];
			$condition 			+= array('WorkCreation.m_plan_id'	=> $m_plan_id);
		}
		if(isset($this->params['named']['m_scheme_type_id']) && (int)$this->params['named']['m_scheme_type_id'] != 0){
			$m_scheme_type_id = $this->params['named']['m_scheme_type_id'];
			$condition 			+= array('WorkCreation.m_scheme_type_id'	=> $m_scheme_type_id);
		}
        if(isset($this->params['named']['m_benificiary_id']) && (int)$this->params['named']['m_benificiary_id'] != 0){
            $m_benificiary_id = $this->params['named']['m_benificiary_id'];
            $condition += array('WorkCreation.m_benificiary_id'     => $m_benificiary_id);
        }
        if(isset($this->params['named']['ben_capacity']) && (int)$this->params['named']['ben_capacity'] != 0){
            $ben_capacity = $this->params['named']['ben_capacity'];
            $condition += array('WorkCreation.ben_capacity'     => $ben_capacity);
        }		
		if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
			$from_date  = $this->date2DB($this->params['named']['from_date'],'-');
			$condition	+= array('WorkCreation.work_submission_date'	=> $from_date);
		}
		if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
			$to_date    = $this->date2DB($this->params['named']['to_date'],'-');
			$condition	+= array('WorkCreation.work_submission_date'	=> $to_date);
		}		

		if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
			$this->set('file_name','work_plan_summry_report'.date('d_m_Y').'.xls');
			$limit = array('limit' => 2000,'maxLimit'	=> 2000);
		}else{
			$limit = array('limit'	=> 20);
		}
		$this->paginate = array(
			'conditions'    => $condition,
			'order'			=> array('WorkCreation.work_creation_id'	=> 'DESC'),
		)+$limit;		
		$this->set(array(
			'workPlanners'			=> $this->paginate('WorkCreation'),
			'm_agency_id'			=> $m_agency_id,
			'agency_name'			=> $agency_name,
			'f_year'				=> $f_year,
			'm_work_categ_id'		=> $m_work_categ_id,
			'm_work_sub_categ_id'	=> $m_work_sub_categ_id,
			'm_plan_id'				=> $m_plan_id,
			'm_scheme_type_id'		=> $m_scheme_type_id,
			'm_benificiary_id'		=> $m_benificiary_id,
			'ben_capacity'			=> $ben_capacity,			
			'from_date'				=> $from_date,
			'to_date'				=> $to_date,			
		));
	}
	function workCreatReportDetailsAjax(){
		$this->layout = 'master';
		$this->loadModel('WorkCreation');
		$this->loadModel('WorkProcessDetail');
		$condition				= array();
		$m_agency_id 			= 0;
		$agency_name 			= '';
		$f_year					= '';
		$m_work_categ_id		= 0;
		$m_work_sub_categ_id	= 0;
		$m_plan_id				= 0;
		$m_scheme_type_id		= 0;
		$m_benificiary_id		= 0;
		$ben_capacity			= 0;		
		$from_date				= '';
		$to_date				= '';
		$title					= '';
		$title_code				= '';
		if(isset($this->params['named']['title']) && $this->params['named']['title'] != ''){
			$title = $this->params['named']['title'];
			if($title == 'COMP'){
				$title_code = 'Work Completed';
				$condition += array('WorkCreation.is_work_completed'	=> 'Y');
			}else if($title == 'NOTCOMP'){
				$title_code = 'Work Not Completed';
				$condition += array('WorkCreation.is_assign_je'	=> 'Y','WorkCreation.is_work_completed'	=> 'N');
			}else if($title == 'NOTSTART'){
				$title_code = 'Work Not Started';
				$condition += array('WorkCreation.is_assign_je'	=> 'N','WorkCreation.is_work_completed'	=> 'N');
			}else{
				$title_code = 'Work Status';
			}
		}else{
			$title_code = 'Work Status';
		}
		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$condition += array('WorkCreation.work_agency_id'	=> $m_agency_id);
		}
		if(isset($this->params['named']['agency_name']) && $this->params['named']['agency_name'] != ''){
			$agency_name = $this->params['named']['agency_name'];
		}
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year = $this->params['named']['f_year'];
			$condition += array('WorkCreation.fyear'	=> $f_year);
		}
		if(isset($this->params['named']['m_work_categ_id']) && (int)$this->params['named']['m_work_categ_id'] != 0){
			$m_work_categ_id = $this->params['named']['m_work_categ_id'];
			$condition += array('WorkCreation.m_work_categ_id'	=> $m_work_categ_id);
		}
		if(isset($this->params['named']['m_work_sub_categ_id']) && (int)$this->params['named']['m_work_sub_categ_id'] != 0){
			$m_work_sub_categ_id = $this->params['named']['m_work_sub_categ_id'];
			$condition += array('WorkCreation.m_work_sub_categ_id'	=> $m_work_sub_categ_id);
		}
		if(isset($this->params['named']['m_plan_id']) && (int)$this->params['named']['m_plan_id'] != 0){
			$m_plan_id = $this->params['named']['m_plan_id'];
			$condition += array('WorkCreation.m_plan_id'	=> $m_plan_id);
		}
		if(isset($this->params['named']['m_scheme_type_id']) && (int)$this->params['named']['m_scheme_type_id'] != 0){
			$m_scheme_type_id = $this->params['named']['m_scheme_type_id'];
			$condition += array('WorkCreation.m_scheme_type_id'	=> $m_scheme_type_id);
		}
        if(isset($this->params['named']['m_benificiary_id']) && (int)$this->params['named']['m_benificiary_id'] != 0){
            $m_benificiary_id = $this->params['named']['m_benificiary_id'];
            $condition += array('WorkCreation.m_benificiary_id'     => $m_benificiary_id);
        }
        if(isset($this->params['named']['ben_capacity']) && (int)$this->params['named']['ben_capacity'] != 0){
            $ben_capacity = $this->params['named']['ben_capacity'];
            $condition += array('WorkCreation.ben_capacity'     => $ben_capacity);
        }		
		if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
			$from_date       = $this->date2DB($this->params['named']['from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$from_date);
		}
		if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
			$to_date      = $this->date2DB($this->params['named']['to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='	=>$to_date);
		}
		//$this->WorkCreation->unBindModel(array('belongsTo' => array('MPlan','MWorkCateg','MWorkSubCateg','MParticular','MBlock','MVillage','MGrampanchayat','MQuarter')));
		$this->WorkCreation->unBindModel(array('hasMany' => array('WorkCreationFund')));
		$this->WorkCreation->unBindModel(array('hasOne'=> array('FeasibiltyCheckDetail')));
		$this->WorkCreation->bindModel(array('hasMany' => array('PaymentBreakup')));
		$this->WorkProcessDetail->bindModel(array('hasMany' => array(
			'MbUploadDetail' 	=> array(
			   'className' 		=> 'MbUploadDetail',
			   'foreignKey' 	=> 'work_process_id',
			),
		)));
		$this->WorkCreation->bindModel(array(
            'hasMany' => array(
                'PaymentBreakup' => array(
					'className'     => 'PaymentBreakup',
					'foreignKey'    => 'work_creation_id',
					'dependent'     => true					
                ),
            ),
        ));			
		$this->paginate = array(
			'limit'     	=> 10,
			'recursive'		=> 3,
			'conditions'    => $condition,
			'order'			=> array('WorkCreation.work_creation_id'	=> 'DESC'),
		);
		//debug($this->paginate('WorkCreation'));exit;
		if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
			$this->set('file_name','work_summry_report'.date('d_m_Y').'.xls');
		} 		
		$this->set(array(
			'workCreats'			=> $this->paginate('WorkCreation'),
			'm_agency_id'			=> $m_agency_id,
			'agency_name'			=> $agency_name,
			'f_year'				=> $f_year,
			'm_work_categ_id'		=> $m_work_categ_id,
			'm_work_sub_categ_id'	=> $m_work_sub_categ_id,
			'm_plan_id'				=> $m_plan_id,
			'm_scheme_type_id'		=> $m_scheme_type_id,
			'm_benificiary_id'		=> $m_benificiary_id,
			'ben_capacity'			=> $ben_capacity,			
			'from_date'				=> $from_date,
			'to_date'				=> $to_date,
			'title'					=> $title,
			'title_code'			=> $title_code,
		));		
	}
	public function perChatReport(){
		$this->layout = 'admin';
		$this->loadModel('MAgency');
		$condition = array('MAgency.m_user_type_id'	=> configure::read('ITDA'));
		if((int)$this->Auth->user('m_agency_id') != 0){
			$condition += array('MAgency.m_agency_id'	=> $this->Auth->user('m_agency_id'));
		}		
		$agencyData = $this->MAgency->find('list',array(
			'recursive'		=> -1,
			'conditions'	=> $condition,
			'fields'		=> array(
				'MAgency.m_agency_id',
				'MAgency.m_agency_name',
			),
			'order'			=> array(
				'MAgency.m_agency_name'		=> 'ASC',						 
			),
		));
		$agencyArr = array(''=>'--Select--');
		if((int)$this->Auth->user('m_agency_id') == 0){
			$agencyArr += $agencyData;
			$agencyData = $agencyArr;
		}		
		$this->set(array(
			'agencyData'	=> $agencyData,				 
		));
	}
    public function ajaxPerChatReport(){
        $this->layout = 'graphAjax';
        $this->loadModel('WorkAgreementStageDetail');
		$condition 		= array();
		$details		= array();
		$graphDataArr 	= array();
		$graphString 	= '';		
		$m_agency_id	= 0;
		$f_year			= '';
		$work_creation_id 	= 0;
		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$condition += array('WorkCreation.work_agency_id'		=> $m_agency_id);
		}
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year = $this->params['named']['f_year'];
			$condition += array('WorkCreation.fyear'		=> $f_year);
		}
		if(isset($this->params['named']['work_creation_id']) && (int)$this->params['named']['work_creation_id'] != 0){
			$work_creation_id = $this->params['named']['work_creation_id'];
			$condition += array('WorkAgreementStageDetail.work_creation_id'		=> $work_creation_id);
		}		
		$data = $this->WorkAgreementStageDetail->find('all',array(
            'recursive'     => -1,
            'fields'        => array(
                'CASE WHEN MIN(mb_stage_comm_date) IS NULL THEN MIN(YEAR(stage_comm_date)) ELSE LEAST(MIN(YEAR(stage_comm_date)),MIN(YEAR(mb_stage_comm_date)))  END AS startyear',
                'CASE WHEN MIN(mb_stage_comp_date) IS NULL THEN MIN(YEAR(stage_comp_date)) ELSE GREATEST(MAX(YEAR(stage_comp_date)),MAX(YEAR(mb_stage_comp_date)))  END  AS lastYear'
            ),
        ));
        if(isset($data) && is_array($data) && count($data)>0){
            $start_year = $data[0][0]['startyear'];
            $last_year  = $data[0][0]['lastYear'];
        }else{
            $start_year = '2010';
            $last_year  = date('Y');
        }
		if((int)$m_agency_id != 0 && $f_year != '' && (int)$work_creation_id != 0){
			$details = $this->WorkAgreementStageDetail->find('all',array(
				'recursive' => -1,
				'joins'         => array(
					array(
						'table'         => 'work_creations',
						'alias'         => 'WorkCreation',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.work_creation_id = WorkCreation.work_creation_id')				
					),
					array(
						'table'         => 'work_process_breakups',
						'alias'         => 'WorkProcessBreakup',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.work_process_breakup_id = WorkProcessBreakup.work_process_breakup_id')				
					),
					array(
						'table'         => 'm_stages',
						'alias'         => 'MStage',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.m_stage_id = MStage.m_stage_id')				
					),                 
				),
				'conditions'	=> $condition,
				'fields'    	=> array(
					'WorkCreation.work_reference_no',
					'WorkProcessBreakup.process_name',
					'MStage.m_stage_nm',
					'CONCAT(MONTH(WorkAgreementStageDetail.stage_comm_date),CONCAT("/",YEAR(WorkAgreementStageDetail.stage_comm_date))) as target_start_date',
					'CONCAT(MONTH(WorkAgreementStageDetail.stage_comp_date),CONCAT("/",YEAR(WorkAgreementStageDetail.stage_comp_date))) as target_end_date',
					'CONCAT(MONTH(WorkAgreementStageDetail.mb_stage_comm_date),CONCAT("/",YEAR(WorkAgreementStageDetail.mb_stage_comm_date))) as actual_start_date',
					'CONCAT(MONTH(WorkAgreementStageDetail.mb_stage_comp_date),CONCAT("/",YEAR(WorkAgreementStageDetail.mb_stage_comp_date))) as actual_end_date',
				),
			));
			/*$fontfamily = array(
				1   => 'ipsum',
				2   => 'lorem',
				3   => 'dolor',
				4   => 'default',
			);*/
			if(is_array($details) && count($details)>0){
				$cnt = 0;
				foreach($details as $detKey=>$detVal){
					$cnt++;
					$targetStartDate    = $detVal[0]['target_start_date'];
					$targetEndDate      = $detVal[0]['target_end_date'];
					//$color = $fontfamily[$cnt];
					$workref            = $detVal['WorkCreation']['work_reference_no']."(".$detVal['WorkProcessBreakup']['process_name']."-".$detVal['MStage']['m_stage_nm'].")";
					$graphDataArr[]     = "['".$targetStartDate."', '".$targetEndDate."', '".$workref."(Target)', 'ipsum']";
					if($detVal[0]['actual_start_date'] != ''){
						$actualStartDate    = $detVal[0]['actual_start_date'];
						$actualEndDate      = $detVal[0]['actual_end_date'];
						$graphDataArr[]     = "['".$actualStartDate."', '".$actualEndDate."', '".$workref."(Actual)', 'lorem']";
					}
					if($cnt == 4){
						$cnt = 0;
					}
				}
				$graphString = implode(',',$graphDataArr);
			}
		}
        $this->set(array(
            'start_year'    => $start_year,
            'last_year'     => $last_year,
            'graphString'   => $graphString,
			'details'		=> $details,
        ));
    }
	public function chatReport(){
		$this->layout = 'admin';
		$this->loadModel('MAgency');
		$condition = array('MAgency.m_user_type_id'	=> configure::read('ITDA'));
		if((int)$this->Auth->user('m_agency_id') != 0){
			$condition += array('MAgency.m_agency_id'	=> $this->Auth->user('m_agency_id'));
		}		
		$agencyData = $this->MAgency->find('list',array(
			'recursive'		=> -1,
			'conditions'	=> $condition,
			'fields'		=> array(
				'MAgency.m_agency_id',
				'MAgency.m_agency_name',
			),
			'order'			=> array(
				'MAgency.m_agency_name'		=> 'ASC',						 
			),
		));
		$agencyArr = array(''=>'--Select--');
		if((int)$this->Auth->user('m_agency_id') == 0){
			$agencyArr += $agencyData;
			$agencyData = $agencyArr;
		}
		$this->set(array(
			'agencyData'	=> $agencyData,				 
		));
	}
    public function ajaxChatReport(){
        $this->layout = 'chatGraphAjax';
        $this->loadModel('WorkAgreementStageDetail');
		$this->loadModel('WorkCreation');
		$condition 		= array();
		$details		= array();
		$graphDataArr 	= array();
		$displayData	= array();
		$graphString 	= '';		
		$m_agency_id	= 0;
		$f_year			= '';
		$work_creation_id 	= 0;
		$m_work_categ_id = 0;
		$m_work_sub_categ_id = 0;
		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$condition += array('WorkCreation.work_agency_id'		=> $m_agency_id);
		}
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year = $this->params['named']['f_year'];
			$condition += array('WorkCreation.fyear'		=> $f_year);
		}
        if(isset($this->params['named']['m_work_categ_id']) && (int)$this->params['named']['m_work_categ_id'] != 0){
            $m_work_categ_id = $this->params['named']['m_work_categ_id'];
            $condition += array('WorkCreation.m_work_categ_id'   => $m_work_categ_id);
        }
        if(isset($this->params['named']['m_work_sub_categ_id']) && (int)$this->params['named']['m_work_sub_categ_id'] != 0){
            $m_work_sub_categ_id = $this->params['named']['m_work_sub_categ_id'];
            $condition += array('WorkCreation.m_work_sub_categ_id'   => $m_work_sub_categ_id);
        }  		
		if(isset($this->params['named']['work_creation_id']) && (int)$this->params['named']['work_creation_id'] != 0){
			$work_creation_id = $this->params['named']['work_creation_id'];
			$condition += array('WorkAgreementStageDetail.work_creation_id'		=> $work_creation_id);
		}
		if((int)$m_agency_id != 0 && $f_year != '' && (int)$work_creation_id != 0){
			$details = $this->WorkAgreementStageDetail->find('all',array(
				'recursive' => -1,
				'joins'         => array(
					array(
						'table'         => 'work_creations',
						'alias'         => 'WorkCreation',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.work_creation_id = WorkCreation.work_creation_id')				
					),
					array(
						'table'         => 'work_process_breakups',
						'alias'         => 'WorkProcessBreakup',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.work_process_breakup_id = WorkProcessBreakup.work_process_breakup_id')				
					),
					array(
						'table'         => 'm_stages',
						'alias'         => 'MStage',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkAgreementStageDetail.m_stage_id = MStage.m_stage_id')				
					),                 
				),
				'conditions'	=> $condition,
				'fields'    	=> array(
					'WorkCreation.work_reference_no',
					'WorkProcessBreakup.process_name',
					'MStage.m_stage_nm',
					'WorkAgreementStageDetail.stage_comm_date',
					'WorkAgreementStageDetail.stage_comp_date',
					'WorkAgreementStageDetail.mb_stage_comm_date',
					'WorkAgreementStageDetail.mb_stage_comp_date',
				),
			));
			if(is_array($details) && count($details)>0){
				$cnt = 0;
				$phasesssName = '';
				foreach($details as $detKey=>$detVal){
					$targetStartDate    = intval(strtotime($detVal['WorkAgreementStageDetail']['stage_comm_date'])) * 1000;
					$targetEndDate      = intval(strtotime($detVal['WorkAgreementStageDetail']['stage_comp_date'])) * 1000;
					if($cnt == 0){
						$workRefNo = $detVal['WorkCreation']['work_reference_no'];
					}else{
						$workRefNo = '';
					}
					$phaseName = $detVal['WorkProcessBreakup']['process_name'];
					if($phasesssName == $phaseName){
						$phaseName = '';
					}else{
						$phaseName = $detVal['WorkProcessBreakup']['process_name'];
					}	
					$stageName = $detVal['MStage']['m_stage_nm'];
					
					$graphDataArr[]     = "{name: '".$phaseName."',desc: '".$stageName."(Target)',
						values: [{from: '/Date(".$targetStartDate.")/',to: '/Date(".$targetEndDate.")/',label: '".$stageName."(Target)', customClass: 'ganttRed'}]
					}";
					
					if($detVal['WorkAgreementStageDetail']['mb_stage_comm_date'] != ''){
						$actualStartDate    = intval(strtotime($detVal['WorkAgreementStageDetail']['mb_stage_comm_date'])) * 1000;;
						$actualEndDate      = intval(strtotime($detVal['WorkAgreementStageDetail']['mb_stage_comp_date'])) * 1000;
						$graphDataArr[]     = "{name: ' ',desc: '".$stageName."(Actual)',
							values: [{from: '/Date(".$actualStartDate.")/',to: '/Date(".$actualEndDate.")/',label: '".$stageName."(Actual)', customClass: 'ganttGreen'}]
						}";
					}
					$cnt++;
					$phasesssName = $detVal['WorkProcessBreakup']['process_name'];
				}
				$graphString = implode(',',$graphDataArr);
			}
			$displayData = $this->WorkCreation->find('first',array(
				'recursive'		=> -1,
				'joins'			=> array(
					array(
						'table'         => 'm_agencies',
						'alias'         => 'MAgency',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkCreation.work_agency_id = MAgency.m_agency_id')				
					),
					array(
						'table'         => 'm_work_categs',
						'alias'         => 'MWorkCateg',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkCreation.m_work_categ_id = MWorkCateg.m_work_categ_id')				
					),
					array(
						'table'         => 'm_work_sub_categs',
						'alias'         => 'MWorkSubCateg',
						'type'          => 'left',
						'foreignKey'    => false,
						'conditions'    => array('WorkCreation.m_work_sub_categ_id = MWorkSubCateg.m_work_sub_categ_id')				
					),				
				),
				'conditions'	=> array(
					'WorkCreation.work_creation_id'	=> $work_creation_id,						 
				),
				'fields'		=> array(
					'WorkCreation.fyear',
					'WorkCreation.work_reference_no',
					'WorkCreation.work_name',
					'MAgency.m_agency_name',
					'MWorkCateg.m_work_categ_nm',
					'MWorkSubCateg.m_work_sub_categ_nm',
				),
			));
		}
		$this->set(array(
            'graphString'   => $graphString,
			'details'		=> $details,
			'displayData'	=> $displayData,
        ));
    }
	public function userAuditReport(){
		$this->layout = 'admin';
		$this->loadModel('User');
		$userList = $this->User->find('list',array(
			'recursice'		=> -1,
			/*'conditions'	=> array(
				'is_active'	=> 'Y',					 
			),*/
			'fields'		=> array(
				'User.username',
				'User.username',
			),
			'order'			=> array(
				'User.username'						 
			),
		));
		
		$this->set(array(
			'userList'	=> $userList,
		));
	}
	public function userAuditReportAjax(){
		$this->layout = 'ajax';
		$this->loadModel('UserAudit');
		$condition = array();
		$user_name = '';
		$ip_address = '';
		$from_date = '';
		$to_date = '';
		if(isset($this->params['named']['user_name']) && $this->params['named']['user_name'] != ''){
			$user_name = $this->params['named']['user_name'];
			$condition += array('UserAudit.user_name'		=> $user_name);
		}
		if(isset($this->params['named']['ip_address']) && $this->params['named']['ip_address'] != ''){
			$ip_address = $this->params['named']['ip_address'];
			$condition += array('UserAudit.ip_address'		=> $ip_address);
		}
		if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
			$from_date       = $this->date2DB($this->params['named']['from_date'],'-');
			$condition+=array('UserAudit.login_date >='=>$from_date);
		}
		if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
			$to_date      = $this->date2DB($this->params['named']['to_date'],'-');
			$condition+=array('UserAudit.login_date <='	=>$to_date);
		}
		$this->paginate = array(
			'recursive'		=> -1,
			'conditions'	=> $condition,
			'limit'			=> 50,
			'order'			=> array(
				'UserAudit.login_date'	=> 'DESC',						 
			),
		);
		$this->set(array(
			'data'			=> $this->paginate('UserAudit'),
			'user_name'		=> $user_name,
			'ip_address'	=> $ip_address,
			'from_date'		=> $from_date,
			'to_date'		=> $to_date,
		));
	}
	function workImageAjax(){
		$this->layout = 'ajax';
		$this->loadModel('WorkCreation');
		$this->loadModel('WorkProcessDetail');
		$condition				= array();
		$m_agency_id 			= 0;
		$agency_name 			= '';
		$f_year					= '';
		$m_work_categ_id		= 0;
		$m_work_sub_categ_id	= 0;
		$m_plan_id				= 0;
		$m_scheme_type_id		= 0;
		$m_benificiary_id		= 0;
		$ben_capacity			= 0;		
		$from_date				= '';
		$to_date				= '';
		$title					= '';
		$title_code				= '';

		$title_code = 'Work Not Completed';
		$condition += array('WorkCreation.is_assign_je'	=> 'Y');

		if(isset($this->params['named']['m_agency_id']) && (int)$this->params['named']['m_agency_id'] != 0){
			$m_agency_id = $this->params['named']['m_agency_id'];
			$condition += array('WorkCreation.work_agency_id'	=> $m_agency_id);
		}
		if(isset($this->params['named']['agency_name']) && $this->params['named']['agency_name'] != ''){
			$agency_name = $this->params['named']['agency_name'];
		}
		if(isset($this->params['named']['f_year']) && $this->params['named']['f_year'] != ''){
			$f_year = $this->params['named']['f_year'];
			$condition += array('WorkCreation.fyear'	=> $f_year);
		}
		if(isset($this->params['named']['m_work_categ_id']) && (int)$this->params['named']['m_work_categ_id'] != 0){
			$m_work_categ_id = $this->params['named']['m_work_categ_id'];
			$condition += array('WorkCreation.m_work_categ_id'	=> $m_work_categ_id);
		}
		if(isset($this->params['named']['m_work_sub_categ_id']) && (int)$this->params['named']['m_work_sub_categ_id'] != 0){
			$m_work_sub_categ_id = $this->params['named']['m_work_sub_categ_id'];
			$condition += array('WorkCreation.m_work_sub_categ_id'	=> $m_work_sub_categ_id);
		}
		if(isset($this->params['named']['m_plan_id']) && (int)$this->params['named']['m_plan_id'] != 0){
			$m_plan_id = $this->params['named']['m_plan_id'];
			$condition += array('WorkCreation.m_plan_id'	=> $m_plan_id);
		}
		if(isset($this->params['named']['m_scheme_type_id']) && (int)$this->params['named']['m_scheme_type_id'] != 0){
			$m_scheme_type_id = $this->params['named']['m_scheme_type_id'];
			$condition += array('WorkCreation.m_scheme_type_id'	=> $m_scheme_type_id);
		}
        if(isset($this->params['named']['m_benificiary_id']) && (int)$this->params['named']['m_benificiary_id'] != 0){
            $m_benificiary_id = $this->params['named']['m_benificiary_id'];
            $condition += array('WorkCreation.m_benificiary_id'     => $m_benificiary_id);
        }
        if(isset($this->params['named']['ben_capacity']) && (int)$this->params['named']['ben_capacity'] != 0){
            $ben_capacity = $this->params['named']['ben_capacity'];
            $condition += array('WorkCreation.ben_capacity'     => $ben_capacity);
        }		
		if(isset($this->params['named']['from_date']) && $this->params['named']['from_date'] != ''){
			$from_date       = $this->date2DB($this->params['named']['from_date'],'-');
			$condition+=array('WorkCreation.work_submission_date >='=>$from_date);
		}
		if(isset($this->params['named']['to_date']) && $this->params['named']['to_date'] != ''){
			$to_date      = $this->date2DB($this->params['named']['to_date'],'-');
			$condition+=array('WorkCreation.work_submission_date <='	=>$to_date);
		}
		if(isset($this->params['named']['img_m_status_id']) && $this->params['named']['img_m_status_id'] != ''){
			$img_m_status_id      = $this->params['named']['img_m_status_id'];
			if($img_m_status_id == 'p'){
				$condition+=array('WorkCreation.is_work_completed ='	=> 'N');
			}
			if($img_m_status_id == 'c'){
				$condition+=array('WorkCreation.is_work_completed ='	=> 'Y');
			}			
			
		}		
		//$this->WorkCreation->unBindModel(array('belongsTo' => array('MPlan','MWorkCateg','MWorkSubCateg','MParticular','MBlock','MVillage','MGrampanchayat','MQuarter')));
		$this->WorkCreation->unBindModel(array('hasMany' => array('WorkCreationFund')));
		$this->WorkCreation->unBindModel(array('hasOne'=> array('FeasibiltyCheckDetail')));
		$this->WorkCreation->bindModel(array('hasMany' => array('PaymentBreakup')));
		$this->WorkProcessDetail->bindModel(array('hasMany' => array(
			'MbUploadDetail' 	=> array(
			   'className' 		=> 'MbUploadDetail',
			   'foreignKey' 	=> 'work_process_id',
			),
		)));
		$this->WorkCreation->bindModel(array(
            'hasMany' => array(
                'PaymentBreakup' => array(
					'className'     => 'PaymentBreakup',
					'foreignKey'    => 'work_creation_id',
					'dependent'     => true					
                ),
            ),
        ));			
		$this->paginate = array(
			'limit'     	=> 10,
			'recursive'		=> 3,
			'conditions'    => $condition,
			'order'			=> array('WorkCreation.work_creation_id'	=> 'DESC'),
		);
		//debug($this->paginate('WorkCreation'));exit;
		if(isset($this->params['named']['xl']) && $this->params['named']['xl']=='Y'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
		}
		if(isset($this->params['named']['reqType']) && $this->params['named']['reqType']=='XLS'){
			$this->layout='export_xls';
			$this->set('is_excel','Y');
			$this->set('file_name','work_progress_report'.date('d_m_Y').'.xls');
		} 		
		$this->set(array(
			'workCreats'			=> $this->paginate('WorkCreation'),
			'm_agency_id'			=> $m_agency_id,
			'agency_name'			=> $agency_name,
			'f_year'				=> $f_year,
			'm_work_categ_id'		=> $m_work_categ_id,
			'm_work_sub_categ_id'	=> $m_work_sub_categ_id,
			'm_plan_id'				=> $m_plan_id,
			'm_scheme_type_id'		=> $m_scheme_type_id,
			'm_benificiary_id'		=> $m_benificiary_id,
			'ben_capacity'			=> $ben_capacity,
			'img_m_status_id'		=> $img_m_status_id,			
			'from_date'				=> $from_date,
			'to_date'				=> $to_date,
			'title'					=> $title,
			'title_code'			=> $title_code,
		));		
	}	
}
<style type="text/css">
/*    .bgcolor:nth-child(even) {background: #ec9742}
    .bgcolor:nth-child(odd) {background: #80ce24}*/
    .bg{
        background:#cce2f0;
    }
    .bgcolor{
        background: white;
    }
    .head{
        background: #cce2f0;
    }

</style>
<?
require_once("../common/globali.php");
require_once("../common/meta_tags.php");
require_once("../common/sqlserver.php");
 header('Content-type: application/vnd.ms-excel');
 header('Content-Disposition: attachment; filename="Audit_Report.xls"');
$formname   = (isset($_GET['formname']) && $_GET['formname'] != '')?$_GET['formname']:'';
$query_Work_lising_sql = "select * from audit_log where form_name = '".trim($formname)."' order by audit_id desc";
//echo $query_Work_lising_sql;exit;
$work_list_res1 = pg_query($query_Work_lising_sql);
//print_r(pg_fetch_array($work_list_res1));
?>
<?php if(isset($work_list_res1) && pg_num_rows($work_list_res1)>0){?>

            <?
                
                $resarray=array();
                while($row = pg_fetch_array($work_list_res1))
                {
                    //print_r($row);
                    $tbl = json_decode($row['table_value']);
                    // echo '<pre>';
                    // print_r($tbl);
                    if(trim($row['form_name'])=='Expenditure Planner(Previous Financial Year)'){
                        $sql="select work_name,pcode from pm_works where work_id=".$tbl->uwa_work_id."";
                        $res = pg_query($sql);
                        extract(pg_fetch_assoc($res));
                        $resarray[$work_name."*****".$tbl->uwa_year."*****".$tbl->uwa_month."*****".$pcode."*****".$tbl->log_modified."*****"][]=$tbl;
                         //echo '<pre>';
                         //print_r($resarray);
                    }
                    if(trim($row['form_name'])=='Physical Target/Achievement Updation'){
                        $sql1="select work_name,pcode from pm_works where work_id=".$tbl->work_id."";
                        $res1 = pg_query($sql1);
                        extract(pg_fetch_assoc($res1));
                        $resarray1[$work_name."*****".$tbl->year."*****".$tbl->month."*****".$pcode."*****".$tbl->log_modified."*****"][]=$tbl;
                         // echo '<pre>';
                         // print_r($resarray1);
                    }
                     if(trim($row['form_name'])=='Overall target for the Project'){
                        // echo '<pre>';
                        // print_r($tbl);
                        $sql2="select work_name,pcode from pm_works where work_id=".$tbl->work_id."";
                        //echo $sql2;
                        $res2 = pg_query($sql2);
                        extract(pg_fetch_assoc($res2));
                        $resarray2[$work_name."*****".$pcode."*****".$tbl->log_modified."*****"][]=$tbl;
                        // echo '<pre>';
                        // print_r($resarray2);
                    }
                    if(trim($row['form_name'])=='Manage Component'){
                        $sql3="select work_name,pcode from pm_works where work_id=".$tbl->work_id."";
                        $res3 = pg_query($sql3);
                        extract(pg_fetch_assoc($res3));
                        $resarray3[$work_name."*****".$pcode."*****".$tbl->log_modified."*****"][]=$tbl;
                    }
                    if(trim($row['form_name'])=='Work Transfer'){
                        $sql4="select work_name,pcode from pm_works where work_id=".$tbl->work_id."";
                        //echo $sql41="select circle_name from circle where circle_id=".$tbl->wa_circle_id."";
                        $res4 = pg_query($sql4);
                        extract(pg_fetch_assoc($res4));
                        $resarray4[$work_name."*****".$pcode."*****".$tbl->log_modified."*****"][]=$tbl;
                        // echo '<pre>';
                        // print_r($resarray4);
                    }
                    
            ?>
            
            <?php }
   //===========================Expenditure planner======================================================  -->

if(isset($resarray) && count($resarray)>0){?>
<h2>Expenditure Planner(Previous Financial Year)(All Amount in Lakhs /-)</h2>
        <table width="100%" cellspacing="1" cellpadding="0" bgcolor="" border="1" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
        <thead class="head">
        <tr style="">
        <th colspan="4"></th>
        <th colspan="4">Before Update</th>
        <th colspan="4">After Update</th>
        <th colspan=""></th>
        <th colspan=""></th>
        </tr>
            <tr class="bg">
                <th align="center"  class="blk2b" >Sl. No.</th>
                <th align="center"  class="blk2b" width="400">Work Name</th>
                <th align="left"    class="blk2b">Year</th>
                <th align="left"    class="blk2b">Month</th>
                <th align="left"    class="blk2b">Target(Propose Expenditure)</th>
                <th align="left"    class="blk2b" style="width: 96px;">Achievement (Actual Expenditure)</th>
                <th align="left"    class="blk2b">Reason </th>
                <th align="left"    class="blk2b" style="width: 96px;">Miscellaneous Expenditure</th>
                <th align="left"    class="blk2b">Target(Propose Expenditure)</th>
                <th align="left"    class="blk2b" style="width: 96px;">Achievement (Actual Expenditure)</th>
                <th align="left"    class="blk2b">Reason </th>
                <th align="left"    class="blk2b" style="width: 96px;">Miscellaneous Expenditure</th>
                <th align="left"    class="blk2b">Updated Date</th>
                <th align="left"    class="blk2b">Updated By</th>

            </tr>
        </thead>
        <tbody style="">
        <?php $cnt = 0;
        $workname="";
        $projectNameArr = array();
        foreach ($resarray as $key => $resvalue) {
            $keyvalues = explode('*****',$key);
            if(($workname == "") || ($workname != $keyvalues[0]))
            {
                $cnt++;
                $projectNameArr[$cnt][] = $keyvalues[0];
            }else{
                $projectNameArr[$cnt][] = $keyvalues[0];
            }
            // echo '<pre>';
            // print_r($keyvalues);
            $workname = $keyvalues[0];
        }
        // echo '<pre>';
        // print_r($projectNameArr);
        $cnt = 0;
        foreach ($resarray as $key => $resvalue) {
            //$cnt++;
            // echo "<pre>";
            // print_r($resvalue);
            $keyvalue = explode('*****',$key);
            ?>
            <tr class="bgcolor">
            
                <?php if(($workname == "") || ($workname != $keyvalue[0])){
                    $cnt++;
                    ?>
                    <td align="center" class="blk2" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $cnt;}?>
                </td>
                
                
                <?php if(($workname == "") || ($workname != $keyvalue[0]))
                {?>
                <td align="left" class="blk2" style="word-wrap: break-word;" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $keyvalue[0]; ?><br><strong><?php echo $keyvalue[3]; ?></strong>
                    </td>
                <?php }?>                
                
                <td align="left" class="blk2"><?php echo $keyvalue[1]; ?></td>
                <td align="left" class="blk2"><?php echo date("F",strtotime("2001-" . $keyvalue[2] . "-01")); ?></td>
                
                 <?php if($resvalue[1]->action =='Before Update' ){ ?>
                <td align="left" class="blk2" style=""><?php echo $resvalue[1]->exp_amount; ?></td>
                <td align="left" class="blk2" style=""><?php echo $resvalue[1]->act_amount; ?></td>
                <td align="left" class="blk2" style=""><?php echo $resvalue[1]->uwa_remarks; ?></td>
                <td align="left" class="blk2" style=""><?php echo $resvalue[1]->misc_amount; ?></td>
                <?php } ?>
                <?php if($resvalue[1] == ''){ ?>
                <td style=""></td>
                <td style=""></td>
                <td style=""></td>
                <td style=""></td>                   
                <?php } ?>
                <?php 
                    if($resvalue[0]->action =='After Update'){
                    ?>

                <td align="left" class="blk2" style="">
                <?php if($resvalue[1]->exp_amount != $resvalue[0]->exp_amount){ ?>
                 <b><?php echo $resvalue[0]->exp_amount; ?></b>
                 <?php  }else{ ?>
                 <?php echo $resvalue[0]->exp_amount; ?>
                   <?php } ?>
                </td>
                <td align="left" class="blk2" style="">
                <?php if($resvalue[1]->act_amount != $resvalue[0]->act_amount){ ?>
                 <b><?php echo $resvalue[0]->act_amount; ?></b>
                 <?php  }else{ ?>
                 <?php echo $resvalue[0]->act_amount; ?>
                   <?php } ?>
                </td>
                <td align="left" class="blk2" style="">
                <?php if($resvalue[1]->uwa_remarks != $resvalue[0]->uwa_remarks){ ?>
                 <b><?php echo $resvalue[0]->uwa_remarks; ?></b>
                 <?php  }else{ ?>
                 <?php echo $resvalue[0]->uwa_remarks; ?>
                   <?php } ?>
                </td>
                <td align="left" class="blk2" style="">
                <?php if($resvalue[1]->misc_amount != $resvalue[0]->misc_amount){ ?>
                 <b><?php echo $resvalue[0]->misc_amount; ?></b>
                 <?php  }else{ ?>
                 <?php echo $resvalue[0]->misc_amount; ?>
                   <?php } ?>
                </td>
                <?php } ?>
                <td align="left" class="blk2"><?php echo $keyvalue[4]; ?></td>
                <td align="left" class="blk2">Admin</td>
                </th>
            </tr>
           
    <?php $workname = $keyvalue[0]; }?>
    </tbody>
    </table>
  <?php }?>
<!--   //==================================physical target Achivement===============================================  -->

<?php if(isset($resarray1) && count($resarray1)>0){?>
<h2>Physical Target/Achievement Updation(All Amount in Lakhs /-)</h2>

        <table width="100%" cellspacing="1" cellpadding="0" bgcolor="" border="1" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
        <thead class="head">
        <tr style="">
        <th colspan="4"></th>
        <th colspan="4">Before Update</th>
        <th colspan="4">After Update</th>
        <th colspan=""></th>
        <th colspan=""></th>
        </tr>
            <tr class="bg">
                <th align="center"  class="blk2b" >Sl. No.</th>
                <th align="center"  class="blk2b" width="400">Work Name</th>
                <th align="left"    class="blk2b">Year</th>
                <th align="left"    class="blk2b">Month</th>

                <th align="left"    class="blk2b">Physical Target</th>
                <th align="left"    class="blk2b">Revise Physical Target(if Any)</th>
                <th align="left"    class="blk2b">Physical Progress</th>
                <th align="left"    class="blk2b">Reason for Shortfall </th>

                <th align="left"    class="blk2b">Physical Target</th>
                <th align="left"    class="blk2b">Revise Physical Target(if Any)</th>
                <th align="left"    class="blk2b">Physical Progress</th>
                <th align="left"    class="blk2b">Reason for Shortfall </th>
                <th align="left"    class="blk2b">Updated Date</th>
                <th align="left"    class="blk2b">Updated By</th>

            </tr>
        </thead>
        <tbody style="">
        <?php $cnt = 0;
        $workname="";
        $projectNameArr = array();
        foreach ($resarray1 as $key => $resvalue) {
            $keyvalues = explode('*****',$key);
            if(($workname == "") || ($workname != $keyvalues[0]))
            {
                $cnt++;
                $projectNameArr[$cnt][] = $keyvalues[0];
            }else{
                $projectNameArr[$cnt][] = $keyvalues[0];
            }
            // echo '<pre>';
            // print_r($keyvalues);
            $workname = $keyvalues[0];
        }
        // echo '<pre>';
        // print_r($projectNameArr);
        $cnt = 0;
        foreach ($resarray1 as $key => $resvalue) {
            //$cnt++;
            $keyvalue = explode('*****',$key);
            // echo "<pre>";
            // print_r($resvalue);
            ?>
            <tr class="bgcolor">
            <?php if(($workname == "") || ($workname != $keyvalue[0])){
                    $cnt++;
                    ?>
                    <td align="center" class="blk2" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $cnt;}?>
                </td>
                
                
                <?php if(($workname == "") || ($workname != $keyvalue[0]))
                {?>
                <td align="left" class="blk2" style="word-wrap: break-word;" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $keyvalue[0]; ?><br><strong><?php echo $keyvalue[3]; ?></strong>
                    </td>
                <?php }?>  

                <td align="left" class="blk2"><?php echo $keyvalue[1]; ?></td>
                <td align="left" class="blk2"><?php echo date("F",strtotime("2001-" . $keyvalue[2] . "-01")); ?></td>
                <td align="left" class="blk2" style="">
                <?php
                if($resvalue[1]->cumulative_target != 'NULL'){
                echo $resvalue[1]->cumulative_target;  
                }
                ?></td>
                <td align="left" class="blk2" style="">
                <?php 
                if($resvalue[1]->cumulative_ext_target != 'NULL'){
                echo $resvalue[1]->cumulative_ext_target; 
                }
                ?>
                </td>
                <td align="left" class="blk2" style="">
                <?php
                if($resvalue[1]->phy_progress != 'NULL'){
                echo $resvalue[1]->phy_progress; 
                }
                 ?>
                 </td>
                <td align="left" class="blk2" style="">
                <?php
                 if($resvalue[1]->shortfall_reason != 'NULL'){
                 echo $resvalue[1]->shortfall_reason; 
                }
                 ?></td>

                <td align="left" class="blk2" style="">
                <?php
                if($resvalue[0]->cumulative_target != $resvalue[1]->cumulative_target){ ?>
                <b><?php echo $resvalue[0]->cumulative_target; ?></b>
                <?php }else{ ?>
                 <?php echo $resvalue[0]->cumulative_target; ?>
                <?php }
                 ?>
                 </td>
                 <td align="left" class="blk2" style="">
                <?php
                if($resvalue[0]->cumulative_ext_target != $resvalue[1]->cumulative_ext_target){ ?>
                <b><?php echo $resvalue[0]->cumulative_ext_target; ?></b>
                <?php }else{ ?>
                 <?php echo $resvalue[0]->cumulative_ext_target; ?>
                <?php }
                 ?>
                 </td>
                  <td align="left" class="blk2" style="">
                <?php
                if($resvalue[0]->phy_progress != $resvalue[1]->phy_progress){ ?>
                <b><?php echo $resvalue[0]->phy_progress; ?></b>
                <?php }else{ ?>
                 <?php echo $resvalue[0]->phy_progress; ?>
                <?php }
                 ?>
                 </td>
                 <td align="left" class="blk2" style="">
                <?php
                if($resvalue[0]->shortfall_reason != $resvalue[1]->shortfall_reason){ ?>
                <b><?php echo $resvalue[0]->shortfall_reason; ?></b>
                <?php }else{ ?>
                 <?php echo $resvalue[0]->shortfall_reason; ?>
                <?php }
                 ?>
                 </td>



                <td align="left" class="blk2"><?php echo $resvalue[0]->log_modified; ?></td>
                <td align="left" class="blk2">Admin</td>
                </th>
            </tr>
    <?php $workname = $keyvalue[0];
    }?>
    </tbody>
    </table>
  <?php }?>
<!--   //==========================Overall target updation=======================================================  -->
<?php if(isset($resarray2) && count($resarray2)>0){?>
<h2>Overall target for the Project(All Amount in Lakhs /-)</h2>

        <table width="100%" cellspacing="1" cellpadding="0" bgcolor="" border="1" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
        <thead class="head">
        <tr style="">
        <th colspan="2"></th>
        <th colspan="1">Before Update</th>
        <th colspan="1">After Update</th>
        <th colspan=""></th>
        <th colspan=""></th>
        </tr>
            <tr class="bg">
                <th align="center"  class="blk2b" >Sl. No.</th>
                <th align="center"  class="blk2b" width="400">Work Name</th>
                <th align="center"  class="blk2b" width="400">Overall Target</th>
                <th align="center"  class="blk2b" width="400">Overall Target</th>

                <th align="left"    class="blk2b">Updated Date</th>
                <th align="left"    class="blk2b">Updated By</th>

            </tr>
        </thead>
        <tbody style="">
        <?php $cnt = 0;
        $workname="";
        $projectNameArr = array();
        foreach ($resarray2 as $key => $resvalue) {
            $keyvalues = explode('*****',$key);
            if(($workname == "") || ($workname != $keyvalues[0]))
            {
                $cnt++;
                $projectNameArr[$cnt][] = $keyvalues[0];
            }else{
                $projectNameArr[$cnt][] = $keyvalues[0];
            }
            // echo '<pre>';
            // print_r($keyvalues);
            $workname = $keyvalues[0];
        }
            // echo '<pre>';
            // print_r($keyvalues);
        $cnt = 0;
        foreach ($resarray2 as $key => $resvalue) {
            $keyvalue = explode('*****',$key);

            ?>
            <tr class="bgcolor">
             <?php if(($workname == "") || ($workname != $keyvalue[0])){
                    $cnt++;
                    ?>
                    <td align="center" class="blk2" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $cnt;?>
                </td>
                <?php } ?>
                

                <?php if(($workname == "") || ($workname != $keyvalue[0]))
                {?>
                <td align="left" class="blk2" style="word-wrap: break-word;" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $keyvalue[0]; ?><br><strong><?php echo $keyvalue[1]; ?></strong>
                    </td>
                <?php }?> 


                <td align="left" class="blk2" style="word-wrap: break-word;"><?php echo $resvalue[1]->work_highlight; ?><br><strong><?php echo $keyvalue[4]; ?></strong></td> </th>
                <td align="left" class="blk2" style="word-wrap: break-word;">
                <?php if($resvalue[0]->work_highlight != $resvalue[1]->work_highlight){ ?>
                <b><?php echo $resvalue[0]->work_highlight; ?></b>
                   <?php }else{ ?>
                <?php echo $resvalue[0]->work_highlight; ?>
                   <?php } ?>
                </td>
                <td align="left" class="blk2"><?php echo $resvalue[0]->log_modified; ?></td>
                <td align="left" class="blk2">Admin</td>
            </tr>
    <?php                 $workname = $keyvalue[0];}?>
    </tbody>
    </table>
  <?php }?>
  <!--   //========================Manage Component=========================================================  -->
  <?php if(isset($resarray3) && count($resarray3)>0){?>
<h2>Manage Component(All Amount in Lakhs /-)</h2>

        <table width="100%" cellspacing="1" cellpadding="0" bgcolor="" border="1" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
        <thead class="head">
        <tr style="">
        <th colspan="2"></th>
        <th colspan="1">Before Update</th>
        <th colspan="1">After Update</th>
        <th colspan=""></th>
        <th colspan=""></th>
         <th colspan=""></th>
        </tr>
            <tr class="bg">
                <th align="center"  class="blk2b" style="width: 100px;">Sl. No.</th>
                <th align="center"  class="blk2b" width="400">Work Name</th>
                <th align="center"  class="blk2b" width="400">Component Name</th>
                <th align="center"  class="blk2b" width="400">Component Name</th>
                <th align="center"  class="blk2b" width="400" style="width: 133px;">Status</th>
                <th align="left"    class="blk2b">Updated Date</th>
                <th align="left"    class="blk2b">Updated By</th>

            </tr>
        </thead>
        <tbody style="">
        <?php $cnt = 0;
        $workname="";
        $projectNameArr = array();
        foreach ($resarray3 as $key => $resvalue) {
            $keyvalues = explode('*****',$key);
            if(($workname == "") || ($workname != $keyvalues[0]))
            {
                $cnt++;
                $projectNameArr[$cnt][] = $keyvalues[0];
            }else{
                $projectNameArr[$cnt][] = $keyvalues[0];
            }
            // echo '<pre>';
            // print_r($keyvalues);
            $workname = $keyvalues[0];
        }
        $cnt = 0;
        foreach ($resarray3 as $key => $resvalue) {
            //$cnt++;
            $keyvalue = explode('*****',$key);
            // echo '<pre>';
            // print_r($resvalue);
            ?>
            <tr class="bgcolor">

<?php if(($workname == "") || ($workname != $keyvalue[0])){
                    $cnt++;
                    ?>
                    <td align="center" class="blk2" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $cnt;?>
                </td>
                <?php } ?>
                
                
                <?php if(($workname == "") || ($workname != $keyvalue[0]))
                {?>
                <td align="left" class="blk2" style="word-wrap: break-word;" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $keyvalue[0]; ?><br><strong><?php echo $keyvalue[1]; ?></strong>
                    </td>
                <?php }?>                
                
                
                <?php if($resvalue[1]->action =='Before Update' ){ ?>
                <td align="center" class="blk2" style=""><?php echo $resvalue[1]->sub_comp_name; ?></td>
                <?php } ?>
                <?php if($resvalue[0]->action =='After Update' ){ ?>


                <td align="center" class="blk2" style="">
                <?php if($resvalue[0]->sub_comp_name != $resvalue[1]->sub_comp_name){ ?>
                <b><?php echo $resvalue[0]->sub_comp_name; ?></b>
                <?php }else{ ?>
<?php echo $resvalue[0]->sub_comp_name; ?>
                   <?php } ?>
                </td>


                <?php } ?>


                <?php if($resvalue[1]->action =='Before Update' ){ ?>
                <td align="left" class="blk2">
                <?php
                 if($resvalue[1]->action == 'Before Update'){
                    echo 'Component Updated';
                 }
                 ?>
                </td>
                <?php } ?>
                <?php if($resvalue[0]->action =='Delete Component' ){ ?>
                <td align="center" class="blk2" style=""><?php echo $resvalue[0]->sub_comp_name; ?></td>
                <td style=""></td>
                <td align="left" class="blk2">
                <?php 
                if($resvalue[0]->action == 'Delete Component'){
                    echo ' Component Deleted';
                 }
                ?>
                </td>
                <?php } ?>
                <td align="left" class="blk2"><?php echo $resvalue[0]->log_modified; ?></td>
                <td align="left" class="blk2">Admin</td>

            </tr>
    <?php $workname = $keyvalue[0];
    }?>
    </tbody>
    </table>
  <?php }?>
    <!--   //==================================Work Transfer===============================================  -->
      <?php if(isset($resarray4) && count($resarray4)>0){?>
<h2>Work Transfer(All Amount in Lakhs /-)</h2>
        <table width="100%" cellspacing="1" cellpadding="0" bgcolor="" border="1" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
        <thead class="head">
        <tr style="">
        <th colspan="2"></th>
        <th colspan="4">Before Update</th>
        <th colspan="4">After Update</th>
        <th colspan=""></th>
        <th colspan=""></th>
        </tr>
            <tr class="bg">
                <th align="center"  class="blk2b" style="width: 100px;">Sl. No.</th>
                <th align="center"  class="blk2b" width="400">Work Name</th>
                <th align="center"  class="blk2b" width="100">Circle Name</th>
                <th align="center"  class="blk2b" width="100">Division Name</th>
                <th align="center"  class="blk2b" width="200">Sub Division Name</th>
                <th align="center"  class="blk2b" width="200">Section Name</th>

                <th align="center"  class="blk2b" width="100">Circle Name</th>
                <th align="center"  class="blk2b" width="100">Division Name</th>
                <th align="center"  class="blk2b" width="200">Sub Division Name</th>
                <th align="center"  class="blk2b" width="200">Section Name</th>
                <th align="left"    class="blk2b">Updated Date</th>
                <th align="left"    class="blk2b">Updated By</th>

            </tr>
        </thead>
        <tbody style="">
        <?php $cnt = 0;
        $workname="";
        $projectNameArr = array();
        foreach ($resarray4 as $key => $resvalue) {
            $keyvalues = explode('*****',$key);
            if(($workname == "") || ($workname != $keyvalues[0]))
            {
                $cnt++;
                $projectNameArr[$cnt][] = $keyvalues[0];
            }else{
                $projectNameArr[$cnt][] = $keyvalues[0];
            }
            // echo '<pre>';
            // print_r($keyvalues);
            $workname = $keyvalues[0];
        }
        $cnt = 0;
        foreach ($resarray4 as $key => $resvalue) {
            //$cnt++;
            $keyvalue = explode('*****',$key);
            // echo '<pre>';
            // print_r($resvalue);
            //print_r($resvaluevalue);
            //echo $resvaluevalue->wa_circle_id;
            ?>
            <tr class="bgcolor">
            <?php if(($workname == "") || ($workname != $keyvalue[0])){
                    $cnt++;
                    ?>
                    <td align="center" class="blk2" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $cnt;?>
                </td>
                <?php } ?>
                
                
                <?php if(($workname == "") || ($workname != $keyvalue[0]))
                {?>
                <td align="left" class="blk2" style="word-wrap: break-word;" rowspan="<?php echo count($projectNameArr[$cnt]); ?>">
                    <?php echo $keyvalue[0]; ?><br><strong><?php echo $keyvalue[1]; ?></strong>
                    </td>
                <?php }?>                
                
                
                <td align="center" class="blk2" style="">
                <?php 
                //echo $resvalue[1]->wa_circle_id; 
                $sql1="select circle_name from circle where circle_id=".$resvalue[1]->wa_circle_id."";
                extract(pg_fetch_assoc(pg_query($sql1)));
                echo $circle_name;
                ?>
                </td>
                <td align="center" class="blk2" style="">
                <?php 
                $sql12="select division_name from division where division_id=".$resvalue[1]->wa_division_id."";
                extract(pg_fetch_assoc(pg_query($sql12)));
                echo $division_name;
                ?>
                </td>
                <td align="center" class="blk2" style="">
                <?php
                 $sql13="select sub_division_name from subdivision where sub_division_id=".$resvalue[1]->wa_sub_division_id."";
                 extract(pg_fetch_assoc(pg_query($sql13)));
                 echo $sub_division_name;
                 ?>
                </td>
                <td align="center" class="blk2" style="">
                <?php 
                $sql14="select section_name from section where section_id=".$resvalue[1]->wa_section_id."";
                extract(pg_fetch_assoc(pg_query($sql14)));
                echo $section_name;
                ?>
                </td>

                <td align="center" class="blk2" style="">
                <?php
                 $sql2="select circle_name from circle where circle_id=".$resvalue[0]->wa_circle_id."";
                 extract(pg_fetch_assoc(pg_query($sql2)));
                 //echo $circle_name; 
                 ?>
                 <?php if($resvalue[0]->wa_circle_id != $resvalue[1]->wa_circle_id){ ?>
                    <b><?php echo $circle_name; ?></b>
                   <?php }else{ 
                    echo $circle_name; 
                   }
                    ?>

                 </td>
                <td align="center" class="blk2" style="">
                <?php
                 $sql22="select division_name from division where division_id=".$resvalue[0]->wa_division_id."";
                extract(pg_fetch_assoc(pg_query($sql22)));
                //echo $division_name;
                  ?>
                  <?php if($resvalue[0]->wa_division_id != $resvalue[1]->wa_division_id){ ?>
                    <b><?php echo $division_name; ?></b>
                   <?php }else{ 
                    echo $division_name; 
                   }
                    ?>
                </td>
                <td align="center" class="blk2" style="">
                <?php
                 $sql23="select sub_division_name from subdivision where sub_division_id=".$resvalue[0]->wa_sub_division_id."";
                 extract(pg_fetch_assoc(pg_query($sql23)));
                 //echo $sub_division_name;
                  ?>
                  <?php if($resvalue[0]->wa_sub_division_id != $resvalue[1]->wa_sub_division_id){ ?>
                    <b><?php echo $sub_division_name; ?></b>
                   <?php }else{ 
                    echo $sub_division_name; 
                   }
                    ?>
                </td>
                <td align="center" class="blk2" style="">
                <?php
                $sql24="select section_name from section where section_id=".$resvalue[0]->wa_section_id."";
                extract(pg_fetch_assoc(pg_query($sql24)));
                //echo $section_name; 
                 ?>
                 <?php if($resvalue[0]->wa_section_id != $resvalue[1]->wa_section_id){ ?>
                    <b><?php echo $section_name; ?></b>
                   <?php }else{ 
                    echo $section_name; 
                   }
                    ?>
                </td>
                <td align="left" class="blk2"><?php echo $resvalue[0]->log_modified; ?></td>
                <td align="left" class="blk2">Admin</td>
            </tr>
    <?php $workname = $keyvalue[0];}?>
    </tbody>
    </table>
  <?php }?>
      <!--   //=================================================================================  -->
<?php }?>

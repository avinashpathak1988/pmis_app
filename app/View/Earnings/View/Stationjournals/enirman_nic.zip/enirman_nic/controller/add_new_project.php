<?
checklogin();

$user=$_SESSION["sess_user_id"];
$opt = (isset($_GET['opt']) && $_GET['opt'] != "")? $_GET['opt']:'';
$msg = (isset($_GET['msg']) && $_GET['msg'] != "")? base64_decode($_GET['msg']):'';
if(preg_match('#<[^>]+>#',$msg)){
     $msg='';
}
$id = (isset($_GET['id']) && $_GET['id'] != 0)?(int) $_GET['id']:0;
$budget_provision_row = (isset($_GET['budget_provision_row']) && $_GET['budget_provision_row'] != '')?(int)$_GET['budget_provision_row']:0;
$PrevBudgetTable_amount_row = (isset($_GET['PrevBudgetTable_amount_row']) && $_GET['PrevBudgetTable_amount_row'] != '')?(int)$_GET['PrevBudgetTable_amount_row']:0;
$sess_user_id = $_SESSION["sess_user_id"];
$sess_wing_id = $_SESSION["sess_wings_id"];
$session_circle_id = $_SESSION["session_circle_id"];
$session_division_id = $_SESSION["session_division_id"];
$session_sub_division_id = $_SESSION["session_sub_division_id"];
$session_section_id = $_SESSION["session_section_id"];
$session_district_id = $_SESSION["session_district_id"];
$building_type_name = 0;
 //print_r($_SESSION);

if(isset($_POST['submit']) && $_POST['submit'] == 'Save')
{
     extract($_POST);
     if($_SESSION['token'] != $token_code)
    { 
        $error[] = "Please Try Later";
        $pre_work_name='';
        $pre_work_remark='';
        $short_work_name='';
    }
    if($pre_work_name == "")
     {
         $error[] = "Please Enter Project Name.";
     }
    //  if($pre_work_name != "")
    //  {
    // if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $pre_work_name))
    //      {
    //         $error[] = "Please Enter Valid Project Name.";
    //         $pre_work_name='';
    //      }
    //  }
     if(strlen($pre_work_name)>500)
     {
     	$error[] = "Work Name Should Not Exceed 500 charcter.";
     }
     if($project_type == 0)
     {
        $error[] = "Please Enter Project Type.";
     }	 
     
     if($project_head == 0)
     {
        $error[] = "Please Enter Project Head.";
     }
     if($source_fund_id == 0)
     {
        $error[] = "Please Select Scheme .";
     }

     
     if($wings_id == 0)
     {
        $error[] = "Please Select Wing .";
     }		 
     if($short_work_name == '')
     {
        $error[] = "Please Enter Project Code.";
     }
     if($short_work_name != "")
     {
    if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $short_work_name))
         {
            $error[] = "Please Enter Valid Project Code.";
            $short_work_name='';
         }
     }
     if($aa_amount == '')
     {
        $error[] = "Please Enter A/A Amount.";
     }
     if($tec_san_amount == '')
     {
        $error[] = "Please Enter Technical Sanction Amount.";
     }
     if($aa_amount != '')
     {
        if(!preg_match("/^[0-9.]+$/i", $aa_amount)){

           $error[] = "Please Enter valid A/A Amount.";
        }
     }
     if($tec_san_amount != '')
     {
        if(!preg_match("/^[0-9.]+$/i", $tec_san_amount)){

           $error[] = "Please Enter valid Technical Sanction Amount .";
        }
     }
     if($dpr_sub_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$dpr_sub_date)) 
         {
            $error[] = "Please Enter Valid Submission of DPR .";
         }
     } 
     if($dpr_san_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$dpr_san_date)) 
         {
            $error[] = "Please Enter Valid Approval of DPR.";
         }
     } 
     if($est_sub_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$est_sub_date)) 
         {
            $error[] = "Please Enter Valid Submission date of detail estimate.";
         }
     } 


     if($tec_san_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$tec_san_date)) 
         {
            $error[] = "Please Enter Valid Technical Sanction Date.";
         }
     } 
     if($aa_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$aa_date)) 
         {
            $error[] = "Please Enter Valid Admin. Approval Date.";
         }
     } 
     if($date_of_inv != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$date_of_inv)) 
         {
            $error[] = "Please Enter Valid Date of invitation tender.";
         }
     } 
     if($date_of_fin != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$date_of_fin)) 
         {
            $error[] = "Please Enter Valid Date of finalization of tender.";
         }
     }
     if($pre_work_remark != "")
     {
       if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $pre_work_remark))
         {
            $error[] = "Please Enter Valid Remark.";
            $pre_work_remark='';
         }
     }
     if($date_of_fin == '')
     {
        $error[] = "Please Enter Date of finalization of tender.";
     }
     if($date_of_inv == '')
     {
        $error[] = "Please Enter Date of invitation tender.";
     }
     if($aa_date == '')
     {
        $error[] = "Please Enter Admin. Approval Date.";
     }
      if($tec_san_date == '')
     {
        $error[] = "Please Enter Technical Sanction Date.";
     }
     if($est_sub_date == '')
     {
        $error[] = "Please Enter Submission date of detail estimate.";
     }
     if($dpr_san_date == '')
     {
        $error[] = "Please Enter Approval of DPR.";
     }
     if($dpr_sub_date == '')
     {
        $error[] = "Please Enter Submission of DPR .";
     }
     
     
     $count_error = 0;
     if($error)
     {
        foreach($error as $val)
        {
            if($val){
            $count_error ++;
            }   
        } 
     }
     if($count_error == 0)
     {  
			//echo ($project_type);exit;
		   //MS SQL Escape double quotes
		   
		   $pre_work_name = escapeSingleQuotes($pre_work_name);
		  
		   $short_work_name = escapeSingleQuotes($short_work_name); 
		   $pre_work_remark = escapeSingleQuotes($pre_work_remark);
		
			if($aa_date != ''){ $aa_date=date2mysql($aa_date); }	
			if($date_of_inv != ''){ $date_of_inv=date2mysql($date_of_inv); }		
			if($date_of_fin != ''){ $date_of_fin=date2mysql($date_of_fin); }
			if($dpr_sub_date != ''){ $dpr_sub_date=date2mysql($dpr_sub_date); }		
			if($dpr_san_date != ''){ $dpr_san_date=date2mysql($dpr_san_date); }		
			if($est_sub_date != ''){ $est_sub_date=date2mysql($est_sub_date); }	
			 if($tec_san_date != ''){ $tec_san_date=date2mysql($tec_san_date); }	
			if($aa_amount == ''){$aa_amount = 0;}
			if($tec_san_amount == ''){$tec_san_amount = 0;}
   
		   $sess_cir_id_proj = $_SESSION["session_circle_id"];
		   if($sess_cir_id_proj == 0){
			 $sess_cir_id_proj = 0;
		   }
		   
		   $sess_div_id_proj = $_SESSION["session_division_id"];
		   if($sess_div_id_proj == 0){
			 $sess_div_id_proj = 0;
		   }	
		   
		   $sess_subdiv_id_proj = $_SESSION["session_sub_division_id"];
		   if($sess_subdiv_id_proj == 0){
			 $sess_subdiv_id_proj = 0;
		   }
		   
		   $sess_sec_id_proj = $_SESSION["session_section_id"];
		   if($sess_sec_id_proj == 0){
			 $sess_sec_id_proj = 0;
		   }


		    $date = date("Y-m-d");
		   // $query 		= "select * from USP_PREWORK_INSERT_UPDATE ('".$pre_work_name."',".$project_type.",'".$short_work_name."',".$project_head_demo.",".$source_fund_id.",".$wings_id.",".$aa_amount.",'".$aa_date."','".$date_of_inv."','".$date_of_fin."','".$dpr_sub_date."','".$dpr_san_date."','".$est_sub_date."','".$tec_san_date."',".$tec_san_amount.",'','N','".$date."','".$_SESSION["sess_power_id"]."',
		   // '".$sess_cir_id_proj."','".$sess_div_id_proj."',0,0,0,'I','".$pre_work_remark."')";
	   
		   //$query 		= "select * from USP_PREWORK_INSERT_UPDATE  ('".$pre_work_name."',".$project_type.",'".$short_work_name."',".$project_head_demo.",".$source_fund_id.",".$wings_id.",".$aa_amount.",'".$aa_date."','".$date_of_inv."','".$date_of_fin."','".$dpr_sub_date."','".$dpr_san_date."','".$est_sub_date."','".$tec_san_date."',".$tec_san_amount.",'','N','','".$_SESSION["sess_power_id"]."','".$sess_cir_id_proj."','".$sess_div_id_proj."','".$sess_subdiv_id_proj."','".$sess_sec_id_proj."','".$pre_work_id."','I','".$pre_work_remark."') ";
		   $query 		= "select * from USP_PREWORK_INSERT_UPDATE  ('".$pre_work_name."',".$project_type.",'".$short_work_name."',".$project_head.",".$source_fund_id.",".$wings_id.",".$aa_amount.",'".$aa_date."','".$date_of_inv."','".$date_of_fin."','".$dpr_sub_date."','".$dpr_san_date."','".$est_sub_date."','".$tec_san_date."',".$tec_san_amount.",'','N','".$date."','".$_SESSION["sess_power_id"]."',".$sess_cir_id_proj.",".$sess_div_id_proj.",".$sess_subdiv_id_proj.",".$sess_sec_id_proj.",0,'I','".$pre_work_remark."') ";
 
          
		   //echo  $query;exit;
		   $data_res 	= pg_query($query);

		   $msg = "New Work  has been Saved Successfully.";
		   $msg= base64_encode($msg);
		   header("Location:index.php?page=267&msg=".urlencode($msg));
		   exit(0);    
       } 
}	   
 
 
 
if(isset($_POST['submit']) && $_POST['submit'] == 'Update')
{
    extract($_POST);
     if($_SESSION['token'] != $token_code)
    { 
        $error[] = "Please Try Later";
    }
    if($pre_work_name == "")
     {
         $error[] = "Please Enter Project Name.";
     }
     // if($pre_work_name != "")
     // {
     //   if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $pre_work_name))
     //     {
     //        $error[] = "Please Enter Valid Project Name.";
     //     }
     // }
     if(strlen($pre_work_name)>500)
     {
        $error[] = "Work Name Should Not Exceed 500 charcter.";
     }
     if($project_type == 0)
     {
        $error[] = "Please Enter Project Type.";
     }   
     
     if($project_head == 0)
     {
        $error[] = "Please Enter Project Head.";
     }
     if($source_fund_id == 0)
     {
        $error[] = "Please Select Scheme .";
     }

     
     if($wings_id == 0)
     {
        $error[] = "Please Select Wing .";
     }       
     if($short_work_name == '')
     {
        $error[] = "Please Enter Project Code.";
     }
     if($short_work_name != "")
     {
       if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $short_work_name))
         {
            $error[] = "Please Enter Valid Project Code.";
         }
     }
     if($aa_amount == '')
     {
        $error[] = "Please Enter A/A Amount.";
     }
     if($tec_san_amount == '')
     {
        $error[] = "Please Enter Technical Sanction Amount.";
     }
     if($aa_amount != '')
     {
        if(!preg_match("/^[0-9.]+$/i", $aa_amount)){

           $error[] = "Please Enter valid A/A Amount.";
        }
     }
     if($tec_san_amount != '')
     {
        if(!preg_match("/^[0-9.]+$/i", $tec_san_amount)){

           $error[] = "Please Enter valid Technical Sanction Amount .";
        }
     }
     if($dpr_sub_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$dpr_sub_date)) 
         {
            $error[] = "Please Enter Valid Submission of DPR .";
         }
     } 
     if($dpr_san_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$dpr_san_date)) 
         {
            $error[] = "Please Enter Valid Approval of DPR.";
         }
     } 
     if($est_sub_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$est_sub_date)) 
         {
            $error[] = "Please Enter Valid Submission date of detail estimate.";
         }
     } 


     if($tec_san_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$tec_san_date)) 
         {
            $error[] = "Please Enter Valid Technical Sanction Date.";
         }
     } 
     if($aa_date != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$aa_date)) 
         {
            $error[] = "Please Enter Valid Admin. Approval Date.";
         }
     } 
     if($date_of_inv != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$date_of_inv)) 
         {
            $error[] = "Please Enter Valid Date of invitation tender.";
         }
     } 
     if($date_of_fin != '')
     {
        if(!preg_match("^\\d{1,2}/\\d{2}/\\d{4}^",$date_of_fin)) 
         {
            $error[] = "Please Enter Valid Date of finalization of tender.";
         }
     }
     if($pre_work_remark != "")
     {
        if(!preg_match('/^[a-zA-Z0-9&()-.\s]+$/', $pre_work_remark))

         {
            $error[] = "Please Enter Valid Remark.";
         }
     }
     if($date_of_fin == '')
     {
        $error[] = "Please Enter Date of finalization of tender.";
     }
     if($date_of_inv == '')
     {
        $error[] = "Please Enter Date of invitation tender.";
     }
     if($aa_date == '')
     {
        $error[] = "Please Enter Admin. Approval Date.";
     }
      if($tec_san_date == '')
     {
        $error[] = "Please Enter Technical Sanction Date.";
     }
     if($est_sub_date == '')
     {
        $error[] = "Please Enter Submission date of detail estimate.";
     }
     if($dpr_san_date == '')
     {
        $error[] = "Please Enter Approval of DPR.";
     }
     if($dpr_sub_date == '')
     {
        $error[] = "Please Enter Submission of DPR .";
     }
     
     $count_error = 0;
     if($error)
     {
        foreach($error as $val)
        {
            if($val){
            $count_error ++;
            }   
        } 
     }
     if($count_error == 0)
     {  
			//echo ($project_type);exit;
		   //MS SQL Escape double quotes
		   
		   $pre_work_name = escapeSingleQuotes($pre_work_name);

		   $short_work_name = escapeSingleQuotes($short_work_name); 
			$pre_work_remark = escapeSingleQuotes($pre_work_remark);
			
			if($aa_date != ''){ $aa_date=date2mysql($aa_date); }	
			if($date_of_inv != ''){ $date_of_inv=date2mysql($date_of_inv); }		
			if($date_of_fin != ''){ $date_of_fin=date2mysql($date_of_fin); }
			if($dpr_sub_date != ''){ $dpr_sub_date=date2mysql($dpr_sub_date); }		
			if($dpr_san_date != ''){ $dpr_san_date=date2mysql($dpr_san_date); }		
			if($est_sub_date != ''){ $est_sub_date=date2mysql($est_sub_date); }	
			 if($tec_san_date != ''){ $tec_san_date=date2mysql($tec_san_date); }	
			if($aa_amount == ''){$aa_amount = 0;}
		   if($tec_san_amount == ''){$tec_san_amount = 0;}
		   

	   
   
		  $sess_cir_id_proj = $_SESSION["session_circle_id"];
		   if($sess_cir_id_proj == 0){
			 $sess_cir_id_proj = 0;
		   }
		   
		   $sess_div_id_proj = $_SESSION["session_division_id"];
		   if($sess_div_id_proj == 0){
			 $sess_div_id_proj = 0;
		   }	
		   
		   $sess_subdiv_id_proj = $_SESSION["session_sub_division_id"];
		   if($sess_subdiv_id_proj == 0){
			 $sess_subdiv_id_proj = 0;
		   }
		   
		   $sess_sec_id_proj = $_SESSION["session_section_id"];
		   if($sess_sec_id_proj == 0){
			 $sess_sec_id_proj = 0;
		   }
		   $date = date("Y-m-d");
		   $power_id= $_SESSION["sess_power_id"];
	   
		   //$query 		= "select * from USP_PREWORK_INSERT_UPDATE  ('".$pre_work_name."',".$project_type.",'".$short_work_name."',".$project_head_demo.",".$source_fund_id.",".$wings_id.",".$aa_amount.",'".$aa_date."','".$date_of_inv."','".$date_of_fin."','".$dpr_sub_date."','".$dpr_san_date."','".$est_sub_date."','".$tec_san_date."',".$tec_san_amount.",'','N','','".$_SESSION["sess_power_id"]."','".$sess_cir_id_proj."','".$sess_div_id_proj."','".$sess_subdiv_id_proj."','".$sess_sec_id_proj."','".$pre_work_id."','U','".$pre_work_remark."') ";
		   //$query 		= "select * from USP_PREWORK_INSERT_UPDATE  ('".$pre_work_name."',".$project_type.",'".$short_work_name."',".$project_head_demo.",".$source_fund_id.",".$wings_id.",".$aa_amount.",'".$aa_date."','".$date_of_inv."','".$date_of_fin."','".$dpr_sub_date."','".$dpr_san_date."','".$est_sub_date."','".$tec_san_date."',".$tec_san_amount.",'','N','".$date."','".$_SESSION["sess_power_id"]."',".$sess_cir_id_proj.",".$sess_div_id_proj.",".$sess_subdiv_id_proj.",".$sess_sec_id_proj.",0,'U','".$pre_work_remark."') ";
		  if($_SESSION["sess_power_id"] == 'EIC'){
           $query 		= " UPDATE pm_pre_work_detail
   SET pre_work_name ='$pre_work_name'
      ,project_type =$project_type  
      ,short_work_name =$short_work_name
      ,project_head =$project_head
      ,source_fund_id =$source_fund_id
      ,wings_id =$wings_id
      ,aa_amount =$aa_amount
      ,aa_date ='$aa_date'
      ,date_of_inv ='$date_of_inv' 
      ,date_of_fin ='$date_of_fin'
      ,dpr_sub_date ='$dpr_sub_date' 
      ,dpr_san_date ='$dpr_san_date'
      ,est_sub_date ='$est_sub_date'
      ,tec_san_date ='$tec_san_date'
      ,tec_san_amount =$tec_san_amount
      ,pcode =''
      ,is_awarded ='N'
      ,award_date ='$date'
      ,power_id ='$power_id'
      -- ,circle_id =$sess_cir_id_proj
      -- ,division_id =$sess_div_id_proj
      -- ,sub_division_id =$sess_subdiv_id_proj
      -- ,section_id =$sess_sec_id_proj
      ,pre_work_remark ='$pre_work_remark'
 WHERE pre_work_id=$pre_work_id; ";
}else{
    $query       = " UPDATE pm_pre_work_detail
   SET pre_work_name ='$pre_work_name'
      ,project_type =$project_type  
      ,short_work_name =$short_work_name
      ,project_head =$project_head
      ,source_fund_id =$source_fund_id
      ,wings_id =$wings_id
      ,aa_amount =$aa_amount
      ,aa_date ='$aa_date'
      ,date_of_inv ='$date_of_inv' 
      ,date_of_fin ='$date_of_fin'
      ,dpr_sub_date ='$dpr_sub_date' 
      ,dpr_san_date ='$dpr_san_date'
      ,est_sub_date ='$est_sub_date'
      ,tec_san_date ='$tec_san_date'
      ,tec_san_amount =$tec_san_amount
      ,pcode =''
      ,is_awarded ='N'
      ,award_date ='$date'
      ,power_id ='$power_id'
      ,circle_id =$sess_cir_id_proj
      ,division_id =$sess_div_id_proj
      ,sub_division_id =$sess_subdiv_id_proj
      ,section_id =$sess_sec_id_proj
      ,pre_work_remark ='$pre_work_remark'
 WHERE pre_work_id=$pre_work_id; ";
}
		   //echo $query;exit;
		   $data_res 	= pg_query($query);
   
		   $msg = "New Work  has been updated Successfully.";
		   $msg= base64_encode($msg);
		   header("Location:index.php?page=267&msg=".urlencode($msg));
				
		   exit(0);    

                 
       } 
}	 
 
 if(isset($_POST) && $_POST['edit'] == 'Edit'){
	extract($_POST);
    $get_proj_detail_sql = "SELECT * FROM pm_pre_work_detail WHERE pre_work_id != 0 AND pre_work_id = ".$pre_work_id." ";
    $get_proj_detail_res = pg_query($get_proj_detail_sql);
    @extract(pg_fetch_assoc($get_proj_detail_res));
}
 

include_once ('view/add_new_project.html');
?>
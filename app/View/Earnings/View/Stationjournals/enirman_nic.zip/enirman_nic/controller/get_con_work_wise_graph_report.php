<?php
error_reporting(0);
session_start();
require_once("../common/globali.php");
require_once("../common/sqlserver.php");

if(count($_POST) > 0){
       extract($_POST);
       //print_r($_POST);
       //getContractor Name
     
    $conname = '';
	$conname = getexistConname($conid);
    $workname = '';
	$workname = getWorkName($workid);	
      /************************************************************TEMPERATURE  CHART REPORT START********************************
       *
       **********************************************************************************************************************/
      
       $calculatedfromdate = date('Y-m-d', mktime(0, 0, 0, $fromMonth, 1, $fromYear));
       $calculatedtodate = date('Y-m-d', mktime(0, 0, 0, $toMonth, 1, $toYear));
       if($calculatedfromdate <= $calculatedtodate){
       
       
	      $categoryarr = Array();
	      $fisYearMonthArr = Array();
	      if($calculatedfromdate <= $calculatedtodate){
		     $fisYearMonthArr = get_month_between_two_datetime($calculatedfromdate, $calculatedtodate);
		     if(!empty($fisYearMonthArr)){
			     foreach($fisYearMonthArr as $key => $val){
				     if(!empty($val)){
					     $yearMonArr = @explode("-",$val);
						     $catval     = date("M", mktime(0, 0, 0, $yearMonArr[1], 10))."<br/>".substr($yearMonArr[0],-2,2);
						     $categoryarr[] = "'".$catval."'";
					     
				     }
			     }
		     }
		     
	      }
	      $categoryval = implode(",",$categoryarr);      
	     
	     $fisYearMonthArr = Array();
	     $performance_sql = "select * from usp_contractor_performance_report('".$conid."',0,0,0,0,0,0,".$fromYear.",".$fromMonth.",".$toYear.",".$toMonth.",'".$_SESSION["sess_power_id"]."',".$workid.")";
	     $performance_res = pg_query($performance_sql);
	     $performance_cnt = pg_num_rows($performance_res);
	     //echo $performance_sql;
	     if($performance_cnt > 0){
		     while($performance_row = pg_fetch_assoc($performance_res)){
		     	
                              // echo "<pre>";
							  // print_r($performance_row);
							  // echo "</pre>";
		

			    $fisYearMonthArr = get_month_between_two_datetime($calculatedfromdate, $calculatedtodate);
                //print_r($fisYearMonthArr);
		

			     if(!empty($fisYearMonthArr)){
				     foreach($fisYearMonthArr as $key => $val){
					     if(!empty($val)){
						     $yearMonArr = @explode("-",$val);
						     //echo $yearMonArr[1]."##".$yearMonArr[0];
						     $targetval 	= '';
						     $actval 	= '';
						     $targetval  = date("F", mktime(0, 0, 0, $yearMonArr[1], 10))."_".$yearMonArr[0]."_".Target;
						     $actualval  = date("F", mktime(0, 0, 0, $yearMonArr[1], 10))."_".$yearMonArr[0]."_".Achivments;
						     //echo "###".$targetval."<br/>";
	                         //echo "@@".$actualval."<br/>";
	      
			     
							     $targetvalarr[] = $performance_row['tot_target'];
							     $actualvalarr[] = $performance_row['tot_achivement'];
							     // echo "<pre>";
							     // print_r($actualvalarr);
							     // echo "</pre>";
							     // echo count($targetvalarr);
						     
					     }
				     }
			     }
		     }
	     }
	     if(count($targetvalarr) > 0){
	      $targetval = $targetvalarr[0];
	      $actualval = $actualvalarr[0];         
	     }
	     //echo $targetval."##".$actualva;

	     
	      /************************************************************TEMPERATURE  CHART REPORT END********************************
	      *
	      **********************************************************************************************************************/
	  
	

?>


<?
//echo $targetval."##".$actualval;

       if(count($targetvalarr) > 0 && count($actualvalarr) > 0){
?>
	      <script type="text/javascript">
	      $(function () {
		Highcharts.setOptions({
		 colors: ['#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263',      '#6AF9C4']
		});		     
		     
		      $('#container').highcharts({
			  chart: {
			      type: 'column'
			  },
			  title: {
			      text: 'Cumulative Target & Achievement Contractor Wise '
			  },
			  subtitle: {
			      text: '<?=$conname?>'
			  },
			  xAxis: {
			      categories: [<?php echo $categoryval; ?>]
			  },
			  yAxis: {
			      title: {
				  text: 'Amont In Lakh'
			      }
			  },
			  tooltip: {
			      enabled: false,
			      formatter: function() {
				  return '<b>'+ this.series.name +'</b><br/>'+
				      this.x +': '+ this.y +'°C';
			      }
			  },
			  plotOptions: {
			      line: {
				  dataLabels: {
				      enabled: true
				  },
				  enableMouseTracking: false
			      }
			  },
			  series: [{
			      name: 'Target',
			      data: [<?php echo $targetval; ?>]
			  }, {
			      name: 'Achievement',
			      data: [<?php echo $actualval; ?>]
			  }]
		      });
		  });
	      </script>
 <?
       }
  ?>
    
 
	      <table width="100%" cellspacing="1" cellpadding="4"   border="0" style="margin-bottom:20px;" align="center" class="entrytable">
		     <tr>
			    <td align="left" class="blu3b" width="20%"> Contractor Name : </td>
			    <td align="left" class="vlt3b" > <?php echo $conname?> </td>
		     </tr>
		     <tr>
			    <td align="left" class="blu3b" width="20%"> Work Name : </td>
			    <td align="left" class="vlt3b" > <?php echo $workname?> </td>
		     </tr>
		     <tr>
			    <td align="left" class="blu3b" width="20%"> Period From : </td>
			    <td align="left" class="vlt3b" > <?php echo date("F", mktime(0, 0, 0, $fromMonth, 10)).",".$fromYear?> </td>
		     </tr>
		     <tr>
			    <td align="left" class="blu3b" width="20%"> Period To : </td>
			    <td align="left" class="vlt3b" > <?php echo date("F", mktime(0, 0, 0, $toMonth, 10)).",".$toYear?> </td>
		     </tr>			 
	      </table>

	      <table width="100%" cellspacing="1" cellpadding="4"   border="0" style="margin-bottom:20px;" align="center">
		     <tr>
			    <td>
	      
		     <?
			    if(count($targetvalarr) > 0 && count($actualvalarr) > 0){
		     ?>
			       <div id="container" style="width:100%;height:1000px;border:1px solid #cccccc; box-shadow:1px 1px 2px 2px #C9C9C9;"></div>
		     <?
			    }
		     ?>
			    </td>
		     </tr>
	      </table>

	      
	      
	
<?
    }    
}
//date comparison end
?>

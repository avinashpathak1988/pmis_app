<?
session_start();
require_once("../common/globali.php");
require_once("../common/sqlserver.php");

if(count($_POST) > 0){
       extract($_POST);
       //print_r($_POST);
       //getContractor Name
      $con_name = str_replace('[','',$con_name);
      $con_name = str_replace(']','',$con_name);
      $con_name = str_replace('"','',$con_name);
      $conid = trim($con_name);
      $conname = getexistConname($conid);
      
	/************************************************************GET PIE CHART REPORT END********************************
	      *
	      **********************************************************************************************************************/
	
         $pcodearr = Array();
         $assigndurationarr = Array();
         $dalaydurationarr  = Array();
         
         $pcodearrval = '';
         $assigndurationarrval = '';
         $dalaydurationarrval  = '';	
	       
    		$query_Work_lising_sql = "select * from USP_CONTRACTOR_DETAILS ('".$conid."',$fromYear,$fromMonth,$toYear,$toMonth) ";
    		$query_Work_lising_res = pg_query($query_Work_lising_sql);
    		$query_Work_lising_cnt = pg_num_rows($query_Work_lising_res);
        //echo $query_Work_lising_sql;
?>

	      
	      
	      
 <table align="center" width="98%" border="0" cellpadding="4" cellspacing="1" class="tableWithFloatingHeaderContractor listtable">
                <tr class="listtabletr1">
                    <td align="center" class="blk2b" width="5%">Sl. No.</td>
                    <td align="left" class="blk2b" width="">Work Name</td>
					<td align="left" class="blk2b" width="8%">Alloted To</td>
                    <td align="left" class="blk2b" width="8%">Admin. Approval Date<br/>[ A/A Amount ]</td>
                    <td align="left" class="blk2b" width="8%">Date of commencement</td>
                    <td align="left" class="blk2b" width="8%">Date of completion</td>
                    <!--<th class="blk2b">Target</th>-->
                    <td class="blk2b">Cumulative Achievement</td>
                    <td class="blk2b">Percentage</th>
                    <td align="left" class="blk2b">View Graph Report </td>
                </tr>
<?php
  $count = 0;
     while($query_Work_lising_row = pg_fetch_assoc($query_Work_lising_res))
    {
        /*echo "<pre>";
        print_r($query_Work_lising_row);*/
        $count ++;
 ?>
               <tr bgcolor="#FFFFFF">
                    <td class="blk2" align="center" valign="top"><?php echo $count?></td>
                    <td align="left" class="blk2"    valign="top"><span class="grn3b">Auto Project Code:</span><span class="blk2">&nbsp;&nbsp;<?php echo $query_Work_lising_row['pcode']?></span><br/><?php echo $query_Work_lising_row['work_name']?><br/><span class="grn2b">Name of Agency:</span><span class="blk2">&nbsp;&nbsp;<?php echo getCONName($query_Work_lising_row['work_id'])?></span><?if($_SESSION["sess_power_id"] == 'EIC'){?> <br/><a class="lnsky4b" href="javascript:void(0);" onclick="javascript:getConWorkDetail('<?php echo $query_Work_lising_row['agency_name']?>','<?php echo $query_Work_lising_row['work_id']?>');">[contractor work detail]</a>  <?}?><br/><span class="grn2b">Agreement Amount:</span><span class="blk2">&nbsp;&nbsp;<?php echo sprintf("%.2f",$query_Work_lising_row['aggrement_amount'])?></span>
                    <?if($query_Work_lising_row['iscomplete'] == 'Y'){?>
                    <br/><span class="grn2b">Financial Completion Date:</span><span class="blk2">&nbsp;&nbsp;<?php echo $query_Work_lising_row['complete_date']?></span>
                    <?}?>
                    </td>
                    <td align="left" class="blk2" valign="top" nowrap="nowrap">
                
                      <?php echo "<span class='blk3b'>"."Circle".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['circle_name']."]".'</span>'?><br/>
                      <?php echo "<span class='blk3b'>"."Division".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['division_name']."]".'</span>'?><br/>
                      <?php echo "<span class='blk3b'>"."Sub Division".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['sub_division_name']."]".'</span>'?><br/>
                      <?php echo "<span class='blk3b'>"."Section".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['section_name']."]".'</span>'?><br/>
                      <?php echo "<span class='blk3b'>"."Section User Name".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['alloted_to']."]".'</span>'?><br/>
                      <?php echo "<span class='blk3b'>"."Mobile No".'</span>'?><br/>	
                      <?php echo "<span class='vlt2b'>"."[".$query_Work_lising_row['mobile_no']."]".'</span>'?><br/>
                    </td>
					
                    <td align="left" class="blk2" valign="top"><?php echo $query_Work_lising_row['work_creation_date']?><br/>[<?php echo $query_Work_lising_row['aaamount']?>]</td>
                    <td align="left" class="blk2" valign="top"><?php echo $query_Work_lising_row['work_commencement_date']?></td>
                    <td align="left" class="blk2" valign="top"><?php echo $query_Work_lising_row['work_completion_date']?></td>

					<!--<td align="left" class="blk2" valign="top"><?php echo $query_Work_lising_row['target_amount']?></td>-->
                    <td align="left" class="blk2" valign="top"><?php echo $query_Work_lising_row['achivement_amount']?></td>
                     <td align="left" class="blk2" valign="top">
                      <?if($query_Work_lising_row['aggrement_amount'] != 0){
                         $pval = '';
                         $pval = ($query_Work_lising_row['achivement_amount']/$query_Work_lising_row['aggrement_amount'])*100;
                         $pval = sprintf ("%.2f", $pval);
                         echo $pval."%";
                      }?>
                      </td>
					 <td valign="top">
						<a class="lnblu2b" onclick="javascript:vieGraphDetail('<?php echo $conid?>','<?php echo $fromMonth?>','<?php echo $fromYear?>','<?php echo $toMonth?>','<?php echo $toYear?>','<?php echo $query_Work_lising_row['work_id']?>');" href="javascript:void(0);">View </a>
					 </td>
					  
					
			</tr>
	
		
		
<?
    }
?>
            </table>
<?
       
}
//date comparison end
?>

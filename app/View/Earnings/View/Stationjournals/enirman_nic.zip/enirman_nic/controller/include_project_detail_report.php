<?php
require_once("../common/globali.php");

$workid   		= (isset($_GET['workid']) && $_GET['workid'] != 0)?(int) $_GET['workid']:0;
$wings_id 		= (isset($_GET['wings_id']) && $_GET['wings_id'] != 0)?(int) $_GET['wings_id']:0;
$source_fund_id 	= (isset($_GET['source_fund_id']) && $_GET['source_fund_id'] != 0)?(int) $_GET['source_fund_id']:0;
$circle_id 		= (isset($_GET['circle_id']) && $_GET['circle_id'] != 0)?(int) $_GET['circle_id']:0;
$division_id 		= (isset($_GET['division_id']) && $_GET['division_id'] != 0)?(int) $_GET['division_id']:0;
$sub_division_id 	= (isset($_GET['sub_division_id']) && $_GET['sub_division_id'] != 0)?(int) $_GET['sub_division_id']:0;
$section_id 		= (isset($_GET['section_id']) && $_GET['section_id'] != 0)?(int) $_GET['section_id']:0;

$_SESSION["sess_dashboard_wingid"] = $wings_id;
$_SESSION["sess_dashboard_circleid"] = $circle_id;
$_SESSION["sess_dashboard_divisionid"] = $division_id;
$_SESSION["sess_dashboard_subdivisionid"] = $sub_division_id;
$_SESSION["sess_dashboard_sectionid"] = $section_id;
$_SESSION["sess_dashboard_schemeid"] = $source_fund_id;


$query_Work_lising_sql = "select * from USP_ALL_WORK_LISTING ('A','".$_SESSION["sess_power_id"]."',".$_SESSION["sess_wings_id"].",".$_SESSION["session_circle_id"].",".$_SESSION["session_division_id"].",".$_SESSION["session_sub_division_id"].",".$_SESSION["session_section_id"].",".$wings_id.",".$circle_id.",".$division_id.",".$source_fund_id.") ";
/*$query_Work_lising_sql = "SELECT	
A.work_name  AS work_name, 
B.con_name AS AGENCY_NAME,
B.con_agreement_amount AS AGGREMENT_AMOUNT,
TO_CHAR(A.work_creation_date,'DD-MM-YYYY') AS WORK_CREATION_DATE,
TO_CHAR(B.con_commencement_date,'DD-MM-YYYY')AS WORK_COMMENCEMENT_DATE,
TO_CHAR(B.con_completion_date,'DD-MM-YYYY') AS WORK_COMPLETION_DATE,
A.short_work_name AS PROJECT_CODE,
A.pcode AS pcode,
D.full_name AS ALLOTED_TO,
D.mobile_num AS MOBILE_NO,
H.circle_name AS CIRCLE_NAME,
E.division_name AS DIVISION_NAME,
F.sub_division_name AS SUB_DIVISION_NAME,
G.section_name AS SECTION_NAME,
J.project_type_name AS project_type_name,
L.fund_name AS fund_name,
C.wa_is_complete AS ISCOMPLETE,
C.wa_is_closed AS ISCLOSED,
c.wa_complete_date as complete_date,
c.wa_closed_date as closed_date,
C.aa_amount AS aaamount
COALESCE(K.tot_ach_val,0) AS tot_ach_val,
COALESCE(mis.tot_misc_val,0) AS tot_misc_val,
COALESCE(Q1.tot_curr_fy_exp,0) AS tot_curr_fy_exp,
COALESCE(Q2.tot_prev_fy_exp,0) AS tot_prev_fy_exp
FROM 
pm_works   A
LEFT JOIN pm_contractor_details  B ON B.con_work_id=A.WORK_ID
LEFT JOIN pm_work_allotment C ON C.work_id=A.WORK_ID
LEFT JOIN circle H ON C.wa_circle_id=H.circle_id
LEFT JOIN division E ON C.wa_division_id=E.division_id
LEFT JOIN subdivision F ON C.wa_sub_division_id=F.sub_division_id
LEFT JOIN section G ON C.wa_section_id=G.section_id
LEFT JOIN pm_fund L ON A.source_fund_id=L.fund_id
LEFT JOIN (SELECT  * FROM pm_auth_user  WHERE power_id='JE' and is_active='Y' AND section_id!=0
    AND user_id IN(SELECT MAX(user_id) FROM pm_auth_user GROUP BY section_id)) D ON C.wa_section_id=D.section_id
LEFT JOIN pm_project_type J ON A.project_type=J.project_id 
LEFT JOIN (SELECT uwa_work_id,SUM(COALESCE(act_amount,0)) AS  tot_ach_val FROM pm_update_work_allotment GROUP BY uwa_work_id)K ON K.uwa_work_id=A.WORK_ID
LEFT JOIN (SELECT uwa_work_id,SUM(COALESCE(misc_amount,0)) AS  tot_misc_val FROM pm_update_work_allotment GROUP BY uwa_work_id) mis ON mis.uwa_work_id=A.WORK_ID
LEFT JOIN
(SELECT uwa_work_id,COALESCE((COALESCE(SUM(act_amount),0)+COALESCE(SUM(misc_amount),0)),0) AS tot_curr_fy_exp FROM pm_update_work_allotment 
WHERE (((uwa_month::CHAR(2))||'-' ||(uwa_year::CHAR(4))|| '-01')::DATE)  BETWEEN _CURR_FY_START_DT AND _ENTER_DT
GROUP BY uwa_work_id)Q1 ON Q1.uwa_work_id=A.WORK_ID
LEFT JOIN
(SELECT uwa_work_id,COALESCE((COALESCE(SUM(act_amount),0)+COALESCE(SUM(misc_amount),0)),0)AS tot_prev_fy_exp FROM pm_update_work_allotment 
WHERE (((uwa_month::CHAR(2))||'-' ||(uwa_year::CHAR(4))|| '-01')::DATE)<_CURR_FY_START_DT
GROUP BY uwa_work_id)Q2 ON Q2.uwa_work_id=A.WORK_ID	
ORDER BY H.circle_name,E.division_name
";
*/
$query_Work_lising_sql;
$_SESSION['session_ajax_listing_query'] = $query_Work_lising_sql;
$_SESSION['sess_query_work_listing_sql'] = $query_Work_lising_sql;
$work_list_res1 = pg_query($query_Work_lising_sql);
?>


			<table width="100%">
				<tr>
				   <td  valign="top" align="right">
						<span class=""><a href="javascript:void(0);" onclick="javascript:NewPopupWindow('index.php?page=289', 1000,800);"  class="lnsky2b" >Excel Report </a>&nbsp;&nbsp;</span>
				   </td>
				</tr>
			</table>	

			
			<table width="100%" cellspacing="1" cellpadding="4" bgcolor="#A8D5F4" border="0" style="margin-bottom:2px;" align="center" class="tableWithFloatingHeader">
				<thead>
					<tr class="listtabletr1" >
						<th align="center"  class="blk2b" width="5%">Sl. No.</th>
						<th align="center"  class="blk2b" width="5%">Circle.</th>
						<th align="left"    class="blk2b" width="8%">Division</th>
						<th align="left"    class="blk2b" width="8%">Name of the work</th>
						<th align="center"    class="blk2b" width="8%">A/A Amount</th>
						<th align="left"    class="blk2b" width="8%">Agreement Amount</th>
						<th align="left"    class="blk2b" width="8%">Agency</th>
						<th align="left"    class="blk2b" width="8%">Date of commencement</th>
						<th align="left"    class="blk2b" width="8%">Stipulated date of completion</th>
						<th align="left"    class="blk2b" width="8%">Cumulative Expenditure up to previous financial Year</th>
						<th align="left"    class="blk2b" width="8%">Expenditure during the current financial year</th>
						<th align="left"    class="blk2b" width="8%">Cumulative Expenditure</th>
<!-- 						<th align="left"    class="blk2b" width="8%">Physical Progress</th>						
 -->						</tr>
				</thead>
<?
	$cnt = 0;
	while($row = pg_fetch_assoc($work_list_res1))
	{
		$cnt++;
		if($cnt%2==0)
		{
			$bgcolor='class="listtabletr2"';
		}
		else
		{
			$bgcolor='class="listtabletr3"';
		}
		
?>
						<tr  <?php echo $bgcolor?>>
							<td align="center" class="blk2" valign="top"><?php echo $cnt?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['circle_name']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['division_name']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['work_name']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['aaamount']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['aggrement_amount']?></td>
							<td align="center" class="blk2" valign="top"><?php echo getCONName($row['work_id'])?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['work_commencement_date']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['work_completion_date']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['tot_prev_fy_exp']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['tot_curr_fy_exp']?></td>
							<td align="center" class="blk2" valign="top"><?php echo $row['tot_prev_fy_exp']+$row['tot_curr_fy_exp']?></td>
<!-- 							<td align="center" class="blk2" valign="top">
								
								<table width="100%" cellspacing="1" cellpadding="4" bgcolor="#A8D5F4" border="0">

<?
//SELECT DISTINCT epd_work_id,CONCAT  (epd_year, '-', epd_month,'-01') as date1 FROM pm_execution_process_details 
$get_month_wise_achieve_sql = "SELECT TOP 1 MONTH(Q.date1) AS MONTHS,YEAR(Q.date1) AS YEARS FROM 
( SELECT DISTINCT epd_work_id,convert(date,((convert(varchar(4),epd_year)+'-'+convert(varchar(4),epd_month)+'-'+'01'))) as date1 
FROM dbo.pm_execution_process_details
WHERE epd_work_id= ".$row['work_id'].")Q
ORDER BY Q.date1 DESC ";
$get_month_wise_achieve_res = pg_query($get_month_wise_achieve_sql);
$get_month_wise_achieve_cnt = pg_num_rows($get_month_wise_achieve_res);
if($get_month_wise_achieve_cnt > 0){
?>
				
				
				<tr bgcolor="#FFFFFF">
					<td align="left" colspan="4">
							<fieldset style="margin-bottom:10px;width:90%;">
								
								<table width="100%" border="0" cellpadding="6" cellspacing="1" class="listtable">
									<tr>
										<td align="left" style="padding-left:10px;" width="20%" class="entrytabletr1 blk2b">Month</td>
										<td align="left" style="padding-left:10px;" width="20%" class="entrytabletr1 blk2b">Year</td>
										<td align="left" style="padding-left:10px;" width="15%" class="entrytabletr1 blk2b">Component</td>
										<td align="left" style="padding-left:10px;" width="15%" class="entrytabletr1 blk2b">Target Scope</td>
										<td align="left" style="padding-left:10px;" width="20%" class="entrytabletr1 blk2b">Cumulative Achievement</td>
								   </tr>
<?
	while($get_month_wise_achieve_row = pg_fetch_assoc($get_month_wise_achieve_res))
	{
		$exe_process_detail_cnt = 0;
		$exe_process_detail_sql = "SELECT * FROM pm_execution_process_details WHERE epd_work_id =".$row['work_id'];
		$exe_process_detail_sql.=" AND epd_month = ".$get_month_wise_achieve_row['months']." ";
		$exe_process_detail_sql.=" AND epd_year = ".$get_month_wise_achieve_row['years']." ";
		$exe_process_detail_res = pg_query($exe_process_detail_sql);
		$exe_process_detail_cnt = pg_num_rows($exe_process_detail_res);
		$moncnt = 0;
		if($exe_process_detail_cnt > 0)
		{
			while($exe_process_detail_row = pg_fetch_assoc($exe_process_detail_res))
			{

						$cnt++;
						$moncnt++;
						if($cnt%2==0)
						{
							$bgcolor='class="listtabletr2"';
						}
						else
						{
							$bgcolor='class="listtabletr3"';
						}					
?>
										<tr <?php echo $bgcolor?>>

<?
				//get target value
				$ACTUALVAL = '';
				$check_is_updated = "SELECT epd_actual_value AS ACTUALVAL FROM pm_execution_process_details WHERE epd_work_id =".$row['WORK_ID'];
				$check_is_updated.= " AND epd_month =".$exe_process_detail_row['epd_month'];
				$check_is_updated.= " AND epd_year =".$exe_process_detail_row['epd_year'];
				$check_is_updated.= " AND epd_component_id =".$exe_process_detail_row['epd_component_id'];
				$check_is_updated.= " AND epd_subcomponent_id =".$exe_process_detail_row['epd_subcomponent_id'];	
				$res_check_is_updated = pg_query($check_is_updated);
				$count_check_is_updated = pg_num_rows($res_check_is_updated);
				if($count_check_is_updated > 0){
					@extract(pg_fetch_assoc($res_check_is_updated));
				}

				if($moncnt == 1){
				
?>
													<td bgcolor="#F0FFFF" align="left" class="blu5b" valign="top" rowspan="<?php echo $exe_process_detail_cnt?>">
                                                       <label><? echo date("F", mktime(0, 0, 0, $exe_process_detail_row['epd_month']+1 , 0, 0))?></label>
													</td>
													<td bgcolor="#F0FFFF" align="left" class="blu5b" valign="top" rowspan="<?php echo $exe_process_detail_cnt?>">
                                                       <label><? echo $exe_process_detail_row['epd_year'];?></label>
													</td>
<?
				}
?>
													<td align="left" class="blk2" width="15%">
                                                       <label><?echo getSubCompName($exe_process_detail_row['epd_subcomponent_id']);?></label>
													</td>
<?
	$TARGETVAL = '';
	$TARGETTODATE = '';
	$check_is_updated = "SELECT target_value AS TARGETVAL,CONVERT(DATE,target_to_date) AS TARGETTODATE FROM pm_target_detail WHERE target_work_id =".$row['work_id'];
	$check_is_updated.= " AND target_comp_id =".$exe_process_detail_row['epd_component_id'];
	$check_is_updated.= " AND target_sub_comp_id =".$exe_process_detail_row['epd_subcomponent_id'];
	$res_check_is_updated = pg_query($check_is_updated);
	$count_check_is_updated = pg_num_rows($res_check_is_updated);
	if($count_check_is_updated > 0){
		@extract(pg_fetch_assoc($res_check_is_updated));
	}
	
?>
													<td align="left" class="blk2">
                                                       <label><?echo $TARGETVAL;?></label>
													</td>													
													<td align="left" class="blk2">
                                                       <label><?echo $ACTUALVAL;?></label>
													</td>
													
													
										
										</tr>
<?
if($moncnt == $exe_process_detail_cnt){
?>
										<tr bgcolor="#FFFFFF"><td colspan="5" height="1px"></td></tr>
<?
					}
		
			}
		}
	}
?>
										
									
								</table>
							</fieldset>									
					</td>
				</tr>	

				<?}
				?>

								</table>
							
							</td> -->							
		        		</tr>
<?
    }
?>
		</table>
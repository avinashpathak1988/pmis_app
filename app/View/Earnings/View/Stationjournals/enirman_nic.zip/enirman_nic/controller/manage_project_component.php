<?php
checklogin();
if(count($_POST) == 0){
    header("Location:index.php?page=192");
}


//define(MASTERPASS,"enirman_".date("d")."_".date("m")."_".date("Y"));
if(isset($_POST) && count($_POST) > 0){
    extract($_POST);
   
}
if(isset($_POST) && isset($_POST['update']) && $_POST['update'] == 'Update Component'){
    //print_r($_POST);exit;
	extract($_POST);
    $subcompname = 'sub_comp_'.$sub_comp_id;						
    $$subcompname = addslashes($$subcompname);
    $$subcompname =  addslashes($$subcompname);
    $$subcompname =  escapeSingleQuotes($$subcompname); 
    //============================================================================================= 
     $select_query = "SELECT * FROM pm_sub_components WHERE sub_comp_id = ".$sub_comp_id." ";  
     $select_query_res = pg_query($select_query);
     autit_log('pm_sub_components' ,pg_fetch_assoc($select_query_res) , 'Before Update', $page_title);
     //=============================================================================================
    $update_sub_comp_sql = "UPDATE pm_sub_components SET sub_comp_name = '".$$subcompname."' WHERE sub_comp_id = ".$sub_comp_id." ";
	pg_query($update_sub_comp_sql);
      //============================================================================================= 
     $select_query = "SELECT * FROM pm_sub_components WHERE sub_comp_id = ".$sub_comp_id." ";  
     $select_query_res = pg_query($select_query);
     autit_log('pm_sub_components' ,pg_fetch_assoc($select_query_res) , 'After Update', $page_title);
     //=============================================================================================
    

	$msg = "Component name has been changed successfully";
	//header("Location:index.php?page=222&msg=".urlencode(base64_encode($msg)));
	//exit;	
}
if(isset($_POST) && isset($_POST['delete']) && $_POST['delete'] == 'Delete Component'){
	extract($_POST);
    //print_r($_POST);
    /*
    if($proj_form != MASTERPASS)
    {
        $error[] = " Sorry Master Key Not Matching";
    }
    */
	$total_error = 0;
    if(isset($error))
    {
        foreach($error as $val)
        {
            if($val)
            {
                $total_error ++;
            }   
        } 
    }
    if($total_error == 0)
    {
    //============================================================================================= 
     $select_query = "SELECT * FROM pm_sub_components WHERE sub_comp_id = ".$sub_comp_id." ";  
     $select_query_res = pg_query($select_query);
     autit_log('pm_sub_components' ,pg_fetch_assoc($select_query_res) , $_POST['delete'], $page_title);
     //=============================================================================================
        
        $del_query  =" DELETE FROM pm_sub_components ";
        $del_query .= " WHERE  work_id=".$work_id;
        $del_query .= " AND    sub_comp_id=".$sub_comp_id;
        @pg_query($del_query);         
        
        $del_query  =" DELETE FROM pm_target_detail ";
        $del_query .= " WHERE  target_work_id=".$work_id;
        $del_query .= " AND    target_sub_comp_id=".$sub_comp_id;
        @pg_query($del_query);       
        
        $del_query  =" DELETE FROM pm_execution_process_details ";
        $del_query .= " WHERE  epd_work_id=".$work_id;
        $del_query .= " AND    epd_subcomponent_id=".$sub_comp_id;
        @pg_query($del_query);
        
        $msg = "Component has been deleted successfully";
        
        //header("Location:index.php?page=222&msg=".urlencode(base64_encode($msg)));
        //exit;	       
        
    }
}

//get work detail
$get_work_sql = "SELECT pcode,source_fund_id FROM pm_works WHERE work_id = ".$work_id." ";
$get_work_res = pg_query($get_work_sql);
$get_work_cnt = pg_num_rows($get_work_res);
if($get_work_cnt > 0)
{
	extract(pg_fetch_assoc(pg_query($get_work_sql)));
}
include_once ('./view/manage_project_component.html');
?>

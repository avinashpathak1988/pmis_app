<?php 
require_once("../common/globali.php");
if(isset($_POST)){
    extract($_POST);
        	//$workarray = array();
    if($status==0){
    	$setstatus=1;
    }else{
    	$setstatus=0;
    }
            $insert_query = "update allow_work_update set is_enable=".$setstatus." where id=".$id."";
            $select_res = pg_query($insert_query);
            if($select_res){
            	$_SESSION['updatemsg'] = "Data Updated successfully";
            	//echo '1';
            }
            else{
            	$_SESSION['updatemsg'] = "Data Failed to Update";
            	//echo '0';
            }
            //echo $workarray;
}
?>
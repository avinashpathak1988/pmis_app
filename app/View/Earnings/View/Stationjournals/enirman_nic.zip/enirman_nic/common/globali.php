<?
session_start();//start Session
set_time_limit(90000);
ini_set( 'session.cookie_httponly', 1 );
//ini_set( 'session.cookie_path', '/enirman/' );
//ini_set('session.cookie_lifetime', 0);
ini_set('upload_max_filesize', '2000M');
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Kolkata');
//define usefull system variables
define("REQ_FIELD", " <span class='red2b'>*</span>");
define("MANDATORY_FIELD", " <span class='blk2'>( All <span class='red2b'>*</span> marked fields are mandatory</span> )");

define("WEB_SERVER", "http://e-nirman.nic.in");// For live Server
define("ANDRIOD_WEB_SERVER", "http://e-nirman.nic.in");// For live Server
define("IMAGE_PATH", "writereaddata/custom/images/");// For department custom pages

//Set Some Global Variables
define('001', 'Finnacial Completion has been Reverted successfully.');
define('002', 'Physical Completion has been Reverted successfully.');
define('003', 'Work has been physically closed successfully.');
//print_r($_SESSION);
//print_r($_COOKIE);
// $_SESSION['destroyed'] = time(); // Since PHP 7.0.0 and up, session_regenerate_id() saves old session data

//                               //print_r($params);
//                              session_regenerate_id();

//                               // New session does not need destroyed timestamp
//                               unset($_SESSION['destroyed']);
//                               $new_sessionid = session_id();
//                               $params = session_get_cookie_params();
// setcookie("PHPSESSID", $new_sessionid,0, "/enirman/", '192.168.1.166', true);
//setcookie("PHPSESSID", $_SESSION["PHPSESSID"],0, "/enirman/", '192.168.1.111', true);
$old_sessionid = session_id();

// Set destroyed timestamp
$_SESSION['destroyed'] = time(); // Since PHP 7.0.0 and up, session_regenerate_id() saves old session data

      //print_r($params);
     session_regenerate_id();

      // New session does not need destroyed timestamp
      unset($_SESSION['destroyed']);
      $new_sessionid = session_id();
      $params = session_get_cookie_params();

      //setcookie("PHPSESSID", $new_sessionid, 0, "/enirman/", '192.168.1.166',
          //true  // this is the httpOnly flag you need to set
      //);
//setcookie("PHPSESSID", $_SESSION["PHPSESSID"], 0, "/E-nirman/", '192.168.1.220',true,true);
//header( "Set-Cookie: PHPSESSID=".$_SESSION['PHPSESSID']."; httpOnly" );
/*if($_SESSION['PHPSESSID'] == ''){
	header("Location:http://192.168.1.220/enirman/index.php");
} */
// echo  $_SERVER['REQUEST_URI'];exit;
//if($_SESSION['PHPSESSID'] != $_COOKIE['PHPSESSID']){
	//if(!strpos($_SERVER['REQUEST_URI'],'index.php?page=11')){
		//if(!strpos($_SERVER['REQUEST_URI'],'index.php')){
			//header("Location:index.php?page=11");
		//}
	//}
//}


require_once("connection_db.php");
$link = conOpen();

//INI Settings //
ini_set("SMTP","relay-hosting.secureserver.net");
//ini_set("SMTP","smtp.secureserver.net");
ini_set("smtp_port","25");    
//$intTime = 2;
//ini_set("session.gc_maxlifetime",$intTime);

//define downloadable file
$download_file = array('jpg','jpeg','gif','png','doc','pdf');
require_once("functionsi.php");
require_once("validation_function.php");
require_once("cyber_security.php");
require_once("savehack.php");

//print_r($_POST);


?>

<?php error_reporting(0); ?>
<!-- <script language="JavaScript">
    window.onbeforeunload = confirmExit;
    function confirmExit() {
        return "You have attempted to leave this page. Are you sure?";
    }
    </script> -->
<script type="text/javascript">
    $(document).ready(function() {
       //
       
       var blink = function() {
           $('.blink').animate({
               opacity: '0'
           }, function(){
               $(this).animate({
                   opacity: '3'
               }, blink);
           });
       }
    
       blink();
    });
    
</script>
<style type="text/css">
    
.menu {background: #2d709a;
    color: #fff;
    line-height: 11px;
    letter-spacing: 1px;
    width: 100%;padding: 5px 0;margin-bottom: -17px;
    top: -16px;}
.old {background: #2d709a;
    color: #fff;
    line-height: 11px;
    letter-spacing: 1px;
    width: 100%;padding: 5px 0;margin-bottom: -17px;
    top: -16px;}
</style>
<script type="text/javascript" src="./js/jquery.sticky.js"></script>
<script>
    $(document).ready(function(){
      /*
       * Author : tanmaya. 12 july. Dashborad Link change
       */
      // $("#myjquerymenu > ul > li.1 a.menulink").attr('href', 'index.php?page=217');
      // $("#myjquerymenu > ul > li.1 > ul > li.submenuseq_1").empty();
      
      // $(".sticker").sticky({topSpacing:0});
    });
</script> 
<tr>
    <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
            <tr>
                <td width="150" height="28" bgcolor="#323233" class="wht3b">
                    <div style="color:#FFFFFF;float:left;" >
                        <b>
                            <div class="blink">All Amount in Lakhs /-</div>
                        </b>
                    </div>
                </td>
                <td width="971" height="28" align="right" bgcolor="#323233">
                    <table border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td align="right"><img src="images/admin_img.jpg" alt="Admin" width="31" height="28" /></td>
                            <td align="right" class="admin_text">Welcome               
                                <?
                                    //Get curent user position value by its Designation / power
                                    $wingsname = "";
                                    $query = "SELECT wings_name AS wingsname FROM pm_wings ";
                                    $query.=" WHERE wings_id = ".$_SESSION['sess_wings_id'];
                                    $current_user_wings = pg_query($query);
                                    @extract(pg_fetch_assoc($current_user_wings));
                                    
                                    $crlidh = 0;
                                    $dividh = 0;
                                    $query = "SELECT circle_id AS crlidh, division_id AS dividh,power_id AS powerh FROM pm_auth_user ";
                                    $query.= " WHERE user_id = ".$_SESSION['sess_user_id'];
                                    $current_user_details = pg_query($query);
                                    //print_r(pg_fetch_assoc($current_user_details));
                                    //$authUser=pg_fetch_assoc($current_user_details);
                                    //print_r(pg_fetch_assoc($current_user_details));
                                    extract(pg_fetch_assoc($current_user_details));
                                    //echo $powerh;
                                    //exit;
                                    
                                    $desgname = "";
                                    $query = "SELECT desg_name AS desgname FROM pm_designation ";
                                    $query.=" WHERE desg_value = '".$powerh."'";
                                    //echo $query;
                                    $current_user_desc = pg_query($query);
                                    //print_r(pg_fetch_assoc($current_user_desc));
                                    extract(pg_fetch_assoc($current_user_desc));
                                    //GEt Wings details
                                    $sess_power_id_Header = $_SESSION["sess_power_id"];
                                    ?>              
                                , <?php echo $desgname?>, 
                                <?
                                    if($sess_power_id_Header != 'EIC' && $sess_power_id_Header != 'CE' && $sess_power_id_Header != 'SE')
                                    {
                                        $divnameh = "";
                                        $query = "SELECT division_name AS divnameh FROM division";
                                        $query.= " WHERE division_id = ".$dividh;
                                        $current_user_division = pg_query($query);
                                        @extract(pg_fetch_assoc($current_user_division));
                                        echo $divnameh;
                                    }
                                    if($sess_power_id_Header != 'EIC' && $sess_power_id_Header != 'CE')
                                    {
                                        $crlnameh = "";
                                        $query = "SELECT circle_name AS crlnameh FROM circle";
                                        $query.= " WHERE circle_id = ".$crlidh;
                                        $current_user_circle = pg_query($query);
                                        @extract(pg_fetch_assoc($current_user_circle));
                                        echo ", ".$crlnameh." ";
                                    }
                                    if($_SESSION['sess_power_id'] == 'CE')
                                    {
                                        echo '( '.$wingsname.' )';
                                    }
                                    $compliance_Pending_tot=0;
                                    $get_complience_sql=" select  COUNT(A.compliance_status) as Tot from pm_inspection_detail_history as A inner join pm_inspection_detail B on A.inspection_id=B.inspection_id  and  A.inspection_detail_id=B.inspection_detail_id ";
                                    $get_complience_sql.=" where B.forward_inspection_to_user=".$_SESSION['sess_user_id']." and A.compliance_status='N'";
                                    //echo $get_complience_sql; 
                                    $get_complience_res =pg_query($get_complience_sql);
                                    if(pg_num_rows($get_complience_res))
                                    {
                                    $compliance_Pending_tot=pg_fetch_assoc($get_complience_res);
                                    //print_r($compliance_Pending_tot['tot']);
                                    }
                                            //echo '<pre>';
                                            //exit;
                                       $get_remark_sql="select COUNT(pidh.is_satisfactory) as TotRemark from pm_inspection_detail_history as pidh";
                                       $get_remark_sql.=" inner join  pm_inspection_detail as pid on pid.inspection_id=pidh.inspection_id and pid.inspection_detail_id=pidh.inspection_detail_id";
                                     $get_remark_sql.=" where pidh.is_satisfactory='P' and pidh.compliance_status = 'Y'";
                                      //echo $get_complience_sql; 
                                    $get_remark_res =pg_query($get_remark_sql);
                                    if(pg_num_rows($get_remark_res))
                                    {
                                    $remark_Pending_tot=pg_fetch_assoc($get_remark_res);
                                    //print_r($remark_Pending_tot);
                                    }
                                    ?>                
                                &nbsp;|&nbsp;  <a class="adminlink" href="index.php?page=11">Logout</a>
                            </td>
                        </tr>
                    </table>
                </td>
                <td width="15" height="28" bgcolor="#323233">&nbsp;</td>
            </tr>
        </table>
    </td>
</tr>
<tr>
    <td height="1" colspan="0" bgcolor="#f5f9fc"><img src="images/spacer.gif" alt="WMS" width="1" height="1" /></td>
</tr>
<tr>
    <td colspan="0" bgcolor="#094979" id="header_td">
        <table width="100%" border="0" align="center" cellpadding="4" cellspacing="2">
            <tr>
                <td align="left" valign="top">
                    <img border="0" alt="Work Monitoring System" src="images/logo.jpg" style="margin-top: -6px; margin-left: -5px;">
                </td>
                <td align="left" valign="top">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td class="blu3b" align="center" valign="top" style="padding-top:0px; padding-bottom:0px;">&nbsp;
                            </td>
                            <td align="right" valign="top">
                                <div style="float:right;">
                                    <div style="margin-top: -55px;"><a href="index.php?page=217" class="back_link"><img src="images/back_icon.png" alt="" align="absmiddle" />Back to Home</a></div>
                                </div>
                            </td>
                        </tr>
                    </table>
                    <?
                        ?>
                </td>
            </tr>
            <tr>
                <td align="left" valign="top" height="1px;">
                </td>
            </tr>
        </table>
    </td>
</tr>
<?
    // Added 33 on 15042017 as client wants to show the header on dashboard also. if not required then remove 33
    if($page_title != "My Home33")
    {
      $page = $_GET['page'];
    ?>
<tr class="menu_bg">
    <td>
    <?php
    if($page == '192'){
    $menu = 'old';
}else{
    $menu = 'menu';
}
     ?>
        <div id="myjquerymenu" class="jquerycssmenu sticker <?php echo $menu ?>">
            <?php 
                if($powerh != '')
                {
                    $sql_user="select au.desg_id from pm_designation au where au.desg_value='".$powerh."'";
                    //echo $sql_user;
                    $res_login_userid=pg_query($sql_user);
                    $rec_login_usertypeid=pg_fetch_array($res_login_userid);
                    $desg_id=$rec_login_usertypeid['desg_id'];
                    //Get All Menu and Submenu Details of currently Loged in User','+replace(desg_id, ' ', '')+','
                    $menu_sql = "select rm.menu_id,me.menu_position from cm_role_menu rm inner join cm_menu_details me on me.menu_id=rm.menu_id where rm.user_desg_id='$desg_id' group by rm.menu_id,me.menu_position order by me.menu_position asc";
                    //echo $menu_sql;
                    $menu_res = pg_query($menu_sql);
                ?>          
            <ul>
            <li class="menulink"><a href="http://e-nirman.nic.in/index.php?page=217">Dashboard</a></li>
                <?php 
                    if(pg_num_rows($menu_res)>0)
                    {
                        $menuseq = 1;
                        while($menu_rows = pg_fetch_assoc($menu_res))
                        {//print_r($menu_rows);
                            $menuid=$menu_rows['menu_id'];
                            $sql_menuname=pg_query("select menu_name from cm_menu_details where menu_id='$menuid'");
                            $rec_menu_name=pg_fetch_array($sql_menuname);
                            $rec_menu_name['menu_name'];
                            $page_c = 0;
                            for($m = 1; $m < $total_page_no; $m ++)
                            {
                                if(md5($m) == $_GET['cp'])
                                {
                                    echo $page_c = $m;
                                    break;
                                }
                            }
                    
                            $sql2="select rm.sub_menu_id from cm_role_menu rm inner join cm_submenu_details me on me.menu_id=rm.menu_id and me.sub_menu_id=rm.sub_menu_id where rm.user_desg_id='$desg_id' and rm.menu_id=".$menu_rows['menu_id']." group by rm.sub_menu_id";
                            $res2=pg_query($sql2);
                            //get Submenu Details
                            /*$menu_select_sql = " SELECT menu_id AS menuid  FROM cm_submenu_details ";
                            $menu_select_sql.= " WHERE page_md5_no = '".$page_c."'";
                            //echo $menu_select_sql;
                            $menu_select_sql_res = pg_query($menu_select_sql);
                            @extract(pg_fetch_assoc($menu_select_sql_res));*/
                        
                          
                    
                    ?>
                <li class="<?=$menuseq?>">
                    <a href="#" class="menulink"><?php echo $rec_menu_name['menu_name'];?> </a>
                    <?php          if(pg_num_rows($res2)>0)
                        {
                            //echo $sub_menu_sql;
                        ?>
                    <ul>
                        <?
                            $submenuseq = 1;
                            while($sub_menu_rows = pg_fetch_assoc($res2))
                            {   
                                $sub_menuid=$sub_menu_rows['sub_menu_id'];
                                //get Submenu Details
                                $menu_select_sql = " SELECT sub_menu_name,page_md5_no FROM cm_submenu_details ";
                                $menu_select_sql.= " WHERE sub_menu_id = '".$sub_menuid."'";
                                //$menu_select_sql.= " WHERE sub_menu_id = '".$menu_rows['menu_id']."'";
                                //echo $menu_select_sql;
                                $menu_select_sql_res = pg_query($menu_select_sql);
                                @extract(pg_fetch_assoc($menu_select_sql_res));
                            ?>
                        <li class="submenuseq_<?=$submenuseq?>">
                            <a <?php echo isset($page_md5_no) && $page_md5_no!=''?'style="color:#000000;background-image: url(images/submenu_hover1.jpg);"':''?> href="index.php?page=<?php echo $page_md5_no; ?>">&raquo;&nbsp; <?php echo $sub_menu_name?></a>
                        </li>
                        <?
                        $submenuseq++;
                            }
                            ?>
                    </ul>
                    <?
                        }
                        ?>
                </li>
                <?
                $menuseq++;
                    }
                    }
                    }
                    ?> 
            </ul>
            <br style="clear: left" />
        </div>
    </td>
</tr>
<tr>
    <td height="17"  style="background-image: url(images/nav_shadow.jpg); background-repeat: repeat-x; background-position: top;"></td>
</tr>
<!--<tr>
    <td align="left" style="padding-top:2px;padding-bottom:10px;padding-right:10px" >
        <table cellpadding="0" cellspacing="0" align="left">
            <tr class="pagetitle">
                <td class="vlt3b">
                    <span style="float:left;padding-left:5px;padding-right:5px;padding-top:2px;padding-bottom:2px;"><?php echo $page_title?></span>
                </td>
            </tr>
        </table>
        <table cellpadding="0" cellspacing="0" align="right">
            <tr>
                <td class="vlt3b"><a class="lnblk2" href="#" onclick="javascript:hideHeader();">Show/Hide Header</a> </td>
            </tr>
        </table>
    </td>
    </tr>-->
<tr>
    <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td width="15" height="400" valign="top" bgcolor="#f5f9fc" style="background-image: url(images/content_bg.jpg); background-repeat: repeat-x; background-position: top;"><img src="images/spacer.gif" alt="WMS" width="15" height="1" /></td>
    <td width="971" valign="top" bgcolor="#f5f9fc" style="background-image: url(images/content_bg.jpg); background-repeat: repeat-x; background-position: top;">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td width="59%" height="38" class="cont_header"><?php echo $page_title?></td>
    <td width="41%" height="38" align="right"><a class="contlink" href="#" onclick="javascript:hideHeader();"></a></td>
</tr>
<?
    }
    ?>
    <script type="text/javascript">
// Create a clone of the menu, right next to original.
$('.menu').addClass('original').clone().insertAfter('.menu').addClass('cloned').css('position','fixed').css('top','0').css('margin-top','0').css('z-index','500').removeClass('original').hide();

scrollIntervalID = setInterval(stickIt, 10);


function stickIt() {

  var orgElementPos = $('.original').offset();
  orgElementTop = orgElementPos.top;               

  if ($(window).scrollTop() >= (orgElementTop)) {
    // scrolled past the original position; now only show the cloned, sticky element.

    // Cloned element should always have same left position and width as original element.     
    orgElement = $('.original');
    coordsOrgElement = orgElement.offset();
    leftOrgElement = coordsOrgElement.left;  
    widthOrgElement = orgElement.css('width');
    $('.cloned').css('left',leftOrgElement+'px').css('top',0).css('width',widthOrgElement).show();
    $('.original').css('visibility','hidden');
  } else {
    // not scrolled past the menu; only show the original menu.
    $('.cloned').hide();
    $('.original').css('visibility','visible');
  }
}
    </script>
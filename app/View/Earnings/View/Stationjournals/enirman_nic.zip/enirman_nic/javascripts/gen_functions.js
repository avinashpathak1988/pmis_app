var sitePath = 'http://'+window.location.host+'/enirman';
//alert(sitePath);
//var sitePath = 'http://192.168.1.110:8585/pms_v3_2013/';
//var sitePath = 'http://118.102.181.253/work/wmsv2/';
function writeFlash(swfPath, width, height)
{
	document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'+width+'" height="'+height+'" align="middle">\n');
	document.write('<param name="allowScriptAccess" value="sameDomain" />\n');
	document.write('<param name="movie" value="'+swfPath+'" />\n');
	document.write('<param name="quality" value="high" />\n');
	document.write('<param name="wmode" value="transparent" />\n');
	document.write('<param name="bgcolor" value="#00000" />\n');
	document.write('<embed src="'+swfPath+'" quality="high" bgcolor="#000000" width="'+width+'" height="'+height+'" wmode="transparent"\n');
	document.write('align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"\n');
	document.write('pluginspage="http://www.macromedia.com/go/getflashplayer" />\n');
	document.write('</object>');
}





 
 




function strTrim(tmpStr)
{
	tmpStr = tmpStr.replace(/^\s+/,"");//remove leading
	tmpStr = tmpStr.replace(/\s+$/,"");//remove trailing
	return tmpStr;
}
//------------------------------------------------------------------------------------
function trimFields()
{
	var obj = document.frmPMS;
	for(var i=0; i < obj.elements.length; i++)
	{
		if(obj.elements[i].type == "text" || obj.elements[i].type == "textarea" || obj.elements[i].type == "password")
		{
			obj.elements[i].value = strTrim(obj.elements[i].value);
		}
	}
}
//------------------------------------------------------------------------------------
function chkEmail(tmpStr)
{
	var email_pat = /^[a-z][a-z0-9_\.\-]*[a-z0-9]@[a-z0-9]+[a-z0-9\.\-_]*\.[a-z]+$/i;
	return(email_pat.test(tmpStr));
}

//Function to validate String
//-----------------------------------------------------------------------------------
function chkString(tmpStr)
{
	var str_pat = /^[a-z0-9_\.\-\'\/\,\?\s]*$/i;
	return(str_pat.test(tmpStr));
}
function chkAddress(tmpStr)
{
	var str_pat = /^[a-z0-9_\.\-\"\'\/\,\?\s]*$/i;
	return(str_pat.test(tmpStr));
}

//----------------------------
var r={  'notnumbers':/[^\d]/g }

function valid(o,w)
{
 	o.value = o.value.replace(r[w],'');
}

//------------------


//----------------------------
function validate(Value,name)
{
    /*
    var ValueArray = Value.split('-');
    var Length = ValueArray.length;
    var hypen = '';
    if(Length != 0 )
    {
        hypen = '-';
        var r = {'notnumbers':/[^\d]/g };
        w = 'notnumbers';
        var val1 = ValueArray[0].replace(r[w],'');
        if(Length == 2)
        {    
            var val2 = ValueArray[1].replace(r[w],'');
            var newVal = val1+'-'+val2;
        }
        else
        {
            var newVal = val1;
        }
        document.getElementById(name).value = newVal;
    }
    */
    var year1={  'notnumbers':/[^\d\-]/g }
    w = 'notnumbers';
    var Newvalues = Value.replace(year1[w],'');
    var temp = Newvalues.split("-");
    var counter = temp.length;
    if(counter >= 3) //donot allow multiple dots
    {
        Newvalues = temp[0]+'-'+temp[1];
    }
    document.getElementById(name).value = Newvalues;
    
}
var r1={  'notnumbers':/[^\d\.]/g }
function validRs(o,w)
{
 	var values = o.value.replace(r1[w],'');
    var temp = o.value.split(".");
    var counter = temp.length;
    if(counter >= 3) //donot allow multiple dots
    {
        values = temp[0]+'.'+temp[1];
    }
    o.value = values;
}

//------------------



//does not allow numeric in name
function chkName(tmpStr)
{
	var str_pat = /^[a-z\.\,\s\&\-()]*$/i;
	return(str_pat.test(tmpStr));
}
function chkState(tmpStr)
{
	var str_pat = /^[a-z\s]*$/i;
	return(str_pat.test(tmpStr));
}
//does not allow character in pin
function chkPin(tmpStr)
{
	var str_pat = /^[0-9\s]*$/i;
	return(str_pat.test(tmpStr));
}
function chkString1(tmpStr)
{       
	var str_pat = /^[a-z0-9_\s]*$/i;
	return(str_pat.test(tmpStr));
}
//Checks URL against pattern
function chkURL(tmpStr)
{
	var url_pat = /^(http|https|ftp):\/\/([\w-]+\.)+[\w-]+(\/[\w-\.\/?%&amp;,=#@\/:]*)?/;
	return(url_pat.test(tmpStr));
}

//Checks the Phone Number
function chkPhone(tmpStr)
{
	var str_pat = /^[a-z0-9]{3}-[a-z0-9]{3}-[a-z0-9]{4}$/i;
	return(str_pat.test(tmpStr));
}

function refreshCaptcha(imgid)
{
	var img = new Image();
	img.src = 'includes/captcha/captcha.php?hash='+parseInt(Math.random() * 10000000000);
	document.getElementById(imgid).src = img.src;
}
//-------------------------------------------------------------------------------------
function NewPopupWindow(pageName, width, height)
{
	window.open(pageName, '', 'width='+width+',height='+height+',toolbar=0,menubar=0,location=0,left=150,top=180,scrollbars=1');
}





function NewWindow(pageName)
{
	window.open(pageName, '', 'width=520,height=600,toolbar=0,menubar=0,location=0,left=0,top=0,scrollbars=1');
}

function printTimeLog(projectID)
{
	window.open('time_log_list.php?id='+projectID, '', 'width=800,height=450,left=200,scrollbars=1,top=50,toolbar=0,menubar=1,location=0');
}

//Opens a new window showing the uploaded image
function viewImage(imgFile)
{
	imgURL = imgFile;
	newWindow = window.open("","newWindow","titlebar=no,width=50,height=50,left=25,top=25");
	var doc = newWindow.document;
	doc.open();
	doc.write('<html>\n');
	doc.write('<head>\n');
	doc.write('<title>View Image</title>\n');
	doc.write('<meta http-equiv="imagetoolbar" content="no">\n');
	doc.write('</head>\n');
	doc.write('<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0" ondblclick="self.close();"  onblur="self.close();" onload="javascript:window.resizeTo(document.getElementById(\'theImage\').width + 10, document.getElementById(\'theImage\').height + 50)">\n');
	doc.write('<img src=\"'+imgURL+'\" alt=\"File: '+imgFile+'\n(Double Click to Close)\" border="0" name="theImage" id="theImage" />\n');
	doc.write('</body>\n');
	doc.write('</html>\n');
	newWindow.focus();
	doc.close();
}


//Right of string
function Right(str, n)
{
      if (n <= 0)
          return "";
      else if (n > String(str).length)
          return str;
      else
   {
          var iLen = String(str).length;
          return String(str).substring(iLen, iLen - n);
      }
}

//left of string
function Left(str, n)
{
   if (n <= 0)
         return "";
   else if (n > String(str).length)
         return str;
   else
         return String(str).substring(0,n);
}


function ltrim(str, chars){
	chars = chars || "\\s";
	return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
 
function rtrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}
function trim(str, chars) {
	return ltrim(rtrim(str, chars), chars);
}

//------------------------------------------------------------------//
//Generic AJAX object for all types of HTTP get/post work			//
//Usage:															//
//	var ajax = new AJAX();											//
//	var arrParam = new Array();										//
//	arrParam['name1'] = 'value1';									//
//	arrParam['name2'] = 'value2';									//
//	arrParam['name3'] = 'value3';									//
//	ajax.getRequest(url, arrParam, responseHandler);				//
//	OR																//
//	ajax.postRequest(url, arrParam, responseHandler);				//
//																	//
//	NOTE: You do not need to escape() or encodeURIComponent() the	//
//	parameter names or values. AJAX will do it on its own.			//
//	You need to define responseHandler() function that will handle	//
//	response back from the server, be it XML or anything else		//
//------------------------------------------------------------------//
//The AJAX object
function AJAX()
{
	//Private variables (properties)
	var __httpRequest = null;
	var __callbackFunc = null;

	//Private method: __createHttpRequest()
	var __createHttpRequest = function()
	{
		if(window.XMLHttpRequest) //Mozilla, Safari etc
		{
			__httpRequest = new XMLHttpRequest();
		}
		else if(window.ActiveXObject) //IE
		{
			try
			{
				__httpRequest = new ActiveXObject("MSXML2.XMLHTTP");
			}
			catch (e)
			{
				try
				{
					__httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
				}
				catch (e)
				{
					//Do whatever you need to do here
					alert("AJAX cannot be used with your browser!");
				}
			}
		}
	}
	//Private method: __createParameters(arr)
	var __createParameters = function(arr)
	{
		var parameters = ""; //Initialize
		for(x in arr)
		{
			var pName = encodeURIComponent(x);
			var pVal = encodeURIComponent(arr[x]);
			parameters = (parameters == "")?pName+'='+pVal:parameters+'&'+pName+'='+pVal;
		}
		return parameters;
	}

	//Private method: __handleResponse()
	var __handleResponse = function()
	{
		//if(__httpRequest.readyState == 1)
		//{
		//	__callbackFunc('<img src=images/ajax_process.gif> Loading.....');
		//}
		//else
		if(__httpRequest.readyState == 4)
		{
			__callbackFunc(__httpRequest.responseText);
		}
	}

	//Public method: getRequest(url, arrParam, callbackFunc)
	this.getRequest = function(url, arrParam, callbackFunc)
	{
		__createHttpRequest() //recreate ajax object to defeat cache problem in IE
		__callbackFunc = callbackFunc;
		if(__httpRequest)
		{
			var param = __createParameters(arrParam);
			__httpRequest.onreadystatechange = __handleResponse;
			//Include a random number to defeat IE cache problem
			__httpRequest.open('GET', url+"?ajaxhash="+Math.random()+'&'+param, true);
			__httpRequest.send(null)
		}
	}

	//Public method: postRequest()
	this.postRequest = function(url, arrParam, callbackFunc)
	{
		__createHttpRequest() //recreate ajax object to defeat cache problem in IE
		__callbackFunc = callbackFunc;
		if (__httpRequest)
		{
			var param = __createParameters(arrParam);
			alert(param);
			__httpRequest.onreadystatechange = __handleResponse;
			__httpRequest.open('POST', url, true);
			__httpRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
			__httpRequest.setRequestHeader("Content-length", param.length);
			__httpRequest.setRequestHeader("Connection", "close");
			__httpRequest.send(param);
		}
	}
}

function validateSearch()
{
	obj1.keywords.value = strTrim(obj1.keywords.value);
	if(obj1.keywords.value == '' || obj1.keywords.value == 'Enter your Keywords')
	{
		alert("Please enter your Keywords.");
		obj1.keywords.focus();
		return false;
	}
	obj1.action = "search_results.php";
	obj1.submit();
}


function validyearformat(textbox, e) {

         var charCode = (e.which) ? e.which : e.keyCode;
          if (charCode == 46 || charCode > 31 && charCode != 45  && (charCode < 48 || charCode > 57)){
				alert("Only Numbers Allowed");
        return false;
        }
    
     }



///**************************////////////////
///START FOR ALL LIGHT BOX CODE ONLY////////
///**************************////////////////
//>>>>>>>>>>>>>>>FOR Change Password Modal Box<<<<<<<<<<<<<<<<<<<<<<<
function changePassword(UID)
{
     //this part is called RTI/modalfiles/modal.js
    passwordwindow=dhtmlmodal.open('Password', 'iframe', 'modalfiles/change_password.php?id='+UID, 'Change Password', 'width=500px,height=300px,center=1,resize=0,scrolling=1');

} 

//>>>>>>>>>>>>>>>> FOR Show Addtional Cost Of Information<<<<<<<<<<<<<<
//Calling page title = Additional Charges Details(You can change here for required title)
function show_Cost_inf(UID)
{
    //this part is called RTI/modalfiles/modal.js
    passwordwindow=dhtmlmodal.open('Additional Charges', 'iframe', 'modalfiles/additional_charge_details.php?id='+UID, 'Additional Charges Details', 'width=500px,height=300px,center=1,resize=0,scrolling=1');

} 

//>>>>>>>>>>>>>>>> FOR Show manage_rule_cont[Rule[11]]<<<<<<<<<<<<<<
//Calling page title = manage_rule_11(You can change here for required title)
function manage_rule_cont()
{
    //this part is called RTI/modalfiles/modal.js
    passwordwindow=dhtmlmodal.open('manage_rule_11', 'iframe', 'modalfiles/manage_rule_11.php', 'Orissa RTI Rules', 'width=500px,height=300px,center=1,resize=0,scrolling=1');

}

//>>>>>>>>>>>>>>>> FOR Show manage_cash_rule_11[Rule[11]]<<<<<<<<<<<<<<
//Calling page title = manage_rule_11(You can change here for required title)
function manage_cash_rule()
{
    //this part is called RTI/modalfiles/modal.js
    passwordwindow=dhtmlmodal.open('manage_rule_11', 'iframe', 'modalfiles/manage_cash_rule_11.php', 'Orissa RTI Rules', 'width=500px,height=300px,center=1,resize=0,scrolling=1');

}
function showPreview()
{
    //this part is called RTI/modalfiles/modal.js
    passwordwindow=dhtmlmodal.open('Preview', 'iframe', 'modalfiles/online_e_filing_form_preview.php', 'Preview', 'width=800px,height=500px,center=1,resize=0,scrolling=1');

}
function caseTransfer(OID,RID)
{
    //this part is called RTI/modalfiles/modal.js
    casetransfer=dhtmlmodal.open('Transfer Case', 'iframe', 'modalfiles/manage_transfer_cases_select_pio.php?oid='+OID+'&rid='+RID, 'Transfer Case', 'width=350px,height=200px,center=1,resize=0,scrolling=1');

}
function caseDecline(OID,RID)
{
    //this part is called RTI/modalfiles/modal.js
    casetransfer=dhtmlmodal.open('Decline Case', 'iframe', 'modalfiles/manage_transfer_cases_decline.php?oid='+OID+'&rid='+RID, 'Decline Case', 'width=450px,height=200px,center=1,resize=0,scrolling=1');

}

////*************************************/////////////////////
///////////END FOR ALL LIGHT BOX CODE ONLY////////////////////
///*************************************/////////////////////

//-----------------------------------------------------------------------------------------------------------
function delete1(evt)
{
	var isOpera, isIE, isNav, isFox, isOther = false;
	if(navigator.userAgent.indexOf("Opera")!=-1) {
	isOpera = true;
	} else if(navigator.userAgent.indexOf("Firefox")!=-1) {
	isFox = true;
	} else if(navigator.appName == "Microsoft Internet Explorer") {
	isIE = true;
	} else if(navigator.appName == "Netscape") {
	isNav = true;
	} else {
	isOther = true;
	}
	
	if(isIE)
	{
		
		if(window.event.clientX < 0 && window.event.clientY < 0)
		{
			var ajax = new AJAX();
			var arrParam = new Array();
			ajax.getRequest('delete_session.php', arrParam, showResponseA);
			alert("Thank you for Visiting RTI CMM");
		}

	}
	else
	{
		 
		
		
		if(document.body.clientWidth <= 0 && document.body.clientHeight <= 0)	
		{      
			var ajax = new AJAX();
			var arrParam = new Array();
			ajax.getRequest('delete_session.php', arrParam, showResponseA);
			alert("Thank you for Visiting RTI CMM");

		}	
	}        
}

function showResponseA(retVal)
{	
}


//@@@@@@@@##########IMAGE MOUSE OVER SCRIPT HERE#############@@@@@@@@@@@@@@@@@@@@@@@@@@@
    var dom = (document.getElementById) ? true : false;
    var ns5 = (!document.all && dom || window.opera) ? true: false;
    var ie5 = ((navigator.userAgent.indexOf("MSIE")>-1) && dom) ? true : false;
    var ie4 = (document.all && !dom) ? true : false;
    var nodyn = (!ns5 && !ie4 && !ie5 && !dom) ? true : false;
    
    var origWidth, origHeight;
    
    // avoid error of passing event object in older browsers
    if (nodyn) { event = "nope" }
    
    ///////////////////////  CUSTOMIZE HERE   ////////////////////
    // settings for tooltip 
    // Do you want tip to move when mouse moves over link?
    var tipFollowMouse= true;   
    var tipWidth= 238;
    var offX= 20;   // how far from mouse to show tip
    var offY= 20; 
    var tipFontFamily= "Verdana, arial, helvetica, sans-serif";
    var tipFontSize= "10pt";
    var tipFontColor= "#D67307";
    var tipBgColor= "#DDECFF"; 
    var tipBorderColor= "#000080";
    var tipBorderWidth= 1;
    var tipBorderStyle= "ridge";
    var tipPadding= 3;
    
    
    var startStr = '<table width="' + tipWidth + '"><tr><td align="center" width="100%"><img src="';
    var midStr = '" border="0" width="230" height="230"></td></tr><tr><td>';
    var endStr = '</td></tr></table>';
    
    var tooltip, tipcss;
    function initTip() {
        if (nodyn) return;
        tooltip = (ie4)? document.all['tipDiv']: (ie5||ns5)? document.getElementById('tipDiv'): null;
        tipcss = tooltip.style;
        if (ie4||ie5||ns5) {    // ns4 would lose all this on rewrites
            tipcss.width = tipWidth+"px";
            tipcss.fontFamily = tipFontFamily;
            tipcss.fontSize = tipFontSize;
            tipcss.color = tipFontColor;
            tipcss.backgroundColor = tipBgColor;
            tipcss.borderColor = tipBorderColor;
            tipcss.borderWidth = tipBorderWidth+"px";
            tipcss.padding = tipPadding+"px";
            tipcss.borderStyle = tipBorderStyle;
        }
        if (tooltip&&tipFollowMouse) {
            document.onmousemove = trackMouse;
        }
    }
    
    window.onload = initTip;
    
    var t1,t2;  // for setTimeouts
    var tipOn = false;  // check if over tooltip link
    
    function doTooltip(evt,num,imgv,caption_img,app_name) 
    {
        var val_img="writereaddata/online_e_filing/"+imgv;
        var caption_img1=" Identity Proof (<span class='wht2b'>"+caption_img+"</span>) of "+app_name;
        //alert(val_img);
        
        if (!tooltip) return;
        if (t1) clearTimeout(t1);   if (t2) clearTimeout(t2);
        tipOn = true;
    
    
        // tooltip content goes here (image, description, optional bgColor, optional textcolor)
        var messages = new Array();
        messages[0] = new Array(val_img,caption_img1,"#000000");
        if (document.images) {
            var theImgs = new Array();
            for (var i=0; i<messages.length; i++) {
            theImgs[i] = new Image();
                theImgs[i].src = messages[i][0];
          }
        }

        // set colors if included in messages array
        if (messages[num][2])   var curBgColor = messages[num][2];
        else curBgColor = tipBgColor;
        if (messages[num][3])   var curFontColor = messages[num][3];
        else curFontColor = tipFontColor;
        if (ie4||ie5||ns5) {
            var tip = startStr + messages[num][0] + midStr + '<span style="font-family:' + tipFontFamily + '; font-size:' + tipFontSize + '; color:' + curFontColor + ';">' + messages[num][1] + '</span>' + endStr;
            tipcss.backgroundColor = curBgColor;
            tooltip.innerHTML = tip;
        }
        if (!tipFollowMouse) positionTip(evt);
        else t1=setTimeout("tipcss.visibility='visible'",100);
    }
    
    var mouseX, mouseY;
    function trackMouse(evt) {
        standardbody=(document.compatMode=="CSS1Compat")? document.documentElement : document.body //create reference to common "body" across doctypes
        mouseX = (ns5)? evt.pageX: window.event.clientX + standardbody.scrollLeft;
        mouseY = (ns5)? evt.pageY: window.event.clientY + standardbody.scrollTop;
        if (tipOn) positionTip(evt);
    }
    
    function positionTip(evt) {
        if (!tipFollowMouse) {
            standardbody=(document.compatMode=="CSS1Compat")? document.documentElement : document.body
            mouseX = (ns5)? evt.pageX: window.event.clientX + standardbody.scrollLeft;
            mouseY = (ns5)? evt.pageY: window.event.clientY + standardbody.scrollTop;
        }
        var tpWd = (ie4||ie5)? tooltip.clientWidth: tooltip.offsetWidth;
        var tpHt = (ie4||ie5)? tooltip.clientHeight: tooltip.offsetHeight;
        var winWd = (ns5)? window.innerWidth-20+window.pageXOffset: standardbody.clientWidth+standardbody.scrollLeft;
        var winHt = (ns5)? window.innerHeight-20+window.pageYOffset: standardbody.clientHeight+standardbody.scrollTop;
        if ((mouseX+offX+tpWd)>winWd) 
            tipcss.left = mouseX-(tpWd+offX)+"px";
        else tipcss.left = mouseX+offX+"px";
        if ((mouseY+offY+tpHt)>winHt) 
            tipcss.top = winHt-(tpHt+offY)+"px";
        else tipcss.top = mouseY+offY+"px";
        if (!tipFollowMouse) t1=setTimeout("tipcss.visibility='visible'",100);
    }
    
    function hideTip() {
        if (!tooltip) return;
        t2=setTimeout("tipcss.visibility='hidden'",100);
        tipOn = false;
    }    
    document.write('<div id="tipDiv" style="position:absolute; visibility:hidden; z-index:100"></div>')
    
//@@@@@@@@@@@@@@@##########END IMAGE MOUSE OVER#####################@@@@@@@@@@@@@@@@@@@@@@@

/*Blink Link function*/
function blinklink(ID)
{
	if(document.getElementById(ID))
	{
		if(!document.getElementById(ID).style.color)
		{
			document.getElementById(ID).style.color="deepskyblue";
		}
		if(document.getElementById(ID).style.color=="deepskyblue")
		{
			document.getElementById(ID).style.color="red";
		}
		else
		{
			document.getElementById(ID).style.color="deepskyblue";				
		}
	}
	timer=setTimeout("blinklink('"+ID+"')",500);
}

function blinknotification(ID)
{
	if(document.getElementById(ID))
	{
		if(!document.getElementById(ID).style.color)
		{
			document.getElementById(ID).style.color="white";
		}
		if(document.getElementById(ID).style.color=="white")
		{
			document.getElementById(ID).style.color="gray";
		}
		else
		{
			document.getElementById(ID).style.color="white";				
		}
	}
	timer=setTimeout("blinknotification('"+ID+"')",500);
}

function stoptimer()
{
	clearTimeout(timer);
}
/*End Blink Link function*/










//#########VALIDATION FOR NEGATIVE+DECIMAL+NUMBER FORMAT###########

	//### FUNCTION USE Test Case####
	/*
		Negative / 3 decimal places
		onblur="extractNumber(this,3,true);" onkeyup="extractNumber(this,3,true);" onkeypress="return blockNonNumbers(this, event, true, true);" 

		No negative / 2 decimal places
		onblur="extractNumber(this,2,false);" onkeyup="extractNumber(this,2,false);" onkeypress="return blockNonNumbers(this, event, true, false);" 

		Negative / No decimal places
		onblur="extractNumber(this,0,true);" onkeyup="extractNumber(this,0,true);" onkeypress="return blockNonNumbers(this, event, false, true);" 

		No negative / No decimal places
		onblur="extractNumber(this,0,false);" onkeyup="extractNumber(this,0,false);" onkeypress="return blockNonNumbers(this, event, false, false);" 

		No negative / Unlimited decimal places
		onblur="extractNumber(this,-1,false);" onkeyup="extractNumber(this,-1,false);" onkeypress="return blockNonNumbers(this, event, true, false);" 

	*/
	//### END#############

function extractNumber(obj, decimalPlaces, allowNegative)
{
	var temp = obj.value;
	// avoid changing things if already formatted correctly
	var reg0Str = '[0-9]*';
	if (decimalPlaces > 0) {
		reg0Str += '\\.?[0-9]{0,' + decimalPlaces + '}';
	} else if (decimalPlaces < 0) {
		reg0Str += '\\.?[0-9]*';
	}
	reg0Str = allowNegative ? '^-?' + reg0Str : '^' + reg0Str;
	reg0Str = reg0Str + '$';
	var reg0 = new RegExp(reg0Str);
	if (reg0.test(temp)) return true;

	// first replace all non numbers
	var reg1Str = '[^0-9' + (decimalPlaces != 0 ? '.' : '') + (allowNegative ? '-' : '') + ']';
	var reg1 = new RegExp(reg1Str, 'g');
	temp = temp.replace(reg1, '');

	if (allowNegative) {
		// replace extra negative
		var hasNegative = temp.length > 0 && temp.charAt(0) == '-';
		var reg2 = /-/g;
		temp = temp.replace(reg2, '');
		if (hasNegative) temp = '-' + temp;
	}
	
	if (decimalPlaces != 0) {
		var reg3 = /\./g;
		var reg3Array = reg3.exec(temp);
		if (reg3Array != null) {
			// keep only first occurrence of .
			//  and the number of places specified by decimalPlaces or the entire string if decimalPlaces < 0
			var reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
			reg3Right = reg3Right.replace(reg3, '');
			reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
			temp = temp.substring(0,reg3Array.index) + '.' + reg3Right;
		}
	}
	
	obj.value = temp;
}
function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}

//######### END VALIDATION FOR NEGATIVE+DECIMAL+NUMBER FORMAT###########


//FUNCTION START FOR COMMON SEARCH OPTION//
function getDivisionSearch(circleid)
{
	if(circleid != '')
	{
		var ajax = new AJAX();
		var arrParam = new Array();
		arrParam['circle_id'] = circleid;
		ajax.getRequest('./controller/get_division_report.php', arrParam, responseDivisionListSearch);
	}
	else
	{	
		document.getElementById('block_id').options[0].selected = true;
		document.getElementById('block_id').disabled = true;
	}
	
	resetSecData = '<select id="section_id" name="section_id" disabled="disabled">';
	resetSecData += '<option>--select section--</option>'; 
	resetSecData += '</select>';
	if(document.getElementById('sectiondivList'))
	{
		document.getElementById('sectiondivList1').innerHTML = resetSecData;
	}
	resetSecData = '<select id="sub_division_id" name="sub_division_id" disabled="disabled">';
	resetSecData += '<option>--select section--</option>'; 
	resetSecData += '</select>';
	if(document.getElementById('SubdivList'))
	{
		document.getElementById('SubdivList1').innerHTML = resetSecData;
	}	

}

function responseDivisionListSearch(retVaL)
{
	document.getElementById('division_list').innerHTML = retVaL;
	document.getElementById('block_id').options[0].selected = true;
	document.getElementById('block_id').disabled = true;
	
	resetSecData = '<select id="section_id" name="section_id" disabled="disabled">';
	resetSecData += '<option>--select section--</option>'; 
	resetSecData += '</select>';
	
	if(document.getElementById('sectiondivList'))
	{
		document.getElementById('sectiondivList').innerHTML = resetSecData;
	}
	
	resetSecData = '<select id="sub_division_id" name="sub_division_id" disabled="disabled">';
	resetSecData += '<option>--select section--</option>'; 
	resetSecData += '</select>';
	
	if(document.getElementById('SubdivList'))
	{
		document.getElementById('SubdivList').innerHTML = resetSecData;
	}	

	
}

function getBlockSearch(distid)
{
	if(distid != 0)
	{
		var ajax = new AJAX();
		var arrParam = new Array();
		arrParam['dist_id'] = distid;
		ajax.getRequest('./controller/get_block_report.php', arrParam, responseBlockListSearch);
	}
	else
	{	
		document.getElementById('block_id').options[0].selected = true;
		document.getElementById('block_id').disabled = true;
	}
}

function responseBlockListSearch(retVaL)
{
	document.getElementById('block_list').innerHTML = retVaL;
}



function getDistrictSearch(getDivId)
{
	if(getDivId != "")
	{
		
		var ajax = new AJAX();
		var arrParam = new Array();
		arrParam['district_id'] = getDivId;		
		ajax.getRequest('controller/get_district_report.php', arrParam, showResponseDistListSearch);	
	}
	else
	{
		
		document.getElementById('district_list').innerHTML ='';
	}

}
function showResponseDistListSearch(retVal)
{
	
	document.getElementById('district_list').innerHTML = '';
	document.getElementById('district_list').innerHTML = retVal;
}

function getDistbyCircleSearch(getCircleId)
{
	if(getCircleId != "")
	{
		
		var ajax = new AJAX();
		var arrParam = new Array();
		arrParam['circle_id'] = getCircleId;		
		ajax.getRequest('controller/get_district_by_circle_report.php', arrParam, showResponseDistbyCircleListSearch);	
	}
	else
	{
		
		document.getElementById('district_list').innerHTML ='';
	}

}
function showResponseDistbyCircleListSearch(retVal)
{
	
	document.getElementById('district_list').innerHTML = '';
	document.getElementById('district_list').innerHTML = retVal;
}

function showByCircleDistrict(divID, altDivID, firstID, secondID)
{
	document.getElementById(divID).style.display = 'block';
	document.getElementById(altDivID).style.display = 'none';
	document.getElementById(firstID).selectedIndex = 0;
	if(document.getElementById(secondID))
	{
		var selectbox = document.getElementById(secondID);
		removeAllOptions(selectbox)
	}
}
function removeAllOptions(selectbox)
{
	var i;
	for(i=selectbox.options.length-1;i>0;i--)
	{
		selectbox.remove(i);
	}
}
//FUNCTION END FOR COMMON SEARCH OPTION//

//FUNCTION END GET SHORT CODE?SCHEME ID//

function showShortCode(workId,type)
{
   	 if(type == 'sc')
	{
		var selectBox = document.getElementById('short_work_id');
		for (var i = 0; i < selectBox.options.length; i++) 
		{
		    if(selectBox.options[i].value == workId)
			selectBox.options[i].selected = true;
		}
	}
	/*
	if(type == 'si')
	{	
		var selectBox = document.getElementById('scheme_work_id');
		for (var i = 0; i < selectBox.options.length; i++) 
		{
		    if(selectBox.options[i].value == workId)
			selectBox.options[i].selected = true;
		}
		
	}
	*/
}
//FUNCTION END GET SHORT CODE?SCHEME ID//

//FUNCTION FOR TOOLTIP TIP WINDOW
function showTipwindow()
{	   
	$("a.tipImage").mouseover(function(){ 
		title = this.title;
		this.title ="";
		$("body").append("<div id='tooltipWindow'></div>");
        $("#tooltipWindow").html('');
		$("a.tipImage").mousemove(function(e){
			if(($(this).position().left)+216 < $(window).width())
			{
				$("#tooltipWindow").css('left',($(this).position().left)+16+'px');
				$("#tooltipWindow").css('top',$(this).position().top+'px');
				$("#tooltipWindow").show('slow');
            }
			else
			{
				 if($(window).width() <= 1224)
				 {
					$("#tooltipWindow").css('left',($(this).position().left)-216+'px');
					$("#tooltipWindow").css('top',$(this).position().top+'px');
					$("#tooltipWindow").show();
				 }
				 else
				 {
					$("#tooltipWindow").css('left',($(this).position().left)+16+'px');
					$("#tooltipWindow").css('top',$(this).position().top+'px');
					$("#tooltipWindow").show('slow');
				 }				
			}
		 });
		document.getElementById('tooltipWindow').innerHTML = title;
	});
	$("a.tipImage").mouseout(function(){ 
			this.title = title;
			$("#tooltipWindow").hide('fast');
            $("#tooltipWindow").html('');				   
	});
}

function show_work_info(workName,shortWorkName)
{
    $(".hyperlink3").mousemove(function(e){
			$("#work_info").html(workName+"<br><br>"+'<span class=blu2b >Project Code :</span> '+" "+shortWorkName);
            if(($(this).position().left)+450 < $(window).width())
			{
				$("#work_info").css('left',($(this).position().left)+250+'px');
				$("#work_info").css('top',$(this).position().top+'px');
				$("#work_info").show('slow');
            }
			else
			{
				 if($(window).width() <= 1224)
				 {
					$("#work_info").css('left',($(this).position().left)-450+'px');
					$("#work_info").css('top',$(this).position().top+'px');
					$("#work_info").show();
				 }
				 else
				 {
					$("#work_info").css('left',($(this).position().left)+250+'px');
					$("#work_info").css('top',$(this).position().top+'px');
					$("#work_info").show('slow');
				 }				
			}
		 });
}
function hide_work_info()
{
    document.getElementById('work_info').style.display = 'none';
}


//FUNCTION FOR HIDE HEADER
function hideHeader()
{
	var headerTD = document.getElementById('header_td');
	if(headerTD.style.display == 'none')
		headerTD.style.display = 'block';
	else if(headerTD.style.display == 'block')
		headerTD.style.display = 'none';
	else
		headerTD.style.display = 'block';
	//alert(headerTD.style.display);
	setCookie(headerTD.style.display);
}
function showHideHeader()
{
	var hideheader = get_cookie ( "hideheader" );
	var headerTD = document.getElementById('header_td');
	if(hideheader == 'none')
		headerTD.style.display = 'none';
	else if(hideheader == 'block')
		headerTD.style.display = 'block';
	//alert(headerTD.style.display);
}
window.onload=function(){
showHideHeader();
}
//$(document).ready(showHideHeader);
function delete_cookie ( cookie_name )
{
  var cookie_date = new Date ( );  // current date & time
  cookie_date.setTime ( cookie_date.getTime() - 1 );
  document.cookie = cookie_name += "=; expires=" + cookie_date.toGMTString();
}
function get_cookie ( cookie_name )
{
  var results = document.cookie.match ( '(^|;) ?' + cookie_name + '=([^;]*)(;|$)' );

  if ( results )
    return ( unescape ( results[2] ) );
  else
    return null;
}
function setCookie(headerTD)
{
	var hideheader = headerTD;
	if ( hideheader )
	{
		var current_date = new Date;
		var cookie_year = current_date.getFullYear ( ) + 1;
		var cookie_month = current_date.getMonth ( );
		var cookie_day = current_date.getDate ( );
		set_cookie ( "hideheader", hideheader, cookie_year, cookie_month, cookie_day );
	}
}
function set_cookie ( name, value, exp_y, exp_m, exp_d, path, domain, secure )
{
  var cookie_string = name + "=" + escape ( value );

  if ( exp_y )
  {
    var expires = new Date ( exp_y, exp_m, exp_d );
    cookie_string += "; expires=" + expires.toGMTString();
  }

  if ( path )
        cookie_string += "; path=" + escape ( path );

  if ( domain )
        cookie_string += "; domain=" + escape ( domain );
  
  if ( secure )
        cookie_string += "; secure";
  
  document.cookie = cookie_string;
}
//FUNCTION FOR HIDE HEADER
/*Blink Link function*/
function blinklink(str)
{
	//alert("str");
	if(document.getElementById(str))
	{
		if(!document.getElementById(str).style.color)
		{
			document.getElementById(str).style.color="darkgray";
		}
		if(document.getElementById(str).style.color=="darkgray")
		{
			document.getElementById(str).style.color="red";
		}
		else
		{
			document.getElementById(str).style.color="darkgray";
		}
		timer=setTimeout("blinklink('"+str+"')",500);
	}
}
function stoptimer()
{
	clearTimeout(timer);
}
/*Blink Link function*/

/*get job code*/
function getJobcode(workid)
{
        //alert(workid);
	var ajax = new AJAX();
	var arrParam = new Array();
	arrParam['workid'] = workid;
	ajax.getRequest('./controller/get_job_code.php', arrParam, responseJobCode);
}
function responseJobCode(retVaL)
{
	//alert(retVal);
    if(document.getElementById('div_job_code'))
	   document.getElementById('div_job_code').innerHTML = retVaL;

}
/*get job code*/

function extractNumber(obj, decimalPlaces, allowNegative)
{
	var temp = obj.value;
	// avoid changing things if already formatted correctly
	var reg0Str = '[0-9]*';
	if (decimalPlaces > 0) {
		reg0Str += '\\.?[0-9]{0,' + decimalPlaces + '}';
	} else if (decimalPlaces < 0) {
		reg0Str += '\\.?[0-9]*';
	}
	reg0Str = allowNegative ? '^-?' + reg0Str : '^' + reg0Str;
	reg0Str = reg0Str + '$';
	var reg0 = new RegExp(reg0Str);
	if (reg0.test(temp)) return true;

	// first replace all non numbers
	var reg1Str = '[^0-9' + (decimalPlaces != 0 ? '.' : '') + (allowNegative ? '-' : '') + ']';
	var reg1 = new RegExp(reg1Str, 'g');
	temp = temp.replace(reg1, '');

	if (allowNegative) {
		// replace extra negative
		var hasNegative = temp.length > 0 && temp.charAt(0) == '-';
		var reg2 = /-/g;
		temp = temp.replace(reg2, '');
		if (hasNegative) temp = '-' + temp;
	}
	
	if (decimalPlaces != 0) {
		var reg3 = /\./g;
		var reg3Array = reg3.exec(temp);
		if (reg3Array != null) {
			// keep only first occurrence of .
			//  and the number of places specified by decimalPlaces or the entire string if decimalPlaces < 0
			var reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
			reg3Right = reg3Right.replace(reg3, '');
			reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
			temp = temp.substring(0,reg3Array.index) + '.' + reg3Right;
		}
	}
	
	obj.value = temp;
}
function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	var key;
	var isCtrl = false;
	var keychar;
	var reg;
		
	if(window.event) {
		key = e.keyCode;
		isCtrl = window.event.ctrlKey
	}
	else if(e.which) {
		key = e.which;
		isCtrl = e.ctrlKey;
	}
	
	if (isNaN(key)) return true;
	
	keychar = String.fromCharCode(key);
	
	// check for backspace or delete, or if Ctrl was pressed
	if (key == 8 || isCtrl)
	{
		return true;
	}

	reg = /\d/;
	var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
	var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
	
	return isFirstN || isFirstD || reg.test(keychar);
}

//######### END VALIDATION FOR NEGATIVE+DECIMAL+NUMBER FORMAT###########


//#### FUNCTION FOR ALL REPORT PAGES #######//

function enableUpdateComponent()
{
	if(document.getElementById('report_page'))
	{
		var length = document.frmPMS.elements.length;
		var i;
		for(i=0;i<(length-1);i++)
		{
			if(document.frmPMS.elements[i].type == 'checkbox' && document.frmPMS.elements[i].disabled == true)
			{
				var idIs = document.frmPMS.elements[i].getAttribute('id');
				var valIs = document.getElementById(idIs).value;
				document.getElementById(idIs).disabled = false;
			}
		}
	}
}







function checkWorkIdReport(SelectedName)
{
  if(SelectedName != '')
  {
   	var component = enableUpdateComponent();
    document.getElementById('processImg').style.display = "block";
    var ajax = new AJAX();
    var arrParam = new Array();
    arrParam['work_name'] = SelectedName;
    ajax.getRequest('./controller/get_work_id_details.php', arrParam, responseWorkIdDetailsReport);
  }
}
function responseWorkIdDetailsReport(retVaLid)
{
    document.getElementById('processImg').style.display = "none";
    document.getElementById('work_id_detail').value = retVaLid;
    if(retVaLid != '')
    {
        var mm = document.getElementById('work_id_detail').value;
        getShortCodeReport(retVaLid);
        //document.getElementById('short_code').focus();
       /*
       var schemeLength = document.getElementById('scheme_work_id').options.length;
        var i;
        for(i=0;i<schemeLength;i++)
        {
            if(document.getElementById('scheme_work_id').options[i].value == retVaLid)
            {
                document.getElementById('scheme_work_id').selectedIndex = i;    
            }
        }
        */
        var shortworkLength = document.getElementById('short_work_id').options.length;
        var i;
        for(i=0;i<shortworkLength;i++)
        {
            if(document.getElementById('short_work_id').options[i].value == retVaLid)
            {
                document.getElementById('short_work_id').selectedIndex = i;    
            }
        } 
        
        getJobcode(retVaLid); 
        if(document.getElementById('division_id'))
        {
       		 getallotedDiv(retVaLid);
       	}
    }
    else
    {
    	document.getElementById('short_code').value = '';
    	document.getElementById('shortcode').value = ''; 
        //document.getElementById('scheme_work_id').selectedIndex = 0;
        document.getElementById('short_work_id').selectedIndex = 0;      
    }
}

function getShortCodeReport(workid)
{
  //alert(workid);
  if(workid != 0)
  {
    var ajax = new AJAX();
    var arrParam = new Array();
    arrParam['workid'] = workid;
    ajax.getRequest('./controller/get_short_work_details.php', arrParam, responseShortcodeDetails);
  }
}
function responseShortcodeDetails(retVaLshort)
{
	
	document.getElementById('short_code').value = retVaLshort;
	document.getElementById('shortcode').value = retVaLshort;

}
/////////################////////
function checkWorkId1(Selectedshortcode)
{
    if(Selectedshortcode != '')
    {  
    	var component = enableUpdateComponent();
        document.getElementById('processImg').style.display = "block";
        var ajax = new AJAX();
        var arrParam = new Array();
        arrParam['shortcode'] = Selectedshortcode;
        ajax.getRequest('./controller/get_work_name_details.php', arrParam, responseWorkIdDetails1);
    }
}

function responseWorkIdDetails1(retVaLid1)
{
    document.getElementById('processImg').style.display = "none";
    document.getElementById('work_id_detail').value = retVaLid1;
    var mm = document.getElementById('work_id_detail').value;
    getWorknameReport(retVaLid1);
    if(retVaLid1 != '')
    {
        //document.getElementById('road_name').focus();
       /*
        var schemeLength = document.getElementById('scheme_work_id').options.length;
        var i;
        for(i=0;i<schemeLength;i++)
        {
            if(document.getElementById('scheme_work_id').options[i].value == retVaLid1)
            {
                document.getElementById('scheme_work_id').selectedIndex = i;    
            }
        }   
        */
        var shortworkLength = document.getElementById('short_work_id').options.length;
        var i;
        for(i=0;i<shortworkLength;i++)
        {
            if(document.getElementById('short_work_id').options[i].value == retVaLid1)
            {
                document.getElementById('short_work_id').selectedIndex = i;    
            }
        }
        getJobcode(retVaLid1);
        if(document.getElementById('division_id'))
        {

	        getallotedDiv(retVaLid1);
	}
    }
    else
    {
    	document.getElementById('road_name').value = '';
        //document.getElementById('scheme_work_id').selectedIndex = 0;
        document.getElementById('short_work_id').selectedIndex = 0;      
    }
    
}
function getWorknameReport(workid)
{
  //alert(workid);
  if(workid != 0)
  {
    var ajax = new AJAX();
    var arrParam = new Array();
    arrParam['workid'] = workid;
    ajax.getRequest('./controller/get_work_name_by_workid.php', arrParam, responseworknameDetails1);
  }
}
function responseworknameDetails1(retVaLwork)
{
	
	document.getElementById('road_name').value = retVaLwork;

}
function getallotedDiv(work_id)
{
	if(work_id != 0)
	{
		var ajax = new AJAX();
		var arrParam = new Array();
		arrParam['work_id'] = work_id;
		ajax.getRequest('./controller/get_allotted_div_by_work_id.php', arrParam, responseDivList);
	}
	else
	{	
		document.getElementById('division_id').options[0].selected = true;
		document.getElementById('division_id').disabled = true;
	}
}
function responseDivList(retVaL)
{
	if(document.getElementById('alloted_list'))
    document.getElementById('alloted_list').innerHTML = retVaL;
}

//Function to convert first letter to uppercase
function upper_case(string_char){
    string_char = string_char.toLowerCase();
    var first_capital_letter=string_char.charAt(0).toUpperCase() + string_char.substr(1);                        
    return first_capital_letter;
}
function swapImage(imageSrc)
{
    //alert(imageSrc);
    if(imageSrc == sitePath+'images/arrow_down.gif')
    {
        document.getElementById('imageID').setAttribute('src', sitePath+'images/arrow_up.gif');
        return false;
    }
    if(imageSrc == sitePath+'images/arrow_up.gif')
    {
        document.getElementById('imageID').setAttribute('src', sitePath+'images/arrow_down.gif');
        return false;
    }
    
}

function isDate(txtDate)
{
  var currVal = txtDate;
  if(currVal == '')
    return false;
  
  //Declare Regex  
  var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; 
  var dtArray = currVal.match(rxDatePattern); // is format OK?

  if (dtArray == null)
     return false;
 
	//Checks for dd/mm/yyyy format.
    dtDay = dtArray[1];
    dtMonth= dtArray[3];
    dtYear = dtArray[5];   

  if (dtMonth < 1 || dtMonth > 12)
      return false;
  else if (dtDay < 1 || dtDay> 31)
      return false;
  else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31)
      return false;
  else if (dtMonth == 2)
  {
     var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
     if (dtDay> 29 || (dtDay ==29 && !isleap))
          return false;
  }
  return true;
}




//******************************************** FLOATING HEADER START ***********************************************************
//if you want to add another floating header just replace FloatingHeader to FloatingHeaderContractor

//change the function name to CommonUpdateTableHeaders to CommonUpdateTableHeadersContarctor

//chage getFloatingHeadreCall to getFloatingHeadreCallContractor

function CommonUpdateTableHeaders() {
	$("div.divTableWithFloatingHeader").each(function() {
		var originalHeaderRow = $(".tableFloatingHeaderOriginal", this);
		var floatingHeaderRow = $(".tableFloatingHeader", this);
		var offset = $(this).offset();
		var scrollTop = $(window).scrollTop();
		if ((scrollTop > offset.top) && (scrollTop < offset.top + $(this).height())) {
			floatingHeaderRow.css("visibility", "visible");
			floatingHeaderRow.css("top", Math.min(scrollTop - offset.top, $(this).height() - floatingHeaderRow.height()) + "px");

			// Copy cell widths from original header
			$("th", floatingHeaderRow).each(function(index) {
				var cellWidth = $("th", originalHeaderRow).eq(index).css('width');
				$(this).css('width', cellWidth);
			});

			// Copy row width from whole table
			floatingHeaderRow.css("width", $(this).css("width"));
		}
		else {
			floatingHeaderRow.css("visibility", "hidden");
			floatingHeaderRow.css("top", "0px");
		}
	});
}


function getFloatingHeadreCall(){
	$("table.tableWithFloatingHeader").each(function() {
		$(this).wrap("<div class=\"divTableWithFloatingHeader\" style=\"position:relative\"></div>");

		var originalHeaderRow = $("tr:first", this)
		originalHeaderRow.before(originalHeaderRow.clone());
		var clonedHeaderRow = $("tr:first", this)

		clonedHeaderRow.addClass("tableFloatingHeader");
		clonedHeaderRow.css("position", "absolute");
		clonedHeaderRow.css("top", "0px");
		clonedHeaderRow.css("left", $(this).css("margin-left"));
		clonedHeaderRow.css("visibility", "hidden");

		originalHeaderRow.addClass("tableFloatingHeaderOriginal");
	});
	CommonUpdateTableHeaders();
	$(window).scroll(CommonUpdateTableHeaders);
	$(window).resize(CommonUpdateTableHeaders);			
}
//******************************************** FLOATING HEADER END ***********************************************************




//******************************************** FLOATING HEADER START  CONTRACTOR***********************************************************
function CommonUpdateTableHeadersContractor() {
	$("div.divTableWithFloatingHeaderContractor").each(function() {
		var originalHeaderRow = $(".tableFloatingHeaderContractorOriginal", this);
		var floatingHeaderRow = $(".tableFloatingHeaderContractor", this);
		var offset = $(this).offset();
		var scrollTop = $(window).scrollTop();
		if ((scrollTop > offset.top) && (scrollTop < offset.top + $(this).height())) {
			floatingHeaderRow.css("visibility", "visible");
			floatingHeaderRow.css("top", Math.min(scrollTop - offset.top, $(this).height() - floatingHeaderRow.height()) + "px");

			// Copy cell widths from original header
			$("th", floatingHeaderRow).each(function(index) {
				var cellWidth = $("th", originalHeaderRow).eq(index).css('width');
				$(this).css('width', cellWidth);
			});

			// Copy row width from whole table
			floatingHeaderRow.css("width", $(this).css("width"));
		}
		else {
			floatingHeaderRow.css("visibility", "hidden");
			floatingHeaderRow.css("top", "0px");
		}
	});
}


function getFloatingHeadreConractorCall(){
	$("table.tableWithFloatingHeaderContractor").each(function() {
		$(this).wrap("<div class=\"divTableWithFloatingHeaderContractor\" style=\"position:relative\"></div>");

		var originalHeaderRow = $("tr:first", this)
		originalHeaderRow.before(originalHeaderRow.clone());
		var clonedHeaderRow = $("tr:first", this)

		clonedHeaderRow.addClass("tableFloatingHeaderContractor");
		clonedHeaderRow.css("position", "absolute");
		clonedHeaderRow.css("top", "0px");
		clonedHeaderRow.css("left", $(this).css("margin-left"));
		clonedHeaderRow.css("visibility", "hidden");

		originalHeaderRow.addClass("tableFloatingHeaderContractorOriginal");
	});
	CommonUpdateTableHeadersContractor();
	$(window).scroll(CommonUpdateTableHeadersContractor);
	$(window).resize(CommonUpdateTableHeadersContractor);			
}
//******************************************** FLOATING HEADER START  CONTRACTOR ***********************************************************


//******************************************** FLOATING HEADER START FOR ISSUE SECTION ***********************************************************
//if you want to add another floating header just replace FloatingHeaderIssue to FloatingHeaderIssueContractor

function CommonUpdateTableHeadersIssue() {
	$("div.divTableWithFloatingHeaderIssue").each(function() {
		var originalHeaderRow = $(".tableFloatingHeaderIssueOriginal", this);
		var FloatingHeaderIssueRow = $(".tableFloatingHeaderIssue", this);
		var offset = $(this).offset();
		var scrollTop = $(window).scrollTop();
		if ((scrollTop > offset.top) && (scrollTop < offset.top + $(this).height())) {
			FloatingHeaderIssueRow.css("visibility", "visible");
			FloatingHeaderIssueRow.css("top", Math.min(scrollTop - offset.top, $(this).height() - FloatingHeaderIssueRow.height()) + "px");

			// Copy cell widths from original header
			$("th", FloatingHeaderIssueRow).each(function(index) {
				var cellWidth = $("th", originalHeaderRow).eq(index).css('width');
				$(this).css('width', cellWidth);
			});

			// Copy row width from whole table
			FloatingHeaderIssueRow.css("width", $(this).css("width"));
		}
		else {
			FloatingHeaderIssueRow.css("visibility", "hidden");
			FloatingHeaderIssueRow.css("top", "0px");
		}
	});
}


function getFloatingHeadreCallIssue(){
	$("table.tableWithFloatingHeaderIssue").each(function() {
		$(this).wrap("<div class=\"divTableWithFloatingHeaderIssue\" style=\"position:relative\"></div>");

		var originalHeaderRow = $("tr:first", this)
		originalHeaderRow.before(originalHeaderRow.clone());
		var clonedHeaderRow = $("tr:first", this)

		clonedHeaderRow.addClass("tableFloatingHeaderIssue");
		clonedHeaderRow.css("position", "absolute");
		clonedHeaderRow.css("top", "0px");
		clonedHeaderRow.css("left", $(this).css("margin-left"));
		clonedHeaderRow.css("visibility", "hidden");

		originalHeaderRow.addClass("tableFloatingHeaderIssueOriginal");
	});
	CommonUpdateTableHeadersIssue();
	$(window).scroll(CommonUpdateTableHeadersIssue);
	$(window).resize(CommonUpdateTableHeadersIssue);			
}
//******************************************** FLOATING HEADER END FOR ISSUE SECTION  ***********************************************************





















//************************************************** javascript cut from admin home page *****************//
function getConWorkDetail(conid,pid){
	var conid = conid;
	NewPopupWindow('index.php?page=219&conid='+conid+'&pid='+pid, 1000, 1000);
}


function getFinancialdetail(wid){//alert(1);
	if(wid != 0)	
	{
		document.getElementById('wid').value = wid;
		$.blockUI({ message: "<h1>Please Wait...</h1>" });
		var workdiv = "financial_div_"+wid;
		 var breakupdiv = "breakup_div_"+wid;
		 var prevbreakupdiv = "prev_breakup_div_"+wid;
		   document.getElementById(breakupdiv).innerHTML = '';
		   document.getElementById(prevbreakupdiv).innerHTML = '';
		if(document.getElementById(workdiv).style.display == 'block'){
			document.getElementById(workdiv).style.display = 'none';
			$.unblockUI();
		}else{
			document.getElementById(workdiv).style.display = 'block';
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['wid'] = wid;
			ajax.getRequest('./controller/get_financial_detail.php', arrParam, showResponsefinanciall);				
		}
	}

}
function showResponsefinanciall(retVaL)
{
  $.unblockUI();	
  var wid     =  document.getElementById('wid').value;
  var workdiv = "financial_div_"+wid; 
  document.getElementById(workdiv).innerHTML = retVaL;
}



function getPrevBreakupDetail(wid,prvyr){//alert(2);
	if(wid != 0)	
	{
		$.blockUI({ message: "<h1>Please Wait...</h1>" });
		document.getElementById('wid').value = wid;
		var workdiv = "prev_breakup_div_"+wid;
		if(document.getElementById(workdiv).style.display == 'block'){
			document.getElementById(workdiv).style.display = 'none';
			 $.unblockUI();
		}else{
			document.getElementById(workdiv).style.display = 'block';
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['wid'] = wid;
			arrParam['prvyr'] = prvyr;
			ajax.getRequest('./controller/prev_get_breakup_detail.php', arrParam, showResponsePrevBreakup);				
		}
	}
}
function getBreakupDetail2(page,wid,aid,action){
	//alert(action);
	if(wid != 0)	
	{

       //$.blockUI({ message: "<h1>Please Wait...</h1>" });
		document.getElementById('wid').value = wid;
		var workdiv = "breakup_div_"+wid;
		if(document.getElementById(workdiv).style.display == 'block'){
			document.getElementById(workdiv).style.display = 'none';
		}else{
			document.getElementById(workdiv).style.display = 'block';
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['wid'] = wid;
			arrParam['year'] = action;
			ajax.getRequest('./controller/get_breakup_detail.php', arrParam, showResponseBreakup);				
		}
	}
}
  function showPopUpDiv(page,wid,aid,action)
  {
  	alert("page-"+page+"wid-"+wid+"aid-"+aid+"action-"+action);
    $("#mainDiv").hide();
        $("#exeFrame").attr('src','index.php?page='+page+'&wid='+wid+'&aid='+aid+'&action='+action);
        var heightDiv = $(window).height() - 125;
        $("#exeFrame").attr('height',heightDiv + 'px');
        $(document).ready(function() {
       /*$.blockUI({
            message: $('#mainDiv'),
            fadeIn: 700,
            fadeOut: 700,
            css: { top: '4%',

                    border: '4px solid #525252',
                  width:'900px',
                  height:'650px',
                    '-webkit-border-radius': '10px',
                    '-moz-border-radius': '10px',
                    left: ($(window).width() - 900) /2 + 'px',
                    height:($(window).height() - 80) + 'px'
                }
            });*/
        });
    
  


        /*
        document.getElementById('bgDiv').style.display = 'block';
    if (typeof window.innerWidth != 'undefined')
    {
      viewportwidth = window.innerWidth,
      viewportheight = window.innerHeight
    }
    else if (typeof document.documentElement != 'undefined' && typeof document.documentElement.clientWidth !='undefined' && document.documentElementclientWidth != 0)
    {
      viewportwidth = document.documentElement.clientWidth,
      viewportheight = document.documentElement.clientHeight
    }
    else
    {
      viewportwidth = document.getElementsByTagName('body')[0].clientWidth,
      viewportheight = document.getElementsByTagName('body')[0].clientHeight
    }

    var windowWidth =  viewportwidth;
    var windowHeight= viewportheight;
    //alert(windowWidth);
    //var tempHeight,tempWidth;

    //var windowWidth = $(document).width();
    //var windowHeight = $(document).height();
    var mainDivWidth = parseInt((windowWidth-900)/2);
    var mainDivHeight = parseInt(windowHeight/6);

    //alert(mainDivWidth);

    document.getElementById('bgDiv').style.width = windowWidth+'px';
    document.getElementById('bgDiv').style.height = windowHeight+'px';


    document.getElementById('mainDiv').style.left = mainDivWidth+'px';
    document.getElementById('mainDiv').style.top = '100px';
    //document.getElementById('mainDiv').style.display = 'block';
      $("#exeFrame").attr('src','index.php?cp='+page+'&pid='+pid+'&aid='+aid);
      //$("#mainDiv").fadeIn(1500);
        $("#mainDiv").animate({height:'toggle'},1500);
        */
  }
function showResponsePrevBreakup(retVaL){
	 $.unblockUI();
	var wid     =  document.getElementById('wid').value;
	var workdiv = "prev_breakup_div_"+wid;
	document.getElementById(workdiv).innerHTML = retVaL;
}





function getBreakupDetail(wid){
	//alert('byy');
	if(wid != 0)	
	{
		$.blockUI({ message: "<h1>Please Wait...</h1>" });
		document.getElementById('wid').value = wid;
		var workdiv = "breakup_div_"+wid;
		if(document.getElementById(workdiv).style.display == 'block'){
			document.getElementById(workdiv).style.display = 'none';
			$.unblockUI();
		}else{
			document.getElementById(workdiv).style.display = 'block';
			var ajax = new AJAX();
			var arrParam = new Array();
			arrParam['wid'] = wid;
			ajax.getRequest('./controller/get_breakup_detail.php', arrParam, showResponseBreakup);				
		}
	}
}
function showResponseBreakup(retVaL){
	$.unblockUI();
	var wid     =  document.getElementById('wid').value;
	var workdiv = "breakup_div_"+wid;
	document.getElementById(workdiv).innerHTML = retVaL;
}




//************************************************** javascript cut from admin home page *****************//
